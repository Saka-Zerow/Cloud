@echo off
setlocal enabledelayedexpansion

echo ===================================================
echo   SCRAPPER CLEANUP UTILITY (Windows)
echo ===================================================

cd /d "%~dp0"

echo [*] Membersihkan build artifacts & executables...
del /f /q /a *.exe 2>nul
del /f /q /a *.exe~ 2>nul
del /f /q /a *.test 2>nul
del /f /q /a *.test.exe 2>nul
del /f /q /a src\*.exe 2>nul
del /f /q /a src\*.test 2>nul
del /f /q /a src\*.test.exe 2>nul

echo [*] Membersihkan output scraping & temporary files...
del /f /q /a Scrapper-*.txt 2>nul
del /f /q /a out_*.txt 2>nul
del /f /q /a *.clean.txt 2>nul
del /f /q /a *.junk.txt 2>nul
del /f /q /a *.tmp 2>nul
del /f /q /a *~ 2>nul
del /f /q /a *.bak 2>nul
del /f /q /a *.log 2>nul
del /f /q /a debug_*.json 2>nul
del /f /q /a coverage.out 2>nul
del /f /q /a coverage.html 2>nul
del /f /q /a profile.out 2>nul

echo [*] Mengosongkan direktori results...
if exist results (
    del /f /q /a results\* 2>nul
    for /d %%p in (results\*) do rmdir /s /q "%%p" 2>nul
) else (
    mkdir results
)

where go >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo [*] Menjalankan go clean...
    go clean -cache -testcache 2>nul
)

echo.
echo [V] Cleanup selesai! Proyek telah bersih seperti sebelum di-build dan digunakan.
echo ===================================================
pause
