# Scrapper Cleanup Script for Windows (PowerShell)
[CmdletBinding()]
param()

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

Write-Host "===================================================" -ForegroundColor Cyan
Write-Host "   SCRAPPER CLEANUP UTILITY (PowerShell)" -ForegroundColor Cyan
Write-Host "===================================================" -ForegroundColor Cyan

# 1. Build artifacts & binaries
Write-Host "[*] Membersihkan binary & executable..." -ForegroundColor Yellow
$binPatterns = @("*.exe", "*.exe~", "*.test", "*.test.exe", "src/*.exe", "src/*.test", "src/*.test.exe")
foreach ($pat in $binPatterns) {
    Get-ChildItem -Path $pat -File -Force -ErrorAction SilentlyContinue | ForEach-Object {
        Write-Host "  [-] Menghapus: $($_.Name)" -ForegroundColor DarkGray
        Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue
    }
}

# 2. Output and runtime files
Write-Host "[*] Membersihkan output scraping & temporary files..." -ForegroundColor Yellow
$tempPatterns = @("Scrapper-*.txt", "out_*.txt", "*.clean.txt", "*.junk.txt", "*.tmp", "*~", "*.bak", "*.log", "debug_*.json", "coverage.out", "coverage.html", "profile.out")
foreach ($pat in $tempPatterns) {
    Get-ChildItem -Path $pat -File -Force -ErrorAction SilentlyContinue | ForEach-Object {
        Write-Host "  [-] Menghapus: $($_.Name)" -ForegroundColor DarkGray
        Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue
    }
}

# 3. Clean results folder
Write-Host "[*] Mengosongkan folder results..." -ForegroundColor Yellow
if (Test-Path "results") {
    Get-ChildItem -Path "results" -Force -Recurse -ErrorAction SilentlyContinue | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
} else {
    New-Item -ItemType Directory -Path "results" -Force | Out-Null
}

# 4. Optional go clean
if (Get-Command go -ErrorAction SilentlyContinue) {
    Write-Host "[*] Menjalankan go clean..." -ForegroundColor Yellow
    go clean -cache -testcache 2>$null
}

Write-Host ""
Write-Host "[V] Cleanup selesai! Proyek telah bersih seperti baru." -ForegroundColor Green
Write-Host "===================================================" -ForegroundColor Cyan
