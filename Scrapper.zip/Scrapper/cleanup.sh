#!/usr/bin/env bash
# ===================================================
#   SCRAPPER CLEANUP UTILITY (Linux / macOS)
# ===================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo -e "\033[1;36m===================================================\033[0m"
echo -e "\033[1;36m   SCRAPPER CLEANUP UTILITY (Linux / Unix)\033[0m"
echo -e "\033[1;36m===================================================\033[0m"

echo -e "\033[1;33m[*] Membersihkan build artifacts & binaries...\033[0m"
# Hapus binary Go Linux
rm -f scraper src test_build
# Hapus jika ada binary Windows / test binaries
rm -f *.exe *.exe~ *.test *.test.exe src/*.exe src/*.test src/*.test.exe

echo -e "\033[1;33m[*] Membersihkan output scraping & temporary files...\033[0m"
rm -f Scrapper-*.txt out_*.txt *.clean.txt *.junk.txt
rm -f *.tmp *~ *.bak *.log debug_*.json
rm -f coverage.out coverage.html profile.out

echo -e "\033[1;33m[*] Mengosongkan direktori results/...\033[0m"
if [ -d "results" ]; then
    find results/ -mindepth 1 -delete 2>/dev/null || true
else
    mkdir -p results
fi

if command -v go >/dev/null 2>&1; then
    echo -e "\033[1;33m[*] Menjalankan go clean...\033[0m"
    go clean -cache -testcache 2>/dev/null || true
fi

echo ""
echo -e "\033[1;32m[✓] Cleanup selesai! Proyek telah bersih seperti sebelum di-build dan digunakan.\033[0m"
echo -e "\033[1;36m===================================================\033[0m"
