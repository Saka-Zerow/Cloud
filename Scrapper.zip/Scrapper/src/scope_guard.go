package main

import (
	"strings"
	"sync"

	"golang.org/x/net/publicsuffix"
)

// ScopeMode defines the filtering policy to prevent scope drift and cross-tenant pollution.
type ScopeMode int

const (
	ScopeUnrestricted ScopeMode = 0 // Allow all discovered domains worldwide
	ScopeTargetTLDs   ScopeMode = 1 // Allow only domains matching the TLD/public-suffix of seed targets (e.g. *.id)
	ScopeSeedApexOnly ScopeMode = 2 // Strict mode: only allow subdomains belonging to the exact seed apexes
)

// ScopeGuard provides thread-safe boundary validation for discovered domains and apexes.
type ScopeGuard struct {
	mu           sync.RWMutex
	mode         ScopeMode
	allowedTLDs  map[string]bool
	allowedApex  map[string]bool
	customSuffix []string
}

var globalScopeGuard = NewScopeGuard(nil, ScopeUnrestricted)

// NewScopeGuard creates a ScopeGuard initialized from a list of seed domains and a scope policy.
func NewScopeGuard(seeds []string, mode ScopeMode) *ScopeGuard {
	sg := &ScopeGuard{
		mode:        mode,
		allowedTLDs: make(map[string]bool),
		allowedApex: make(map[string]bool),
	}
	for _, s := range seeds {
		sg.AddSeed(s)
	}
	return sg
}

var genericTLDs = map[string]bool{
	"com": true, "net": true, "org": true, "edu": true, "gov": true,
	"info": true, "biz": true, "xyz": true, "top": true, "site": true,
	"online": true, "vip": true, "club": true, "live": true, "pro": true,
	"app": true, "dev": true, "cloud": true, "ai": true, "io": true, "co": true,
}

// AddSeed extracts the root TLD and apex from a seed domain and registers it.
func (sg *ScopeGuard) AddSeed(s string) {
	s = strings.ToLower(strings.TrimSpace(strings.Trim(s, ".")))
	if s == "" || !strings.Contains(s, ".") {
		return
	}

	a := apexOf(s)
	if a == "" {
		a = s
	}

	sg.mu.Lock()
	defer sg.mu.Unlock()

	sg.allowedApex[a] = true

	// Extract top-level country code / TLD (e.g. "id" from "kemenag.go.id")
	// Generic TLDs (com, net, org, etc.) are restricted to their seed apex only
	// to prevent cross-tenant scope drift on shared hosting servers.
	parts := strings.Split(a, ".")
	if len(parts) >= 2 {
		tld := parts[len(parts)-1]
		if tld != "" && !genericTLDs[tld] {
			sg.allowedTLDs[tld] = true
		}
		// Also register second-level public suffix if applicable (e.g. "go.id", "ac.id")
		if len(parts) >= 3 {
			sTLD := parts[len(parts)-2] + "." + parts[len(parts)-1]
			if !genericTLDs[sTLD] {
				sg.allowedTLDs[sTLD] = true
			}
		}
	}
}

// SetMode updates the active filtering mode.
func (sg *ScopeGuard) SetMode(m ScopeMode) {
	sg.mu.Lock()
	defer sg.mu.Unlock()
	sg.mode = m
}

// Mode returns current mode.
func (sg *ScopeGuard) Mode() ScopeMode {
	sg.mu.RLock()
	defer sg.mu.RUnlock()
	return sg.mode
}

// AddExplicitTLD adds an explicit allowed TLD or suffix (e.g. "id", "go.id").
func (sg *ScopeGuard) AddExplicitTLD(tld string) {
	tld = strings.ToLower(strings.TrimPrefix(strings.TrimSpace(tld), "."))
	if tld == "" {
		return
	}
	sg.mu.Lock()
	defer sg.mu.Unlock()
	sg.allowedTLDs[tld] = true
}

// IsAllowed evaluates whether a domain or apex is inside the authorized scope boundary.
func (sg *ScopeGuard) IsAllowed(d string) bool {
	if sg == nil {
		return true
	}

	sg.mu.RLock()
	mode := sg.mode
	sg.mu.RUnlock()

	if mode == ScopeUnrestricted {
		return true
	}

	d = strings.ToLower(strings.TrimSpace(strings.Trim(d, ".")))
	if d == "" || !strings.Contains(d, ".") {
		return false
	}

	a := apexOf(d)
	if a == "" {
		a = d
	}

	sg.mu.RLock()
	defer sg.mu.RUnlock()

	if mode == ScopeSeedApexOnly {
		return sg.allowedApex[a]
	}

	if mode == ScopeTargetTLDs {
		// 1. Direct match on apex
		if sg.allowedApex[a] {
			return true
		}
		// 2. Check TLD / suffix matching
		parts := strings.Split(a, ".")
		if len(parts) < 2 {
			return false
		}
		tld := parts[len(parts)-1]
		if sg.allowedTLDs[tld] {
			return true
		}
		if len(parts) >= 3 {
			sTLD := parts[len(parts)-2] + "." + parts[len(parts)-1]
			if sg.allowedTLDs[sTLD] {
				return true
			}
		}

		// Also check public suffix directly
		ps, _ := publicsuffix.PublicSuffix(a)
		if ps != "" && sg.allowedTLDs[ps] {
			return true
		}
		return false
	}

	return true
}
