package main

import (
	"encoding/binary"
	"fmt"
	"net"
	"strings"
	"sync"
)

// ipv4Range represents an IPv4 CIDR block in uint32 integer representation for
// zero-allocation, nanosecond-speed containment checks.
type ipv4Range struct {
	network uint32
	mask    uint32
}

func (r ipv4Range) contains(ip uint32) bool {
	return (ip & r.mask) == r.network
}

var (
	cdnRangesInitOnce sync.Once
	cdnRanges         []ipv4Range
)

// cidrList contains major Anycast CDN ranges (Cloudflare, CloudFront, Fastly, Akamai, Azure Edge).
// Reverse-IP / sameip lookups on these shared IPs return either Cloudflare error pages or millions of
// unrelated domains. Skipping them saves bandwidth and isolates true origin web servers.
var rawCDNCIDRs = []string{
	// Cloudflare IPv4
	"173.245.48.0/20",
	"103.21.244.0/22",
	"103.22.200.0/22",
	"103.31.4.0/22",
	"141.101.64.0/18",
	"108.162.192.0/18",
	"190.93.240.0/20",
	"188.114.96.0/20",
	"197.234.240.0/22",
	"198.41.128.0/17",
	"162.158.0.0/15",
	"104.16.0.0/13",
	"104.24.0.0/14",
	"172.64.0.0/13",
	"131.0.72.0/22",

	// AWS CloudFront
	"13.224.0.0/14",
	"13.32.0.0/15",
	"52.84.0.0/15",
	"54.230.0.0/15",
	"18.64.0.0/15",
	"65.8.0.0/15",
	"99.84.0.0/15",
	"143.204.0.0/16",
	"204.246.160.0/19",
	"205.251.192.0/19",
	"216.137.0.0/19",

	// Fastly
	"151.101.0.0/16",
	"199.232.0.0/16",

	// Akamai Edges
	"23.0.0.0/12",
	"23.32.0.0/11",
	"23.64.0.0/14",
	"104.64.0.0/10",
	"184.24.0.0/13",
	"184.84.0.0/14",
	"2.16.0.0/13",
	"23.192.0.0/11",

	// Microsoft Azure CDN / Front Door / Edge
	"13.107.0.0/16",
	"13.107.246.0/24",
	"13.107.213.0/24",
	"20.150.0.0/16",
	"20.107.0.0/16",

	// AWS S3 & Multi-tenant Cloud Endpoints
	"52.92.0.0/14",
	"52.216.0.0/15",
	"54.231.0.0/16",
	"52.218.0.0/15",

	// Incapsula / Imperva
	"199.83.128.0/21",
	"198.143.32.0/19",
	"149.126.72.0/21",
	"103.28.248.0/22",
	"185.11.124.0/22",
	"192.230.64.0/18",
	"107.154.0.0/16",
	"45.64.64.0/22",

	// Sucuri Anycast WAF / CDN
	"192.124.249.0/24",
	"185.93.228.0/24",
	"192.169.216.0/24",
	"192.169.217.0/24",
	"66.248.200.0/24",

	// Edge PaaS / Git Hosting Shared Edges (GitHub Pages, Vercel, Netlify)
	"185.199.108.0/22",
	"76.76.21.0/24",
	"75.2.60.0/24",
	"99.83.231.0/24",
}

func initCDNRanges() {
	for _, cidr := range rawCDNCIDRs {
		_, ipNet, err := net.ParseCIDR(cidr)
		if err != nil || ipNet == nil {
			continue
		}
		ip4 := ipNet.IP.To4()
		mask4 := ipNet.Mask
		if ip4 == nil || len(mask4) != 4 {
			continue
		}
		ipUint := binary.BigEndian.Uint32(ip4)
		maskUint := binary.BigEndian.Uint32(mask4)
		cdnRanges = append(cdnRanges, ipv4Range{
			network: ipUint & maskUint,
			mask:    maskUint,
		})
	}
}

// IsAnycastCDN reports whether the given IP string belongs to a known public CDN / Anycast edge.
func IsAnycastCDN(ipStr string) bool {
	cdnRangesInitOnce.Do(initCDNRanges)
	ip := net.ParseIP(strings.TrimSpace(ipStr))
	if ip == nil {
		return false
	}
	ip4 := ip.To4()
	if ip4 == nil {
		return false
	}
	ipUint := binary.BigEndian.Uint32(ip4)
	for _, r := range cdnRanges {
		if r.contains(ipUint) {
			return true
		}
	}
	return false
}

// GenerateSmartSubnetNeighbors generates adjacent IP addresses within the same /24 subnet
// (e.g. rack neighbors in web hosting datacenters), skipping Anycast CDNs, private ranges,
// network/broadcast addresses, and default gateways.
func GenerateSmartSubnetNeighbors(ipStr string, maxNeighbors int) []string {
	if IsAnycastCDN(ipStr) {
		return nil
	}
	parsed := net.ParseIP(strings.TrimSpace(ipStr))
	if parsed == nil {
		return nil
	}
	ipv4 := parsed.To4()
	if ipv4 == nil {
		return nil
	}
	// Avoid private, loopback, link-local, multicast
	if ipv4[0] == 10 || ipv4[0] == 127 ||
		(ipv4[0] == 172 && ipv4[1] >= 16 && ipv4[1] <= 31) ||
		(ipv4[0] == 192 && ipv4[1] == 168) ||
		ipv4[0] >= 224 {
		return nil
	}

	hostNum := int(ipv4[3])
	if maxNeighbors <= 0 {
		maxNeighbors = 6
	}

	var neighbors []string
	// Offsets to probe: close neighbors first (±1, ±2, ±3, ±4, ±5, ±8, ±16)
	offsets := []int{-1, 1, -2, 2, -3, 3, -4, 4, -5, 5, -8, 8, -10, 10}
	for _, off := range offsets {
		if len(neighbors) >= maxNeighbors {
			break
		}
		targetHost := hostNum + off
		// Skip subnet ID (.0), gateway (.1), broadcast (.255), and self
		if targetHost <= 1 || targetHost >= 255 || targetHost == hostNum {
			continue
		}
		candidate := fmt.Sprintf("%d.%d.%d.%d", ipv4[0], ipv4[1], ipv4[2], targetHost)
		neighbors = append(neighbors, candidate)
	}
	return neighbors
}
