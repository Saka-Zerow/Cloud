package main

import "testing"

// --- Secondary reverse providers + tntcode now honour the per-exit-IP gate ----
//
// These pin the wiring: a per-IP block from a reverse provider must classify as
// a limit (so ensureFreshExit rotates the Tor exit) and must NOT share the
// rapiddns/crt.name gates.

func TestClassifyReverseAndTntcodeLimits(t *testing.T) {
	if v := classifyLimit(srcTntcode, 429, nil, nil); v.Kind != limitChallenge {
		t.Errorf("tntcode 429 = %v, want challenge", v.Kind)
	}
	if v := classifyLimit(srcTntcode, 403, nil, nil); v.Kind != limitChallenge {
		t.Errorf("tntcode 403 = %v, want challenge", v.Kind)
	}
	if v := classifyLimit(srcReverse, 429, nil, nil); v.Kind != limitChallenge {
		t.Errorf("reverse 429 = %v, want challenge", v.Kind)
	}
	// hackertarget daily quota arrives as HTTP 200 with a marker body.
	body := []byte("API count exceeded - Increase Quota with Membership")
	if v := classifyLimit(srcReverse, 200, nil, body); v.Kind != limitQuota {
		t.Errorf("hackertarget quota body = %v, want quota", v.Kind)
	}
	// A clean 200 from a reverse provider is not a limit.
	if v := classifyLimit(srcReverse, 200, nil, []byte(`{"hostnames":["a.example.com"]}`)); v.Kind != limitNone {
		t.Errorf("clean reverse 200 = %v, want none", v.Kind)
	}
}

// Each source family must own its gate: a rapiddns challenge must not cool the
// exit for tntcode, and vice versa.
func TestGatesAreSeparatePerSourceFamily(t *testing.T) {
	if gateFor(srcTntcode) == gateFor(srcRapidSub) {
		t.Error("tntcode must not share the rapiddns gate")
	}
	if gateFor(srcReverse) == gateFor(srcRapidSub) {
		t.Error("reverse must not share the rapiddns gate")
	}
	if gateFor(srcTntcode) == gateFor(srcReverse) {
		t.Error("tntcode and reverse must have distinct gates")
	}
	if gateFor(srcCrtName) != crtNameGate {
		t.Error("crt.name must keep its own gate")
	}
}

// Direct mode has a single identity; the gate must never disable a provider
// there (no exit to rotate to).
func TestEnsureFreshExitDirectModeAllowsNewSources(t *testing.T) {
	off := &worker{}
	off.useTor.Store(false)
	for _, src := range []apiSource{srcTntcode, srcReverse} {
		if !off.ensureFreshExit(src) {
			t.Errorf("ensureFreshExit(%s) must allow direct mode", src)
		}
	}
}
