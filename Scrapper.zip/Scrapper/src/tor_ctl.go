package main

import (
	"bufio"
	"encoding/hex"
	"fmt"
	"net"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// --- Tor control port: learn WHICH exit relay our own request used -----------
//
// Verified live against Tor 0.4.9.11 (2026-09-20), all four steps:
//
//  1. every request already carries a unique SOCKS username (torCircuitUser),
//     and Tor's IsolateSOCKSAuth turns that into one circuit per request;
//  2. the control port echoes that username back in async stream events:
//     650 STREAM <id> SUCCEEDED <circid> <target> SOCKS_USERNAME="w7_..."
//  3. `GETINFO circuit-status` maps <circid> to its path, whose LAST hop is the
//     exit relay fingerprint (`$FINGERPRINT~nickname`);
//  4. `GETINFO ns/id/<fp>` gives that relay's IP address.
//
// Cross-check against an IP-echo request made through the same circuit matched
// exactly (192.42.116.142 == 192.42.116.142), i.e. blocks can be attributed to a
// specific relay WITHOUT spending an extra request. After
// `SETCONF ExcludeExitNodes=<fp> StrictNodes=0` the excluded relay was reused
// 0/8 times for fresh circuits.
//
// Everything here is best effort: when no control port is reachable (a Tor
// started without ControlPort) the scraper keeps its old behaviour and reports
// that steering is off instead of pretending otherwise.

const (
	torCtrlDialTimeout = 2 * time.Second
	torCtrlCmdTimeout  = 6 * time.Second
	torCtrlUserTTL     = 10 * time.Minute
	torCtrlUserMax     = 4096
	torCtrlStatusGap   = 200 * time.Millisecond
)

type torCtl struct {
	addr string

	conn    net.Conn
	reader  *bufio.Reader
	replies chan string

	mu         sync.Mutex
	userCirc   map[string]string // socks username -> circuit id
	userAt     map[string]time.Time
	circExit   map[string]string // circuit id -> exit fingerprint
	relayIPs   map[string]string // exit fingerprint -> IP
	lastStatus time.Time

	sendMu sync.Mutex
	dead   bool
}

func findTorCookie() []byte {
	if p := os.Getenv("TOR_CONTROL_COOKIE"); p != "" {
		if b, err := os.ReadFile(p); err == nil && len(b) > 0 {
			return b
		}
	}
	uProfile := os.Getenv("USERPROFILE")
	cands := []string{
		filepath.Join(os.TempDir(), "submass_tor_data", "control_auth_cookie"),
		filepath.Join(uProfile, "AppData", "Roaming", "tor", "control_auth_cookie"),
		filepath.Join(uProfile, "AppData", "Local", "tor", "control_auth_cookie"),
		filepath.Join(uProfile, "Desktop", "Tor Browser", "Browser", "TorBrowser", "Data", "Tor", "control_auth_cookie"),
		filepath.Join(uProfile, ".local", "tor", "Tor", "control_auth_cookie"),
		"/var/run/tor/control.authcookie",
		"/var/lib/tor/control_auth_cookie",
	}
	for _, c := range cands {
		if b, err := os.ReadFile(c); err == nil && len(b) > 0 {
			return b
		}
	}
	return nil
}

func newTorCtl(addr string) *torCtl {
	t := &torCtl{
		addr:     addr,
		replies:  make(chan string, 8),
		userCirc: map[string]string{},
		userAt:   map[string]time.Time{},
		circExit: map[string]string{},
		relayIPs: map[string]string{},
	}
	c, err := net.DialTimeout("tcp", t.addr, torCtrlDialTimeout)
	if err != nil {
		return nil
	}
	// The control port sends NOTHING before AUTHENTICATE. First try NULL auth;
	// if 515 is returned (Cookie auth required), attempt reading control_auth_cookie.
	c.SetDeadline(time.Now().Add(torCtrlCmdTimeout))
	if _, err := fmt.Fprintf(c, "AUTHENTICATE \"\"\r\n"); err != nil {
		c.Close()
		return nil
	}
	r := bufio.NewReader(c)
	line, err := r.ReadString('\n')
	if err != nil {
		c.Close()
		return nil
	}
	if strings.HasPrefix(line, "515") || strings.HasPrefix(line, "514") {
		authenticated := false
		if cookie := findTorCookie(); len(cookie) > 0 {
			hexCookie := hex.EncodeToString(cookie)
			if _, err := fmt.Fprintf(c, "AUTHENTICATE %s\r\n", hexCookie); err == nil {
				line, err = r.ReadString('\n')
				if err == nil && strings.HasPrefix(line, "250") {
					authenticated = true
				}
			}
		}
		if !authenticated {
			if pass := os.Getenv("TOR_CONTROL_PASSWORD"); pass != "" {
				if _, err := fmt.Fprintf(c, "AUTHENTICATE \"%s\"\r\n", pass); err == nil {
					line, err = r.ReadString('\n')
					if err == nil && strings.HasPrefix(line, "250") {
						authenticated = true
					}
				}
			}
		}
	}
	if err != nil || !strings.HasPrefix(line, "250") {
		c.Close()
		return nil
	}
	c.SetDeadline(time.Time{})
	t.conn, t.reader = c, r
	go t.readLoop()
	if _, err := t.command("SETEVENTS STREAM CIRC"); err != nil {
		t.close()
		return nil
	}
	return t
}

func (t *torCtl) close() {
	t.mu.Lock()
	t.dead = true
	conn := t.conn
	t.mu.Unlock()
	if conn != nil {
		conn.Close()
	}
}

func (t *torCtl) isDead() bool {
	t.mu.Lock()
	defer t.mu.Unlock()
	return t.dead
}

// command runs one control command and returns its (multi-line) reply.
func (t *torCtl) command(cmd string) (string, error) {
	if t.isDead() {
		return "", fmt.Errorf("tor control %s tidak tersedia", t.addr)
	}
	t.sendMu.Lock()
	defer t.sendMu.Unlock()
	if t.isDead() {
		return "", fmt.Errorf("tor control %s tidak tersedia", t.addr)
	}

	// Drain any stale replies left in channel to avoid desynchronization
	for {
		select {
		case <-t.replies:
		default:
			goto drained
		}
	}
drained:

	t.conn.SetDeadline(time.Now().Add(torCtrlCmdTimeout))
	defer t.conn.SetDeadline(time.Time{})

	if _, err := fmt.Fprintf(t.conn, "%s\r\n", cmd); err != nil {
		t.close()
		return "", err
	}
	select {
	case rep, ok := <-t.replies:
		if !ok {
			return "", fmt.Errorf("tor control %s tertutup", t.addr)
		}
		if strings.Contains(rep, "515 ") {
			return rep, fmt.Errorf("tor control %s butuh autentikasi", t.addr)
		}
		return rep, nil
	case <-time.After(torCtrlCmdTimeout):
		t.close()
		return "", fmt.Errorf("tor control %s timeout", t.addr)
	}
}

func (t *torCtl) readLoop() {
	r := t.reader
	var buf []string
	inData := false
	for {
		line, err := r.ReadString('\n')
		if err != nil {
			t.close()
			close(t.replies)
			return
		}
		line = strings.TrimRight(line, "\r\n")
		if inData {
			if line == "." {
				inData = false
				continue
			}
			buf = append(buf, line)
			continue
		}
		if strings.HasPrefix(line, "650 ") || strings.HasPrefix(line, "650-") {
			t.handleEvent(line)
			continue
		}
		if strings.HasPrefix(line, "250+") {
			buf = append(buf, line)
			inData = true
			continue
		}
		buf = append(buf, line)
		if len(line) >= 4 && line[3] == '-' {
			continue // multi-line reply continues
		}
		rep := strings.Join(buf, "\n")
		buf = nil
		select {
		case t.replies <- rep:
		default: // nobody waiting: drop
		}
	}
}

func (t *torCtl) handleEvent(line string) {
	f := strings.Fields(line)
	if len(f) < 4 {
		return
	}
	switch f[1] {
	case "STREAM":
		// 650 STREAM <streamid> <status> <circid> <target> ... SOCKS_USERNAME=".."
		if len(f) < 6 || f[4] == "0" {
			return
		}
		switch f[3] {
		case "SENTCONNECT", "SUCCEEDED", "REMAP":
			if u := ctrlField(line, "SOCKS_USERNAME"); u != "" {
				t.setUserCirc(u, f[4])
			}
		}
	case "CIRC":
		// 650 CIRC <circid> <status> <path> PURPOSE=...
		if f[3] == "BUILT" && len(f) >= 6 {
			if fp := exitFingerprint(f[4]); fp != "" {
				t.setCircExit(f[2], fp)
			}
		}
	}
}

// exitFingerprint returns the relay fingerprint of the LAST hop of a circuit
// path (`$AA..AA~name,$BB..BB~name,$CC..CC~name`), i.e. the exit relay.
func exitFingerprint(path string) string {
	hops := strings.Split(path, ",")
	last := hops[len(hops)-1]
	if i := strings.IndexByte(last, '~'); i > 0 {
		return last[:i]
	}
	if strings.HasPrefix(last, "$") {
		return last
	}
	return ""
}

// exitFromCircuitStatus returns the exit relay of one circuit id from a
// `GETINFO circuit-status` reply:
//
//	250+circuit-status=
//	55 BUILT $a~n1,$b~n2,$c~n3 PURPOSE=GENERAL TIME_CREATED=...
//	.
func exitFromCircuitStatus(reply, cid string) string {
	for _, line := range strings.Split(reply, "\n") {
		f := strings.Fields(line)
		if len(f) < 4 || f[0] != cid {
			continue
		}
		return exitFingerprint(f[2])
	}
	return ""
}

func ctrlField(line, key string) string {
	i := strings.Index(line, key+"=\"")
	if i < 0 {
		return ""
	}
	rest := line[i+len(key)+2:]
	if j := strings.IndexByte(rest, '"'); j >= 0 {
		return rest[:j]
	}
	return ""
}

func (t *torCtl) setUserCirc(user, circ string) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if len(t.userCirc) >= torCtrlUserMax {
		for k, at := range t.userAt {
			if time.Since(at) > torCtrlUserTTL {
				delete(t.userCirc, k)
				delete(t.userAt, k)
			}
		}
		if len(t.userCirc) >= torCtrlUserMax { // still full: drop oldest
			oldest, oldestAt := "", time.Now()
			for k, at := range t.userAt {
				if at.Before(oldestAt) {
					oldest, oldestAt = k, at
				}
			}
			delete(t.userCirc, oldest)
			delete(t.userAt, oldest)
		}
	}
	t.userCirc[user] = circ
	t.userAt[user] = time.Now()
}

func (t *torCtl) setCircExit(circ, fp string) {
	t.mu.Lock()
	if len(t.circExit) >= torCtrlUserMax {
		// Prune older circuit mappings when capacity is reached
		pruned := 0
		for c := range t.circExit {
			delete(t.circExit, c)
			pruned++
			if pruned >= torCtrlUserMax/2 {
				break
			}
		}
	}
	t.circExit[circ] = fp
	t.mu.Unlock()
}

// exitForUser resolves the exit relay serving `user`'s stream, or "".
func (t *torCtl) exitForUser(user string) string {
	if user == "" || t.isDead() {
		return ""
	}
	t.mu.Lock()
	circ := t.userCirc[user]
	fp := t.circExit[circ]
	stale := time.Since(t.lastStatus) > torCtrlStatusGap
	t.mu.Unlock()
	if fp != "" {
		return fp
	}
	if circ == "" || !stale {
		return ""
	}
	// Circuit was pre-built (Tor keeps spares ready), so its BUILT event may
	// predate our subscription: ask for the full list instead.
	t.refreshCircuitStatus()
	t.mu.Lock()
	fp = t.circExit[circ]
	t.mu.Unlock()
	return fp
}

func (t *torCtl) refreshCircuitStatus() {
	rep, err := t.command("GETINFO circuit-status")
	if err != nil {
		return
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	t.lastStatus = time.Now()
	for _, line := range strings.Split(rep, "\n") {
		f := strings.Fields(line)
		if len(f) < 3 {
			continue
		}
		if fp := exitFingerprint(f[2]); fp != "" {
			t.circExit[f[0]] = fp
		}
	}
}

// relayIP resolves a relay fingerprint to its IP (cached).
func (t *torCtl) relayIP(fp string) string {
	if fp == "" || t.isDead() {
		return ""
	}
	t.mu.Lock()
	ip := t.relayIPs[fp]
	t.mu.Unlock()
	if ip != "" {
		return ip
	}
	rep, err := t.command("GETINFO ns/id/" + strings.TrimPrefix(fp, "$"))
	if err != nil {
		return ""
	}
	for _, line := range strings.Split(rep, "\n") {
		if !strings.HasPrefix(line, "r ") {
			continue
		}
		for _, f := range strings.Fields(line)[3:] {
			if net.ParseIP(f) != nil {
				ip = f
				break
			}
		}
		break
	}
	if ip != "" {
		t.mu.Lock()
		if len(t.relayIPs) < 4096 {
			t.relayIPs[fp] = ip
		}
		t.mu.Unlock()
	}
	return ip
}

// exclude hands Tor the complete list of relays it must stop using for NEW
// circuits. StrictNodes=1 enforces that Tor never uses excluded exits even as fallback.
func (t *torCtl) exclude(fingerprints []string) error {
	if len(fingerprints) == 0 || t.isDead() {
		return nil
	}
	list := make([]string, 0, len(fingerprints))
	for _, fp := range fingerprints {
		list = append(list, "$"+strings.TrimPrefix(fp, "$"))
	}
	_, err := t.command("SETCONF ExcludeExitNodes=" + strings.Join(list, ",") + " StrictNodes=1")
	return err
}

// circuitForUser returns the circuit ID associated with user, or "".
func (t *torCtl) circuitForUser(user string) string {
	if user == "" || t.isDead() {
		return ""
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	return t.userCirc[user]
}

// closeCircuit instructs Tor daemon to immediately close and destroy a circuit.
func (t *torCtl) closeCircuit(circID string) error {
	if circID == "" || t.isDead() {
		return nil
	}
	_, err := t.command("CLOSECIRCUIT " + circID)
	return err
}

