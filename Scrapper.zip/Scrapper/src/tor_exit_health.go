package main

import (
	"fmt"
	"net"
	"os"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// --- Exit reputation: stop handing burned relays to our own requests --------
//
// The problem this solves (measured, not guessed): Tor's exit pool is finite,
// so "give me a brand new circuit" does NOT guarantee a brand new exit IP. On a
// live crt.name run, two of six fresh circuits came out through the SAME relay
// IP that was already rate-limiting us (429), and a third was simply too slow.
//
// The fix is to remember which relay burned us and let Tor route around it:
// tor_ctl.go tells us exactly which relay served each request, so every
// 429/403/503 can be blamed on a specific fingerprint; after
// torExitStrikesToBan strikes that relay goes into ExcludeExitNodes (verified
// live: 0/8 reuse afterwards). The list is persisted so the next run starts
// with the knowledge already in place.

const (
	torExitTTL          = 1 * time.Hour
	torExitMaxExcluded  = 512
	torExitApplyEvery   = 30 * time.Second
	torExitUnavailRetry = 60 * time.Second
	torExitSaveDebounce = 5 * time.Second

	// Strike policy (why the tool got slower and slower):
	//
	// A sameip / rapiddns 429 is very often a TRANSIENT per-exit-IP challenge,
	// not a dead relay. Banning a relay on the FIRST strike burned the whole
	// exit pool within minutes: every ban forces Tor to rebuild circuits around
	// a shrinking pool, and each SETCONF ExcludeExitNodes restart of the exit
	// list makes the next circuit slower. That is exactly what the operator saw:
	// 136/s at the start, then a long sag ("81 relay aktif dikecualikan").
	//
	// New policy keeps the two failure kinds apart:
	//   - torExitStrikesToBan (=3) transient blocks (429/403/503, "sameip 429",
	//     Cloudflare challenges): counted, but the relay is only excluded on the
	//     3rd strike inside torExitTTL.
	//   - torExitQuotaBanStrikes (=1) quota-type blocks (crt.name free-tier
	//     quota, "exit sudah dipakai worker lain"): excluded immediately,
	//     because the exit is useless for that provider for 24h anyway.
	torExitStrikesToBan    = 3
	torExitQuotaBanStrikes = 1
)

// isQuotaBlockReason reports whether a block reason is the quota kind that
// justifies immediate exclusion (the relay cannot serve that provider for a
// long time), as opposed to a transient challenge that decays in minutes.
//
// NOTE: keyed on the quota wording ONLY — never on the provider name. Matching
// "crt.name" as a substring used to make every crt.name block (including
// per-IP rate limits and false-positive "+1" rotations) a 1-strike instant ban,
// which burned the whole exit pool and made long runs slower and slower.
func isQuotaBlockReason(reason string) bool {
	r := strings.ToLower(reason)
	return strings.Contains(r, "quota") ||
		strings.Contains(r, "free tier") ||
		strings.Contains(r, "limit reached") ||
		strings.Contains(r, "per ip per day")
}

// torExitBlacklistFile is a var so tests can point it at a temp dir.
var torExitBlacklistFile = "tor_exit_blacklist.txt"

// torSteerFlag backs -torsteer (default on) for ablation/debugging.
var torSteerFlag = true

type exitStat struct {
	FP      string
	IP      string
	Strikes int
	Last    time.Time
	Reason  string
}

type torExitHealth struct {
	mu    sync.Mutex
	bad   map[string]*exitStat // key: fingerprint (or "ip:<addr>" when unknown)
	ban   map[string]bool      // fingerprints currently excluded from circuits
	order []string             // ban order, capped at torExitMaxExcluded

	ctls      map[string]*torCtl // ctrl address -> client
	ctlFailAt map[string]time.Time
	dirty     bool
	lastSave  time.Time
	started   atomic.Bool
	// stop ends the applier goroutine (guarded by mu). It used to be absent, so
	// the loop ticked for the life of the PROCESS and a GUI restart could never
	// take it down with its run. Each applyLoop owns the channel that was
	// installed when it started, so stopLoop can hand the next run a fresh one
	// without racing the old loop.
	stop chan struct{}
	notify chan struct{}
}

var exitHealth = &torExitHealth{
	bad:       map[string]*exitStat{},
	ban:       map[string]bool{},
	ctls:      map[string]*torCtl{},
	ctlFailAt: map[string]time.Time{},
	notify:    make(chan struct{}, 1),
}

// autoTorCtrlAddr is the control port of the Tor instance WE launched
// (ControlPort auto + ControlPortWriteToFile), used when the conventional
// socks+1 port has no control listener.
var autoTorCtrlAddr atomic.Pointer[string]

// autoTorCtrlFile is where that Tor instance writes the port it picked.
var autoTorCtrlFile string

// readAutoTorCtrlPort picks up the control port Tor chose for us. Format:
//
// \tPORT=127.0.0.1:42751
func readAutoTorCtrlPort() {
	if autoTorCtrlFile == "" {
		return
	}
	data, err := os.ReadFile(autoTorCtrlFile)
	if err != nil {
		return
	}
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if !strings.HasPrefix(line, "PORT=") {
			continue
		}
		addr := strings.TrimPrefix(line, "PORT=")
		if _, _, err := net.SplitHostPort(addr); err != nil {
			continue
		}
		autoTorCtrlAddr.Store(&addr)
		return
	}
}

// torControlAddrFor resolves the control port belonging to a SOCKS address.
func torControlAddrFor(socksAddr string) string {
	if auto := autoTorCtrlAddr.Load(); auto != nil && *auto != "" &&
		(socksAddr == "" || socksAddr == defaultTorSocks) {
		return *auto
	}
	return torCtrlFromSocks(socksAddr)
}

// startTorExitSteering loads what previous runs learned and starts the applier.
// runSocksAddr is the Tor the current run will actually use (`-tor ...`), which
// may be neither the default port nor a member of the torports.txt fleet.
func startTorExitSteering(runSocksAddr string) {
	if !torSteerFlag {
		guiLogf("tor", "", 0, "[tor] exit steering OFF (-torsteer=false)")
		return
	}
	if !exitHealth.started.CompareAndSwap(false, true) {
		return
	}
	exitHealth.mu.Lock()
	if exitHealth.stop == nil {
		exitHealth.stop = make(chan struct{})
	}
	exitHealth.mu.Unlock()
	exitHealth.load()
	go exitHealth.applyLoop()

	// Subscribe BEFORE any request goes out: a control connection only receives
	// stream events opened after its SETEVENTS, so a client created lazily on the
	// first block would miss the very stream it is supposed to attribute.
	addrs := []string{defaultTorSocks}
	if runSocksAddr != "" && runSocksAddr != "off" && runSocksAddr != "false" {
		addrs = append(addrs, runSocksAddr)
	}
	addrs = append(addrs, loadTorFleet()...)
	seen := map[string]bool{}
	active := 0
	for _, a := range addrs {
		if seen[a] {
			continue
		}
		seen[a] = true
		if c := exitHealth.ctlFor(a); c != nil {
			active++
		}
	}
	if active == 0 {
		guiLogf("tor", "", 0, "[tor] exit steering OFF: tidak ada ControlPort yang bisa dipakai "+
			"(tambahkan \"ControlPort 9051\" + \"CookieAuthentication 0\" ke torrc, atau biarkan tool menjalankan Tor sendiri)")
		return
	}
	guiLogf("tor", "", 0, "[tor] exit steering AKTIF di %d instance Tor - %d relay diblokir, %d dikeluarkan dari sirkuit",
		active, exitHealth.badCount(), len(exitHealth.bannedList()))
}

// ctlFor returns a live control client for a SOCKS address, or nil. Failed
// dials are remembered for a while: a Tor without a control port must not cost
// a TCP connect attempt on every single blocked request.
//
// IMPORTANT: the dial + AUTHENTICATE handshake (up to ~4s combined) happens
// OUTSIDE h.mu. Holding the mutex across it serialised all 50 workers at startup
// (every claimUniqueExit called ctlFor simultaneously and queued behind one
// global lock while each dial took seconds).
func (h *torExitHealth) ctlFor(socksAddr string) *torCtl {
	addr := torControlAddrFor(socksAddr)
	if addr == "" {
		return nil
	}
	h.mu.Lock()
	if c, ok := h.ctls[addr]; ok && !c.isDead() {
		h.mu.Unlock()
		return c
	}
	if at, ok := h.ctlFailAt[addr]; ok && time.Since(at) < torExitUnavailRetry {
		h.mu.Unlock()
		return nil
	}
	h.mu.Unlock()

	c := newTorCtl(addr)

	h.mu.Lock()
	defer h.mu.Unlock()
	if c == nil {
		h.ctlFailAt[addr] = time.Now()
		return nil
	}
	// Re-check after the dial: another goroutine may have won the race.
	if existing, ok := h.ctls[addr]; ok && !existing.isDead() {
		c.close()
		return existing
	}
	// Replace a dead entry so a control connection that timed out earlier does
	// not disable exit steering for the rest of the run.
	h.ctls[addr] = c
	delete(h.ctlFailAt, addr)
	return c
}

// noteBlocked attributes a 429/403/503 to the exit relay that served the
// request `user` and bans that relay after enough strikes.
func (h *torExitHealth) noteBlocked(socksAddr, user, reason string) {
	if !torSteerFlag {
		return
	}
	ctl := h.ctlFor(socksAddr)
	if ctl == nil {
		return
	}
	fp := ctl.exitForUser(user)
	if fp == "" {
		return
	}
	h.recordBlock(fp, ctl.relayIP(fp), reason)
}

// recordBlock is the policy half of noteBlocked: strikes, ban, persistence.
// Kept separate (and ctl-free) so it is unit-testable without a Tor daemon.
//
// Quota-type blocks ban immediately (the exit cannot serve that provider for a
// long time); transient blocks (429/403/503, challenges) are counted and only
// excluded on the 3rd strike — banning them on the first strike burned the whole
// exit pool within minutes and made every run slower and slower.
func (h *torExitHealth) recordBlock(fp, ip, reason string) {
	if fp == "" {
		return
	}
	h.mu.Lock()
	st := h.bad[fp]
	if st == nil {
		st = &exitStat{FP: fp}
		h.bad[fp] = st
	}
	st.Strikes++
	st.Last = time.Now()
	st.IP = ip
	st.Reason = reason
	need := torExitStrikesToBan
	if isQuotaBlockReason(reason) {
		need = torExitQuotaBanStrikes
	}
	banned := st.Strikes >= need
	newBan := false
	if banned && !h.ban[fp] {
		h.ban[fp] = true
		h.order = append(h.order, fp)
		if len(h.order) > torExitMaxExcluded {
			drop := h.order[0]
			h.order = h.order[1:]
			delete(h.ban, drop)
			delete(h.bad, drop)
		}
		newBan = true
	}
	h.dirty = true
	nBan := len(h.order)
	strikes := st.Strikes // snapshot: st is shared and keeps being incremented
	h.mu.Unlock()

	label := ip
	if label == "" {
		label = "ip?"
	}
	threshold := needBanStrikes(reason)
	if newBan {
		// Rate-guard the ban chatter: at 80+ bans per run the "[tor] exit
		// diblokir" line used to hide the real progress bar. The file blacklist
		// (h.save) still records every ban; only the console row is throttled
		// (one line per torBanLogEvery, but always the first ban).
		torBanLogMu.Lock()
		last := torBanLogLast
		torBanLogLast = time.Now()
		torBanLogTotal++
		say := torBanLogTotal == 1 || time.Since(last) >= torBanLogEvery
		total := torBanLogTotal
		torBanLogMu.Unlock()
		if say {
			extra := ""
			if nBan >= torBanLogBulk && total > 1 {
				extra = fmt.Sprintf(" (+%d total ban, lihat --debug)", total)
			}
			guiLogf("tor", "", 0, "[tor] exit %s (%s) diblokir %s - strike %d, DIKELUARKAN dari sirkuit berikutnya (%d relay aktif dikecualikan)%s",
				shortFP(fp), label, reason, strikes, nBan, extra)
		}
		h.save()
		select {
		case h.notify <- struct{}{}:
		default:
		}
	} else if strikes >= threshold {
		guiLogQuiet("tor", "", 0, "[tor] exit %s (%s) diblokir %s - strike %d/%d (SUDAH DIKELUARKAN, Tor sirkuit lama draining)",
			shortFP(fp), label, reason, strikes, threshold)
	} else {
		guiLogf("tor", "", 0, "[tor] exit %s (%s) diblokir %s - strike %d/%d (transient, belum dikeluarkan)",
			shortFP(fp), label, reason, strikes, threshold)
	}
}

// The vars below throttle the ban chatter only.
//
// guiLogf/guiLogQuiet are process-global sinks guarded by guiMu; the flamegraph
// hypothesis ("logging mutex") did not hold — pushGuiEntry is O(1) under one
// mutex with a 1200-row ring. The real cost was fmt + heap churn at ban rates,
// which the throttle above removes.
var (
	torBanLogMu    sync.Mutex
	torBanLogLast  time.Time
	torBanLogTotal int
	// torBanLogEvery: at most one dedicated ban line per this interval on the CLI.
	torBanLogEvery = 60 * time.Second
	// torBanLogBulk: once this many relays are excluded, the line becomes an
	// aggregate ("+N total ban").
	torBanLogBulk = 10
)

// needBanStrikes returns the strike threshold for a reason (mirrors the policy
// inside recordBlock) so the log line shows the correct denominator.
func needBanStrikes(reason string) int {
	if isQuotaBlockReason(reason) {
		return torExitQuotaBanStrikes
	}
	return torExitStrikesToBan
}

func shortFP(fp string) string {
	fp = strings.TrimPrefix(fp, "$")
	if len(fp) > 10 {
		return fp[:10]
	}
	return fp
}

// stopLoop ends the applier goroutine and re-arms `started` so a later run in
// the same process (GUI restart, a second runMass) gets a fresh applier instead
// of being permanently latched out. Safe to call when nothing is running.
func (h *torExitHealth) stopLoop() {
	if h == nil {
		return
	}
	h.mu.Lock()
	ch := h.stop
	h.stop = nil // next run installs its own
	h.mu.Unlock()
	if ch != nil {
		close(ch)
	}
	h.started.Store(false)
}

func (h *torExitHealth) applyLoop() {
	// Take the channel installed by startTorExitSteering, not a shared field: a
	// stopLoop that already ran must not end a loop that starts afterwards.
	h.mu.Lock()
	stop := h.stop
	h.mu.Unlock()

	tick := time.NewTicker(torExitApplyEvery)
	defer tick.Stop()
	for {
		select {
		case <-stop:
			return
		case <-tick.C:
		case <-h.notify:
		}
		h.pruneExpired()

		h.mu.Lock()
		dirty, list := h.dirty, append([]string(nil), h.order...)
		ctls := make([]*torCtl, 0, len(h.ctls))
		for _, c := range h.ctls {
			ctls = append(ctls, c)
		}
		h.mu.Unlock()
		if !dirty || len(list) == 0 || len(ctls) == 0 {
			continue
		}
		applied := 0
		for _, c := range ctls {
			if err := c.exclude(list); err == nil {
				applied++
			}
		}
		if applied > 0 {
			h.mu.Lock()
			h.dirty = false
			h.mu.Unlock()
		}
	}
}

// pruneExpired forgets relays whose ban has aged out, so a long run (or a relay
// that got fixed upstream) is not locked out forever.
func (h *torExitHealth) pruneExpired() {
	cut := time.Now().Add(-torExitTTL)
	h.mu.Lock()
	defer h.mu.Unlock()
	for fp, st := range h.bad {
		if st.Last.Before(cut) {
			delete(h.bad, fp)
			if h.ban[fp] {
				delete(h.ban, fp)
				for i, o := range h.order {
					if o == fp {
						h.order = append(h.order[:i], h.order[i+1:]...)
						break
					}
				}
				h.dirty = true
			}
		}
	}
}

func (h *torExitHealth) badCount() int {
	h.mu.Lock()
	defer h.mu.Unlock()
	return len(h.bad)
}

func (h *torExitHealth) bannedList() []string {
	h.mu.Lock()
	defer h.mu.Unlock()
	return append([]string(nil), h.order...)
}

func (h *torExitHealth) isBanned(fp string) bool {
	if h == nil || fp == "" {
		return false
	}
	h.mu.Lock()
	defer h.mu.Unlock()
	return h.ban[fp]
}

// load reads the persisted blacklist (best effort: a broken file is ignored).
func (h *torExitHealth) load() {
	data, err := os.ReadFile(torExitBlacklistFile)
	if err != nil {
		return
	}
	cut := time.Now().Add(-torExitTTL)
	h.mu.Lock()
	defer h.mu.Unlock()
	for _, line := range strings.Split(string(data), "\n") {
		parts := strings.Split(strings.TrimSpace(line), "|")
		if len(parts) < 4 || !strings.HasPrefix(parts[0], "$") {
			continue
		}
		ts, err := strconv.ParseInt(parts[3], 10, 64)
		if err != nil {
			continue
		}
		last := time.Unix(ts, 0)
		if last.Before(cut) {
			continue
		}
		strikes, _ := strconv.Atoi(parts[2])
		// Reason is informational only; a legacy 4-column line (no reason field)
		// must be tolerated, not crash the whole run. `parts[4:][0]` panicked here
		// on exactly-4-field lines (index out of range).
		reason := ""
		if len(parts) >= 5 {
			reason = strings.TrimSpace(parts[4])
		}
		h.bad[parts[0]] = &exitStat{FP: parts[0], IP: parts[1], Strikes: strikes, Last: last, Reason: reason}
		if strikes >= torExitStrikesToBan {
			h.ban[parts[0]] = true
			h.order = append(h.order, parts[0])
		}
	}
	if len(h.order) > torExitMaxExcluded {
		// keep the most recently burned ones
		sort.SliceStable(h.order, func(i, j int) bool {
			return h.bad[h.order[i]].Last.Before(h.bad[h.order[j]].Last)
		})
		for _, drop := range h.order[:len(h.order)-torExitMaxExcluded] {
			delete(h.ban, drop)
		}
		h.order = h.order[len(h.order)-torExitMaxExcluded:]
	}
	if len(h.order) > 0 {
		h.dirty = true // re-apply to whatever Tor instance answers
	}
}

// save writes the blacklist atomically (temp file + rename).
func (h *torExitHealth) save() {
	h.mu.Lock()
	if time.Since(h.lastSave) < torExitSaveDebounce {
		h.mu.Unlock()
		return
	}
	h.lastSave = time.Now()
	lines := make([]string, 0, len(h.bad))
	for fp, st := range h.bad {
		lines = append(lines, fmt.Sprintf("%s|%s|%d|%d|%s", fp, st.IP, st.Strikes, st.Last.Unix(), st.Reason))
	}
	h.mu.Unlock()

	sort.Strings(lines)
	tmp := torExitBlacklistFile + ".tmp"
	if err := os.WriteFile(tmp, []byte(strings.Join(lines, "\n")+"\n"), 0o600); err != nil {
		return
	}
	_ = os.Rename(tmp, torExitBlacklistFile)
}

// flushSave forces a blacklist write immediately (bypassing the save debounce)
// so the last ban(s) recorded in a run are not lost when the process exits
// right after a block was applied.
func (h *torExitHealth) flushSave() {
	h.mu.Lock()
	dirty := h.dirty
	h.lastSave = time.Time{}
	h.mu.Unlock()
	if !dirty {
		return
	}
	h.save()
}

// exitHealthUser returns the SOCKS username of the client a worker is about to
// use, so a failed request can be traced back to its relay.
func (w *worker) torUserForAttempt(retry int) string {
	if w == nil || !w.torOn() {
		return ""
	}
	if retry == 0 {
		return fmt.Sprintf("w%d", w.id) // pinned client from newTorClient
	}
	return w.lastTorUser()
}
