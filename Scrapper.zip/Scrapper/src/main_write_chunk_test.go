package main

import (
	"bufio"
	"bytes"
	"fmt"
	"strings"
	"testing"
)

// writeLines now processes big batches in bounded chunks (writeLockChunk) so a
// tntcode payload cannot hold s.mu for hundreds of ms. This pins that the
// chunking is transparent: every accepted domain is still counted, written, and
// sampled.
func TestWriteLinesChunkedLargeBatch(t *testing.T) {
	var buf bytes.Buffer
	shared := &sharedState{
		apexDone:   map[string]bool{},
		apexCount:  map[string]int{},
		ipDone:     map[string]bool{},
		seedApexes: map[string]bool{},
		cancel:     func() {},
		w:          bufio.NewWriter(&buf),
	}
	w := &worker{shared: shared}

	n := writeLockChunk*3 + 7
	batch := make([]string, 0, n)
	for i := 0; i < n; i++ {
		// Unique apex per domain so the per-apex cap never trims the batch.
		batch = append(batch, fmt.Sprintf("h%d.example%d.com", i, i))
	}

	got := w.writeLines(batch)
	if got != n {
		t.Fatalf("writeLines accepted %d, want %d", got, n)
	}
	_ = shared.w.Flush()
	if lines := strings.Count(buf.String(), "\n"); lines != n {
		t.Fatalf("wrote %d lines, want %d", lines, n)
	}
	if len(shared.results) != n {
		t.Fatalf("sample pool has %d entries, want %d", len(shared.results), n)
	}
	if shared.count != int64(n) {
		t.Fatalf("count = %d, want %d", shared.count, n)
	}
}
