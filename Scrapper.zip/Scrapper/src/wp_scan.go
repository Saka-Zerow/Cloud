package main

import (
	"bufio"
	"context"
	"fmt"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"
)

// ---------------------------------------------------------------------------
// Menu 9: Scanning CMS WordPress massal
//
// Shell-out ke wp_scanner.exe (tool terpisah, module wp_scanner). Binary
// di-detect otomatis lewat env/path kandidat, dan dipanggil memakai flag
// non-interaktif supaya menu Scrapper yang jadi pengendali. Menu ini tidak
// mengubah perilaku tool lain di Scrapper.
// ---------------------------------------------------------------------------

// wpTag renders the "[wp]" marker used by every prompt in this menu.
func wpTag() string { return paint(colCyan, "[wp]") }

// askWP prints "[wp] Label [default]: " and reads one line.
func askWP(r *bufio.Reader, label, def string) string {
	if def != "" {
		fmt.Printf("%s %s [%s%s%s]: ", wpTag(), label, colYel, def, colRst)
	} else {
		fmt.Printf("%s %s: ", wpTag(), label)
	}
	s, _ := r.ReadString('\n')
	s = strings.Trim(strings.TrimSpace(strings.Trim(s, "\ufeff")), "\r")
	if s == "" {
		return def
	}
	return s
}

// wpScannerBinaryCandidates: lokasi wp_scanner.exe yang paling mungkin, urut prioritas.
func wpScannerBinaryCandidates() []string {
	var out []string
	if env := strings.TrimSpace(os.Getenv("WP_SCANNER_BIN")); env != "" {
		out = append(out, env)
	}
	if p, err := exec.LookPath("wp_scanner.exe"); err == nil {
		out = append(out, p)
	}
	// relatif terhadap cwd Scrapper (mode .\scraper.exe)
	out = append(out, filepath.Join("..", "Auto-Scan-CMS-WP", "wp_scanner.exe"))
	out = append(out, "wp_scanner.exe")
	// relatif terhadap lokasi scraper.exe (kalau dijalankan dari dalam src/)
	if exe, err := os.Executable(); err == nil {
		dir := filepath.Dir(exe)
		out = append(out,
			filepath.Join(dir, "..", "Auto-Scan-CMS-WP", "wp_scanner.exe"),
			filepath.Join(dir, "..", "..", "Auto-Scan-CMS-WP", "wp_scanner.exe"),
			filepath.Join(dir, "wp_scanner.exe"),
		)
	}
	if home, err := os.UserHomeDir(); err == nil {
		out = append(out, filepath.Join(home, "All-Tools-Lab-Security", "Auto-Scan-CMS-WP", "wp_scanner.exe"))
	}
	return out
}

// findWPScannerBinary: kandidat pertama yang benar-benar ada di disk.
func findWPScannerBinary() string {
	for _, c := range wpScannerBinaryCandidates() {
		if st, err := os.Stat(c); err == nil && !st.IsDir() {
			if abs, aerr := filepath.Abs(c); aerr == nil {
				return abs
			}
			return c
		}
	}
	return ""
}

// isWPOutput menandai artefak buatan menu ini sendiri (wp_scan_YYYYMMDD_HHMMSS.txt)
// supaya file hasil WordPress tidak pernah dijadikan target scan berikutnya.
func isWPOutput(name string) bool {
	name = strings.ToLower(name)
	if !strings.HasPrefix(name, "wp_scan_") || !strings.HasSuffix(name, ".txt") {
		return false
	}
	stamp := strings.TrimSuffix(strings.TrimPrefix(name, "wp_scan_"), ".txt")
	_, err := time.Parse("20060102_150405", stamp)
	return err == nil
}

// wpTargetCandidates: hasil scrape terbaru, tapi artefak WP sendiri dibuang.
func wpTargetCandidates(limit int) []string {
	var out []string
	// limit 0 = ambil semua kandidat dulu, baru saring artefak wp_scan_*.
	// Kalau memakai pool terbatas (limit*3), banyak file wp_scan_ bisa
	// menghabiskan pool dan menyisakan default target kosong.
	for _, c := range scraperResultCandidates(0) {
		if isWPOutput(filepath.Base(c)) {
			continue
		}
		out = append(out, c)
		if limit > 0 && len(out) >= limit {
			break
		}
	}
	return out
}

// runWPScanMenu menampilkan alur "Scanning CMS WordPress massal" dan menjalankan wp_scanner.
func runWPScanMenu(r *bufio.Reader) {
	waitEnter := func() {
		fmt.Print("\nTekan Enter untuk kembali ke menu...")
		r.ReadString('\n')
	}

	fmt.Println(paint(colPur, "== Scanning CMS WordPress massal (wp_scanner) =="))

	bin := findWPScannerBinary()
	fmt.Printf("%s Scanner : %s\n", wpTag(), paint(colDim, firstNonEmpty(bin, "tidak ditemukan")))
	fmt.Println()

	if bin == "" {
		fmt.Printf("%s %s\n", wpTag(), paint(colRed, "wp_scanner.exe tidak ditemukan."))
		fmt.Printf("%s %s\n", wpTag(), paint(colDim,
			"taruh di ..\\Auto-Scan-CMS-WP\\wp_scanner.exe, atau set env WP_SCANNER_BIN ke path lengkapnya."))
		waitEnter()
		return
	}

	// --- File target ------------------------------------------------------
	candidates := wpTargetCandidates(5)
	defaultTarget := ""
	if len(candidates) > 0 {
		defaultTarget = candidates[0]
	}

	targetFile := askWP(r, "File List Domain", defaultTarget)
	if targetFile == "" {
		fmt.Printf("%s %s\n", wpTag(), paint(colRed, "file target kosong, dibatalkan."))
		waitEnter()
		return
	}
	if st, err := os.Stat(targetFile); err != nil || st.IsDir() {
		fmt.Printf("%s %s\n", wpTag(), paint(colRed, fmt.Sprintf("file '%s' tidak ditemukan.", targetFile)))
		waitEnter()
		return
	}

	total := countTargets(targetFile)
	if total == 0 {
		fmt.Printf("%s %s\n", wpTag(), paint(colRed, fmt.Sprintf("file '%s' kosong / tanpa baris target.", targetFile)))
		if len(candidates) > 1 {
			fmt.Printf("%s %s\n", wpTag(), paint(colDim, "kandidat lain yang lebih baru:"))
			for _, c := range candidates[1:] {
				fmt.Printf("    %s\n", paint(colDim, c))
			}
		}
		fmt.Printf("%s %s\n", wpTag(), paint(colYel, "tip: jalankan dulu menu 1 (scraping) supaya ada hasil scrape baru."))
		waitEnter()
		return
	}

	// --- Opsi scan --------------------------------------------------------
	threads := 30
	for {
		v := strings.TrimSpace(askWP(r, "Concurrent threads (1-200)", "30"))
		if v == "" {
			break
		}
		if n, err := strconv.Atoi(v); err == nil && n >= 1 && n <= 200 {
			threads = n
			break
		}
		fmt.Printf("%s %s\n", wpTag(), paint(colRed, "masukkan angka 1-200."))
	}

	timeout := "8"
	for {
		v := strings.TrimSpace(askWP(r, "Timeout per request (detik)", "8"))
		if v == "" {
			break
		}
		if f, err := strconv.ParseFloat(v, 64); err == nil && f > 0 {
			timeout = v
			break
		}
		fmt.Printf("%s %s\n", wpTag(), paint(colRed, "masukkan angka detik > 0 (contoh: 8)."))
	}

	fastMode := strings.ToLower(strings.TrimSpace(askWP(r, "Mode Turbo Fast? [Y/n]", ""))) != "n"

	wp2 := strings.ToLower(strings.TrimSpace(askWP(r, "Cek wp2shell (non-destruktif)? [y/N]", "")))
	useWP2Shell := wp2 == "y" || wp2 == "ya" || wp2 == "yes"

	validSaveModes := map[string]bool{"clean_wp": true, "wp_only": true, "clean_vuln": true, "vuln_only": true, "all": true}
	saveMode := "clean_wp"
	for {
		v := strings.ToLower(strings.TrimSpace(askWP(r, "Save mode (clean_wp|wp_only|clean_vuln|vuln_only|all)", "clean_wp")))
		if v == "" {
			break
		}
		if validSaveModes[v] {
			saveMode = v
			break
		}
		fmt.Printf("%s %s\n", wpTag(), paint(colRed, "save mode tidak valid, pilih salah satu dari daftar."))
	}

	proxy := strings.TrimSpace(askWP(r, "HTTP proxy (kosongkan = direct)", ""))

	ts := time.Now().Format("20060102_150405")
	outFile := askWP(r, "Output file", filepath.Join("results", "wp_scan_"+ts+".txt"))
	if dir := filepath.Dir(outFile); dir != "" && dir != "." {
		_ = os.MkdirAll(dir, 0o755)
	}

	args := []string{"-f", targetFile, "-t", strconv.Itoa(threads), "-timeout", timeout, "-o", outFile, "-save-mode", saveMode}
	if fastMode {
		args = append(args, "--fast")
	}
	if useWP2Shell {
		args = append(args, "--wp2shell-check")
	}
	if proxy != "" {
		args = append(args, "--proxy", proxy)
	}

	fmt.Println()
	fmt.Printf("%s Target  : %s host — %s\n", wpTag(), paint(colGrn, human(int64(total))), paint(colDim, targetFile))
	fmt.Printf("%s Threads : %s\n", wpTag(), paint(colDim, strconv.Itoa(threads)))
	fmt.Printf("%s Mode    : %s\n", wpTag(), paint(colDim, map[bool]string{true: "turbo fast (short-circuit)", false: "standar"}[fastMode]))
	if useWP2Shell {
		fmt.Printf("%s wp2shell: %s\n", wpTag(), paint(colDim, "ON (non-destruktif)"))
	}
	fmt.Printf("%s Save    : %s\n", wpTag(), paint(colDim, saveMode))
	fmt.Printf("%s Proxy   : %s\n", wpTag(), paint(colDim, map[bool]string{true: proxy, false: "direct"}[proxy != ""]))
	fmt.Printf("%s Output  : %s\n", wpTag(), paint(colDim, outFile))
	fmt.Println()

	if strings.ToLower(strings.TrimSpace(askWP(r, "Mulai scan WordPress? [Y/n]", ""))) == "n" {
		fmt.Printf("%s %s\n", wpTag(), paint(colDim, "dibatalkan."))
		waitEnter()
		return
	}

	fmt.Printf("\n%s\n", paint(colGrn, "[ Load "+filepath.Base(targetFile)+" — scanning CMS WordPress massal ]"))
	fmt.Printf("%s %s\n\n", wpTag(), paint(colDim,
		"Heartbeat tiap 20 detik selama proses masih hidup — layar diam itu normal."))

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, os.Interrupt, syscall.SIGTERM)
	go func() {
		select {
		case <-sigCh:
			cancel()
		case <-ctx.Done():
		}
	}()
	defer signal.Stop(sigCh)

	cmd := exec.CommandContext(ctx, bin, args...)
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr

	start := time.Now()
	stopBeat := startHeartbeatTagged(wpTag(), start, "menunggu output wp_scanner")
	err := cmd.Run()
	stopBeat()
	fmt.Println()
	elapsed := time.Since(start).Truncate(time.Second)

	if err != nil {
		if ctx.Err() != nil {
			fmt.Printf("%s %s\n", wpTag(), paint(colYel, "scan WordPress dibatalkan oleh user."))
		} else {
			fmt.Printf("%s %s\n", wpTag(), paint(colYel, fmt.Sprintf("wp_scanner berhenti: %v", err)))
		}
	}
	found := countTargets(outFile)
	fmt.Printf("%s Selesai dalam %s. Target tersimpan: %s\n", wpTag(), elapsed, paint(colGrn, fmt.Sprintf("%d", found)))
	fmt.Printf("%s Hasil disimpan di: %s\n", wpTag(), paint(colCyan, outFile))

	waitEnter()
}
