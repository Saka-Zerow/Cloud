package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestValidateDebugToken(t *testing.T) {
	InitDebugToken("test-secret-key-123")

	// 1. Missing token
	req1 := httptest.NewRequest(http.MethodGet, "/api/debug/snapshot", nil)
	if ValidateDebugToken(req1) {
		t.Errorf("expected missing token to fail validation")
	}

	// 2. Wrong token
	req2 := httptest.NewRequest(http.MethodGet, "/api/debug/snapshot?token=wrong-key", nil)
	if ValidateDebugToken(req2) {
		t.Errorf("expected wrong token to fail validation")
	}

	// 3. Valid query token
	req3 := httptest.NewRequest(http.MethodGet, "/api/debug/snapshot?token=test-secret-key-123", nil)
	if !ValidateDebugToken(req3) {
		t.Errorf("expected valid query token to pass")
	}

	// 4. Valid header token
	req4 := httptest.NewRequest(http.MethodGet, "/api/debug/snapshot", nil)
	req4.Header.Set("X-Debug-Token", "test-secret-key-123")
	if !ValidateDebugToken(req4) {
		t.Errorf("expected valid header token to pass")
	}

	// 5. Valid Bearer token
	req5 := httptest.NewRequest(http.MethodGet, "/api/debug/snapshot", nil)
	req5.Header.Set("Authorization", "Bearer test-secret-key-123")
	if !ValidateDebugToken(req5) {
		t.Errorf("expected valid bearer token to pass")
	}
}

func TestDebugSnapshotEndpoint(t *testing.T) {
	InitDebugToken("admin-test-token")
	hub := NewDebugHub(50)
	hub.SetWorkerState(0, "CRT_FETCH", "example.com")
	hub.RecordFilterDecision("bad.vps123.com", "vps\\d+", "DROP_INFRA")
	hub.RecordFilterDecision("clean.example.com", "valid", "ACCEPT")

	snap := hub.Snapshot()
	if snap.TotalEvaluated != 2 {
		t.Errorf("expected totalEvaluated = 2, got %d", snap.TotalEvaluated)
	}
	if snap.TotalAccepted != 1 {
		t.Errorf("expected totalAccepted = 1, got %d", snap.TotalAccepted)
	}
	if snap.DropBreakdown["infra"] != 1 {
		t.Errorf("expected infra dropped = 1, got %d", snap.DropBreakdown["infra"])
	}

	mux := http.NewServeMux()
	RegisterDebugRoutes(mux)

	// Unauthorized test
	w1 := httptest.NewRecorder()
	r1 := httptest.NewRequest(http.MethodGet, "/api/debug/snapshot", nil)
	r1.Host = "127.0.0.1:9876"
	mux.ServeHTTP(w1, r1)
	if w1.Code != http.StatusUnauthorized {
		t.Errorf("expected 401 Unauthorized for missing token, got %d", w1.Code)
	}

	// Authorized test
	w2 := httptest.NewRecorder()
	r2 := httptest.NewRequest(http.MethodGet, "/api/debug/snapshot?token=admin-test-token", nil)
	r2.Host = "127.0.0.1:9876"
	mux.ServeHTTP(w2, r2)
	if w2.Code != http.StatusOK {
		t.Errorf("expected 200 OK for valid token, got %d", w2.Code)
	}

	var res DebugSnapshot
	if err := json.NewDecoder(w2.Body).Decode(&res); err != nil {
		t.Fatalf("failed to decode snapshot JSON: %v", err)
	}
	if res.Timestamp == "" {
		t.Errorf("expected non-empty timestamp in snapshot")
	}
}

func TestDebugActionEndpoint(t *testing.T) {
	InitDebugToken("admin-test-token")
	mux := http.NewServeMux()
	RegisterDebugRoutes(mux)

	body := strings.NewReader(`{"action":"trigger_gc"}`)
	req := httptest.NewRequest(http.MethodPost, "/api/debug/action?token=admin-test-token", body)
	req.Host = "127.0.0.1:9876"
	w := httptest.NewRecorder()
	mux.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("expected 200 OK for trigger_gc action, got %d: %s", w.Code, w.Body.String())
	}
	var res map[string]interface{}
	json.NewDecoder(w.Body).Decode(&res)
	if res["ok"] != true {
		t.Errorf("expected ok=true in action response, got %v", res)
	}
}
