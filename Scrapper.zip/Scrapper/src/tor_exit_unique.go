package main

import (
	"fmt"
	"net"
	"net/http"
	"sync"
	"time"

	"golang.org/x/net/proxy"
)

// --- One exit IP per worker (no two workers may share a Tor exit) ------------
//
// The old model gave every HTTP request a brand new SOCKS identity
// ("w<id>_<seq>"), which is great for dodging per-IP quotas but terrible for
// speed and for the "jangan ada worker yang IP Tor-nya sama" requirement:
//
//   - a new identity means a new circuit, so every request paid a fresh SOCKS
//     handshake + TLS handshake over Tor (~2-4s measured) and HTTP keep-alive
//     could never be used;
//   - nothing prevented two of the 50 workers from landing on the SAME exit IP,
//     which also re-burns the same crt.name quota twice.
//
// New model, per worker:
//
//  1. claim a circuit identity and force Tor to build it (warmExitCircuit);
//  2. ask the control port which relay served it and what its IP is
//     (tor_ctl.go already resolves STREAM SUCCEEDED -> circuit -> relay -> IP
//     without spending an application request);
//  3. register (fingerprint, IP) in the global registry. If another live worker
//     already owns it, hand that relay to Tor's ExcludeExitNodes and try again
//     with the next identity — so two workers can never share an exit IP;
//  4. keep that identity pinned for the life of the worker and REUSE the HTTP
//     client, so keep-alive works and requests get much faster.
//
// The exit is rotated only when the provider says so (crt.name 100 req/IP/day,
// rapiddns Cloudflare challenge): the burned relay is banned (exit steering) and
// the worker claims a new, still-unique exit and re-scans the same target.

const (
	// exitClaimTries bounds how many relays we try before giving up and falling
	// back to plain per-request isolation (no uniqueness guarantee, but never
	// stuck forever).
	exitClaimTries = 6
	// exitWarmTimeout bounds one warm-up SOCKS connect. Circuit build through
	// Tor is typically 1-3s; 4s is the ceiling, not the norm — a claim that hangs
	// longer than this would stall a worker inside a request path.
	exitWarmTimeout = 4 * time.Second
	// exitWarmTarget is a public IP:80 pair, so the warm-up is a bare TCP
	// connect (no TLS, no HTTP, no data) that only exists to make Tor build the
	// circuit and report its exit relay.
	exitWarmTarget = "1.1.1.1:80"
	// exitClaimBudget caps ONE whole claimUniqueExit call (all tries together).
	exitClaimBudget = 10 * time.Second
	// torSocksPass is THE SOCKS password everywhere: Tor's IsolateSOCKSAuth keys
	// a circuit on the (user, password) PAIR, so the identity that gets warmed
	// and claimed in the registry MUST be the same pair the HTTP client dials
	// with. Before this constant existed, warmExitCircuit used "warm" while
	// pinnedClient used "pin" — the claimed exit was NOT the exit traffic used,
	// which silently broke both the "1 worker = 1 exit IP" guarantee and the
	// per-IP cooldown keys. (The username stays unique per identity; the password
	// is constant because the username already carries the isolation.)
	torSocksPass = "iso"
)

type exitRegistry struct {
	mu       sync.Mutex
	byFP     map[string]int // relay fingerprint -> worker id
	byIP     map[string]int // relay IP -> worker id
	seenFP   map[string]bool // fingerprints seen this run (for fresh-exit preference)
	seenIP   map[string]bool // IPs seen this run
}

var exitUniq = &exitRegistry{
	byFP:   map[string]int{},
	byIP:   map[string]int{},
	seenFP: map[string]bool{},
	seenIP: map[string]bool{},
}

// claim reserves (fp, ip) for worker. It returns false when another live worker
// already holds the same relay/IP. Claims of the same worker are replaced, so a
// rotation never leaks an old entry.
// Prefers fresh exits (not seen this run) when possible.
func (r *exitRegistry) claim(fp, ip string, worker int) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.dropLocked(worker)
	if fp != "" {
		if owner, ok := r.byFP[fp]; ok && owner != worker {
			return false
		}
	}
	if ip != "" {
		if owner, ok := r.byIP[ip]; ok && owner != worker {
			return false
		}
	}
	// Track seen exits for fresh-exit preference
	if fp != "" {
		r.byFP[fp] = worker
		r.seenFP[fp] = true
	}
	if ip != "" {
		r.byIP[ip] = worker
		r.seenIP[ip] = true
	}
	return true
}

func (r *exitRegistry) dropLocked(worker int) {
	for k, v := range r.byFP {
		if v == worker {
			delete(r.byFP, k)
		}
	}
	for k, v := range r.byIP {
		if v == worker {
			delete(r.byIP, k)
		}
	}
}

// release forgets everything a worker held (worker exit / end of run).
func (r *exitRegistry) release(worker int) {
	r.mu.Lock()
	r.dropLocked(worker)
	r.mu.Unlock()
}

// owner reports which worker holds an exit (0 = free).
func (r *exitRegistry) owner(fp, ip string) int {
	r.mu.Lock()
	defer r.mu.Unlock()
	if fp != "" {
		if w, ok := r.byFP[fp]; ok {
			return w
		}
	}
	if ip != "" {
		if w, ok := r.byIP[ip]; ok {
			return w
		}
	}
	return 0
}

// count returns how many distinct exit IPs are currently pinned (this is the
// "worker nyata" metric: N unique exits == N workers looking out from N IPs).
func (r *exitRegistry) count() int {
	r.mu.Lock()
	defer r.mu.Unlock()
	return len(r.byIP)
}

func (r *exitRegistry) reset() {
	r.mu.Lock()
	r.byFP = map[string]int{}
	r.byIP = map[string]int{}
	r.seenFP = map[string]bool{}
	r.seenIP = map[string]bool{}
	r.mu.Unlock()
}

// deadlineDialer wraps a proxy.Dialer so every connection it hands out carries
// an absolute deadline.
//
// proxy.SOCKS5 has NO timeout of its own: the TCP connect to the Tor SOCKS port,
// the SOCKS greeting and the CONNECT reply (which waits for Tor to BUILD the
// circuit) can each block indefinitely. Stamping the deadline on the underlying
// conn covers all three, because the handshake runs over that same conn.
type deadlineDialer struct {
	base    proxy.Dialer
	timeout time.Duration
}

func (d deadlineDialer) Dial(network, addr string) (net.Conn, error) {
	c, err := d.base.Dial(network, addr)
	if err != nil {
		return nil, err
	}
	if err := c.SetDeadline(time.Now().Add(d.timeout)); err != nil {
		c.Close()
		return nil, err
	}
	return c, nil
}

// warmExitCircuit opens one bare SOCKS connection carrying `user`, which forces
// Tor to build the circuit that this isolation identity maps to. The connection
// is closed immediately; nothing is sent.
//
// Synchronous on purpose. The old version ran the dial in a goroutine and gave
// up after exitWarmTimeout — and that goroutine, with its half-open socket, kept
// running for as long as Tor felt like taking. Under a 50-worker fleet the
// stragglers piled up and competed with the live requests for Tor's limited
// circuit slots. Now the deadline lives on the socket, so the dial itself
// returns and nothing outlives the call.
func warmExitCircuit(socksAddr, user string) {
	if socksAddr == "" || user == "" {
		return
	}
	d, err := proxy.SOCKS5("tcp", socksAddr, &proxy.Auth{User: user, Password: torSocksPass},
		deadlineDialer{base: proxy.Direct, timeout: exitWarmTimeout})
	if err != nil {
		return
	}
	c, err := d.Dial("tcp", exitWarmTarget)
	if err == nil && c != nil {
		_ = c.Close()
	}
}

// pinExit stores the claimed exit on the worker and drops any previous HTTP
// client so the next request uses the new circuit with keep-alive.
func (w *worker) pinExit(user, fp, ip string) {
	if w == nil {
		return
	}
	w.pinMu.Lock()
	if old := w.pinClient; old != nil {
		if tr, ok := old.Transport.(*http.Transport); ok {
			tr.CloseIdleConnections()
		}
	}
	w.pinnedUser, w.exitFP, w.exitIP = user, fp, ip
	w.pinClient = nil
	w.pinMu.Unlock()
}

// releaseExit gives the claimed exit back (used before claiming a new one, and
// on worker shutdown). A scoped fallback copy must NEVER release: it shares the
// parent worker's id, so releasing would un-pin the live parent's exit while it
// is still serving traffic.
func (w *worker) releaseExit() {
	if w == nil || w.scopedCopy {
		return
	}
	w.pinMu.Lock()
	if old := w.pinClient; old != nil {
		if tr, ok := old.Transport.(*http.Transport); ok {
			tr.CloseIdleConnections()
		}
	}
	w.pinnedUser, w.exitFP, w.exitIP, w.pinClient = "", "", "", nil
	w.pinMu.Unlock()
	exitUniq.release(w.id)
}

// pinInfo returns the currently pinned identity (empty strings when unpinned).
func (w *worker) pinInfo() (user, fp, ip string) {
	if w == nil {
		return "", "", ""
	}
	w.pinMu.Lock()
	defer w.pinMu.Unlock()
	return w.pinnedUser, w.exitFP, w.exitIP
}

// hasPin reports whether the worker currently holds a claimed unique exit.
func (w *worker) hasPin() bool {
	if w == nil {
		return false
	}
	w.pinMu.Lock()
	defer w.pinMu.Unlock()
	return w.pinnedUser != ""
}

// currentExitUser is the SOCKS identity whose stream the NEXT request will use.
// Block attribution (tor_ctl.go) must be handed THIS name, otherwise a 429 is
// blamed on a relay the worker is not even using.
func (w *worker) currentExitUser() string {
	if user, _, _ := w.pinInfo(); user != "" {
		return user
	}
	return w.torUserForAttempt(0)
}


// pinnedClient returns the keep-alive HTTP client bound to the pinned exit
// identity. Because the SOCKS username is the isolation key, reusing this client
// keeps BOTH the circuit and the TCP/TLS connections: no new handshake per
// request, and the worker keeps looking out from the exact IP it claimed.
func (w *worker) pinnedClient() *http.Client {
	if w == nil {
		return nil
	}
	w.pinMu.Lock()
	defer w.pinMu.Unlock()
	if w.pinnedUser == "" {
		return nil
	}
	if w.pinClient != nil {
		return w.pinClient
	}
	dialer, err := proxy.SOCKS5("tcp", w.torAddr, &proxy.Auth{User: w.pinnedUser, Password: torSocksPass}, proxy.Direct)
	if err != nil {
		return nil
	}
	// DialContext, not Dial: this is the transport almost every request rides,
	// and dialer.Dial runs x/net's SOCKS handshake with context.Background(), so
	// a CONNECT that Tor accepts but never answers blocks its goroutine until the
	// socket dies. pprof on the debug server showed 84% of ~1.9k goroutines
	// parked in net/http.(*Transport).dialConn [IO wait] with ~325 goroutines/s
	// still being created. torDialContext carries a deadline down to x/net/socks
	// (it sets the socket deadline AND aborts the handshake when ctx is done).
	c := &http.Client{
		Transport: &http.Transport{
			DialContext:         torDialContext(dialer),
			MaxIdleConns:        16,
			MaxIdleConnsPerHost: 8,
			IdleConnTimeout:     120 * time.Second,
			TLSHandshakeTimeout: 10 * time.Second,
		},
		Timeout: httpTimeout,
	}
	w.pinClient = c
	return c
}

// claimUniqueExit pins this worker on an exit relay/IP that no other live worker
// holds. Returns false when it cannot be guaranteed (Tor off, no control port,
// or every tried relay was already taken) so the caller can fall back instead of
// stalling.
//
// Speed guard: claiming runs bounded warm-ups (not full requests) and takes at
// most exitClaimTries identities; a collision costs an extra warm-up, not a full
// banned circuit — collisions are recorded as strikes in the registry instead of
// as hard bans, because two workers landing on the same relay is routine when the
// fleet is small, not proof that the relay is dead.
//
// Prefers fresh exits (never seen this run) to maximize unique IP count.
func (w *worker) claimUniqueExit() bool {
	if w == nil || w.scopedCopy || !w.torOn() || w.torAddr == "" {
		return false
	}
	ctl := exitHealth.ctlFor(w.torAddr)
	if ctl == nil {
		return false // without a control port we cannot even read our own exit
	}
	// Overall budget: a claim runs INSIDE request paths (fetchCrtNameDirect
	// rotates up to 4x per limit), so unbounded warm-up retries would stall a
	// worker for tens of seconds. Give the whole claim one deadline; past it we
	// fall back to per-request isolation instead of freezing.
	deadline := time.Now().Add(exitClaimBudget)

	// Phase 1: Try fresh exits only (not seen this run)
	for try := 0; try < exitClaimTries && time.Now().Before(deadline); try++ {
		user := torCircuitUser(w.id)
		warmExitCircuit(w.torAddr, user)
		fp := ctl.exitForUser(user)
		if fp == "" {
			continue
		}
		if exitHealth.isBanned(fp) {
			if circ := ctl.circuitForUser(user); circ != "" {
				_ = ctl.closeCircuit(circ)
			}
			continue
		}
		ip := ctl.relayIP(fp)
		exitUniq.mu.Lock()
		seenFP := exitUniq.seenFP[fp]
		seenIP := exitUniq.seenIP[ip]
		exitUniq.mu.Unlock()
		if seenFP || seenIP {
			continue // skip seen exits in phase 1
		}
		if exitUniq.claim(fp, ip, w.id) {
			w.pinExit(user, fp, ip)
			guiLogQuiet("tor", "", 0, "[exit] w%d pinned fresh %s (%s) - 1 worker = 1 exit IP", w.id, orDash(ip), shortFP(fp))
			return true
		}
		exitUniq.noteCollision(fp)
	}

	// Phase 2: Fallback to any available exit (seen or not)
	for try := 0; try < exitClaimTries && time.Now().Before(deadline); try++ {
		user := torCircuitUser(w.id)
		warmExitCircuit(w.torAddr, user)
		fp := ctl.exitForUser(user)
		if fp == "" {
			continue
		}
		if exitHealth.isBanned(fp) {
			if circ := ctl.circuitForUser(user); circ != "" {
				_ = ctl.closeCircuit(circ)
			}
			continue
		}
		ip := ctl.relayIP(fp)
		if exitUniq.claim(fp, ip, w.id) {
			w.pinExit(user, fp, ip)
			guiLogQuiet("tor", "", 0, "[exit] w%d pinned ke %s (%s) - 1 worker = 1 exit IP", w.id, orDash(ip), shortFP(fp))
			return true
		}
		exitUniq.noteCollision(fp)
	}
	return false
}

// noteCollision records that a claimed identity was already owned by another
// live worker. Unlike a provider block this is normal contention, so it only
// nudges the relay's strike counter — the relay is excluded only if provider
// blocks keep proving it is actually bad.
func (r *exitRegistry) noteCollision(fp string) {
	if fp == "" {
		return
	}
	exitHealth.mu.Lock()
	st := exitHealth.bad[fp]
	if st == nil {
		st = &exitStat{FP: fp}
		exitHealth.bad[fp] = st
	}
	if st.Strikes < torExitStrikesToBan {
		st.Strikes++
	}
	st.Last = time.Now()
	exitHealth.dirty = true
	exitHealth.mu.Unlock()
}

// rotateExit releases the burned exit and claims a NEW unique one, which is what
// turns a provider "limit" into "auto ganti IP" instead of a stalled run.
func (w *worker) rotateExit() bool {
	if w == nil || w.scopedCopy || !w.torOn() {
		return false
	}
	if !w.rotating.CompareAndSwap(false, true) {
		return false // a rotation is already in flight inside this worker
	}
	defer w.rotating.Store(false)
	w.releaseExit()
	if w.claimUniqueExit() {
		return true
	}
	// No control port / no spare relay: fall back to a one-shot fresh identity
	// (inline — calling rotateTorClient from here would hit its own try-lock and
	// hand back the client we just released).
	c := w.torPickClient()
	w.torMu.Lock()
	w.client = c
	w.torMu.Unlock()
	return false
}

func orDash(s string) string {
	if s == "" {
		return "-"
	}
	return s
}

// describeExits is the end-of-run "worker nyata" summary: how many distinct Tor
// exits were in use at once AND how many were burned by provider limits.
func describeExits() string {
	burnedCrt, _, coolingCrt := crtNameGate.stats()
	burnedRapid, _, coolingRapid := rapidGate.stats()
	return fmt.Sprintf("exit unik aktif=%d, crt.name dibakar=%d (cooldown %d), rapiddns dibakar=%d (cooldown %d)",
		exitUniq.count(), burnedCrt, coolingCrt, burnedRapid, coolingRapid)
}

