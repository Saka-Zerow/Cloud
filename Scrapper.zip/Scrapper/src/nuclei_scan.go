package main

import (
	"bufio"
	"context"
	"fmt"
	"hash/fnv"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"sort"
	"strings"
	"syscall"
	"time"
)

// ---------------------------------------------------------------------------
// Menu 8: Scan Nuclei
//
// Nembak hasil scraper ke nuclei templates. Binary & template root di-detect
// otomatis, jadi operator tidak perlu mengetik path panjang.
// ---------------------------------------------------------------------------

const nucleiReset = "\x1b[0m"

// nucleiTag renders the "[-]" marker used by every prompt in this menu.
func nucleiTag() string { return paint(colCyan, "[-]") }

// askNuclei prints "\u005b-\u005d Label [default]: " and reads one line.
func askNuclei(r *bufio.Reader, label, def string) string {
	if def != "" {
		fmt.Printf("%s %s [%s%s%s]: ", nucleiTag(), label, colYel, def, nucleiReset)
	} else {
		fmt.Printf("%s %s: ", nucleiTag(), label)
	}
	s, _ := r.ReadString('\n')
	s = strings.Trim(strings.TrimSpace(strings.Trim(s, "\ufeff")), "\r")
	if s == "" {
		return def
	}
	return s
}

// nucleiBinaryCandidates: lokasi nuclei.exe yang paling mungkin, urut prioritas.
func nucleiBinaryCandidates() []string {
	var out []string
	if env := strings.TrimSpace(os.Getenv("NUCLEI_BIN")); env != "" {
		out = append(out, env)
	}
	if p, err := exec.LookPath("nuclei.exe"); err == nil {
		out = append(out, p)
	}
	if home, err := os.UserHomeDir(); err == nil {
		out = append(out, filepath.Join(home, "go", "bin", "nuclei.exe"))
		out = append(out, filepath.Join(home, "nuclei", "nuclei.exe"))
	}
	return out
}

func findNucleiBinary() string {
	for _, c := range nucleiBinaryCandidates() {
		if st, err := os.Stat(c); err == nil && !st.IsDir() {
			return c
		}
	}
	return ""
}

func findNucleiTemplatesRoot() string {
	if env := strings.TrimSpace(os.Getenv("NUCLEI_TEMPLATES")); env != "" {
		if st, err := os.Stat(env); err == nil && st.IsDir() {
			return env
		}
	}
	if home, err := os.UserHomeDir(); err == nil {
		for _, c := range []string{
			filepath.Join(home, "nuclei-templates"),
			filepath.Join(home, "nuclei", "nuclei-templates"),
		} {
			if st, err := os.Stat(c); err == nil && st.IsDir() {
				return c
			}
		}
	}
	return ""
}

// nucleiJunkFiles: file .txt yang bukan hasil scrape, biar tidak salah pilih.
var nucleiJunkFiles = map[string]bool{
	"url.txt":                true,
	"torports.txt":           true,
	"tor_exit_ports.txt":     true,
	"tor_exit_blacklist.txt": true,
	"rapiddns_sessions.txt":  true,
	"test_domains.txt":       true,
}

// isNucleiOutput menandai artefak buatan menu ini sendiri (nuclei_YYYYMMDD_HHMMSS.txt)
// supaya tidak pernah dijadikan target scan berikutnya.
func isNucleiOutput(name string) bool {
	name = strings.ToLower(name)
	if !strings.HasPrefix(name, "nuclei_") || !strings.HasSuffix(name, ".txt") {
		return false
	}
	stamp := strings.TrimSuffix(strings.TrimPrefix(name, "nuclei_"), ".txt")
	_, err := time.Parse("20060102_150405", stamp)
	return err == nil
}

// scraperResultCandidates mengembalikan file hasil scrape terbaru (hasil termuda
// dulu). Folder results/ dan folder kerja sama-sama dipindai.
func scraperResultCandidates(limit int) []string {
	type cand struct {
		path string
		mod  time.Time
	}
	var all []cand

	for _, dir := range []string{"results", "."} {
		entries, err := os.ReadDir(dir)
		if err != nil {
			continue
		}
		for _, e := range entries {
			if e.IsDir() || !strings.HasSuffix(strings.ToLower(e.Name()), ".txt") {
				continue
			}
			// artefak internal (cache live host) tidak pernah jadi target
			if strings.HasPrefix(e.Name(), ".") {
				continue
			}
			if nucleiJunkFiles[strings.ToLower(e.Name())] || isNucleiOutput(e.Name()) {
				continue
			}
			info, err := e.Info()
			if err != nil {
				continue
			}
			all = append(all, cand{filepath.Join(dir, e.Name()), info.ModTime()})
		}
	}

	sort.Slice(all, func(i, j int) bool { return all[i].mod.After(all[j].mod) })
	var out []string
	for _, c := range all {
		if limit > 0 && len(out) >= limit {
			break
		}
		out = append(out, filepath.Clean(c.path))
	}
	return out
}

// latestScraperResult: kandidat terbaru, dipakai sebagai nilai default.
func latestScraperResult() string {
	c := scraperResultCandidates(1)
	if len(c) == 0 {
		return ""
	}
	return c[0]
}

// countTargets hitung baris non-kosong sebuah file target.
func countTargets(path string) int {
	f, err := os.Open(path)
	if err != nil {
		return 0
	}
	defer f.Close()

	n := 0
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 0, 64*1024), 4*1024*1024)
	for sc.Scan() {
		if strings.TrimSpace(sc.Text()) != "" {
			n++
		}
	}
	return n
}

// nucleiElapsed format durasi jadi mm:ss (atau hh:mm:ss kalau lebih dari 1 jam).
func nucleiElapsed(d time.Duration) string {
	d = d.Truncate(time.Second)
	h := int(d.Hours())
	m := int(d.Minutes()) % 60
	s := int(d.Seconds()) % 60
	if h > 0 {
		return fmt.Sprintf("%02d:%02d:%02d", h, m, s)
	}
	return fmt.Sprintf("%02d:%02d", m, s)
}

// nucleiSeverity bersihin input severity jadi daftar lowercase tanpa spasi.
func nucleiSeverity(raw string) string {
	parts := strings.FieldsFunc(strings.ToLower(raw), func(r rune) bool {
		return r == ',' || r == ' ' || r == '/'
	})
	allowed := map[string]bool{"info": true, "low": true, "medium": true, "high": true, "critical": true, "unknown": true}
	var out []string
	seen := map[string]bool{}
	for _, p := range parts {
		if allowed[p] && !seen[p] {
			seen[p] = true
			out = append(out, p)
		}
	}
	return strings.Join(out, ",")
}

// runNucleiScanMenu menampilkan alur "Scan Nuclei" dan menjalankan nuclei.
func runNucleiScanMenu(r *bufio.Reader) {
	waitEnter := func() {
		fmt.Print("\nTekan Enter untuk kembali ke menu...")
		r.ReadString('\n')
	}

	fmt.Println(paint(colPur, "== Scan Nuclei (template CVE / kerentanan) =="))

	bin := findNucleiBinary()
	tplRoot := findNucleiTemplatesRoot()

	fmt.Printf("%s Nuclei    : %s\n", nucleiTag(), paint(colDim, firstNonEmpty(bin, "tidak ditemukan")))
	fmt.Printf("%s Templates : %s\n", nucleiTag(), paint(colDim, firstNonEmpty(tplRoot, "tidak terdeteksi (pakai default nuclei)")))
	fmt.Println()

	if bin == "" {
		fmt.Printf("%s %s\n", nucleiTag(), paint(colRed, "nuclei.exe tidak ditemukan — taruh di %USERPROFILE%\\go\\bin\\ atau set env NUCLEI_BIN."))
		waitEnter()
		return
	}

	// --- File target -------------------------------------------------------
	candidates := scraperResultCandidates(5)
	defaultTarget := ""
	if len(candidates) > 0 {
		defaultTarget = candidates[0]
	}

	targetFile := askNuclei(r, "File List Domain", defaultTarget)
	if targetFile == "" {
		fmt.Printf("%s %s\n", nucleiTag(), paint(colRed, "file target kosong, dibatalkan."))
		waitEnter()
		return
	}
	if st, err := os.Stat(targetFile); err != nil || st.IsDir() {
		fmt.Printf("%s %s\n", nucleiTag(), paint(colRed, fmt.Sprintf("file '%s' tidak ditemukan.", targetFile)))
		waitEnter()
		return
	}

	total := countTargets(targetFile)
	if total == 0 {
		fmt.Printf("%s %s\n", nucleiTag(), paint(colRed, fmt.Sprintf("file '%s' kosong / tanpa baris target.", targetFile)))
		if len(candidates) > 1 {
			fmt.Printf("%s %s\n", nucleiTag(), paint(colDim, "kandidat lain yang lebih baru:"))
			for _, c := range candidates[1:] {
				fmt.Printf("    %s\n", paint(colDim, c))
			}
		}
		fmt.Printf("%s %s\n", nucleiTag(), paint(colYel, "tip: jalankan dulu menu 1 (scraping) supaya ada hasil scrape baru."))
		waitEnter()
		return
	}

	// --- Tahap filter host hidup (opsional, hasilnya di-cache) -------------
	rawTargetFile, rawTotal := targetFile, total
	filtered := false

	fmt.Println()
	if httpxBin := findHTTPXBinary(); httpxBin != "" {
		fmt.Printf("%s %s\n", nucleiTag(), paint(colDim,
			"Filter dulu = nuclei hanya menembak host yang responsif."))
		fmt.Printf("%s %s\n", nucleiTag(), paint(colDim,
			"Terukur: 300 host -> 24-40 detik via httpx, vs 239 detik kalau nuclei probe sendiri."))
		if strings.ToLower(strings.TrimSpace(askNuclei(r, "Filter host hidup dengan httpx? [Y/n]", ""))) != "n" {
			if livePath, liveCount, ok := ensureLiveHosts(r, httpxBin, rawTargetFile, rawTotal); ok {
				targetFile, total, filtered = livePath, liveCount, true
			}
		}
	} else {
		fmt.Printf("%s %s\n", nucleiTag(), paint(colYel,
			"httpx.exe tidak ada — nuclei akan probe sendiri (jauh lebih lambat)."))
	}

	// --- Mode --------------------------------------------------------------
	fmt.Printf("%s %s\n", nucleiTag(), "Mode scan:")
	fmt.Println("1.CVE ID tertentu (contoh: CVE-2021-44228)")
	fmt.Println("2.Semua CVE satu tahun")
	fmt.Println("3.Semua template CVE")
	fmt.Println("4.Berdasarkan severity")
	fmt.Println("5.Semua template (paling lama)")
	mode := askNuclei(r, "Select [1-5]", "3")

	args := []string{"-l", targetFile}
	var modeLabel string
	switch mode {
	case "1":
		ids := strings.TrimSpace(askNuclei(r, "CVE ID (pisah koma)", "CVE-2021-44228"))
		if ids == "" {
			fmt.Printf("%s %s\n", nucleiTag(), paint(colRed, "CVE ID kosong, dibatalkan."))
			waitEnter()
			return
		}
		args = append(args, "-id", ids)
		modeLabel = "CVE ID: " + ids
	case "2":
		year := strings.TrimSpace(askNuclei(r, "Tahun CVE", "2024"))
		if tplRoot == "" {
			fmt.Printf("%s %s\n", nucleiTag(), paint(colRed, "folder template tidak terdeteksi, mode tahun tidak bisa dipakai."))
			waitEnter()
			return
		}
		dir := filepath.Join(tplRoot, "http", "cves", year)
		if st, err := os.Stat(dir); err != nil || !st.IsDir() {
			fmt.Printf("%s %s\n", nucleiTag(), paint(colRed, fmt.Sprintf("template tahun %s tidak ada (%s).", year, dir)))
			waitEnter()
			return
		}
		args = append(args, "-t", dir)
		modeLabel = "CVE tahun " + year
	case "4":
		sev := nucleiSeverity(askNuclei(r, "Severity (critical,high,medium,low,info)", "critical,high"))
		if sev == "" {
			fmt.Printf("%s %s\n", nucleiTag(), paint(colRed, "severity tidak valid, dibatalkan."))
			waitEnter()
			return
		}
		args = append(args, "-s", sev)
		modeLabel = "severity " + sev
	case "5":
		modeLabel = "semua template"
	default:
		if tplRoot == "" {
			fmt.Printf("%s %s\n", nucleiTag(), paint(colRed, "folder template tidak terdeteksi, mode semua CVE tidak bisa dipakai."))
			waitEnter()
			return
		}
		args = append(args, "-t", filepath.Join(tplRoot, "http", "cves"))
		modeLabel = "semua template CVE"
	}

	// --- Proxy + output ----------------------------------------------------
	torLine := strings.ToLower(strings.TrimSpace(askNuclei(r, "Pakai Tor proxy (socks5 127.0.0.1:9050)? [y/N]", "")))
	useTor := torLine == "y" || torLine == "ya" || torLine == "yes"

	ts := time.Now().Format("20060102_150405")
	outFile := askNuclei(r, "Output file", filepath.Join("results", "nuclei_"+ts+".txt"))
	if dir := filepath.Dir(outFile); dir != "" && dir != "." {
		_ = os.MkdirAll(dir, 0o755)
	}

	args = append(args,
		"-o", outFile,
		"-nc", "-duc", "-stats", "-si", "5",
		"-c", "150", "-rl", "1000", "-bs", "50",
		"-timeout", "5", "-retries", "1", "-mhe", "30",
		"-prc", "150", "-tlc", "150",
	)
	if useTor {
		args = append(args, "-proxy", "socks5://127.0.0.1:9050")
	}
	if filtered {
		args = append(args, "-nh")
	}

	fmt.Println()
	fmt.Printf("%s Mode   : %s\n", nucleiTag(), paint(colGrn, modeLabel))
	if filtered {
		fmt.Printf("%s Target : %s host hidup — %s\n", nucleiTag(), paint(colGrn, human(int64(total))), paint(colDim, targetFile))
		fmt.Printf("%s          %s\n", nucleiTag(), paint(colDim, fmt.Sprintf(
			"difilter dari %s host (%s)", human(int64(rawTotal)), filepath.Base(rawTargetFile))))
	} else {
		fmt.Printf("%s Target : %s host — %s\n", nucleiTag(), paint(colGrn, human(int64(total))), paint(colDim, targetFile))
	}
	fmt.Printf("%s Output : %s\n", nucleiTag(), paint(colDim, outFile))
	fmt.Printf("%s Proxy  : %s\n", nucleiTag(), paint(colDim, map[bool]string{true: "socks5://127.0.0.1:9050", false: "direct"}[useTor]))
	fmt.Printf("%s Probing: %s\n", nucleiTag(), paint(colDim, map[bool]string{
		true:  "dilewati di nuclei (-nh) — daftar sudah terverifikasi hidup",
		false: "httpx internal nuclei (tahap awal, bisa lama tanpa output)",
	}[filtered]))
	fmt.Println()

	if strings.ToLower(strings.TrimSpace(askNuclei(r, "Mulai scan? [Y/n]", ""))) == "n" {
		fmt.Printf("%s %s\n", nucleiTag(), paint(colDim, "dibatalkan."))
		waitEnter()
		return
	}

	fmt.Printf("\n%s\n", paint(colGrn, "[ Load "+filepath.Base(targetFile)+" — scanning dengan nuclei ]"))
	fmt.Printf("%s %s\n\n", nucleiTag(), paint(colDim,
		"Heartbeat tiap 20 detik selama proses masih hidup — layar diam itu normal."))

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, os.Interrupt, syscall.SIGTERM)
	go func() {
		select {
		case <-sigCh:
			cancel()
		case <-ctx.Done():
		}
	}()
	defer signal.Stop(sigCh)

	cmd := exec.CommandContext(ctx, bin, args...)
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr

	start := time.Now()
	stopBeat := startHeartbeat(start, "menunggu output nuclei (fase probing/scan)")
	err := cmd.Run()
	stopBeat()
	fmt.Println()
	elapsed := time.Since(start).Truncate(time.Second)

	if err != nil {
		if ctx.Err() != nil {
			fmt.Printf("%s %s\n", nucleiTag(), paint(colYel, "scan nuclei dibatalkan oleh user."))
		} else {
			fmt.Printf("%s %s\n", nucleiTag(), paint(colYel, fmt.Sprintf("nuclei berhenti: %v", err)))
		}
	}

	found := 0
	if f, ferr := os.Open(outFile); ferr == nil {
		sc := bufio.NewScanner(f)
		sc.Buffer(make([]byte, 0, 64*1024), 4*1024*1024)
		for sc.Scan() {
			if strings.TrimSpace(sc.Text()) != "" {
				found++
			}
		}
		f.Close()
	}
	fmt.Printf("%s Selesai dalam %s. Temuan: %s\n", nucleiTag(), elapsed, paint(colGrn, fmt.Sprintf("%d", found)))
	fmt.Printf("%s Hasil disimpan di: %s\n", nucleiTag(), paint(colCyan, outFile))

	waitEnter()
}

// ---------------------------------------------------------------------------
// Pra-filter host hidup (opsional, pipa httpx -> nuclei)
// ---------------------------------------------------------------------------

// findHTTPXBinary: httpx.exe opsional, dipakai hanya untuk pra-filter.
func findHTTPXBinary() string {
	if env := strings.TrimSpace(os.Getenv("HTTPX_BIN")); env != "" {
		if st, err := os.Stat(env); err == nil && !st.IsDir() {
			return env
		}
	}
	if p, err := exec.LookPath("httpx.exe"); err == nil {
		return p
	}
	if home, err := os.UserHomeDir(); err == nil {
		c := filepath.Join(home, "go", "bin", "httpx.exe")
		if st, err := os.Stat(c); err == nil && !st.IsDir() {
			return c
		}
	}
	return ""
}

// liveCachePath: satu file cache per file sumber (path-based, supaya hasilnya
// tetap terakumulasi walau file sumber bertambah isinya).
func liveCachePath(src string) string {
	abs, err := filepath.Abs(src)
	if err != nil {
		abs = src
	}
	h := fnv.New64a()
	_, _ = h.Write([]byte(strings.ToLower(abs)))
	return filepath.Join("results", fmt.Sprintf(".live_%x.txt", h.Sum64()))
}

// readHostSet baca daftar host/URL jadi himpunan unik (aman untuk CRLF).
func readHostSet(path string) map[string]struct{} {
	set := map[string]struct{}{}
	f, err := os.Open(path)
	if err != nil {
		return set
	}
	defer f.Close()

	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 0, 64*1024), 8*1024*1024)
	for sc.Scan() {
		line := strings.Trim(strings.TrimSpace(strings.Trim(sc.Text(), "\ufeff")), "\r")
		if line != "" {
			set[line] = struct{}{}
		}
	}
	return set
}

// writeHostSet tulis himpunan host secara deterministik (urut, LF).
func writeHostSet(path string, set map[string]struct{}) {
	lines := make([]string, 0, len(set))
	for h := range set {
		lines = append(lines, h)
	}
	sort.Strings(lines)
	if dir := filepath.Dir(path); dir != "" && dir != "." {
		_ = os.MkdirAll(dir, 0o755)
	}
	_ = os.WriteFile(path, []byte(strings.Join(lines, "\n")+"\n"), 0o644)
}

// cacheAge: umur cache dalam teks pendek.
func cacheAge(path string) string {
	st, err := os.Stat(path)
	if err != nil {
		return "?"
	}
	d := time.Since(st.ModTime()).Truncate(time.Minute)
	if d < time.Minute {
		return "baru saja"
	}
	return fmt.Sprintf("%s lalu", d)
}

// startHeartbeat cetak bukti hidup tiap 20 detik sampai fungsi kembaliannya dipanggil.
func startHeartbeat(start time.Time, label string) func() {
	return startHeartbeatTagged(nucleiTag(), start, label)
}

// startHeartbeatTagged sama seperti startHeartbeat, tapi tag "[-]/[wp]/..." bisa
// ditentukan pemanggil supaya konsisten dengan menu yang sedang aktif.
func startHeartbeatTagged(tag string, start time.Time, label string) func() {
	done := make(chan struct{})
	go func() {
		ticker := time.NewTicker(20 * time.Second)
		defer ticker.Stop()
		for {
			select {
			case <-done:
				return
			case <-ticker.C:
				fmt.Printf("%s %s\n", tag, paint(colDim,
					fmt.Sprintf("masih berjalan %s — %s", nucleiElapsed(time.Since(start)), label)))
			}
		}
	}()
	return func() { close(done) }
}

// ensureLiveHosts menyiapkan daftar host hidup lewat httpx.
//
// PENTING: hasil tiap pass DIGABUNG (union) dengan cache, tidak pernah
// menggantikan. Pengukuran menunjukkan satu pass httpx hanya menangkap sebagian
// host yang sebenarnya hidup (82/46/87 dari 300 host yang sama, overlap cuma
// ~separuh), jadi mengganti cache akan membuang host secara diam-diam.
func ensureLiveHosts(r *bufio.Reader, httpxBin, src string, srcTotal int) (string, int, bool) {
	cache := liveCachePath(src)
	known := readHostSet(cache)

	if len(known) > 0 {
		fmt.Printf("%s Live   : %s host (cache %s)\n", nucleiTag(),
			paint(colGrn, human(int64(len(known)))), cacheAge(cache))
		if strings.ToLower(strings.TrimSpace(
			askNuclei(r, "Probe ulang untuk menambah host baru (union)? [y/N]", ""))) != "y" {
			return cache, len(known), true
		}
	}

	tmp := cache + ".pass"
	_ = os.Remove(tmp)

	fmt.Printf("\n%s %s\n", nucleiTag(), paint(colGrn, "[ httpx — memfilter host hidup dari "+filepath.Base(src)+" ]"))
	fmt.Printf("%s %s\n\n", nucleiTag(), paint(colDim,
		"Baris yang muncul = host hidup. Heartbeat tiap 20 detik."))

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, os.Interrupt, syscall.SIGTERM)
	go func() {
		select {
		case <-sigCh:
			cancel()
		case <-ctx.Done():
		}
	}()
	defer signal.Stop(sigCh)

	cmd := exec.CommandContext(ctx, httpxBin, "-l", src, "-silent", "-nc", "-o", tmp,
		"-timeout", "5", "-retries", "1")
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr

	start := time.Now()
	stopBeat := startHeartbeat(start, "menunggu httpx")
	err := cmd.Run()
	stopBeat()
	fmt.Println()

	pass := readHostSet(tmp)
	_ = os.Remove(tmp)

	if err != nil {
		fmt.Printf("%s %s\n", nucleiTag(), paint(colYel, fmt.Sprintf("httpx berhenti: %v", err)))
	}
	for h := range pass {
		known[h] = struct{}{}
	}
	if len(known) == 0 {
		fmt.Printf("%s %s\n", nucleiTag(), paint(colRed,
			"httpx tidak menemukan host hidup — filter dibatalkan, nuclei pakai daftar asli."))
		return "", 0, false
	}

	writeHostSet(cache, known)

	ratio := 0.0
	if srcTotal > 0 {
		ratio = float64(len(known)) / float64(srcTotal) * 100
	}
	fmt.Printf("%s %s\n", nucleiTag(), paint(colGrn, fmt.Sprintf(
		"Live   : %s dari %s host (%.1f%%) — pass ini menambah %s host baru",
		human(int64(len(known))), human(int64(srcTotal)), ratio, human(int64(len(pass))))))
	fmt.Printf("%s %s\n", nucleiTag(), paint(colDim, "daftar live disimpan di "+cache))

	return cache, len(known), true
}
