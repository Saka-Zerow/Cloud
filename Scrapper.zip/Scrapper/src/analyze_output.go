package main

import (
	"bufio"
	"fmt"
	"net"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
)

// junkReason mirrors filterValid's drop rules and returns the reason a domain
// is dropped ("" if it is a clean, keep-worthy domain). Used by -clean so the
// offline cleaning tool and the live scraper share one source of truth.
func junkReason(d string) string {
	d = strings.ToLower(strings.TrimSpace(strings.TrimPrefix(d, "*.")))
	if d == "" || strings.Contains(d, "*") {
		return "syntax"
	}
	if net.ParseIP(d) != nil {
		return "ip"
	}
	if !isValidDomain(d) {
		return "syntax"
	}
	if isBigTechOrPaaS(d) {
		return "bigtech/paas"
	}
	if isProvisioningSpam(d) {
		return "provisioning"
	}
	if isGarbageDomain(d) {
		return "garbage/dga/multi-digit"
	}
	if !keepInfra && isInfraNoise(d) {
		return "infra"
	}
	return ""
}

// cleanOutput reads a result file, drops junk domains, and writes two files:
// <name>.clean.txt (deduped, kept) and <name>.junk.txt (dropped, with reason).
func cleanOutput(path string) {
	f, err := os.Open(path)
	if err != nil {
		fmt.Fprintf(os.Stderr, "clean: %v\n", err)
		return
	}
	defer f.Close()

	base := strings.TrimSuffix(path, filepath.Ext(path))
	cleanF, err := os.Create(base + ".clean.txt")
	if err != nil {
		fmt.Fprintf(os.Stderr, "clean: %v\n", err)
		return
	}
	defer cleanF.Close()
	junkF, err := os.Create(base + ".junk.txt")
	if err != nil {
		fmt.Fprintf(os.Stderr, "clean: %v\n", err)
		return
	}
	defer junkF.Close()

	seenClean := map[string]bool{}
	seenJunk := map[string]bool{}
	reasons := map[string]int{}
	total := 0
	// First pass: offline classification, collecting clean candidates and the
	// distinct apexes they belong to (for the wildcard probe below).
	var cleanLines []string
	cleanApexes := map[string]bool{}
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1024*1024), 1024*1024)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		total++
		if r := junkReason(line); r != "" {
			reasons[r]++
			if !seenJunk[line] {
				seenJunk[line] = true
				fmt.Fprintf(junkF, "%s\t# %s\n", line, r)
			}
		} else if !seenClean[line] {
			seenClean[line] = true
			cleanLines = append(cleanLines, line)
			if a := apexOf(line); a != "" {
				cleanApexes[a] = true
			}
		}
	}
	// A scan error (or a line past the 1MB buffer cap) used to be swallowed: the
	// clean pass then wrote a SHORT file and printed a total that looked normal.
	// Report it and refuse to write the truncated result.
	if err := sc.Err(); err != nil {
		// Close before removing: Windows os.Create opens WITHOUT
		// FILE_SHARE_DELETE, so a Remove on the still-open handle fails and would
		// leave the truncated file behind. The deferred Closes then run a second
		// time, which is a harmless no-op.
		cleanF.Close()
		junkF.Close()
		os.Remove(base + ".clean.txt")
		os.Remove(base + ".junk.txt")
		fmt.Fprintf(os.Stderr, "clean: baca %s gagal: %v (output tidak ditulis)\n", path, err)
		return
	}

	// Second pass: probe wildcard DNS concurrently (one DoH query per distinct
	// apex). Wildcarded apexes resolve any subdomain, so their hosts are fake.
	if len(cleanApexes) > 0 {
		wildApex := sync.Map{}
		var wg sync.WaitGroup
		sem := make(chan struct{}, 24)
		for a := range cleanApexes {
			wg.Add(1)
			go func(a string) {
				defer wg.Done()
				sem <- struct{}{}
				defer func() { <-sem }()
				if isWildcardDomain(a) {
					wildApex.Store(a, true)
				}
			}(a)
		}
		wg.Wait()

		// Move wildcarded-apex hosts from clean to junk.
		var kept []string
		for _, line := range cleanLines {
			a := apexOf(line)
			if a != "" {
				if _, bad := wildApex.Load(a); bad {
					reasons["wildcard"]++
					if !seenJunk[line] {
						seenJunk[line] = true
						fmt.Fprintf(junkF, "%s\t# wildcard\n", line)
					}
					continue
				}
			}
			kept = append(kept, line)
		}
		cleanLines = kept
	}

	for _, line := range cleanLines {
		fmt.Fprintln(cleanF, line)
	}
	// cleanLines, not seenClean: the wildcard pass above MOVES hosts out of
	// cleanLines into the junk file, so len(seenClean) over-reported the clean
	// count by exactly the number of wildcard hosts dropped from THIS file.
	fmt.Printf("total=%d  clean=%d  junk=%d\n", total, len(cleanLines), len(seenJunk))
	type kv struct {
		k string
		v int
	}
	var kvs []kv
	for k, v := range reasons {
		kvs = append(kvs, kv{k, v})
	}
	sort.Slice(kvs, func(i, j int) bool { return kvs[i].v > kvs[j].v })
	for _, e := range kvs {
		fmt.Printf("  %-18s %d\n", e.k, e.v)
	}
	fmt.Printf("clean -> %s\njunk  -> %s\n", base+".clean.txt", base+".junk.txt")
}

// postProcessAction menjalankan aksi post-processing hasil scrape dari menu 2.
// act: "0"=batal, "1"=bersihkan, "2"=analisis, "" atau "3"=keduanya.
// Mengembalikan tahap yang benar-benar dijalankan supaya pemetaan aksi bisa
// diuji tanpa menyentuh stdin.
func postProcessAction(filePath, act string) (cleaned, analyzed bool) {
	switch strings.TrimSpace(act) {
	case "0":
		return false, false
	case "1":
		cleanOutput(filePath)
		return true, false
	case "2":
		analyzeOutput(filePath)
		return false, true
	default:
		cleanOutput(filePath)
		analyzeOutput(filePath)
		return true, true
	}
}

func analyzeOutput(resPath string) {
	f, err := os.Open(resPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "analyze: %v\n", err)
		return
	}
	defer f.Close()

	firstLabel := map[string]int{}
	fourthLabel := map[string]int{}
	total := 0

	// Categories of junk
	netUser := 0     // net\d+-user\d+
	cpanelSubs := 0  // cpcalendars, cpcontacts
	hostingPlan := 0 // vps\d, ded\d, srv\d etc

	// Known cPanel auto-generated subdomains
	cpanelJunk := map[string]bool{
		"cpcalendars": true, "cpcontacts": true, "webdisk": true,
		"cpanel": true, "whm": true, "webmail": true,
		"cprwhois": true, "ftp": true, "cpanelproxy": true,
	}

	// Known hosting plan prefixes
	infraPrefixes := []string{
		"vps", "srv", "server", "dedi", "dedicated", "vds", "node",
		"ded", "cc", "secure", "ecbiz", "biz", "advanced", "sudo",
		"elite", "ld", "ecngx", "gs", "ngx", "sb", "bizdev",
		"amsngx", "ecld", "cloud", "reseller", "shared", "semi",
		"host",
	}

	// Service prefixes that are legit (not infra)
	legitPrefixes := map[string]bool{
		"www": true, "mail": true, "smtp": true, "pop": true,
		"imap": true, "ns": true, "dns": true, "mx": true,
		"autodiscover": true, "autoconfig": true, "sip": true,
		"lyncdiscover": true, "api": true, "portal": true,
		"dev": true, "test": true, "staging": true, "stage": true,
		"uat": true, "admin": true, "remote": true, "vpn": true,
		"intranet": true, "origin": true, "maps": true,
		"wildcard": true, "stg": true, "apps": true,
	}

	scanner := bufio.NewScanner(f)
	// Same 1MB cap as cleanOutput: an enlarged-line result file used to abort the
	// scan at 64KB silently and report a total that was short by thousands.
	scanner.Buffer(make([]byte, 1024*1024), 1024*1024)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}
		total++
		parts := strings.Split(line, ".")
		if len(parts) < 3 {
			continue
		}

		first := parts[0]
		firstLabel[first]++

		// net\d+-user\d+ pattern
		if strings.HasPrefix(first, "net") && strings.Contains(first, "-user") {
			netUser++
			continue
		}

		// cPanel auto-generated subdomains
		if cpanelJunk[first] {
			cpanelSubs++
			continue
		}

		// Check hosting plan pattern: prefix + digits
		hasDigit := false
		for _, c := range first {
			if c >= '0' && c <= '9' {
				hasDigit = true
				break
			}
		}
		if hasDigit && !legitPrefixes[first] {
			for _, p := range infraPrefixes {
				if strings.HasPrefix(first, p) {
					hostingPlan++
					break
				}
			}
		}

		if len(parts) >= 5 {
			fourth := parts[len(parts)-4]
			fourthLabel[fourth]++
		}
	}
	// The statistics below are only meaningful over a complete file; say so
	// instead of printing percentages of a truncated one.
	if err := scanner.Err(); err != nil {
		fmt.Fprintf(os.Stderr, "analyze: baca %s gagal: %v (statistik di bawah TIDAK lengkap)\n", resPath, err)
	}

	type kv struct {
		Key   string
		Value int
	}

	fmt.Printf("Total lines: %d\n\n", total)
	fmt.Printf("=== JUNK CATEGORIES ===\n")
	fmt.Printf("  net\\d+-user\\d+ pattern: %d\n", netUser)
	fmt.Printf("  cPanel auto-subs:      %d\n", cpanelSubs)
	fmt.Printf("  Hosting plan prefix:   %d\n", hostingPlan)
	fmt.Printf("  TOTAL JUNK:            %d\n\n", netUser+cpanelSubs+hostingPlan)

	fmt.Println("=== First label (top 40) ===")
	sorted1 := make([]kv, 0, len(firstLabel))
	for k, v := range firstLabel {
		sorted1 = append(sorted1, kv{k, v})
	}
	sort.Slice(sorted1, func(i, j int) bool { return sorted1[i].Value > sorted1[j].Value })
	for i := 0; i < 40 && i < len(sorted1); i++ {
		fmt.Printf("  %-30s %d\n", sorted1[i].Key, sorted1[i].Value)
	}

	fmt.Println("\n=== 4th-level labels (top 20) ===")
	sorted2 := make([]kv, 0, len(fourthLabel))
	for k, v := range fourthLabel {
		sorted2 = append(sorted2, kv{k, v})
	}
	sort.Slice(sorted2, func(i, j int) bool { return sorted2[i].Value > sorted2[j].Value })
	for i := 0; i < 20 && i < len(sorted2); i++ {
		fmt.Printf("  %-30s %d\n", sorted2[i].Key, sorted2[i].Value)
	}
}
