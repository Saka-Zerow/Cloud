package main

import (
	"os"
	"path/filepath"
	"sync"
	"testing"
)

func TestRapidSessionPool_Basic(t *testing.T) {
	pool := NewRapidSessionPool()
	if pool.Count() != 0 {
		t.Fatalf("expected 0 sessions, got %d", pool.Count())
	}

	tok1 := ".eJwtjttOg0AURf9lnk3DDCnavlHiwMECYhguvhCYYjjcLVYsjf8uDb6vtfa-kUzKYhzTr74uOrInxdUuc1OihzaIGaiLMEL3tpUGaFAPcWjYu80CUcnCa8yaGqr-x51rejTsJo_4kN_Bzi0zxrX32P72Ta7kjA4Jo2UWTZcsesKFXX11CZviPtbKNmwAJ8wirvw3J6dKFCdY24Wlo1c9q16gz26gUy8Q67HVLxPmNlJ18MPfvEyD6uvYQ6in7XgQan6y4OgcOjxbUCkT1_hn2Qv-6jnkgVzG4pziiezp4277-wcNqVqT.arVDgw.OsIV7DG6Hf450npLHwlMByeAn7A"
	tok2 := ".eJwtkttOg1AQRf9ln81A55o2PqDFQk2p1dZlqW1rCjRj3B1WLP13x1rT_b7mXp9IJpMwS5f8q5q1x3iGvS9kZlKszA0xK1Gq0yM-m0Y6qIEM5q7l163Bw6U3-M1x-14-1e0eT8y585w5NdfY_f5u9_nJm9zXfJqGk40d2M-qL-O5u1t-r0-O_PZ5G7m-eL74u68n37v-4wX9Xw.ABC123.Xyz987"

	// 1. Add session with "session=" prefix
	if !pool.AddSession("session=" + tok1) {
		t.Fatalf("expected tok1 to be added")
	}
	if pool.Count() != 1 {
		t.Fatalf("expected 1 session, got %d", pool.Count())
	}

	// 2. Duplicate add should return false
	if pool.AddSession(tok1) {
		t.Fatalf("expected duplicate tok1 to be rejected")
	}

	// 3. Add second session
	if !pool.AddSession(tok2) {
		t.Fatalf("expected tok2 to be added")
	}
	if pool.Count() != 2 {
		t.Fatalf("expected 2 sessions, got %d", pool.Count())
	}

	// 4. Test Round-Robin rotation
	t1, h1 := pool.GetSession()
	t2, h2 := pool.GetSession()
	t3, h3 := pool.GetSession()
	t4, h4 := pool.GetSession()

	if t1 != tok1 || h1 != "session="+tok1 {
		t.Errorf("round-robin step 1 mismatch: got %v", t1)
	}
	if t2 != tok2 || h2 != "session="+tok2 {
		t.Errorf("round-robin step 2 mismatch: got %v", t2)
	}
	if t3 != tok1 || h3 != "session="+tok1 {
		t.Errorf("round-robin step 3 mismatch: got %v", t3)
	}
	if t4 != tok2 || h4 != "session="+tok2 {
		t.Errorf("round-robin step 4 mismatch: got %v", t4)
	}

	// 5. Test RemoveSession
	if !pool.RemoveSession(tok1) {
		t.Errorf("failed to remove tok1")
	}
	if pool.Count() != 1 {
		t.Errorf("expected 1 session after removal, got %d", pool.Count())
	}

	// 6. Test MaskSession
	masked := MaskSession(tok1)
	if masked == tok1 || len(masked) > 20 {
		t.Errorf("expected masked preview, got %s", masked)
	}
}

func TestRapidSessionPool_Concurrent(t *testing.T) {
	pool := NewRapidSessionPool()
	pool.AddSession("token-A")
	pool.AddSession("token-B")
	pool.AddSession("token-C")

	var wg sync.WaitGroup
	for i := 0; i < 50; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := 0; j < 100; j++ {
				tok, hdr := pool.GetSession()
				if tok == "" || hdr == "" {
					t.Errorf("got empty session during concurrent access")
				}
			}
		}()
	}
	wg.Wait()
}

func TestRapidSessionPool_FileIO(t *testing.T) {
	tmpDir := t.TempDir()
	filePath := filepath.Join(tmpDir, "test_sessions.txt")

	pool1 := NewRapidSessionPool()
	pool1.AddSession("sess_alpha_123")
	pool1.AddSession("sess_beta_456")

	if err := pool1.SaveToFile(filePath); err != nil {
		t.Fatalf("SaveToFile failed: %v", err)
	}

	pool2 := NewRapidSessionPool()
	loaded, err := pool2.LoadFromFile(filePath)
	if err != nil {
		t.Fatalf("LoadFromFile failed: %v", err)
	}
	if loaded != 2 || pool2.Count() != 2 {
		t.Errorf("expected 2 sessions loaded, got %d (count: %d)", loaded, pool2.Count())
	}
}

func TestRapidSessionPool_Env(t *testing.T) {
	os.Setenv("RAPIDDNS_SESSIONS", "env_sess_1, env_sess_2\nenv_sess_3")
	defer os.Unsetenv("RAPIDDNS_SESSIONS")

	pool := NewRapidSessionPool()
	added := pool.LoadFromEnv()
	if added != 3 || pool.Count() != 3 {
		t.Errorf("expected 3 sessions loaded from env, got %d", added)
	}
}
