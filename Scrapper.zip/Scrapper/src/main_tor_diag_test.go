package main

import "testing"

// TestParseTorCheckIP mengunci parser respons /api/ip check.torproject.org yang
// dipakai -diag sebagai fallback saat ipify/ifconfig/checkip tidak terjangkau.
func TestParseTorCheckIP(t *testing.T) {
	cases := []struct {
		name string
		body string
		want string
	}{
		{"valid", `{"IsTor":true,"IP":"192.42.116.105"}`, "192.42.116.105"},
		{"tanpa iptor", `{"IsTor":false,"IP":"203.0.113.7"}`, "203.0.113.7"},
		{"html error", `<html><head><title>403 Forbidden</title></head></html>`, ""},
		{"body kosong", ``, ""},
		{"ip kosong", `{"IsTor":true,"IP":""}`, ""},
	}
	for _, c := range cases {
		if got := parseTorCheckIP([]byte(c.body)); got != c.want {
			t.Fatalf("%s: parseTorCheckIP(%q) = %q, mau %q", c.name, c.body, got, c.want)
		}
	}
}
