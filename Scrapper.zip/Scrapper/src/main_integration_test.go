package main

import (
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"runtime"
	"strings"
	"sync"
	"testing"
	"time"
)

// Integration test (Session 2) for fetchCrt() primary path using a mock
// crt.name server (no external network). Verifies the configurable endpoint
// hook (crtNameAPI) + JSON parsing + filterValid normalization/dedup.

func TestFetchCrtViaMock(t *testing.T) {
	body := `[{"sub":"a.mocktest.invalid"},{"sub":"b.mocktest.invalid"},{"sub":"A.MOCKTEST.Invalid"},{"sub":"127.0.0.1"},{"sub":"x"},{"sub":""}]`
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Query().Get("name") != "" {
			// DoH wildcard probe stub: NXDOMAIN -> not wildcarded (no real net)
			w.Header().Set("Content-Type", "application/dns-json")
			_, _ = w.Write([]byte(`{"Status":3,"Answer":[]}`))
			return
		}
		if r.URL.Query().Get("apex") != "mocktest.invalid" {
			http.Error(w, "bad apex", http.StatusBadRequest)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(body))
	}))
	defer srv.Close()

	orig := crtNameAPI
	origDoH := dohEndpoints
	crtNameAPI = srv.URL
	dohEndpoints = []struct {
		url    string
		accept string
	}{{srv.URL, "application/dns-json"}}
	defer func() { crtNameAPI = orig; dohEndpoints = origDoH }()

	ww := &worker{
		direct: srv.Client(),
		client: srv.Client(),
		shared: &sharedState{
			mu:       sync.RWMutex{},
			visited:  sync.Map{},
			apexDone: map[string]bool{},
		},
	}

	// isolate: confirm getRetry hits the mock and gets 200 (no fallthrough to prod).
	resp, err := ww.getRetry(crtNameAPI + "?apex=mocktest.invalid&format=json")
	if err != nil {
		t.Fatalf("getRetry to mock failed: %v", err)
	}
	if resp.StatusCode != 200 {
		t.Fatalf("getRetry mock returned %d, want 200", resp.StatusCode)
	}
	resp.Body.Close()

	got := ww.fetchCrt("mocktest.invalid")
	// fan-out sukses-path adds live subdomain.center extra → may return >2. Check containment, not exact count.
	// ponytail: pin subcenterAPI var and mock it to assert exact 2 when network isolation needed.
	if len(got) < 2 {
		t.Fatalf("fetchCrt returned %d items, want >=2 (%v)", len(got), got)
	}
	seen := map[string]bool{}
	for _, d := range got {
		seen[d] = true
	}
	if !seen["a.mocktest.invalid"] || !seen["b.mocktest.invalid"] {
		t.Fatalf("fetchCrt missing a/b.mocktest.invalid: %v", got)
	}
}

// TestRunMassMockedEndToEnd drives the whole worker pool through a mocked
// crt.name + DoH endpoint (reverse expansion disabled): it covers the shared
// atomics (guiFound/guiTarget/guiQueue), writeLines' fetch/flush, the end-of-run
// report path and the output tidy step without touching the internet for data.
func TestRunMassMockedEndToEnd(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		if apex := r.URL.Query().Get("apex"); apex != "" {
			fmt.Fprintf(w, `[{"sub":"alpha.%s"},{"sub":"beta.%s"},{"sub":"gamma.%s"}]`, apex, apex, apex)
			return
		}
		// DoH stub: NXDOMAIN for the mutation probe -> no network dependency.
		_, _ = w.Write([]byte(`{"Status":3,"Answer":[]}`))
	}))
	defer srv.Close()

	origAPI, origDoH, origNoReverse := crtNameAPI, dohEndpoints, noReverse
	crtNameAPI = srv.URL
	noReverse = true
	dohEndpoints = []struct {
		url    string
		accept string
	}{{srv.URL, "application/dns-json"}}
	t.Cleanup(func() {
		crtNameAPI = origAPI
		dohEndpoints = origDoH
		noReverse = origNoReverse
	})

	const outName = "zz_runmass_e2e_out.txt"
	t.Cleanup(func() { _ = os.Remove(outName) })

	baseline := runtime.NumGoroutine()
	n, err := runMass([]string{"zzmock.dev"}, 2, outName, "off", 3, false, "speed", 0)
	if err != nil {
		t.Fatalf("runMass: %v", err)
	}
	if n < 2 {
		t.Errorf("runMass counted %d domains, want >= 2", n)
	}
	b, err := os.ReadFile(outName)
	if err != nil {
		t.Fatalf("output file: %v", err)
	}
	body := strings.TrimSpace(string(b))
	if body == "" {
		t.Fatal("output file is empty")
	}
	for _, want := range []string{"alpha.zzmock.dev", "beta.zzmock.dev"} {
		if !strings.Contains(body, want) {
			t.Errorf("output missing %s: %q", want, body)
		}
	}
	// The reported count must match what actually landed in the file (catches
	// lost writes / double counting in writeLines + the final flush).
	if lines := len(strings.Split(body, "\n")); int64(lines) != n {
		t.Errorf("file has %d lines but runMass reported %d domains", lines, n)
	}

	// No worker/source goroutine may outlive the run. A raw goroutine count is
	// NOT a leak signal here: net/http keeps idle keep-alive connections alive
	// (persistConn.readLoop/writeLoop) until IdleConnTimeout, so assert on the
	// scraper frames instead, then confirm the pool is reclaimable.
	time.Sleep(2 * time.Second)
	buf := make([]byte, 1<<20)
	stacks := string(buf[:runtime.Stack(buf, true)])
	for _, frame := range []string{"fetchCrt(", "fetchRapid(", "fetchSameIP(", "expandReverse(", "probeMutations(", "runMass(", "workerFn"} {
		if strings.Contains(stacks, frame) {
			t.Errorf("scraper goroutine still alive after runMass: %s", frame)
		}
	}
	idle := runtime.NumGoroutine()
	dohTransport.CloseIdleConnections()
	sharedDirectTransport.CloseIdleConnections()
	time.Sleep(300 * time.Millisecond)
	t.Logf("goroutines: %d baseline, %d with pooled conns, %d after closing idle conns",
		baseline, idle, runtime.NumGoroutine())
}
