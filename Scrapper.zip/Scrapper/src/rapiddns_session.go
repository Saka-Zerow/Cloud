package main

import (
	"bufio"
	"os"
	"strings"
	"sync"
	"sync/atomic"
)

// RapidSessionPool manages a thread-safe round-robin pool of authenticated RapidDNS sessions.
type RapidSessionPool struct {
	mu       sync.RWMutex
	sessions []string
	idx      uint64
	failures map[string]int
}

var globalRapidSessions = NewRapidSessionPool()

// NewRapidSessionPool creates a new empty session pool.
func NewRapidSessionPool() *RapidSessionPool {
	return &RapidSessionPool{
		failures: make(map[string]int),
	}
}

// CleanSessionToken strips whitespace, cookie name prefixes ("session="), quotes, and "Cookie:".
func CleanSessionToken(raw string) string {
	s := strings.TrimSpace(raw)
	s = strings.Trim(s, "\"'`\ufeff\r\n")
	if strings.HasPrefix(strings.ToLower(s), "cookie:") {
		s = strings.TrimSpace(s[7:])
	}
	// Extract session= value if present among other cookies
	if strings.Contains(s, "session=") {
		parts := strings.Split(s, ";")
		for _, p := range parts {
			p = strings.TrimSpace(p)
			if strings.HasPrefix(strings.ToLower(p), "session=") {
				s = strings.TrimSpace(p[8:])
				break
			}
		}
	}
	s = strings.Trim(s, "\"'`\r\n ")
	return s
}

// AddSession validates and adds a session token to the pool. Returns true if added.
func (p *RapidSessionPool) AddSession(raw string) bool {
	token := CleanSessionToken(raw)
	if token == "" {
		return false
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	for _, existing := range p.sessions {
		if existing == token {
			return false
		}
	}
	p.sessions = append(p.sessions, token)
	return true
}

// RemoveSession removes a specific session token from the pool.
func (p *RapidSessionPool) RemoveSession(raw string) bool {
	token := CleanSessionToken(raw)
	if token == "" {
		return false
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	for i, s := range p.sessions {
		if s == token {
			p.sessions = append(p.sessions[:i], p.sessions[i+1:]...)
			delete(p.failures, token)
			return true
		}
	}
	return false
}

// Clear removes all sessions.
func (p *RapidSessionPool) Clear() {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.sessions = nil
	p.failures = make(map[string]int)
	atomic.StoreUint64(&p.idx, 0)
}

// Count returns the number of active sessions in the pool.
func (p *RapidSessionPool) Count() int {
	p.mu.RLock()
	defer p.mu.RUnlock()
	return len(p.sessions)
}

// GetAll returns a copy of all session tokens.
func (p *RapidSessionPool) GetAll() []string {
	p.mu.RLock()
	defer p.mu.RUnlock()
	res := make([]string, len(p.sessions))
	copy(res, p.sessions)
	return res
}

// GetSession returns the next session token and the formatted "Cookie" header value (e.g. "session=...").
// Uses lock-free atomic round-robin. Returns ("", "") if no session is available.
func (p *RapidSessionPool) GetSession() (token string, cookieHeader string) {
	p.mu.RLock()
	n := len(p.sessions)
	if n == 0 {
		p.mu.RUnlock()
		return "", ""
	}
	cur := atomic.AddUint64(&p.idx, 1) - 1
	token = p.sessions[cur%uint64(n)]
	p.mu.RUnlock()
	return token, "session=" + token
}

// LoadFromFile loads sessions from a text file (one session per line).
// Ignores blank lines and comments starting with #.
func (p *RapidSessionPool) LoadFromFile(path string) (int, error) {
	f, err := os.Open(path)
	if err != nil {
		return 0, err
	}
	defer f.Close()

	scanner := bufio.NewScanner(f)
	added := 0
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "//") {
			continue
		}
		if p.AddSession(line) {
			added++
		}
	}
	return added, scanner.Err()
}

// SaveToFile saves all current sessions to a file.
func (p *RapidSessionPool) SaveToFile(path string) error {
	p.mu.RLock()
	sessions := make([]string, len(p.sessions))
	copy(sessions, p.sessions)
	p.mu.RUnlock()

	var sb strings.Builder
	sb.WriteString("# RapidDNS Logged-In Sessions Pool (1 session per line)\n")
	sb.WriteString("# Format: .eJw... atau session=.eJw...\n\n")
	for _, s := range sessions {
		sb.WriteString(s)
		sb.WriteString("\n")
	}
	return os.WriteFile(path, []byte(sb.String()), 0600)
}

// LoadFromEnv loads sessions from RAPIDDNS_SESSION or RAPIDDNS_SESSIONS env vars.
func (p *RapidSessionPool) LoadFromEnv() int {
	added := 0
	for _, envKey := range []string{"RAPIDDNS_SESSIONS", "RAPIDDNS_SESSION", "RAPID_SESSION"} {
		val := os.Getenv(envKey)
		if val == "" {
			continue
		}
		// Split by comma or newline
		tokens := strings.FieldsFunc(val, func(r rune) bool {
			return r == ',' || r == '\n' || r == ';'
		})
		for _, t := range tokens {
			if p.AddSession(t) {
				added++
			}
		}
	}
	return added
}

const defaultSessionFile = "rapiddns_sessions.txt"

// InitRapidSessions initializes the global session pool from file, env, or fallback.
func InitRapidSessions() {
	// 1. Try file
	if _, err := os.Stat(defaultSessionFile); err == nil {
		globalRapidSessions.LoadFromFile(defaultSessionFile)
	}
	// 2. Try env
	globalRapidSessions.LoadFromEnv()
}

// MaskSession returns a masked preview for display in logs/UI (e.g. ".eJwtjt...7A").
func MaskSession(s string) string {
	if len(s) <= 12 {
		return s
	}
	return s[:7] + "..." + s[len(s)-5:]
}
