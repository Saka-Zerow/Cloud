package main

import (
	"bufio"
	"bytes"
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"net"
	"net/http"
	neturl "net/url"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"regexp"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"

	"golang.org/x/net/proxy"
	"golang.org/x/net/publicsuffix"
)

const (
	defaultTorSocks = "127.0.0.1:9050"
	defaultTorCtrl  = "127.0.0.1:9051"
	torPortsFile    = "torports.txt"
	httpTimeout     = 30 * time.Second
	// torDialTimeout bounds ONE SOCKS5 dial+handshake through Tor. Without it a
	// dial that Tor never answers blocks forever (see torDialContext).
	torDialTimeout   = 8 * time.Second
	maxRetries       = 2
	maxInputDomains  = 100000
	maxTargetDomains = 1000000
	// browserUA: HTML-scraped providers (rapiddns) sit behind Cloudflare bot
	// protection. A bare "Mozilla/5.0" is a known bot signature and gets
	// challenged (HTTP 429 "Just a moment...") far more often than a full UA.
	browserUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
	// rapidMaxBody caps a single rapiddns response read (2 MB).
	rapidMaxBody = 2 << 20
	// rapidGuestRowCap is how many table rows rapiddns serves to a guest. Live
	// check (2026-09-19): the table always stops at 100 numbered rows ("Limited
	// Access: You are using RapidDNS as a guest"), ?page is ignored and
	// /advanced redirects to /user/upgrade. So 100 rows is the free ceiling.
	rapidGuestRowCap = 100
)

// modeDelay returns per-hit delay based on mode: speed=0, balanced=50ms, stealth=1500ms
func modeDelay(mode string) time.Duration {
	switch mode {
	case "speed":
		return 0
	case "stealth":
		return 1500 * time.Millisecond
	default: // balanced, unknown
		return 50 * time.Millisecond
	}
}

var crtNameAPI = "https://crt.name/v1/search"

// EngineMode defines how discovery queries are executed.
type EngineMode string

const (
	EngineSmart    EngineMode = "smart"    // RapidDNS-First -> crt.name escalation if low results
	EngineParallel EngineMode = "parallel" // Concurrent crt.name + RapidDNS
	EnginePureDual EngineMode = "puredual" // Pure Concurrent crt.name + RapidDNS (Zero Fallback, Max Speed, Infinite Feed)
	EngineRapid    EngineMode = "rapid"    // RapidDNS Only
	EngineCrt      EngineMode = "crt"      // crt.name Only
)

func formatTarget(target int, isUnlimited bool) string {
	if isUnlimited {
		return "∞"
	}
	return strconv.Itoa(target)
}

var globalEngineMode EngineMode = EngineSmart

// crtNameToken is an optional crt.name API token. crt.name's free tier is
// 100 requests per IP per day ("Supply an API token for unmetered access");
// with a token the scraper can skip the Tor circuit rotation it otherwise
// needs to dodge that limit. Set via the CRT_NAME_TOKEN environment variable.
var crtNameToken = os.Getenv("CRT_NAME_TOKEN")

// rapidBaseURL is a var (not a const) so tests can point the rapiddns scrapers
// at an httptest server.
var rapidBaseURL = "https://rapiddns.io"

// torFleetAddrs caches the discovered Tor SOCKS fleet. loadTorFleet() is called
// concurrently by every worker (via pickTorAddr -> torEffectiveAddr), and the
// fleet used to be published with a plain `torFleetAddrs = out` write guarded
// only by a nil check — a data race on the slice header (BUG-011, reported by
// `go test -race` on the GUI path).
var (
	torFleetMu     sync.Mutex
	torFleetAddrs  []string
	torFleetLoaded bool
)

// noReverse disables reverse-IP cross-apex expansion.
var noReverse bool

// torUserChosen is set by runInteractiveMenu when the operator answers the Tor
// prompt. Without it, main()'s "auto tor" block considered a menu-supplied
// address (e.g. 127.0.0.1:9150) non-explicit, found no fleet on 9050 and
// silently rewrote it to "off" — the opposite of the comment that promised a
// manual choice is never overridden. Same write-before-start pattern as
// noReverse/keepInfra.
var torUserChosen bool

// NEWNYM singleflight per-ctrl (kompromi S1/S2): satu ctrl hanya 1 rotate
// dalam flight; cooldown 10s. Try-lock NON-BLOCKING: worker gagal lock SKIP
// rotate (lanjut isolate/direct) — tidak ada worker nunggu worker lain.
// ponytail: naikkan cooldown bila ctrl auth rate-limit; pisah ke tor.go saat split.
var torRotateMu sync.Mutex
var torRotateFlight = map[string]bool{}
var torRotateLast = map[string]time.Time{}

const torRotateCooldown = 10 * time.Second

// loadTorFleet returns the cached Tor fleet. The fast path is a single lock
// acquisition; discovery (probing torports.txt + the common ports) happens
// outside the lock so workers never queue behind a slow port probe.
func loadTorFleet() []string {
	torFleetMu.Lock()
	if torFleetLoaded {
		addrs := torFleetAddrs
		torFleetMu.Unlock()
		return addrs
	}
	torFleetMu.Unlock()

	discovered := discoverTorFleet()

	torFleetMu.Lock()
	defer torFleetMu.Unlock()
	if !torFleetLoaded {
		torFleetAddrs = discovered
		torFleetLoaded = true
	}
	return torFleetAddrs
}

func discoverTorFleet() []string {
	seen := map[string]bool{}
	var out []string
	if data, err := os.ReadFile(torPortsFile); err == nil {
		for _, ln := range strings.Split(string(data), "\n") {
			ln = strings.TrimSpace(ln)
			if ln == "" {
				continue
			}
			if _, err := net.LookupPort("tcp", ln); err == nil {
				ln = "127.0.0.1:" + ln
			}
			if !strings.Contains(ln, ":") || seen[ln] {
				continue
			}
			if tcpProbe(ln) {
				seen[ln] = true
				out = append(out, ln)
			}
		}
	}
	// Auto-discovery swarm: probe the SOCKS5 ports the fleet can occupy (never the
	// ControlPorts, which are the odd ones).
	//
	// The list is GENERATED from the same 9050+2i rule ensureTorFleet spawns with,
	// up to the documented 24-instance ceiling. It used to be hardcoded to
	// 9050..9060 + 9150, which capped discovery at 7 sockets: any -torfleet above 6
	// spawned Tor instances that discovery never returned, so the tool paid for the
	// processes and 50 workers kept sharing 6 exits. 9150 stays last for the
	// Tor Browser case.
	//
	// Probing the dead ones is free: a closed port on loopback answers with RST
	// immediately, so the 800ms tcpProbe timeout is never spent.
	commonPorts := make([]string, 0, 51)
	for i := 0; i < 50; i++ {
		commonPorts = append(commonPorts, fmt.Sprintf("127.0.0.1:%d", 9050+2*i))
	}
	commonPorts = append(commonPorts, "127.0.0.1:9150")
	for _, p := range commonPorts {
		if !seen[p] && tcpProbe(p) {
			seen[p] = true
			out = append(out, p)
		}
	}
	if len(out) == 0 {
		out = []string{defaultTorSocks}
	}
	return out
}

func pickTorAddr(workerID int) string {
	addrs := loadTorFleet()
	if len(addrs) == 0 {
		return defaultTorSocks
	}
	return addrs[workerID%len(addrs)]
}

var (
	autoTorCmds   []*exec.Cmd
	autoTorMu     sync.Mutex
	autoTorCancel context.CancelFunc // for cleanup
)

func killAutoTor() {
	autoTorMu.Lock()
	defer autoTorMu.Unlock()
	for _, cmd := range autoTorCmds {
		if cmd != nil && cmd.Process != nil {
			pid := cmd.Process.Pid
			_ = cmd.Process.Kill()
			if runtime.GOOS == "windows" && pid > 0 {
				_ = exec.Command("taskkill", "/F", "/T", "/PID", strconv.Itoa(pid)).Run()
			}
		}
	}
	autoTorCmds = nil
}

func findTorBinary() (string, string) {
	uProfile := os.Getenv("USERPROFILE")
	cands := []struct {
		bin string
		rc  string
	}{
		{
			filepath.Join(uProfile, ".local", "tor", "Tor", "tor.exe"),
			filepath.Join(uProfile, ".local", "tor", "Tor", "torrc_proxy"),
		},
		{
			filepath.Join(uProfile, "Desktop", "Tor Browser", "Browser", "TorBrowser", "Tor", "tor.exe"),
			filepath.Join(uProfile, "Desktop", "Tor Browser", "Browser", "TorBrowser", "Tor", "torrc_proxy"),
		},
		{
			"C:\\Program Files\\Tor\\tor.exe",
			"",
		},
		{
			"C:\\Program Files (x86)\\Tor\\tor.exe",
			"",
		},
	}
	if p, err := exec.LookPath("tor"); err == nil {
		cands = append([]struct{ bin, rc string }{{p, ""}}, cands...)
	}
	for _, c := range cands {
		if fi, err := os.Stat(c.bin); err == nil && !fi.IsDir() {
			return c.bin, c.rc
		}
	}
	return "", ""
}

// torAcceptsSocksFlag asks THIS Tor build whether it understands a SocksPort
// flag (e.g. KeepAliveIsolateSOCKSAuth) using `--verify-config`, which only
// parses the config: no ports bound, no network, ~60ms. Spawning blind instead
// is what let an unsupported option kill every instance at config parse, after
// which the run silently dropped to direct IP (and burned the whole wait
// ceiling before the early-exit fix).
func torAcceptsSocksFlag(bin, flag string) bool {
	if bin == "" {
		return false
	}
	dir := filepath.Join(os.TempDir(), "submass_tor_preflight")
	_ = os.MkdirAll(dir, 0o700)
	// The port in the spec is never a fleet port and --verify-config binds
	// nothing, so this cannot collide with a live fleet.
	cmd := exec.Command(bin,
		"--verify-config",
		"--SocksPort", "19050"+flag,
		"--DataDirectory", dir,
	)
	hideWindow(cmd)
	return cmd.Run() == nil
}

// torSpawnArgs builds the argv for one fleet instance. Extracted so the shape
// that actually broke is testable: KeepAliveIsolateSOCKSAuth is a SocksPort
// FLAG and must ride on the --SocksPort value, never appear as its own
// top-level option (tor then exits with "Unknown option" and the fleet dies).
func torSpawnArgs(portStr, socksFlag, dataDir, ctrlPort, ctrlFile string) []string {
	return []string{
		"--SocksPort", portStr + socksFlag,
		"--DataDirectory", dataDir,
		"--ControlPort", ctrlPort,
		"--ControlPortWriteToFile", ctrlFile,
		"--CookieAuthentication", "0",
		"--MaxCircuitDirtiness", "3600",
		// Tor defaults this to 32. The fleet exists so 50+ workers can claim a
		// circuit at (roughly) the same moment; at 32 they queue behind the
		// pending ceiling instead, and an abandoned warm-up (the tool gives up
		// at 4s, Tor keeps building) holds a slot until it finishes.
		"--MaxClientCircuitsPending", "128",
	}
}

// torFleetSize is how many Tor instances the tool autostarts (-torfleet, default
// 15). More instances mean more parallel circuit capacity, which is what actually
// lets 50 workers run at once; each instance uses SOCKS 9050+2i / control 9051+2i.
//
// The default moved 6 -> 10 -> 15 because crt.name's free tier is 100 requests
// per EXIT IP per day (crtNameDailyQuota), so the fleet size multiplies that
// budget linearly: 10 ~= 1.000, 15 ~= 1.500, 50 ~= 5.000. Ideal: 1 worker =
// 1 fleet instance (1:1 ratio) to avoid sharing quota. Max 50, port range
// 9050-9148 (SOCKS) / 9051-9149 (Control), does not conflict with Tor Browser
// at 9150.
var torFleetSize = 15

// ensureTorFleet checks and auto-starts a swarm fleet of multiple independent Tor instances
// (e.g. 9050, 9052, 9054, 9056, 9058, 9060) so high-concurrency workers avoid single-socket bottleneck.
func ensureTorFleet() int {
	autoTorMu.Lock()
	defer autoTorMu.Unlock()

	n := torFleetSize
	if n < 2 {
		n = 2
	}
	if n > 50 {
		n = 50
	}
	portsToEnsure := make([]string, 0, n)
	for i := 0; i < n; i++ {
		portsToEnsure = append(portsToEnsure, strconv.Itoa(9050+2*i))
	}
	if data, err := os.ReadFile(torPortsFile); err == nil {
		var customPorts []string
		for _, ln := range strings.Split(string(data), "\n") {
			ln = strings.TrimSpace(ln)
			if ln == "" {
				continue
			}
			if strings.Contains(ln, ":") {
				parts := strings.Split(ln, ":")
				ln = parts[len(parts)-1]
			}
			customPorts = append(customPorts, ln)
		}
		if len(customPorts) > 0 {
			portsToEnsure = customPorts
		}
	}

	bin, _ := findTorBinary()
	if bin == "" {
		if tcpProbe(defaultTorSocks) {
			return 1
		}
		return 0
	}

	// Flag support is a property of the BINARY, so probe it once instead of
	// discovering it per instance. Older builds (some Tor Browser bundles) do
	// not know this SocksPort flag: dropping it keeps IsolateSOCKSAuth — which
	// is default-on and is what gives each worker its own exit — and loses only
	// the keep-alive tweak. That is strictly better than the whole fleet dying
	// at config parse and the run quietly going direct.
	socksFlag := " KeepAliveIsolateSOCKSAuth"
	if !torAcceptsSocksFlag(bin, socksFlag) {
		socksFlag = ""
		fmt.Fprintf(os.Stderr, "[tor] versi Tor ini tidak mendukung opsi KeepAliveIsolateSOCKSAuth — pakai SocksPort standar (isolasi worker tetap aktif)\n")
	}

	spawnedCount := 0
	var spawnedAlive int32
	for _, portStr := range portsToEnsure {
		addr := "127.0.0.1:" + portStr
		if tcpProbe(addr) {
			continue
		}

		portNum, err := strconv.Atoi(portStr)
		ctrlPort := "auto"
		if err == nil {
			ctrlPort = fmt.Sprintf("%d", portNum+1)
		}

		dataDir := filepath.Join(os.TempDir(), fmt.Sprintf("submass_tor_%s", portStr))
		_ = os.MkdirAll(dataDir, 0o700)
		_ = os.Remove(filepath.Join(dataDir, "lock"))
		ctrlFile := filepath.Join(dataDir, "control_port")
		_ = os.Remove(ctrlFile)

		// Tuning below exists to protect the pinned-exit model (tor_exit_unique.go):
		// one worker claims ONE exit IP and keeps it, and limitGate records 24h
		// crt.name quotas against exactly that IP (exitKeyFor -> "ip:<addr>").
		//
		// Tor's stock MaxCircuitDirtiness is 600s, which quietly breaks that
		// promise: past 10 minutes the pinned circuit goes dirty, the next NEW
		// connection on the same SOCKS identity is built on a DIFFERENT exit, and
		// the worker keeps believing it sits on IP_A while its traffic leaves
		// through IP_B. The 429 then arrives from IP_B but the 24h cooldown is
		// written against IP_A, so IP_B is handed out again and burns twice.
		// 1h outlives any realistic run segment. Deliberate rotation is unaffected:
		// rotateExit() claims a fresh torCircuitUser(), i.e. a brand-new circuit
		// whatever the dirtiness says.
		// KeepAliveIsolateSOCKSAuth is a SocksPort FLAG, not a top-level torrc
		// option: passed as "--KeepAliveIsolateSOCKSAuth 1" every spawned Tor
		// exited at config parse ("Unknown option"), so the fleet died, no
		// SocksPort ever opened, and ensureTorFleet burned its full 24s wait
		// ceiling before silently falling back to direct IP — the "lama saat
		// mulai" on menu 1/2. It must ride on the SocksPort value, and only if
		// the binary accepts it (probed above).
		cmd := exec.Command(bin, torSpawnArgs(portStr, socksFlag, dataDir, ctrlPort, ctrlFile)...)
		hideWindow(cmd)
		if err := cmd.Start(); err == nil {
			autoTorCmds = append(autoTorCmds, cmd)
			spawnedCount++
			atomic.AddInt32(&spawnedAlive, 1)
			// Reap the child asynchronously so the wait loop below can tell
			// "still booting" from "already dead" instead of sleeping out the
			// whole ceiling on a fleet that will never answer.
			go func(c *exec.Cmd) {
				_ = c.Wait()
				atomic.AddInt32(&spawnedAlive, -1)
			}(cmd)
		}
	}

	if spawnedCount > 0 {
		// 24 x 500ms = 12s ceiling, and it exits as soon as EVERY port answers, so
		// the wait only costs anything when Tor is genuinely failing. The old 14
		// (7s) was sized for the 6-instance default; with -torfleet 10 a slow
		// instance could still be binding when the fleet snapshot was taken below,
		// and loadTorFleet caches that snapshot for the whole run — the process
		// would stay up, unused, until the next start.
		for i := 0; i < 48; i++ {
			time.Sleep(500 * time.Millisecond)
			alive := 0
			for _, portStr := range portsToEnsure {
				if tcpProbe("127.0.0.1:" + portStr) {
					alive++
				}
			}
			if alive >= len(portsToEnsure) {
				break
			}
			// Nothing we launched is still running: no port can ever open, so
			// waiting out the 24s ceiling only delays the run and hides the
			// failure. Report it and fall through to the live-port probe.
			if atomic.LoadInt32(&spawnedAlive) == 0 {
				fmt.Fprintf(os.Stderr, "[tor] %d instance Tor di-autostart tapi semuanya langsung mati (opsi/config Tor tidak didukung versi ini) — lanjut tanpa Tor\n", spawnedCount)
				break
			}
		}
	}

	torFleetMu.Lock()
	torFleetLoaded = false
	torFleetMu.Unlock()

	activePorts := loadTorFleet()
	// discoverTorFleet() falls back to {defaultTorSocks} whenever nothing answers,
	// so loadTorFleet() is never empty even when no Tor is actually listening.
	// Reporting its length made menu 6 and the menu 1/2 auto-start print "SUKSES"
	// unconditionally, then hand the run a dead SOCKS address. Probe each
	// candidate and return only the ones that really answer; a closed loopback
	// port fails instantly with RST, so this adds no measurable cost.
	livePorts := make([]string, 0, len(activePorts))
	for _, addr := range activePorts {
		if tcpProbe(addr) {
			livePorts = append(livePorts, addr)
		}
	}
	if len(livePorts) > 1 {
		fmt.Printf("[tor] Multi-Tor Swarm Fleet AKTIF: %d instance (%s)\n", len(livePorts), strings.Join(livePorts, ", "))
	}
	return len(livePorts)
}

// ensureTorRunning checks if Tor is active; if not, launches the multi-Tor swarm fleet.
func ensureTorRunning() bool {
	return ensureTorFleet() > 0
}

var guiFlag = flag.Bool("gui", false, "launch GUI on http://localhost:9876")

// --- CLI pretty ---
const cliBanner = "\n" +
	"   ____       __                        \n" +
	"  / __ \\_____/ /_____ _____  __  _______\n" +
	" / / / / ___/ __/ __ `/ __ \\/ / / / ___/\n" +
	"/ /_/ / /__/ /_/ /_/ / /_/ / /_/ (__  ) \n" +
	"\\____/\\___/\\__/\\__,_/ .___/\\__,_/____/  \n" +
	"                   /_/                  \n" +
	"\n" +
	"[  SubMass — crt.name × rapiddns  ]\n"

var (
	ansiOn  = initTerminal()
	colRst  = "\x1b[0m"
	colDim  = "\x1b[2m"
	colPur  = "\x1b[38;5;141m"
	colCyan = "\x1b[38;5;51m"
	colGrn  = "\x1b[32m"
	colYel  = "\x1b[33m"
	colRed  = "\x1b[31m"
	cliMu   sync.Mutex
	// S2-07 ringkasan CLI: hit per-apex untuk throttle + total per-apex akhir.
	apexHitCount = map[string]int{}
	apexTotals   = map[string]int{}
	apexTotalsMu sync.Mutex
)

// printApexSummary cetak top-apex kontributor di akhir run (max 15).
// File output tetap penuh; ini cuma ringkasan console agar tak spam.
func printApexSummary(top int) {
	apexTotalsMu.Lock()
	type kv struct {
		apex string
		n    int
	}
	var kvs []kv
	for a, n := range apexTotals {
		kvs = append(kvs, kv{a, n})
	}
	apexTotalsMu.Unlock()
	if len(kvs) == 0 {
		return
	}
	sort.Slice(kvs, func(i, j int) bool { return kvs[i].n > kvs[j].n })
	if top <= 0 || top > len(kvs) {
		top = len(kvs)
	}
	if top > 15 {
		top = 15
	}
	fmt.Println()
	fmt.Println(paint(colCyan, "── Top Apex Discovered ──────────────────────────────"))
	for _, kv := range kvs[:top] {
		fmt.Printf("  %-38s %s\n", truncateDomain(kv.apex), paint(colGrn, human(int64(kv.n))))
	}
}

// initTerminal reports whether colored/ANSI output is available. The Windows
// console-mode syscalls live in console_windows.go (build-tagged) so this
// package also compiles on Linux/macOS.
func initTerminal() bool {
	if runtime.GOOS == "windows" && enableVirtualTerminal() {
		return true
	}
	fi, err := os.Stdout.Stat()
	if err != nil {
		return false
	}
	return fi.Mode()&os.ModeCharDevice != 0
}

func clearLine() {
	if ansiOn {
		fmt.Print("\r\x1b[2K")
	}
}

func isTerminal() bool {
	return ansiOn
}
func paint(c, s string) string {
	if !ansiOn {
		return s
	}
	return c + s + colRst
}
func paintf(c, f string, a ...interface{}) string { return paint(c, fmt.Sprintf(f, a...)) }

// drainAndClose discards any unread bytes (up to 64KB) before closing the response body.
// This allows net/http to reuse the underlying TCP/TLS connection for Keep-Alive,
// preventing socket churn and WSAENOBUFS exhaustion on Windows.
func drainAndClose(body io.ReadCloser) {
	if body == nil {
		return
	}
	_, _ = io.Copy(io.Discard, io.LimitReader(body, 64*1024))
	_ = body.Close()
}

type cliGeo struct{ IP, Country, CountryCode, Region, City, Org string }

func fetchGeo(timeout time.Duration, torAddr string, useTor bool) *cliGeo {
	client := &http.Client{Timeout: timeout}
	if useTor && torAddr != "" && torAddr != "off" {
		if c, _, ok, _ := newTorClient(torAddr, 0, true); ok {
			client = c
		}
	}
	try := func(url string, parse func([]byte) *cliGeo) *cliGeo {
		resp, err := client.Get(url)
		if err != nil {
			return nil
		}
		defer resp.Body.Close()
		b, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
		return parse(b)
	}
	// ipapi.co
	if g := try("https://ipapi.co/json/", func(b []byte) *cliGeo {
		var d struct {
			IP          string `json:"ip"`
			CountryName string `json:"country_name"`
			CountryCode string `json:"country_code"`
			Region      string `json:"region"`
			City        string `json:"city"`
			Org         string `json:"org"`
			Error       bool   `json:"error"`
		}
		if json.Unmarshal(b, &d) != nil || d.Error || d.IP == "" {
			return nil
		}
		return &cliGeo{d.IP, d.CountryName, d.CountryCode, d.Region, d.City, d.Org}
	}); g != nil {
		return g
	}
	if g := try("https://ipinfo.io/json", func(b []byte) *cliGeo {
		var d struct {
			IP      string `json:"ip"`
			Country string `json:"country"`
			Region  string `json:"region"`
			City    string `json:"city"`
			Org     string `json:"org"`
		}
		if json.Unmarshal(b, &d) != nil || d.IP == "" {
			return nil
		}
		return &cliGeo{d.IP, d.Country, d.Country, d.Region, d.City, d.Org}
	}); g != nil {
		return g
	}
	return nil
}
func bar(pct float64, w int) string {
	if w < 10 {
		w = 28
	}
	filled := int(pct/100*float64(w) + 0.5)
	if filled < 0 {
		filled = 0
	}
	if filled > w {
		filled = w
	}
	// always ascii — avoids [????] on CP437 PowerShell 5.1
	return strings.Repeat("#", filled) + strings.Repeat("-", w-filled)
}
func human(n int64) string {
	if n >= 1000000 {
		return fmt.Sprintf("%.1fM", float64(n)/1e6)
	}
	if n >= 1000 {
		return fmt.Sprintf("%.1fk", float64(n)/1e3)
	}
	return fmt.Sprintf("%d", n)
}
func firstNonEmpty(a, b string) string {
	if a != "" {
		return a
	}
	return b
}

// isFalseWord interprets the value of a `--flag=value` boolean in the manual
// CLI overlay (Go's flag package accepts 0/1/t/f/T/F/true/false; the overlay
// adds the words an operator is likely to type). An unrecognised value is NOT
// false — `-noreverse=OFF` disables, `-noreverse` alone means the switch form
// and never reaches this helper.
func isFalseWord(v string) bool {
	switch strings.ToLower(strings.TrimSpace(v)) {
	case "0", "f", "false", "no", "n", "off", "tidak", "nope":
		return true
	}
	return false
}

type node struct {
	domain string
	useCrt bool
	retry  int
	source string
}

// eTLDPlusOne returns the registrable domain of d (e.g. a.b.example.co.uk ->
// example.co.uk). Empty string on failure. Used to clamp cross-tenant noise.
// etldCache memoizes publicsuffix.EffectiveTLDPlusOne, the hottest CPU path in
// the filter pipeline: apexOf/eTLDPlusOne are called on every candidate domain
// by isBigTechOrPaaS/filterValid/inSkipZone, and the public-suffix trie walk
// adds up over 100k+ domains.
var etldCache sync.Map

func effectiveTLDPlusOne(d string) (string, bool) {
	if v, ok := etldCache.Load(d); ok {
		a := v.(string)
		return a, a != ""
	}
	a, err := publicsuffix.EffectiveTLDPlusOne(d)
	if err != nil {
		a = ""
	}
	etldCache.Store(d, a)
	return a, a != ""
}

func eTLDPlusOne(d string) string {
	d = strings.ToLower(strings.TrimSpace(d))
	d = strings.TrimPrefix(d, "*.")
	if a, ok := effectiveTLDPlusOne(d); ok {
		return a
	}
	if strings.Count(d, ".") == 1 {
		return d
	}
	return ""
}

// buildSeedApexes computes the set of seed registrable domains from the input
// list — the ONLY eTLD+1 scope a worker will ever scan. Everything else
// (reverse-IP hostnames, shared-hosting cert SANs like lan.go.id /
// lumendatabase.org / edlink.id) is dropped at dequeue time.
func buildSeedApexes(list []string) map[string]bool {
	m := make(map[string]bool, len(list))
	for _, d := range list {
		if a := eTLDPlusOne(d); a != "" {
			m[a] = true
		}
	}
	return m
}

type sharedState struct {
	ctx             context.Context
	cancel          context.CancelFunc
	visited         sync.Map // concurrent-safe for read-heavy write-once dedup
	apexDone        map[string]bool
	ipDone          map[string]bool
	seedApexes      map[string]bool // eTLD+1 set; non-seed hosts are dropped at dequeue
	torIPs          map[string]int  // exit IP -> workerID; dedup so workers share no exit IP
	mu              sync.RWMutex    // protects apexDone, ipDone, torIPs, file, count, results, apexCount
	w               *bufio.Writer
	wMu             sync.Mutex // protects the buffered writer only (see writeLines)
	file            *os.File
	count           int64
	results         []string
	expandSeen      int
	expandApexCount map[string]int // tracks per-apex host sampling in expandReverse
	apexCount       map[string]int // per-apex cap di writeLines (bulk cert SND dedup)
	// Flow backlog (loop crt->IP->reverse->crt utuh, tanpa cabang buang):
	// pendingIPs = IP overflow/retry sameip; pendingApex = apex overflow
	// cap/ch-full; ipEmpty = hitung fetch kosong-transien per IP (retry<3);
	// apexSeen = dedup root expand (terpisah dari visited subdomain agar
	// root yang pernah tertulis sebagai sub tidak hilang sebelum di-fetch).
	pendingIPs  []string
	pendingApex []string
	ipEmpty     map[string]int
	apexSeen    sync.Map
	// expandActive = 1 saat expandReverse berjalan (exit-guard: worker lain
	// tidak boleh exit saat ada expand aktif walau queueLen sesaat 0).
	expandActive int32
	// expandMu guards expanders/noExpand. Expander goroutines are DETACHED (the
	// pump's expander, plus the child expandReverse it spawns); nothing used to
	// wait for them, so a still-running expander called writeLines AFTER runMass
	// had already flushed and closed the output file, losing its last batch and
	// hammering a closed handle. A counter + poll is used rather than a
	// sync.WaitGroup because the child is spawned from the expander goroutine
	// itself: Add-during-Wait is a documented WaitGroup misuse, and a mutex-guarded
	// counter has no such rule.
	expandMu  sync.Mutex
	expanders int
	noExpand  bool
	// closed marks the output sink as torn down. writeLines refuses to write once
	// it is set, so a straggler that loses the drain race drops its batch instead
	// of writing into a closed bufio.Writer.
	closed             atomic.Bool
	harvestedIPs       sync.Map // ip (string) -> true, collected passively from RapidDNS, HackerTarget, OTX
	seedsReverseProbed bool
	seedsCompleted     int64
	// rapiddns guest-cap telemetry: how many apex/IP lookups were truncated and
	// the largest advertised total seen (reported once at the end of the run).
	rapidCapped      int64
	rapidCappedTotal int64
	rapidCappedEx    string
	// apexLimited counts limit-driven re-scans already spent per apex, so
	// "ganti IP lalu scan ulang sampai berhasil" cannot loop forever. The cap is
	// limitRescanMax (api_limit.go).
	apexLimited map[string]int
	// apexSuspect counts "+1 only" re-scans per apex, bounded by the much smaller
	// suspectRescanMax. Separate from apexLimited because a thin answer must not
	// inherit a real provider block's budget or trigger a circuit rotation.
	apexSuspect map[string]int
	// subnetSwept bounds how many hosts we will visit inside any single /24.
	//
	// Why this exists (the "queue meledak di target 500k" bug): handleIP fed
	// GenerateSmartSubnetNeighbors output back into ipCh, and every neighbour
	// that got processed fed 6-12 MORE neighbours back in. That is exponential
	// fan-out over a 254-address space: the workers spend their entire budget
	// walking /24 racks that contain nothing in scope, while the apex queue
	// (the actual target list) starves behind it. ipDone only stopped exact
	// duplicates, not the explosion.
	//
	// A /24 is a hosting rack: sweeping a handful of its hosts reliably finds the
	// neighbours worth having, and past that the yield is noise. subnetsSwept
	// records the per-/24 count; subnetsTaken bounds how many distinct /24s a run
	// may sweep at all so the scan stays bounded no matter how many IPs it sees.
	subnetSwept  map[string]int
	subnetsTaken int
	// apexRequeued caps the OTHER re-queue reason (fan-out saturation) so a busy
	// queue cannot loop a target forever either.
	apexRequeued map[string]int
}

// expandDrainTimeout bounds how long runMass waits for detached expander
// goroutines to unwind before it flushes and closes the output file.
const expandDrainTimeout = 6 * time.Second

// --- Constant-cost background sweeps (the "makin lama makin lambat" fix) -----
//
// The scrape keeps every accepted domain in an in-memory sample pool that the
// 250ms reactor and the reverse-expander re-read to find new apexes. That pool
// grows to N over a run, and the old code swept it linearly on every tick, so
// the cost of one tick was O(N): at a few hundred thousand domains a single
// sweep spent hundreds of milliseconds, repeated four times a second, and
// throughput decayed as the corpus grew.
//
// The fix is a fixed *budget* per sweep. A moving cursor still walks the whole
// pool over time, but any single tick is capped, so per-tick cost is O(budget) =
// O(1) regardless of N. The pool itself is ring-bounded so memory stays flat.
const (
	// resultsSampleCap bounds the in-memory pool used ONLY for heuristic
	// re-seeding. The output file still receives every accepted domain, so this
	// is a sample, not the source of truth.
	resultsSampleCap = 262144 // ~256k most-recent results
	// cascadeScanPerTick bounds how many pool entries the 250ms cascade reactor
	// reads per tick.
	cascadeScanPerTick = 4096
	// expandScanPerCall bounds expandReverse's pool scan.
	expandScanPerCall = 4096
	// ipDoneScanPerCall bounds the rack-fallback's walk of ipDone (taken under s.mu).
	ipDoneScanPerCall = 4096
	// harvestedDrainPerCall bounds how many overflow IPs one expandReverse call
	// pulls out of the harvestedIPs set.
	harvestedDrainPerCall = 1024
)

// appendResult records d in the bounded sample pool. Caller must hold s.mu.
// When the pool is full the oldest half is dropped in a single copy (amortized
// O(1)), mirroring pushGuiEntry. Dropping the oldest is safe: those domains'
// apexes have already been expanded, so they are just noise to the re-seeder.
func (s *sharedState) appendResult(d string) {
	s.results = append(s.results, d)
	if len(s.results) > resultsSampleCap {
		n := copy(s.results, s.results[len(s.results)-resultsSampleCap/2:])
		s.results = s.results[:n]
	}
}

// beginExpand registers one expander goroutine. false means the run is already
// tearing down and the caller must NOT start it.
func (s *sharedState) beginExpand() bool {
	if s == nil {
		return false
	}
	s.expandMu.Lock()
	defer s.expandMu.Unlock()
	if s.noExpand {
		return false
	}
	s.expanders++
	return true
}

// endExpand unregisters one expander goroutine (paired with every beginExpand).
func (s *sharedState) endExpand() {
	if s == nil {
		return
	}
	s.expandMu.Lock()
	if s.expanders > 0 {
		s.expanders--
	}
	s.expandMu.Unlock()
}

// sealExpanders forbids new expander goroutines. Called once, at teardown.
func (s *sharedState) sealExpanders() {
	if s == nil {
		return
	}
	s.expandMu.Lock()
	s.noExpand = true
	s.expandMu.Unlock()
}

// expandersRunning reports how many expander goroutines are still alive.
func (s *sharedState) expandersRunning() int {
	if s == nil {
		return 0
	}
	s.expandMu.Lock()
	defer s.expandMu.Unlock()
	return s.expanders
}

// waitUntil polls cond until it holds or d elapses. Used instead of a
// sync.WaitGroup because the things waited for spawn each other.
func waitUntil(cond func() bool, d time.Duration) bool {
	if cond() {
		return true
	}
	deadline := time.Now().Add(d)
	for {
		time.Sleep(10 * time.Millisecond)
		if cond() {
			return true
		}
		if time.Now().After(deadline) {
			return false
		}
	}
}

// requeueApex pushes an apex back onto the pending list. Unlike a channel send
// this cannot be dropped, and the run's pump goroutine turns it into a real
// queue item again — used when a saturated fan-out means the target was NOT
// actually scanned.
func (s *sharedState) requeueApex(apex string) {
	if s == nil || apex == "" {
		return
	}
	s.mu.Lock()
	if s.apexRequeued == nil {
		s.apexRequeued = make(map[string]int)
	}
	if s.apexRequeued[apex] < requeueMax {
		s.apexRequeued[apex]++
		s.pendingApex = append(s.pendingApex, apex)
	}
	s.mu.Unlock()
}

// noteLimitedApex books one limit-driven attempt and reports how many have been
// spent (and whether another one is still allowed).
func (s *sharedState) noteLimitedApex(apex string) (spent int, allowed bool) {
	if s == nil {
		return limitRescanMax, false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.apexLimited == nil {
		s.apexLimited = make(map[string]int)
	}
	s.apexLimited[apex]++
	spent = s.apexLimited[apex]
	return spent, spent <= limitRescanMax
}

const (
	// subnetHostBudget is how many hosts of ONE /24 we will ever look up. A rack
	// sweep past a handful of hosts has negligible yield but feeds itself: each
	// processed neighbour proposes more neighbours, so the fan-out is
	// multiplicative, not additive. 16 of 254 keeps the productive part of a rack
	// while cutting the walk from ~254 lookups to 16.
	subnetHostBudget = 16
	// subnetCountBudget bounds how many DISTINCT /24s one run may sweep. Each one
	// costs up to subnetHostBudget sameip lookups through Tor, so this is the
	// ceiling that keeps a 500k-target run from spending its whole life walking
	// racks instead of scanning the apex queue it was given.
	subnetCountBudget = 20000
)

// allowSubnetHost reports whether one more host inside ip's /24 may be swept.
// Callers must treat a false result as "skip this neighbour", never as an error.
//
// The two budgets are separate on purpose: the per-/24 cap stops the recursive
// fan-out, and the global cap stops a run that sees thousands of distinct racks
// (a shared-hosting range) from queueing 16 lookups for each of them.
func (s *sharedState) allowSubnetHost(ip string) bool {
	if s == nil || ip == "" {
		return false
	}
	parsed := net.ParseIP(ip)
	if parsed == nil {
		return false
	}
	v4 := parsed.To4()
	if v4 == nil {
		return false // IPv6 has no /24 rack semantics here; skip sweeping
	}
	key := fmt.Sprintf("%d.%d.%d", v4[0], v4[1], v4[2])

	s.mu.Lock()
	defer s.mu.Unlock()
	if s.subnetSwept == nil {
		s.subnetSwept = make(map[string]int)
	}
	n, seen := s.subnetSwept[key]
	if !seen {
		if s.subnetsTaken >= subnetCountBudget {
			return false
		}
		s.subnetsTaken++
	}
	if n >= subnetHostBudget {
		return false
	}
	s.subnetSwept[key] = n + 1
	return true
}

// claimRackHost atomically decides whether ip may be swept NOW and, if so, marks
// it scanned and bills it against the /24 budget in one critical section.
//
// This is allowSubnetHost + the ipDone write merged together, and it exists for
// ONE caller: expandReverse's rack fallback already holds s.mu while iterating
// shared.ipDone to collect candidates, so it must release the lock before doing
// anything else — but the dedup check and the budget check have to stay atomic or
// two expanders racing on the same rack would both claim it. Collecting first and
// claiming through this helper after unlocking keeps both properties.
//
// A denied host is NOT marked ipDone: budget-exhausted means "we chose not to
// sweep this rack", not "we scanned it", and other paths use ipDone as a truth
// about scanning.
func (s *sharedState) claimRackHost(ip string) bool {
	if s == nil || ip == "" {
		return false
	}
	parsed := net.ParseIP(ip)
	if parsed == nil {
		return false
	}
	v4 := parsed.To4()
	if v4 == nil {
		return false
	}
	key := fmt.Sprintf("%d.%d.%d", v4[0], v4[1], v4[2])

	s.mu.Lock()
	defer s.mu.Unlock()
	if s.ipDone[ip] {
		return false
	}
	if s.subnetSwept == nil {
		s.subnetSwept = make(map[string]int)
	}
	n, seen := s.subnetSwept[key]
	if !seen {
		if s.subnetsTaken >= subnetCountBudget {
			return false
		}
		s.subnetsTaken++
	}
	if n >= subnetHostBudget {
		return false
	}
	s.subnetSwept[key] = n + 1
	if s.ipDone == nil {
		s.ipDone = make(map[string]bool)
	}
	s.ipDone[ip] = true
	return true
}

// noteSuspectApex books one "+1 only" re-scan and reports how many this apex has
// spent. Kept separate from noteLimitedApex because the two have very different
// budgets: a real block is worth limitRescanMax attempts WITH a fresh exit each
// time, while a thin answer only earns suspectRescanMax attempts and must NOT
// force a rotation. Sharing one counter meant a 1-row apex inherited the 24h
// provider's budget and, worse, its rotation.
func (s *sharedState) noteSuspectApex(apex string) int {
	if s == nil || apex == "" {
		return suspectRescanMax
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.apexSuspect == nil {
		s.apexSuspect = make(map[string]int)
	}
	s.apexSuspect[apex]++
	return s.apexSuspect[apex]
}

// takePending moves the re-queue buffer into dst (bounded by max).
func (s *sharedState) takePending(max int) []string {
	if s == nil {
		return nil
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.pendingApex) == 0 {
		return nil
	}
	n := len(s.pendingApex)
	if max > 0 && n > max {
		n = max
	}
	out := append([]string(nil), s.pendingApex[:n]...)
	s.pendingApex = append([]string(nil), s.pendingApex[n:]...)
	return out
}

func (s *sharedState) addHarvestedIP(ip string) {
	if s == nil {
		return
	}
	ip = strings.TrimSpace(ip)
	if ip == "" || net.ParseIP(ip) == nil {
		return
	}
	if strings.HasPrefix(ip, "127.") || ip == "::1" || strings.HasPrefix(ip, "0.") {
		return
	}
	s.harvestedIPs.Store(ip, true)
}

// suffixSet is a list of domain suffixes indexed for O(labels) containment
// checks. The previous shape of inSkipZone/isBigTechOrPaaS scanned every entry
// with `strings.HasSuffix(d, "."+sfx)`, i.e. ~190 HasSuffix comparisons per
// call — measured at 3.8 µs for inSkipZone and 2.2 µs for isBigTechOrPaaS on a
// plain 4-label domain, and those two run on every host returned by every
// provider. Matching at label boundaries instead of scanning the list gives the
// exact same answer in ~0.15 µs.
type suffixSet map[string]struct{}

func newSuffixSet(list []string) suffixSet {
	m := make(suffixSet, len(list))
	for _, s := range list {
		if s != "" {
			m[s] = struct{}{}
		}
	}
	return m
}

// has reports whether d equals a listed suffix or ends with ".<suffix>".
// Equivalent to `d == z || strings.HasSuffix(d, "."+z)` for any listed z, but
// without allocating the "."+z concatenation per entry.
func (s suffixSet) has(d string) bool {
	if len(s) == 0 || d == "" {
		return false
	}
	if _, ok := s[d]; ok {
		return true
	}
	for i := 0; i < len(d); i++ {
		if d[i] == '.' {
			if _, ok := s[d[i+1:]]; ok {
				return true
			}
		}
	}
	return false
}

var expandSkipZones = []string{
	"1e100.net", "google.com", "googleapis.com", "gstatic.com",
	"cloudflare.com", "cloudflare.net", "cloudfront.net", "akamaiedge.net", "akamai.net",
	"amazonaws.com", "amazon.com", "azureedge.net", "azure.com",
	"microsoft.com", "facebook.com", "yahoo.com", "netflix.com",
	"fastly.net", "github.com", "githubusercontent.com",
	// Cloudflare Zero Trust Access & Tunnels
	"cloudflareaccess.com", "trycloudflare.com",
	// AI & ephemeral workspace deployment platforms
	"manus.space",
	// Automated wildcard spam clusters & parking scrapers
	"djg1.co", "whoisbucket.com", "jsdcoffee.com",
	// Microsoft 365 / SharePoint tenant platforms
	"microsoftonline.com", "onmicrosoft.com", "sharepoint.com",
	// Hosting panel auto-install placeholders, temporary hostnames, and CDN proxy clusters
	"justinstalledpanel.com", "cprapid.com", "secureserver.net",
	"hstgr.net", "hstgr.cloud", "webhostbox.net", "myhostadmin.net", "plesk.page", "directrouter.com",
	// Hosting farm & SaaS multi-tenant platforms
	"worldsysweb.com", "marketcube.io", "relinns.website", "hnh.digital",
	"intract.io", "msschool.cloud", "empsecure.com", "djpcloud.nl",
	"webapps.net", "securedserverspace.com", "spinstack.dev", "shopify.com",
	"b-cdn.net", "akadns.net",
	// Free Dynamic DNS & ephemeral edge platforms
	"eu.cc", "edgeone.app", "edgeone.dev", "skpr.io", "softr.app",
	"cloudns.net", "cloudns.org", "cloudns.biz", "cloudns.asia",
	"duckdns.org", "hopto.org", "zapto.org", "no-ip.org", "no-ip.biz", "no-ip.info", "ddns.net",
	"bplaced.net", "000webhostapp.com", "rf.gd", "epizy.com", "infinityfreeapp.com",
	"freehostia.com", "cpanel.site",
	// Developer tunneling & serverless app platforms
	"ngrok.io", "ngrok-free.app", "localtunnel.me", "serveo.net",
	"fly.dev", "render.com", "onrender.com", "railway.app", "up.railway.app",
	"deno.dev", "supabase.co",
}

// expandSkipZoneSet indexes expandSkipZones for label-boundary matching.
var expandSkipZoneSet = newSuffixSet(expandSkipZones)

func inSkipZone(d string) bool {
	d = strings.ToLower(d)
	if isBigTechOrPaaS(d) {
		return true
	}
	return expandSkipZoneSet.has(d)
}

func apexOf(d string) string {
	d = strings.TrimSpace(strings.ToLower(d))
	d = strings.TrimSuffix(d, ".")
	if a, ok := effectiveTLDPlusOne(d); ok {
		return a
	}
	p := strings.Split(d, ".")
	if len(p) >= 2 {
		return strings.Join(p[len(p)-2:], ".")
	}
	return d
}

// bigTechApexes: exact apex domains of Big Tech, raw CDN, and global social media
var bigTechApexes = map[string]bool{
	// Google
	"google.com": true, "googleapis.com": true, "gstatic.com": true, "1e100.net": true, "googleusercontent.com": true, "googletagmanager.com": true,
	// Facebook / Meta
	"facebook.com": true, "fb.com": true, "meta.com": true, "instagram.com": true, "whatsapp.com": true, "whatsapp.net": true, "fbcdn.net": true,
	// Microsoft
	"microsoft.com": true, "live.com": true, "office.com": true, "office365.com": true, "msn.com": true, "bing.com": true, "azure.com": true, "azureedge.net": true, "windows.net": true, "skype.com": true,
	// Apple
	"apple.com": true, "icloud.com": true, "mzstatic.com": true,
	// Amazon
	"amazon.com": true, "amazonaws.com": true, "cloudfront.net": true,
	// Cloudflare / CDN
	"cloudflare.com": true, "cloudflare.net": true, "akamaiedge.net": true, "akamai.net": true, "akamaitechnologies.com": true, "fastly.net": true,
	// Social / Streaming / Messaging / Search
	"twitter.com": true, "x.com": true, "twimg.com": true,
	"linkedin.com": true, "licdn.com": true,
	"tiktok.com": true, "byteoversea.com": true,
	"netflix.com": true, "nflxvideo.net": true, "nflximg.net": true,
	"telegram.org": true, "t.me": true,
	"yandex.com": true, "yandex.net": true, "yandex.ru": true,
}

// freePaaSSuffixes: shared free hosting, PaaS, and serverless platforms where subdomains are arbitrary users
var freePaaSSuffixes = []string{
	"pages.dev",
	"workers.dev",
	"github.io",
	"githubusercontent.com",
	"github.com",
	"gitlab.io",
	"vercel.app",
	"vercel.com",
	"netlify.app",
	"firebaseapp.com",
	"web.app",
	"azurewebsites.net",
	"herokuapp.com",
	"myshopify.com",
	"blogspot.com",
	"wordpress.com",
	"wixsite.com",
	// Hosting panel auto-install placeholders & ephemeral hosting platforms
	"justinstalledpanel.com",
	"cprapid.com",
	"secureserver.net",
	"hstgr.net",
	"hstgr.cloud",
	"webhostbox.net",
	"myhostadmin.net",
	"plesk.page",
	"directrouter.com",
	// Cloudflare Zero Trust Access & Tunnels
	"cloudflareaccess.com",
	"trycloudflare.com",
	// AI & ephemeral workspace deployment platforms
	"manus.space",
	// Automated wildcard spam clusters & parking scrapers
	"djg1.co",
	"whoisbucket.com",
	"jsdcoffee.com",
	// Microsoft 365 / SharePoint tenant platforms
	"microsoftonline.com",
	"onmicrosoft.com",
	"sharepoint.com",
	// Hosting farm & SaaS multi-tenant platforms
	"worldsysweb.com",
	"marketcube.io",
	"relinns.website",
	"hnh.digital",
	"intract.io",
	"msschool.cloud",
	"empsecure.com",
	"djpcloud.nl",
	"webapps.net",
	"securedserverspace.com",
	"spinstack.dev",
	"shopify.com",
	"b-cdn.net",
	"akadns.net",
	// Free Dynamic DNS & ephemeral edge platforms
	"eu.cc",
	"edgeone.app",
	"edgeone.dev",
	"skpr.io",
	"softr.app",
	"cloudns.net",
	"cloudns.org",
	"cloudns.biz",
	"cloudns.asia",
	"duckdns.org",
	"hopto.org",
	"zapto.org",
	"no-ip.org",
	"no-ip.biz",
	"no-ip.info",
	"ddns.net",
	"bplaced.net",
	"000webhostapp.com",
	"rf.gd",
	"epizy.com",
	"infinityfreeapp.com",
	"freehostia.com",
	"cpanel.site",
	// Developer tunneling & serverless app platforms
	"ngrok.io",
	"ngrok-free.app",
	"localtunnel.me",
	"serveo.net",
	"fly.dev",
	"render.com",
	"onrender.com",
	"railway.app",
	"up.railway.app",
	"deno.dev",
	"supabase.co",
}

// spamBlogSuffixes: free blog/forum/shop/SEO-spam hosting platforms. Every
// subdomain is a user-generated page — almost always an auto-generated,
// keyword-stuffed SEO/parking/cam spam entry, never a meaningful enumeration
// target. Kept separate from freePaaSSuffixes (legit PaaS like pages.dev /
// github.io) for clarity, but dropped just the same.
var spamBlogSuffixes = []string{
	// free blog / SEO-spam farms (name+digits, keyword stuffing)
	"mpeblog.com", "timeblog.net", "onesmablog.com", "shotblogs.com",
	"getblogs.net", "alltdesign.com", "xzblogs.com", "blogkoo.com",
	"thezenweb.com", "jaiblogs.com", "diowebhost.com", "articlealley.com",
	"blog.hr", "blog.terra.com.br", "flogbrasil.terra.com.br", "letras.terra.com.br", "weblogger.terra.com.br", "dnice.cc",
	// free forum / shop / game profile hosts
	"forumer.com", "imweb.me", "gamezhero.com",
	// random-hash customer platforms
	"stspg-customer.com", "zhongmengwy.com", "soopage.com",
	// SEO product/keyword spam + cam spam
	"windows10compatible.com", "china-and-china.com", "camzania.com",
}

// paasSuffixSet / spamBlogSuffixSet index the two platform lists for
// label-boundary matching (see suffixSet).
var (
	paasSuffixSet     = newSuffixSet(freePaaSSuffixes)
	spamBlogSuffixSet = newSuffixSet(spamBlogSuffixes)
)

// isBigTechOrPaaS reports true if the domain belongs to Big Tech, CDN infra, or a free shared hosting platform
func isBigTechOrPaaS(d string) bool {
	d = strings.ToLower(strings.TrimSpace(d))
	d = strings.TrimPrefix(d, "*.")
	d = strings.TrimSuffix(d, ".")
	if d == "" {
		return false
	}
	// 1. Check free PaaS / hosting platforms (e.g. *.pages.dev, *.vercel.app)
	if paasSuffixSet.has(d) {
		return true
	}
	// 1b. Free blog/forum/SEO-spam hosting platforms (every subdomain is a
	// generated spam page, never a real enumeration target).
	if spamBlogSuffixSet.has(d) {
		return true
	}
	// 2. Check apex domain against Big Tech
	apex := apexOf(d)
	if bigTechApexes[apex] {
		return true
	}
	// 3. Google/Amazon/Blogspot ccTLD check on apex (e.g. google.co.id, amazon.co.uk)
	if strings.HasPrefix(apex, "google.") || strings.HasPrefix(apex, "amazon.") || strings.HasPrefix(apex, "blogspot.") {
		return true
	}
	return false
}

func randomName() string {
	b := make([]byte, 4)
	rand.Read(b)
	return filepath.Join("results", "out_"+hex.EncodeToString(b)+".txt")
}

func torRotateCtrl(ctrlAddr string) bool {
	if ctrlAddr == "" {
		ctrlAddr = torControlAddrFor(defaultTorSocks)
	}
	if ctrlAddr == "" {
		ctrlAddr = defaultTorCtrl
	}
	// singleflight per-ctrl + cooldown, try-lock non-blocking
	torRotateMu.Lock()
	if torRotateFlight[ctrlAddr] {
		torRotateMu.Unlock()
		return false
	}
	if last, ok := torRotateLast[ctrlAddr]; ok && time.Since(last) < torRotateCooldown {
		torRotateMu.Unlock()
		return false
	}
	torRotateFlight[ctrlAddr] = true
	torRotateMu.Unlock()
	defer func() {
		torRotateMu.Lock()
		delete(torRotateFlight, ctrlAddr)
		torRotateLast[ctrlAddr] = time.Now()
		torRotateMu.Unlock()
	}()
	c, err := net.DialTimeout("tcp", ctrlAddr, 3*time.Second)
	if err != nil {
		return false
	}
	defer c.Close()
	c.SetDeadline(time.Now().Add(4 * time.Second))
	fmt.Fprintf(c, "AUTHENTICATE \"\"\r\n")
	buf := make([]byte, 128)
	n, _ := c.Read(buf)
	if strings.Contains(string(buf[:n]), "515") {
		if cookie := findTorCookie(); len(cookie) > 0 {
			hexCookie := hex.EncodeToString(cookie)
			fmt.Fprintf(c, "AUTHENTICATE %s\r\n", hexCookie)
			n, _ = c.Read(buf)
		}
	}
	if !strings.Contains(string(buf[:n]), "250") {
		return false
	}
	fmt.Fprintf(c, "SIGNAL NEWNYM\r\n")
	n, _ = c.Read(buf)
	if strings.Contains(string(buf[:n]), "250") {
		guiLogf("system", "", 0, "[tor] NEWNYM OK (ctrl=%s) wait 5s", ctrlAddr)
		time.Sleep(5 * time.Second)
		return true
	}
	return false
}

func torCtrlFromSocks(socksAddr string) string {
	if socksAddr == "" || socksAddr == "off" || socksAddr == "false" {
		return ""
	}
	host, portStr, err := net.SplitHostPort(socksAddr)
	if err != nil {
		if p, err := strconv.Atoi(socksAddr); err == nil && p > 0 {
			return "127.0.0.1:" + strconv.Itoa(p+1)
		}
		return defaultTorCtrl
	}
	port, err := strconv.Atoi(portStr)
	if err != nil || port <= 0 {
		return defaultTorCtrl
	}
	return host + ":" + strconv.Itoa(port+1)
}

var (
	sharedDirectTransport = &http.Transport{
		MaxIdleConns:        256,
		MaxIdleConnsPerHost: 64,
		IdleConnTimeout:     60 * time.Second,
		TLSHandshakeTimeout: 10 * time.Second,
		DisableCompression:  false,
	}
	sharedDirectClient = &http.Client{
		Transport: sharedDirectTransport,
		Timeout:   httpTimeout,
	}
)

// normalizeTorAddr accepts the same bare-port form torports.txt accepts
// ("9052") and turns it into something dialable. net.Dial needs host:port, so
// an explicit `-tor 9052` used to be masked by the fleet override and now has
// to be normalized instead of failing the probe.
func normalizeTorAddr(addr string) string {
	if addr == "" || strings.Contains(addr, ":") {
		return addr
	}
	if _, err := net.LookupPort("tcp", addr); err == nil {
		return "127.0.0.1:" + addr
	}
	return addr
}

// torEffectiveAddr resolves the SOCKS port a worker should use. An explicit
// -tor address always wins; the torports.txt fleet is only consulted when the
// caller left the default. (Before: the fleet pick silently replaced ANY
// -tor value, so `-tor 127.0.0.1:9150` still went out over the fleet.)
func torEffectiveAddr(torAddr string, workerID int) string {
	if torAddr != "" && torAddr != defaultTorSocks {
		return normalizeTorAddr(torAddr)
	}
	if addrs := loadTorFleet(); len(addrs) > 0 {
		return pickTorAddr(workerID)
	}
	return torAddr
}

func newTorClient(torAddr string, workerID int, useTor bool) (*http.Client, *http.Client, bool, string) {
	direct := sharedDirectClient
	if !useTor || torAddr == "" || torAddr == "off" || torAddr == "false" {
		return direct, direct, false, ""
	}
	// pin worker->fleet addr DULU, probe SETELAH pick. Probe mentah sebelum pick
	// salah bila fleet member mati (probe 9050 OK, pick 9052 mati = error/request).
	eff := torEffectiveAddr(torAddr, workerID)
	if !tcpProbe(eff) {
		if tcpProbe(defaultTorSocks) {
			if eff != defaultTorSocks {
				torFallbackOnce.Do(func() {
					guiLogf("tor", "", 0, "[tor] %s tidak bisa dihubungi - fallback ke %s", eff, defaultTorSocks)
				})
			}
			eff = defaultTorSocks
		} else if ensureTorRunning() {
			eff = defaultTorSocks
		} else {
			return direct, direct, false, ""
		}
	}
	// Password is torSocksPass (constant): IsolateSOCKSAuth keys on the
	// (user,password) pair and the username already carries worker isolation.
	// A per-construction random password here made the initial client's circuit
	// unmatchable with any claimed identity.
	auth := &proxy.Auth{User: fmt.Sprintf("w%d", workerID), Password: torSocksPass}
	dialer, err := proxy.SOCKS5("tcp", eff, auth, proxy.Direct)
	if err != nil {
		return direct, direct, false, ""
	}
	c := &http.Client{
		Transport: &http.Transport{
			DialContext:         torDialContext(dialer),
			MaxIdleConns:        128,
			MaxIdleConnsPerHost: 32,
			IdleConnTimeout:     60 * time.Second,
		},
		Timeout: httpTimeout,
	}
	return c, direct, true, eff
}

// torDialContext adapts a SOCKS5 proxy dialer into the context-aware DialContext
// the HTTP transport prefers.
//
// The transports used to set Transport.Dial = dialer.Dial. That variant runs
// x/net's SOCKS handshake with context.Background(): no socket deadline and no
// ctx watcher, so a CONNECT that Tor accepts but never answers (overloaded
// instance, circuit still building) blocks its goroutine until the OS socket
// dies. Traced with the debug pprof: 84% of ~1.9k goroutines were
// net/http.(*Transport).dialConn parked in IO wait, growing ~27/s while
// throughput decayed 349 -> 202/s over 64s.
//
// DialContext instead carries a deadline down to x/net/socks, which sets it on
// the socket AND aborts the handshake when the context is done — so a stuck
// dial now fails within torDialTimeout and is retried instead of piling up.
func torDialContext(d proxy.Dialer) func(context.Context, string, string) (net.Conn, error) {
	cd, ok := d.(proxy.ContextDialer)
	return func(ctx context.Context, network, addr string) (net.Conn, error) {
		dctx, cancel := context.WithTimeout(ctx, torDialTimeout)
		defer cancel()
		if ok {
			return cd.DialContext(dctx, network, addr)
		}
		// Non-context dialer: run it aside and abandon it on timeout (closing
		// whatever connection eventually comes back).
		type dialRes struct {
			c   net.Conn
			err error
		}
		ch := make(chan dialRes, 1)
		go func() {
			c, err := d.Dial(network, addr)
			ch <- dialRes{c, err}
		}()
		select {
		case r := <-ch:
			return r.c, r.err
		case <-dctx.Done():
			go func() {
				if r := <-ch; r.c != nil {
					_ = r.c.Close()
				}
			}()
			return nil, dctx.Err()
		}
	}
}

// torUserSeq makes every per-request SOCKS5 identity unique.
var torUserSeq int64

// torFallbackOnce keeps the "explicit Tor port unreachable" notice to one line.
var torFallbackOnce sync.Once

// torCircuitUser returns the SOCKS5 auth username for one request. Tor's
// IsolateSOCKSAuth maps each (user, password) pair to its own circuit, so a NEW
// username = a NEW exit IP without the 5s SIGNAL NEWNYM wait. Uniqueness is what
// makes mass rotation work: the old `w%d_%d` form used UnixNano()%1000000,
// which repeats every 1 ms, so two requests exactly a millisecond apart were
// routed onto the same (already-burned) circuit.
func torCircuitUser(workerID int) string {
	seq := atomic.AddInt64(&torUserSeq, 1)
	return fmt.Sprintf("w%d_%d_%d", workerID, seq, time.Now().UnixNano()%1000000)
}

func (w *worker) torPickClient() *http.Client {
	if !w.torOn() {
		return w.direct
	}
	// Pinned unique exit (tor_exit_unique.go): reuse its keep-alive client so the
	// worker keeps the exit IP it claimed AND skips the per-request SOCKS+TLS
	// handshake. That handshake alone cost ~2-4s per request through Tor, which is
	// the real reason 50 workers felt slow.
	if c := w.pinnedClient(); c != nil {
		return c
	}
	// per-request isolate: USER baru -> circuit/exit baru pada Tor worker SENDIRI
	// (bypass 429 tanpa NEWNYM 5s). Pin w.torAddr — JANGAN hop fleet acak,
	// supaya worker0..4 deterministik 1:1 ke torports.txt dan NEWNYM tepat sasaran.
	addr := w.torAddr
	user := torCircuitUser(w.id)
	w.setLastTorUser(user)
	dialer, err := proxy.SOCKS5("tcp", addr, &proxy.Auth{User: user, Password: torSocksPass}, proxy.Direct)
	if err != nil {
		w.torMu.Lock()
		w.torTransport = nil
		w.torMu.Unlock()
		return w.direct
	}
	// Build the transport with robust keep-alive pooling to prevent Windows TIME_WAIT exhaustion
	tr := &http.Transport{
		DialContext:         torDialContext(dialer),
		MaxIdleConns:        64,
		MaxIdleConnsPerHost: 16,
		IdleConnTimeout:     45 * time.Second,
	}
	w.torMu.Lock()
	if oldTr := w.torTransport; oldTr != nil {
		oldTr.CloseIdleConnections()
	}
	w.torTransport = tr
	w.torMu.Unlock()
	return &http.Client{Transport: tr, Timeout: httpTimeout}
}

func (w *worker) torActiveClient() *http.Client {
	if !w.torOn() {
		return w.direct
	}
	// Pinned unique exit wins: it is the exit IP this worker claimed in the
	// registry, so every request keeps the "1 worker = 1 exit IP" guarantee.
	if c := w.pinnedClient(); c != nil {
		return c
	}
	w.torMu.Lock()
	defer w.torMu.Unlock()
	if w.client == nil {
		w.client = w.torPickClient()
	}
	return w.client
}

func (w *worker) rotateTorClient() *http.Client {
	if !w.torOn() {
		return w.direct
	}
	// F11: try-lock — a concurrent rotation inside this same worker (smart-engine
	// runs fetchRapid + fetchCrtNameDirect in parallel) must not interleave
	// release/claim cycles. The loser reuses whatever the winner installs
	// instead of stacking a second rotation.
	if !w.rotating.CompareAndSwap(false, true) {
		return w.torActiveClient()
	}
	defer w.rotating.Store(false)
	// A provider limit just burned this exit. Release it unconditionally so
	// idle connections on the burned circuit are severed and the old pin is wiped.
	w.releaseExit()
	if w.claimUniqueExit() {
		if c := w.pinnedClient(); c != nil {
			w.torMu.Lock()
			w.client = c
			w.torMu.Unlock()
			return c
		}
	}
	c := w.torPickClient()
	w.torMu.Lock()
	w.client = c
	w.torMu.Unlock()
	return c
}

// verifyTorIP: confirm Tor exit address via ipify/ifconfig/ CheckIP through
// the worker's SOCKS5 circuit. Empty string = failed/unverified.
func verifyTorIP(socksAddr string) string {
	if socksAddr == "" || socksAddr == "off" || socksAddr == "false" {
		return ""
	}
	// FIX H-02: use canonical torSocksPass so verify matches isolation circuit auth
	auth := &proxy.Auth{User: "ipcheck", Password: torSocksPass}
	dialer, err := proxy.SOCKS5("tcp", socksAddr, auth, proxy.Direct)
	if err != nil {
		return ""
	}
	c := &http.Client{Transport: &http.Transport{DialContext: torDialContext(dialer)}, Timeout: 8 * time.Second}
	for _, u := range []string{"https://api.ipify.org?format=text", "https://ifconfig.me/ip", "https://checkip.amazonaws.com"} {
		resp, err := c.Get(u)
		if err != nil {
			continue
		}
		b, _ := io.ReadAll(resp.Body)
		resp.Body.Close()
		if resp.StatusCode == 200 {
			ip := strings.TrimSpace(string(b))
			if ip != "" && ip != "<nil>" && !strings.Contains(ip, "<") {
				return ip
			}
		}
	}
	return ""
}

// parseTorCheckIP mengekstrak field IP dari respons /api/ip check.torproject.org.
func parseTorCheckIP(b []byte) string {
	var parsed struct {
		IsTor bool   `json:"IsTor"`
		IP    string `json:"IP"`
	}
	if json.Unmarshal(b, &parsed) != nil || parsed.IP == "" {
		return ""
	}
	return parsed.IP
}

// ---- per-worker scraper helpers ----
type worker struct {
	id     int
	client *http.Client // immutable Tor client (assigned once at construction)
	direct *http.Client // immutable direct client
	// useTor is atomic: concurrent fetch goroutines flip it to false when the
	// Tor circuit dies mid-run. Always go through torOn()/disableTor().
	useTor       atomic.Bool
	shared       *sharedState
	scopedCtx    context.Context
	torAddr      string
	torCtrl      string
	torIP        string
	torMu        sync.Mutex
	torTransport *http.Transport // guarded by torMu
	// lastAPI is written by the worker goroutine and read by the GUI/progress
	// goroutine -> atomic to avoid a data race.
	lastAPI atomic.Pointer[string]
	// lastUser is the SOCKS5 identity behind the most recent torPickClient()
	// draw, i.e. the stream that a 429/403/503 can be blamed on. It is how a
	// block gets attributed to an exact exit relay (tor_ctl.go).
	lastUser atomic.Pointer[string]
	// limitV is the UNATTRIBUTED verdict of the last provider call: quota /
	// rate-limit / Cloudflare challenge / "suspect (+1)". The worker loop reads
	// it to decide "switch IP and rescan the same target" (api_limit.go).
	limitV atomic.Pointer[limitVerdict]
	// limitBySrc keeps one verdict PER PROVIDER. EngineSmart fires fetchRapid and
	// fetchCrtNameDirect CONCURRENTLY inside a single worker, and both wrote the
	// single slot above: the node's verdict became "whoever wrote last", so a
	// signal from one provider could mask a clean answer from the other (and a
	// spurious rate verdict invented by ensureFreshExit losing the rotation
	// try-lock could survive into handleNode). limitVerdict() now aggregates
	// every slot worst-wins.
	limitBySrc [numLimitSources]atomic.Pointer[limitVerdict]
	// Latency baseline per provider (api_limit.go: noteLatency/noteSlowExit).
	// slowMu guards all four; lock order is pinMu -> slowMu, never the reverse.
	slowMu      sync.Mutex
	slowEWMA    [numLimitSources]float64 // EWMA seconds over HEALTHY samples only
	slowN       [numLimitSources]int     // healthy samples seen (baseline maturity)
	slowStrikes int                      // consecutive slow samples on slowFor
	slowFor     string                   // exit IP those strikes were measured on
	// refetch lets a limit-driven re-queue bypass the apexDone gate so the SAME
	// target is scanned again on a fresh IP until it succeeds.
	refetch atomic.Bool
	// Pinned exit (tor_exit_unique.go): one unique exit IP per worker, reused
	// with keep-alive; rotated only when a provider limit burns it.
	pinMu      sync.Mutex
	pinnedUser string
	pinClient  *http.Client
	exitFP     string
	exitIP     string
	// scopedCopy marks a short-lived fan-out copy (scopedTo). A copy SHARES the
	// parent's pin identity for reuse but must NEVER release/claim registry
	// entries: the fallback goroutines used to call rotateTorClient → releaseExit
	// → exitUniq.release(parentID), silently un-pinning the live parent so two
	// workers could end up on the same exit IP. Read-only after construction.
	scopedCopy bool
	// rotating serialises exit rotation WITHIN one worker: EngineSmart runs
	// fetchRapid + fetchCrtNameDirect on two goroutines of the same worker, and
	// both may hit a limit at once. Concurrent release+claim cycles interleave
	// (A releases what B just claimed). Try-lock, non-blocking: the loser simply
	// reuses the client the winner is installing — no rotation stack-up.
	rotating atomic.Bool
}

// torClientNow is the race-free accessor for the mutable client field.
// getRetry/resolveHost/scopedTo used to read w.client directly while
// rotateTorClient/torActiveClient write it under torMu — a real data race under
// -race with 50 workers.
//
// It prefers the PINNED client: the initial claim in workerFn does not rewrite
// w.client, so auxiliary paths (retry, DoH-over-Tor, fallback fan-out) used to
// dial out of the construction circuit — a DIFFERENT exit IP than the one the
// worker claimed, which broke the "1 worker = 1 exit IP" attribution and burned
// a second identity per worker.
func (w *worker) torClientNow() *http.Client {
	if w.torOn() {
		if c := w.pinnedClient(); c != nil {
			return c
		}
	}
	w.torMu.Lock()
	c := w.client
	w.torMu.Unlock()
	if c == nil {
		return w.direct
	}
	return c
}

// scopedTo returns a worker bound to ctx for a fallback fan-out WITHOUT copying
// the atomic fields. The old `wScoped := *w` (go vet: "assignment copies lock
// value ... contains sync/atomic.noCopy") also handed the copy its own useTor /
// limitV / pin state, so disableTor() and setLimitVerdict() on the copy were
// silently lost — including the "tor died mid-run" fallback.
func (w *worker) scopedTo(ctx context.Context) *worker {
	sc := &worker{
		id:         w.id,
		client:     w.torClientNow(),
		direct:     w.direct,
		shared:     w.shared,
		scopedCtx:  ctx,
		torAddr:    w.torAddr,
		torCtrl:    w.torCtrl,
		torIP:      w.torIP,
		scopedCopy: true,
	}
	sc.useTor.Store(w.torOn())
	sc.setLastTorUser(w.lastTorUser())
	sc.setLastAPI(w.api())
	// Copy the verdicts BY VALUE. The copy reads the parent's limit state, but its
	// own writes land on its own slots and never on the parent's; fetchCrt's
	// fallback path pushes them back with absorbLimitVerdicts once the fan-out is
	// done (otherwise every limit a fallback provider reported died with the copy
	// and the target got marked finished).
	if p := w.limitV.Load(); p != nil {
		cp := *p
		sc.limitV.Store(&cp)
	}
	for i := range w.limitBySrc {
		if p := w.limitBySrc[i].Load(); p != nil {
			cp := *p
			sc.limitBySrc[i].Store(&cp)
		}
	}
	w.pinMu.Lock()
	sc.pinnedUser, sc.exitFP, sc.exitIP = w.pinnedUser, w.exitFP, w.exitIP
	w.pinMu.Unlock()
	return sc
}

// torOn reports whether this worker still routes through Tor.
func (w *worker) torOn() bool {
	if w == nil {
		return false
	}
	return w.useTor.Load()
}

// disableTor switches this worker to direct mode (Tor died mid-run). Safe to
// call from concurrent fetch goroutines.
func (w *worker) disableTor() {
	if w == nil {
		return
	}
	w.useTor.Store(false)
}

// setLastAPI / api: race-free accessor for the display-only "last provider" tag.
func (w *worker) setLastAPI(s string) {
	if w == nil {
		return
	}
	w.lastAPI.Store(&s)
}

func (w *worker) api() string {
	if w == nil {
		return ""
	}
	if p := w.lastAPI.Load(); p != nil {
		return *p
	}
	return ""
}

func (w *worker) setLastTorUser(u string) {
	if w == nil || u == "" {
		return
	}
	w.lastUser.Store(&u)
}

// lastTorUser is the identity used by the last per-request circuit draw.
func (w *worker) lastTorUser() string {
	if w == nil {
		return ""
	}
	if p := w.lastUser.Load(); p != nil {
		return *p
	}
	return ""
}

func (w *worker) reqContext() context.Context {
	if w != nil && w.scopedCtx != nil {
		return w.scopedCtx
	}
	if w != nil && w.shared != nil && w.shared.ctx != nil {
		return w.shared.ctx
	}
	return context.Background()
}

func isConnRefused(err error) bool {
	if err == nil {
		return false
	}
	s := strings.ToLower(err.Error())
	return strings.Contains(s, "connection refused") ||
		strings.Contains(s, "could not connect") ||
		strings.Contains(s, "connectex") ||
		strings.Contains(s, "no connection could be made") ||
		strings.Contains(s, "actively refused")
}

// isQuotaHit detects crt.name free-tier exhaustion in error text or body:
// "free tier limit reached: 100 requests per IP per day".
// Probe live 2026-09-14: 96-byte body, 0 subs. Log eksplisit agar exhaust
// terbaca sebagai quota, bukan bug loop. ponytail: dukung token via env/API
// bila tersedia agar limit naik.
func isQuotaHit(err error) bool {
	if err == nil {
		return false
	}
	s := strings.ToLower(err.Error())
	return strings.Contains(s, "free tier limit") ||
		strings.Contains(s, "limit reached")
}

// crtAttemptTimeout bounds ONE crt.name attempt (connect + headers + body).
// getRetry used to have no per-request deadline at all — only the worker
// client's httpTimeout (30s) — so a single stalled Tor stream parked that worker
// for a full 30s, and because getRetry retries, one apex could stall ~60s while
// the run looked frozen (progress bar still, no new results). 15s is ~4x the
// measured Tor round trip (3-4s TLS negotiation through SOCKS) and still
// generous for the largest CT responses.
const crtAttemptTimeout = 6 * time.Second

// retryBackoff returns a bounded exponential backoff delay for attempt i.
// Deterministic (milliseconds) so retry pacing is predictable and testable:
//
//	attempt 0 -> 200ms, 1 -> 400ms, 2 -> 800ms, 3 -> 1.6s, capped at 2s.
func retryBackoff(attempt int) time.Duration {
	d := 200 * (1 << attempt) * time.Millisecond
	if d > 2*time.Second {
		d = 2 * time.Second
	}
	return d
}

// cancelOnCloseBody keeps a request context (and its deadline timer) alive until
// the response body is closed, then releases it. Callers read the body AFTER
// getRetry returns, so a plain `defer cancel()` would truncate every response;
// the previous code instead called directCancel() right before returning the
// 200 response of the direct fallback, which invalidated that body read and made
// the rescue path a silent no-op (it returned a 200 with an unreadable body).
type cancelOnCloseBody struct {
	io.ReadCloser
	cancel context.CancelFunc
}

func (b *cancelOnCloseBody) Close() error {
	err := b.ReadCloser.Close()
	if b.cancel != nil {
		b.cancel()
		b.cancel = nil
	}
	return err
}

func (w *worker) getRetry(url string) (*http.Response, error) {
	var last error
	for i := 0; i < maxRetries; i++ {
		// per-request isolate: fresh exit without NEWNYM 5s (verified 9/9 IP beda vs NEWNYM 1 IP stuck)
		client := w.direct
		if w.torOn() {
			client = w.torClientNow() // pinned circuit on the first attempt (race-free)
			if i > 0 {
				client = w.torPickClient() // fresh circuit on retries
			}
		}
		// Per-attempt deadline (see crtAttemptTimeout): without it a stalled
		// stream was only bounded by the client's 30s timeout, twice.
		ctx, cancel := context.WithTimeout(w.reqContext(), crtAttemptTimeout)
		req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
		if err != nil {
			cancel()
			return nil, err
		}
		if crtNameToken != "" {
			req.Header.Set("Authorization", "Bearer "+crtNameToken)
		}
		startReq := time.Now()
		resp, err := client.Do(req)
		elapsedReq := time.Since(startReq).Milliseconds()
		if err != nil {
			globalDebug.RecordNetworkLatency("crt", elapsedReq, 0, true)
			if w.reqContext().Err() != nil {
				cancel()
				return nil, w.reqContext().Err()
			}
			last = err
			// Tor mati di tengah (connection refused): matikan Tor worker ini,
			// lanjut direct. Tanpa ini semua retry gagal dan hasil 0.
			if w.torOn() && isConnRefused(err) && i == 0 {
				w.disableTor()
			}
			// Direct fallback for crt.name if Tor timed out or failed on final retry.
			// The body is wrapped so the 2500ms budget covers the body read too
			// (previously the context was cancelled before the caller could read
			// it, so this fallback never produced a single subdomain).
			if w.torOn() && i == maxRetries-1 && w.direct != nil {
				directCtx, directCancel := context.WithTimeout(context.Background(), 2500*time.Millisecond)
				reqD, errD := http.NewRequestWithContext(directCtx, "GET", url, nil)
				if errD == nil {
					if crtNameToken != "" {
						reqD.Header.Set("Authorization", "Bearer "+crtNameToken)
					}
					if respD, errD := w.direct.Do(reqD); errD == nil && respD.StatusCode == 200 {
						respD.Body = &cancelOnCloseBody{ReadCloser: respD.Body, cancel: directCancel}
						cancel()
						return respD, nil
					} else if respD != nil {
						respD.Body.Close()
					}
				}
				directCancel()
			}
			cancel()
			select {
			case <-w.reqContext().Done():
				return nil, w.reqContext().Err()
			case <-time.After(retryBackoff(i)):
			}
			continue
		}
		if resp.StatusCode == 404 || resp.StatusCode == 400 || resp.StatusCode == 413 {
			b, _ := io.ReadAll(resp.Body)
			resp.Body.Close()
			last = fmt.Errorf("http %d %.120s", resp.StatusCode, string(b))
			cancel()
			return nil, last
		}
		if resp.StatusCode == 429 || resp.StatusCode == 503 || resp.StatusCode == 403 {
			b, _ := io.ReadAll(resp.Body)
			resp.Body.Close()
			last = fmt.Errorf("http %d %.120s", resp.StatusCode, string(b))
			// Attribute the block to the relay that served this attempt, so it can
			// be excluded from future circuits (tor_exit_health.go).
			exitHealth.noteBlocked(w.torAddr, w.torUserForAttempt(i), fmt.Sprintf("http %d", resp.StatusCode))
			// per-request already new exit, only global rotate on 2nd 429
			if w.torOn() && i == 1 {
				// async rotate: NEWNYM + 5s cooldown must NOT block this worker.
				// Per-worker rotate via dedicated control port; other workers
				// keep fetching on their own circuits in parallel.
				go func() { _ = torRotateCtrl(w.torCtrl) }()
			} else {
				select {
				case <-w.reqContext().Done():
					cancel()
					return nil, w.reqContext().Err()
				case <-time.After(retryBackoff(i)):
				}
			}
			cancel()
			continue
		}
		if resp.StatusCode != 200 {
			b, _ := io.ReadAll(resp.Body)
			resp.Body.Close()
			last = fmt.Errorf("http %d %.120s", resp.StatusCode, string(b))
			cancel()
			select {
			case <-w.reqContext().Done():
				return nil, w.reqContext().Err()
			case <-time.After(retryBackoff(i)):
			}
			continue
		}
		// Success: hand the deadline over to the body reader (closed by caller).
		resp.Body = &cancelOnCloseBody{ReadCloser: resp.Body, cancel: cancel}
		return resp, nil
	}
	return nil, last
}

func (w *worker) fetchHackertarget(apex string) []string {
	// free fallback for 413/502
	url := fmt.Sprintf("https://api.hackertarget.com/hostsearch/?q=%s", apex)
	ctx, cancel := context.WithTimeout(w.reqContext(), 3*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		guiLogQuiet("error", apex, 0, "[hackertarget] %s request error: %v", apex, err)
		return nil
	}
	req.Header.Set("User-Agent", "Mozilla/5.0")
	client := w.direct
	if w.torOn() {
		client = w.torPickClient()
	}
	resp, err := client.Do(req)
	if err != nil {
		guiLogQuiet("error", apex, 0, "[hackertarget] %s network error: %v", apex, err)
		return nil
	}
	defer drainAndClose(resp.Body)
	if resp.StatusCode != 200 {
		guiLogQuiet("error", apex, 0, "[hackertarget] %s HTTP %d", apex, resp.StatusCode)
		return nil
	}
	b, _ := io.ReadAll(resp.Body)
	body := strings.TrimSpace(string(b))
	if strings.Contains(body, "API count exceeded") || strings.Contains(body, "error") {
		return nil
	}
	seen := map[string]bool{}
	var out []string
	for _, ln := range strings.Split(body, "\n") {
		parts := strings.Split(strings.TrimSpace(ln), ",")
		d := strings.ToLower(strings.TrimSpace(parts[0]))
		if d == "" || !strings.Contains(d, ".") || seen[d] {
			continue
		}
		seen[d] = true
		out = append(out, d)
		if len(parts) >= 2 && w.shared != nil {
			w.shared.addHarvestedIP(parts[1])
		}
	}
	return out
}

type apiCircuitBreaker struct {
	mu       sync.RWMutex
	failures int
	until    time.Time
	perExit  map[string]time.Time
}

var (
	cbHackerTarget = &apiCircuitBreaker{}
	cbURLScan      = &apiCircuitBreaker{}
	cbRobtex       = &apiCircuitBreaker{}
)

// Tntcode (domains.tntcode.com) is the highest-yield free reverse-IP source
// known: one page lists up to 100,000 hostnames on an IP. It is gzip-served, so
// a 100k-domain page is only ~2-3 MB on the wire, and the parser streams it so
// the tens-of-MB decompressed body never sits in memory. Enabled by default;
// -tntcode=false turns it off. Discovered via batmanuwu/Nosleep-reverseip.
var (
	tntcodeEnabled = true
	// tntcodePageBase is a var (not a const) so tests can retarget it.
	tntcodePageBase = "https://domains.tntcode.com"
	// tntcodeSem bounds concurrent tntcode fetches: each is a multi-MB transfer,
	// and a burst would swamp a single Tor circuit or the uplink.
	tntcodeSem = make(chan struct{}, tntcodeMaxConcurrent)
)

const (
	// tntcodeMaxBytes caps the DECOMPRESSED page read, guarding a pathological IP.
	tntcodeMaxBytes = 96 << 20
	// tntcodeTimeout is generous: a ~100k-domain page can take several seconds
	// even gzipped, and more through Tor.
	tntcodeTimeout       = 25 * time.Second
	tntcodeMaxConcurrent = 24
	// dgaClusterMax bounds filterValidBatch's O(sum group^2) DGA clustering pass.
	// A 100k-hostname payload (tntcode) would otherwise turn one long
	// length-group into billions of comparisons.
	dgaClusterMax = 4000
	// writeLockChunk bounds how many domains writeLines processes per hold of
	// s.mu, so a 100k-domain payload cannot stall every other worker's funnel.
	writeLockChunk = 2048
)

// parseTntcodeTextarea streams a tntcode IP page and returns the hostnames from
// its <textarea> block (first one shares the open-tag line, the rest are one per
// line). Also accepts the anchor form href="/domain/x" as a fallback so a page
// layout change still yields data. Byte-streamed, so memory stays flat on a
// 30 MB+ page.
func parseTntcodeTextarea(r io.Reader) []string {
	sc := bufio.NewScanner(r)
	sc.Buffer(make([]byte, 64*1024), 4*1024*1024)
	acc := make(map[string]struct{}, 4096)
	inTa := false
	for sc.Scan() {
		line := sc.Text()
		if !inTa {
			if i := strings.Index(line, "<textarea"); i >= 0 {
				inTa = true
				if j := strings.IndexByte(line[i:], '>'); j >= 0 {
					addTntcodeCandidate(acc, line[i+j+1:])
				}
				continue
			}
			// Anchor form fallback: extract EVERY href="/domain/x" on the line.
			for i := 0; i < len(line); {
				j := strings.Index(line[i:], "/domain/")
				if j < 0 {
					break
				}
				start := i + j + len("/domain/")
				end := strings.IndexByte(line[start:], '"')
				if end <= 0 {
					break
				}
				addTntcodeCandidate(acc, line[start:start+end])
				i = start + end
			}
			continue
		}
		if i := strings.Index(line, "</textarea>"); i >= 0 {
			if i > 0 {
				addTntcodeCandidate(acc, line[:i])
			}
			inTa = false
			continue
		}
		addTntcodeCandidate(acc, line)
	}
	out := make([]string, 0, len(acc))
	for h := range acc {
		out = append(out, h)
	}
	return out
}

// addTntcodeCandidate keeps a line only if it can be a bare hostname (no HTML
// markup, no spaces). Rejects the surrounding markup lines cheaply; the real
// validation still happens in filterValid at the call site.
func addTntcodeCandidate(acc map[string]struct{}, s string) {
	s = strings.ToLower(strings.TrimSpace(s))
	if s == "" || !strings.Contains(s, ".") || strings.ContainsAny(s, " <>\"'()") {
		return
	}
	acc[s] = struct{}{}
}

// fetchTntcode pulls the hostnames on ip from domains.tntcode.com. Concurrency
// is capped (a page is a few MB even gzipped); a caller that cannot get a slot
// within a short wait is skipped rather than stalling the IP queue, because the
// other reverse providers still cover that IP.
func (w *worker) fetchTntcode(ip string) []string {
	if !tntcodeEnabled || net.ParseIP(ip) == nil {
		return nil
	}
	// Per-exit-IP limit gate, same contract as crt.name/rapiddns: if THIS exit
	// already hit a wall, rotate the Tor exit BEFORE spending the request.
	if !w.ensureFreshExit(srcTntcode) {
		return nil
	}
	select {
	case tntcodeSem <- struct{}{}:
		defer func() { <-tntcodeSem }()
	case <-time.After(6 * time.Second):
		return nil
	}
	u := tntcodePageBase + "/ip/" + neturl.PathEscape(ip)
	ctx, cancel := context.WithTimeout(w.reqContext(), tntcodeTimeout)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, "GET", u, nil)
	if err != nil {
		return nil
	}
	req.Header.Set("User-Agent", browserUA)
	req.Header.Set("Accept", "text/html,application/xhtml+xml")
	client := w.direct
	if w.torOn() {
		client = w.torPickClient()
	}
	start := time.Now()
	resp, err := client.Do(req)
	if err != nil {
		return nil
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		// A per-IP block (429/403/503) cools THIS exit so the next tntcode call
		// rotates, instead of parking the whole provider behind a lockout.
		if v := classifyLimit(srcTntcode, resp.StatusCode, resp.Header, nil); v.blocked() {
			w.noteLimit(srcTntcode, v)
		}
		return nil
	}
	raw := parseTntcodeTextarea(io.LimitReader(resp.Body, tntcodeMaxBytes))
	if len(raw) == 0 {
		return nil
	}
	// Slow-exit policy: a ~36 MB page is legitimately slow, so measure against
	// the provider budget rather than punishing a healthy relay.
	if d := time.Since(start); d > 0 && w.noteLatency(srcTntcode, d) {
		w.noteSlowExit(srcTntcode, d)
	}
	return filterValid(raw)
}

func (cb *apiCircuitBreaker) allowExit(exitKey string) bool {
	cb.mu.RLock()
	defer cb.mu.RUnlock()
	now := time.Now()
	if !now.After(cb.until) {
		return false
	}
	if exitKey != "" && cb.perExit != nil {
		if until, ok := cb.perExit[exitKey]; ok && !now.After(until) {
			return false
		}
	}
	return true
}

func (cb *apiCircuitBreaker) recordExitSuccess(exitKey string) {
	cb.mu.Lock()
	defer cb.mu.Unlock()
	if exitKey != "" && cb.perExit != nil {
		delete(cb.perExit, exitKey)
	}
	cb.failures = 0
	cb.until = time.Time{}
}

func (cb *apiCircuitBreaker) recordExitFailure(exitKey string, is429 bool) {
	cb.mu.Lock()
	defer cb.mu.Unlock()
	if exitKey != "" {
		if cb.perExit == nil {
			cb.perExit = make(map[string]time.Time)
		}
		if len(cb.perExit) > 1024 {
			now := time.Now()
			for k, v := range cb.perExit {
				if now.After(v) {
					delete(cb.perExit, k)
				}
			}
		}
		cb.perExit[exitKey] = time.Now().Add(5 * time.Minute)
		return
	}
	cb.failures++
	if is429 || cb.failures >= 3 {
		cb.until = time.Now().Add(5 * time.Minute)
	}
}

func (cb *apiCircuitBreaker) allow() bool { return cb.allowExit("") }
func (cb *apiCircuitBreaker) recordSuccess() { cb.recordExitSuccess("") }
func (cb *apiCircuitBreaker) recordFailure(is429 bool) { cb.recordExitFailure("", is429) }

// fetchHackerTargetReverseIP: https://api.hackertarget.com/reverseiplookup/?q=IP -> hostnames on same IP
func (w *worker) fetchHackerTargetReverseIP(ip string) []string {
	exitKey, _ := w.exitKeyFor()
	if net.ParseIP(ip) == nil || !cbHackerTarget.allowExit(exitKey) {
		return nil
	}
	// hackertarget enforces a PER IP daily quota ("API count exceeded"), so the
	// Tor exit is the quota: rotate it before spending a doomed request.
	if !w.ensureFreshExit(srcReverse) {
		return nil
	}
	u := fmt.Sprintf("https://api.hackertarget.com/reverseiplookup/?q=%s", ip)
	query := func(client *http.Client, timeout time.Duration) ([]string, int) {
		ctx, cancel := context.WithTimeout(w.reqContext(), timeout)
		defer cancel()
		req, err := http.NewRequestWithContext(ctx, "GET", u, nil)
		if err != nil {
			return nil, -1
		}
		req.Header.Set("User-Agent", "Mozilla/5.0")
		resp, err := client.Do(req)
		if err != nil {
			return nil, -1
		}
		defer drainAndClose(resp.Body)
		if resp.StatusCode == 429 {
			cbHackerTarget.recordExitFailure(exitKey, true)
			w.noteReverseLimit(resp.StatusCode, resp.Header, nil)
			return nil, resp.StatusCode
		}
		if resp.StatusCode != 200 {
			return nil, resp.StatusCode
		}
		b, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
		body := strings.TrimSpace(string(b))
		if strings.Contains(body, "API count exceeded") {
			cbHackerTarget.recordExitFailure(exitKey, true)
			w.noteReverseLimit(200, nil, b)
			return nil, 200
		}
		if strings.Contains(body, "No records found") || strings.Contains(body, "No DNS A records found") || strings.Contains(body, "error") {
			return nil, 200
		}
		cbHackerTarget.recordExitSuccess(exitKey)
		cbHackerTarget.recordSuccess()
		seen := make(map[string]bool)
		var out []string
		for _, ln := range strings.Split(body, "\n") {
			d := strings.ToLower(strings.TrimSpace(ln))
			if d == "" || !strings.Contains(d, ".") || seen[d] || !isValidDomain(d) {
				continue
			}
			seen[d] = true
			out = append(out, d)
		}
		return out, 200
	}

	client := w.direct
	if w.torOn() {
		client = w.torPickClient()
	}
	out, code := query(client, 4000*time.Millisecond)
	if len(out) > 0 {
		return out
	}
	if code > 0 {
		guiLogQuiet("error", ip, 0, "[hackertarget-rev] %s HTTP %d", ip, code)
	} else if code == -1 {
		guiLogQuiet("error", ip, 0, "[hackertarget-rev] %s network error", ip)
	}
	// Direct fallback if Tor failed, timed out, or returned 0
	if w.torOn() && (code != 200 || len(out) == 0) && w.direct != nil {
		directCtx, directCancel := context.WithTimeout(context.Background(), 2500*time.Millisecond)
		defer directCancel()
		reqD, errD := http.NewRequestWithContext(directCtx, "GET", u, nil)
		if errD == nil {
			reqD.Header.Set("User-Agent", "Mozilla/5.0")
			if respD, errD := w.direct.Do(reqD); errD == nil && respD.StatusCode == 200 {
				defer respD.Body.Close()
				bD, _ := io.ReadAll(io.LimitReader(respD.Body, 1<<20))
				bodyD := strings.TrimSpace(string(bD))
				if !strings.Contains(bodyD, "API count exceeded") && !strings.Contains(bodyD, "No records found") && !strings.Contains(bodyD, "No DNS A records found") && !strings.Contains(bodyD, "error") {
					seen := make(map[string]bool)
					var outD []string
					for _, ln := range strings.Split(bodyD, "\n") {
						d := strings.ToLower(strings.TrimSpace(ln))
						if d != "" && strings.Contains(d, ".") && !seen[d] && isValidDomain(d) {
							seen[d] = true
							outD = append(outD, d)
						}
					}
					if len(outD) > 0 {
						guiLogQuiet("system", ip, 0, "[hackertarget-rev] %s recovered via direct connection", ip)
						return outD
					}
				}
			} else if errD != nil {
				guiLogQuiet("error", ip, 0, "[hackertarget-rev] %s direct fallback network error: %v", ip, errD)
			} else if respD != nil {
				guiLogQuiet("error", ip, 0, "[hackertarget-rev] %s direct fallback HTTP %d", ip, respD.StatusCode)
				respD.Body.Close()
			}
		}
	}
	return nil
}

// fetchSubcenter: https://api.subdomain.center/?domain= -> JSON array. Verified 200 live.
func (w *worker) fetchSubcenter(apex string) []string {
	url := "https://api.subdomain.center/?domain=" + neturl.QueryEscape(apex)
	ctx, cancel := context.WithTimeout(w.reqContext(), 3*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		guiLogQuiet("error", apex, 0, "[subcenter] %s request error: %v", apex, err)
		return nil
	}
	req.Header.Set("User-Agent", "Mozilla/5.0")
	client := w.direct
	if w.torOn() {
		client = w.torPickClient()
	}
	resp, err := client.Do(req)
	if err != nil {
		guiLogQuiet("error", apex, 0, "[subcenter] %s network error: %v", apex, err)
		return nil
	}
	if resp.StatusCode != 200 {
		guiLogQuiet("error", apex, 0, "[subcenter] %s HTTP %d", apex, resp.StatusCode)
		drainAndClose(resp.Body)
		return nil
	}
	defer drainAndClose(resp.Body)
	b, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	var arr []string
	if err := json.Unmarshal(b, &arr); err != nil {
		return nil
	}
	return arr
}

// fetchURLScan: https://urlscan.io/api/v1/search/?q=ip:IP&size=100 -> results[].page.domain. Verified 200 live.
func (w *worker) fetchURLScan(ip string) []string {
	exitKey, _ := w.exitKeyFor()
	if net.ParseIP(ip) == nil || !cbURLScan.allowExit(exitKey) {
		return nil
	}
	if !w.ensureFreshExit(srcReverse) {
		return nil
	}
	url := fmt.Sprintf("https://urlscan.io/api/v1/search/?q=ip:%s&size=100", ip)
	query := func(client *http.Client, timeout time.Duration) ([]string, int) {
		ctx, cancel := context.WithTimeout(w.reqContext(), timeout)
		defer cancel()
		req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
		if err != nil {
			return nil, -1
		}
		req.Header.Set("User-Agent", "Mozilla/5.0")
		resp, err := client.Do(req)
		if err != nil {
			return nil, -1
		}
		defer drainAndClose(resp.Body)
		if resp.StatusCode == 429 {
			cbURLScan.recordExitFailure(exitKey, true)
			w.noteReverseLimit(resp.StatusCode, resp.Header, nil)
			return nil, resp.StatusCode
		}
		if resp.StatusCode != 200 {
			cbURLScan.recordExitFailure(exitKey, false)
			return nil, resp.StatusCode
		}
		b, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
		var data struct {
			Results []struct {
				Page struct {
					Domain string `json:"domain"`
				} `json:"page"`
			} `json:"results"`
		}
		if err := json.Unmarshal(b, &data); err != nil {
			return nil, 200
		}
		cbURLScan.recordExitSuccess(exitKey)
		cbURLScan.recordSuccess()
		seen := map[string]bool{}
		var out []string
		for _, r := range data.Results {
			d := strings.ToLower(strings.TrimSpace(r.Page.Domain))
			if d == "" || !strings.Contains(d, ".") || seen[d] || !isValidDomain(d) {
				continue
			}
			seen[d] = true
			out = append(out, d)
		}
		return out, 200
	}

	client := w.direct
	if w.torOn() {
		client = w.torPickClient()
	}
	out, code := query(client, 4000*time.Millisecond)
	if len(out) > 0 {
		return out
	}
	if code > 0 {
		guiLogQuiet("error", ip, 0, "[urlscan] %s HTTP %d", ip, code)
	} else if code == -1 {
		guiLogQuiet("error", ip, 0, "[urlscan] %s network error", ip)
	}
	if w.torOn() && (code != 200 || len(out) == 0) && w.direct != nil {
		outD, codeD := query(w.direct, 2000*time.Millisecond)
		if len(outD) > 0 {
			guiLogQuiet("system", ip, 0, "[urlscan] %s recovered via direct connection", ip)
			return outD
		}
		if codeD > 0 {
			guiLogQuiet("error", ip, 0, "[urlscan] %s direct fallback HTTP %d", ip, codeD)
		} else if codeD == -1 {
			guiLogQuiet("error", ip, 0, "[urlscan] %s direct fallback network error", ip)
		}
	}
	return nil
}

// fetchRobtex: https://freeapi.robtex.com/ipquery/IP -> {"pas":[{"o":host}]} or ["host"]. Verified 200 live.
func (w *worker) fetchRobtex(ip string) []string {
	exitKey, _ := w.exitKeyFor()
	if net.ParseIP(ip) == nil || !cbRobtex.allowExit(exitKey) {
		return nil
	}
	if !w.ensureFreshExit(srcReverse) {
		return nil
	}
	url := fmt.Sprintf("https://freeapi.robtex.com/ipquery/%s", ip)
	query := func(client *http.Client, timeout time.Duration) ([]string, int) {
		ctx, cancel := context.WithTimeout(w.reqContext(), timeout)
		defer cancel()
		req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
		if err != nil {
			return nil, -1
		}
		req.Header.Set("User-Agent", "Mozilla/5.0")
		resp, err := client.Do(req)
		if err != nil {
			return nil, -1
		}
		defer drainAndClose(resp.Body)
		if resp.StatusCode == 429 {
			cbRobtex.recordExitFailure(exitKey, true)
			w.noteReverseLimit(resp.StatusCode, resp.Header, nil)
			return nil, resp.StatusCode
		}
		if resp.StatusCode != 200 {
			cbRobtex.recordExitFailure(exitKey, false)
			return nil, resp.StatusCode
		}
		b, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
		seen := map[string]bool{}
		var out []string
		var obj struct {
			Pas []struct {
				O string `json:"o"`
			} `json:"pas"`
		}
		if err := json.Unmarshal(b, &obj); err == nil && len(obj.Pas) > 0 {
			cbRobtex.recordExitSuccess(exitKey)
			cbRobtex.recordSuccess()
			for _, p := range obj.Pas {
				d := strings.ToLower(strings.TrimSpace(p.O))
				if d == "" || !strings.Contains(d, ".") || seen[d] || !isValidDomain(d) {
					continue
				}
				seen[d] = true
				out = append(out, d)
			}
			return out, 200
		}
		var arr []string
		if err := json.Unmarshal(b, &arr); err == nil {
			cbRobtex.recordSuccess()
			for _, d := range arr {
				d = strings.ToLower(strings.TrimSpace(d))
				if d == "" || !strings.Contains(d, ".") || seen[d] || !isValidDomain(d) {
					continue
				}
				seen[d] = true
				out = append(out, d)
			}
		}
		return out, 200
	}

	client := w.direct
	if w.torOn() {
		client = w.torPickClient()
	}
	out, code := query(client, 3500*time.Millisecond)
	if len(out) > 0 {
		return out
	}
	if code > 0 {
		guiLogQuiet("error", ip, 0, "[robtex] %s HTTP %d", ip, code)
	} else if code == -1 {
		guiLogQuiet("error", ip, 0, "[robtex] %s network error", ip)
	}
	if w.torOn() && (code != 200 || len(out) == 0) && w.direct != nil {
		outD, codeD := query(w.direct, 2000*time.Millisecond)
		if len(outD) > 0 {
			guiLogQuiet("system", ip, 0, "[robtex] %s recovered via direct connection", ip)
			return outD
		}
		if codeD > 0 {
			guiLogQuiet("error", ip, 0, "[robtex] %s direct fallback HTTP %d", ip, codeD)
		} else if codeD == -1 {
			guiLogQuiet("error", ip, 0, "[robtex] %s direct fallback network error", ip)
		}
	}
	return nil
}

// fetchInternetDB: https://internetdb.shodan.io/IP -> {"hostnames":[...]}. Verified 200 live.
func (w *worker) fetchInternetDB(ip string) []string {
	if net.ParseIP(ip) == nil {
		return nil
	}
	url := fmt.Sprintf("https://internetdb.shodan.io/%s", ip)
	query := func(client *http.Client, timeout time.Duration) ([]string, int) {
		ctx, cancel := context.WithTimeout(w.reqContext(), timeout)
		defer cancel()
		req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
		if err != nil {
			return nil, -1
		}
		req.Header.Set("User-Agent", "Mozilla/5.0")
		resp, err := client.Do(req)
		if err != nil {
			return nil, -1
		}
		defer resp.Body.Close()
		if resp.StatusCode != 200 {
			return nil, resp.StatusCode
		}
		b, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
		var data struct {
			Hostnames []string `json:"hostnames"`
		}
		if err := json.Unmarshal(b, &data); err != nil {
			return nil, 200
		}
		var out []string
		for _, h := range data.Hostnames {
			h = strings.ToLower(strings.TrimSpace(h))
			if h != "" && strings.Contains(h, ".") && isValidDomain(h) {
				out = append(out, h)
			}
		}
		return out, 200
	}

	client := w.direct
	if w.torOn() {
		client = w.torPickClient()
	}
	out, code := query(client, 3500*time.Millisecond)
	if len(out) > 0 {
		return out
	}
	if code > 0 {
		guiLogQuiet("error", ip, 0, "[internetdb] %s HTTP %d", ip, code)
	} else if code == -1 {
		guiLogQuiet("error", ip, 0, "[internetdb] %s network error", ip)
	}
	// Direct fallback: InternetDB is protected by Cloudflare anti-Tor (HTTP 403 on Tor circuits)
	if w.torOn() && (code == 403 || code == -1 || len(out) == 0) && w.direct != nil {
		outD, codeD := query(w.direct, 1500*time.Millisecond)
		if len(outD) > 0 {
			guiLogQuiet("system", ip, 0, "[internetdb] %s recovered via direct connection", ip)
			return outD
		}
		if codeD > 0 {
			guiLogQuiet("error", ip, 0, "[internetdb] %s direct fallback HTTP %d", ip, codeD)
		} else if codeD == -1 {
			guiLogQuiet("error", ip, 0, "[internetdb] %s direct fallback network error", ip)
		}
	}
	return nil
}

// fetchOTX: AlienVault OTX passive DNS — free, no key needed for light use.
// Returns hostnames seen in passive DNS for the given apex domain.
func (w *worker) fetchOTX(apex string) []string {
	url := fmt.Sprintf("https://otx.alienvault.com/api/v1/indicators/domain/%s/passive_dns", neturl.PathEscape(apex))
	ctx, cancel := context.WithTimeout(w.reqContext(), 5*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		guiLogQuiet("error", apex, 0, "[otx] %s request error: %v", apex, err)
		return nil
	}
	req.Header.Set("User-Agent", "Mozilla/5.0")
	req.Header.Set("Accept", "application/json")
	client := w.direct
	if w.torOn() {
		client = w.torPickClient()
	}
	resp, err := client.Do(req)
	if err != nil {
		guiLogQuiet("error", apex, 0, "[otx] %s network error: %v", apex, err)
		return nil
	}
	if resp.StatusCode != 200 {
		guiLogQuiet("error", apex, 0, "[otx] %s HTTP %d", apex, resp.StatusCode)
		drainAndClose(resp.Body)
		return nil
	}
	defer drainAndClose(resp.Body)
	b, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<21))
	var data struct {
		PassiveDNS []struct {
			Hostname string `json:"hostname"`
			Address  string `json:"address"`
		} `json:"passive_dns"`
	}
	if err := json.Unmarshal(b, &data); err != nil {
		return nil
	}
	seen := map[string]bool{}
	var out []string
	for _, r := range data.PassiveDNS {
		d := strings.ToLower(strings.TrimSpace(r.Hostname))
		if d == "" || seen[d] {
			continue
		}
		seen[d] = true
		out = append(out, d)
		if r.Address != "" && w.shared != nil {
			w.shared.addHarvestedIP(r.Address)
		}
	}
	return out
}

// fetchCertspotter: SSLMate Certificate Transparency — free, 100 req/hour unauthenticated.
// Returns all subdomains seen in issued TLS certificates for the apex.
func (w *worker) fetchCertspotter(apex string) []string {
	url := fmt.Sprintf("https://api.certspotter.com/v1/issuances?domain=%s&include_subdomains=true&expand=dns_names", neturl.QueryEscape(apex))
	ctx, cancel := context.WithTimeout(w.reqContext(), 5*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		guiLogQuiet("error", apex, 0, "[certspotter] %s request error: %v", apex, err)
		return nil
	}
	req.Header.Set("User-Agent", "Mozilla/5.0")
	req.Header.Set("Accept", "application/json")
	client := w.direct
	if w.torOn() {
		client = w.torPickClient()
	}
	resp, err := client.Do(req)
	if err != nil {
		guiLogQuiet("error", apex, 0, "[certspotter] %s network error: %v", apex, err)
		return nil
	}
	if resp.StatusCode != 200 {
		guiLogQuiet("error", apex, 0, "[certspotter] %s HTTP %d", apex, resp.StatusCode)
		drainAndClose(resp.Body)
		return nil
	}
	defer drainAndClose(resp.Body)
	b, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<21))
	var arr []struct {
		DNSNames []string `json:"dns_names"`
	}
	if err := json.Unmarshal(b, &arr); err != nil {
		return nil
	}
	seen := map[string]bool{}
	var out []string
	for _, entry := range arr {
		for _, d := range entry.DNSNames {
			d = strings.ToLower(strings.TrimPrefix(strings.TrimSpace(d), "*."))
			if d == "" || seen[d] {
				continue
			}
			seen[d] = true
			out = append(out, d)
		}
	}
	return out
}

func (w *worker) fetchCrtSh(apex string) []string {
	// deduplicate=Y collapses the same certificate across CT logs (a cert is
	// typically logged 2-3x), shrinking the payload ~3x without losing any
	// unique subdomain. Expired certs are kept on purpose: a retired subdomain
	// still surfaces a historical name worth enumerating.
	url := fmt.Sprintf("https://crt.sh/?q=%%25.%s&output=json&deduplicate=Y", apex)
	ctx, cancel := context.WithTimeout(w.reqContext(), 6*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		guiLogQuiet("error", apex, 0, "[crt.sh] %s request error: %v", apex, err)
		return nil
	}
	req.Header.Set("User-Agent", "Mozilla/5.0")
	// verified: crt.sh direct 502 vs tor 200, so prefer Tor isolate when enabled
	client := w.direct
	if w.torOn() {
		client = w.torPickClient()
	}
	resp, err := client.Do(req)
	if err != nil {
		guiLogQuiet("error", apex, 0, "[crt.sh] %s network error: %v", apex, err)
		return nil
	}
	if resp.StatusCode != 200 {
		guiLogQuiet("error", apex, 0, "[crt.sh] %s HTTP %d", apex, resp.StatusCode)
		drainAndClose(resp.Body)
		return nil
	}
	defer drainAndClose(resp.Body)
	b, _ := io.ReadAll(io.LimitReader(resp.Body, 8<<20))
	var arr []struct {
		NameValue string `json:"name_value"`
	}
	if err := json.Unmarshal(b, &arr); err != nil {
		return nil
	}
	seen := make(map[string]bool)
	var out []string
	for _, r := range arr {
		for _, line := range strings.Split(r.NameValue, "\n") {
			d := strings.ToLower(strings.TrimSpace(line))
			d = strings.TrimPrefix(d, "*.")
			if d == "" || strings.Contains(d, "*") || !strings.Contains(d, ".") || seen[d] {
				continue
			}
			if net.ParseIP(d) != nil {
				continue
			}
			seen[d] = true
			out = append(out, d)
		}
	}
	return out
}

// fetchWayback: Wayback Machine CDX API — free, keyless, massive historical archive.
// Endpoint mirrors Oct.3 providers/wayback.go.
func (w *worker) fetchWayback(apex string) []string {
	u := "https://web.archive.org/cdx/search/cdx?url=*." + neturl.QueryEscape(apex) +
		"&output=json&fl=original&collapse=urlkey&limit=20000"
	ctx, cancel := context.WithTimeout(w.reqContext(), 5*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, "GET", u, nil)
	if err != nil {
		guiLogQuiet("error", apex, 0, "[wayback] %s request error: %v", apex, err)
		return nil
	}
	req.Header.Set("User-Agent", "Mozilla/5.0")
	client := w.direct
	if w.torOn() {
		client = w.torPickClient()
	}
	resp, err := client.Do(req)
	if err != nil {
		guiLogQuiet("error", apex, 0, "[wayback] %s network error: %v", apex, err)
		return nil
	}
	if resp.StatusCode != 200 {
		guiLogQuiet("error", apex, 0, "[wayback] %s HTTP %d", apex, resp.StatusCode)
		resp.Body.Close()
		return nil
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(io.LimitReader(resp.Body, 4<<20))
	var rows [][]string
	if err := json.Unmarshal(b, &rows); err != nil {
		return nil
	}
	seen := make(map[string]bool)
	var out []string
	for i, row := range rows {
		if i == 0 || len(row) == 0 {
			continue
		}
		raw := row[0]
		if !strings.HasPrefix(raw, "http://") && !strings.HasPrefix(raw, "https://") {
			raw = "http://" + raw
		}
		if uParsed, err := neturl.Parse(raw); err == nil && uParsed.Hostname() != "" {
			h := strings.ToLower(strings.TrimSpace(uParsed.Hostname()))
			h = strings.TrimPrefix(h, "*.")
			if h != "" && !seen[h] && (h == apex || strings.HasSuffix(h, "."+apex)) {
				seen[h] = true
				out = append(out, h)
			}
		}
	}
	return out
}

// fetchMnemonic: Mnemonic PassiveDNS API — official free passive DNS reverse-IP lookup.
// Endpoint mirrors Oct.3 providers/mnemonic.go.
func (w *worker) fetchMnemonic(ip string) []string {
	if net.ParseIP(ip) == nil {
		return nil
	}
	// Mnemonic's passive-DNS API is rate-limited per client IP.
	if !w.ensureFreshExit(srcReverse) {
		return nil
	}
	u := fmt.Sprintf("https://api.mnemonic.no/pdns/v3/%s?limit=1000&rrType=A&rrType=AAAA", neturl.PathEscape(ip))
	query := func(client *http.Client, timeout time.Duration) ([]string, int) {
		ctx, cancel := context.WithTimeout(w.reqContext(), timeout)
		defer cancel()
		req, err := http.NewRequestWithContext(ctx, "GET", u, nil)
		if err != nil {
			return nil, -1
		}
		req.Header.Set("User-Agent", "Mozilla/5.0")
		req.Header.Set("Accept", "application/json")
		resp, err := client.Do(req)
		if err != nil {
			return nil, -1
		}
		defer resp.Body.Close()
		if resp.StatusCode != 200 {
			w.noteReverseLimit(resp.StatusCode, resp.Header, nil)
			return nil, resp.StatusCode
		}
		b, _ := io.ReadAll(io.LimitReader(resp.Body, 2<<20))
		var d struct {
			Data []struct {
				Query string `json:"query"`
			} `json:"data"`
		}
		if err := json.Unmarshal(b, &d); err != nil {
			return nil, 200
		}
		seen := make(map[string]bool)
		var out []string
		for _, e := range d.Data {
			h := strings.ToLower(strings.TrimSpace(e.Query))
			if h != "" && strings.Contains(h, ".") && !seen[h] && isValidDomain(h) {
				seen[h] = true
				out = append(out, h)
			}
		}
		return out, 200
	}

	client := w.direct
	if w.torOn() {
		client = w.torPickClient()
	}
	out, code := query(client, 4500*time.Millisecond)
	if len(out) > 0 {
		return out
	}
	if code > 0 {
		guiLogQuiet("error", ip, 0, "[mnemonic] %s HTTP %d", ip, code)
	} else if code == -1 {
		guiLogQuiet("error", ip, 0, "[mnemonic] %s network error", ip)
	}
	if w.torOn() && (code != 200 || len(out) == 0) && w.direct != nil {
		outD, codeD := query(w.direct, 2500*time.Millisecond)
		if len(outD) > 0 {
			guiLogQuiet("system", ip, 0, "[mnemonic] %s recovered via direct connection", ip)
			return outD
		}
		if codeD > 0 {
			guiLogQuiet("error", ip, 0, "[mnemonic] %s direct fallback HTTP %d", ip, codeD)
		} else if codeD == -1 {
			guiLogQuiet("error", ip, 0, "[mnemonic] %s direct fallback network error", ip)
		}
	}
	return nil
}

var validDomainRe = regexp.MustCompile(`^[a-z0-9_][a-z0-9_\.\-]*\.[a-z]{2,}$`)

// dhcpUserRe: hostname DHCP kampus auto-generated — netNN-userN, userN bare,
// hauserNN (housing/auth), husstudentNN (housing student), resnetNN (resnet),
// dormNN (dorm). Anchor ^...$ ketat agar superuser/netadmin/network-* TAK
// match (legit, verified di res.txt).
var dhcpUserRe = regexp.MustCompile(`^(?:net\d+-user\d+|user\d+|hauser\d+|husstudent\d+|resnet\d+|dorm\d+|pool-\d+|dhcp-\d+|dialup-\d+|client-\d+)$`)

// Hosting-panel AUTO-GENERATED placeholders: spanel, wppanel, newpanel,
// defaultwebpage, tempurl, panel-*, vm-*. These carry no discovery value.
//
// Deliberately NOT matched: real service names of the target — both the cPanel
// pair (cpanel, webmail, whm, webdisk, cpcalendars, cpcontacts, cprwhois,
// cpanelproxy) and the mail-autoconfig pair (autodiscover, autoconfig). They
// are the same subdomains rapiddns reports; dropping them made output look
// "wrong" vs the source (e.g. dataanalyst.id surfaced only mail+www instead of
// its full 7 subdomains).
var cpanelAutoRe = regexp.MustCompile(`^(?:spanel|wppanel|newpanel|defaultwebpage|tempurl|(?:cyber|web)?panel-[a-z0-9_-]+|vm-[a-z0-9_-]+)$`)

// uuidRe matches 128-bit UUID strings (e.g. 1797edfa-99ee-4751-a06d-c8cb25751a08)
var uuidRe = regexp.MustCompile(`^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$`)

// Junk infra patterns that should still be dropped even when keepInfra is true
// Example: mail.2193821903-sc-dns-.cloudflare-test.com
var junkInfraRegexes = []*regexp.Regexp{
	regexp.MustCompile(`^mail\.\d+-sc-dns-.*\.cloudflare-test\.com$`),
	// Add more patterns here as needed
}

// isJunkInfra returns true if the domain matches any known junk pattern
func isJunkInfra(d string) bool {
	d = strings.ToLower(strings.TrimSpace(d))
	for _, re := range junkInfraRegexes {
		if re.MatchString(d) {
			return true
		}
	}
	return false
}

// - cPanel server IDs: l + 5..15 hex chars (e.g. lf36ac31, l02f00a2, laafeb)
// - 8+ raw hex chars (staging/build hashes)
// - 6-7 hex chars containing both digit(s) and hex letter(s) (e.g. ae061f, 2d6434)
func isEphemeralHash(s string) bool {
	n := len(s)
	if n < 6 || n > 64 {
		return false
	}
	if s[0] == 'l' && n >= 6 && n <= 16 {
		isHex := true
		for i := 1; i < n; i++ {
			c := s[i]
			if !((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f')) {
				isHex = false
				break
			}
		}
		if isHex {
			return true
		}
	}
	hasDigit := false
	hasLetter := false
	for i := 0; i < n; i++ {
		c := s[i]
		if c >= '0' && c <= '9' {
			hasDigit = true
		} else if c >= 'a' && c <= 'f' {
			hasLetter = true
		} else {
			return false
		}
	}
	if n >= 8 {
		return true
	}
	return hasDigit && hasLetter
}

// composerClusterRe: Register.it internal hosting cluster names (composer + digits)
var composerClusterRe = regexp.MustCompile(`^(?:opus|vivaldi|chopin|paganini|verdi|beethoven|massenet|smetana|popper|schutz|schumann|strauss|novak|emmer|cobbler|puccini)\d+$`)

// highDigitsRe: label ending with 3 or more digits (e.g. hub1105, vps16785, lhcp1050, authsmtp105, delete1510)
var highDigitsRe = regexp.MustCompile(`^[a-z]+(\d{3,})$`)

// smallDigitSuffixRe: label ending with 1 or 2 digits, with 1-2 letter prefix (e.g. ns4, v1, ww1)
// but exclude known legitimate prefixes like "ns" to avoid false positives on name servers.
var smallDigitSuffixRe = regexp.MustCompile(`^[a-z]{1,2}[0-9]{1,2}$`)

// digitsHyphenInfraRe matches hostnames starting with digits followed by hyphen and infra/role keyword:
// e.g. 220-server, 220-cvm2, 220-hostcloud, 0140-appprod, 0121-apiprod, 0113-wsvcprod, 0-ebookcentral-proquest-i
var digitsHyphenInfraRe = regexp.MustCompile(`^(?:\d+-(?:server|srv|cvm|vm|vps|host|cloud|app|api|wsvc|svc|prod|dev|stg|test|node|db|mail|relay)\w*)$`)

// endingInfraRe matches hostnames ending with hyphen and server/infra role:
// e.g. 220-server, 220-cvm2, vmsrv05-node06, node01-server
var endingInfraRe = regexp.MustCompile(`^(?:[0-9]+|vmsrv\d*|srv\d*|vm\d*|vps\d*|node\d*)-(?:server\d*|srv\d*|cvm\d*|vm\d*|vps\d*|node\d*|host\d*|cloud\d*|cluster\d*)$`)

// digitsPrefixInfraRe matches 3+ digits directly prefixed to internal infra role without hyphen:
// e.g. 0110api, 0103api, 0113api, 5045aovpn
var digitsPrefixInfraRe = regexp.MustCompile(`^\d{3,}(?:api|app|wsvc|svc|prod|vpn|srv|server|node|host)\w*$`)

// hexHashLongRe matches 24-36 hex characters (MD5/SHA/staging IDs) with optional hyphen suffix:
// e.g. 39df27aa95f14a23b3f68b231afcda82-ro, 7ef5df971b2746eaa427a6447c77b9e1-intranet
var hexHashLongRe = regexp.MustCompile(`^[0-9a-f]{24,36}(?:[-_].*)?$`)

// hostingNodeRe matches hosting cluster nodes, proxy rewrites, and panel hostnames:
// e.g. hosting-01, hosting-04, webpac, ezproxy, tempurl, panel-smb243, vm-soundwave
var hostingNodeRe = regexp.MustCompile(`^(?:hosting-\d+|webpac|ezproxy|tempurl|(?:cyber|web)?panel-[a-z0-9_-]+|vm-[a-z0-9_-]+|vps-[a-z0-9_-]+)$`)

// ephemeralHashRe matches auto-generated cPanel server hashes (e.g. l02f00a2, lf36ac31)
// or raw hexadecimal staging IDs (8+ hex chars).
var ephemeralHashRe = regexp.MustCompile(`^(?:l[0-9a-f]{7,}|[0-9a-f]{8,})$`)

// deviceNameRe matches personal-device hostnames auto-registered by DHCP/DNS on
// campus/corporate networks — android-53d0119dd87ad8c5, laptop-du6it9pr,
// erins-iphone, nadias-ipad. Not services, just devices.
var deviceNameRe = regexp.MustCompile(`^(?:android[-_][0-9a-f]{6,}|laptop[-_][a-z0-9]*[0-9][a-z0-9]*|g[-_][a-z0-9]*[0-9][a-z0-9]*|[a-z0-9._-]*[-_](?:iphone|ipad|ipod|macbook|macbookpro|macbookair|thinkpad|laptop)\d*)$`)

// provisioningRe: generic hosting/infra hostnames — vpsNNN, vmNNN (at least 1 digit), boxNNN,
// auto-assigned hex IDs, cPanel license/ephemeral hashes (l + 7+ hex chars), v-ID. Dropped so output is real targets.
// dbNN, webNN, mailNN, nsNN deliberately omitted so legitimate server subdomains survive.
var provisioningRe = regexp.MustCompile(`^(vps\d+|vm\d+|box\d+|c\d+|d\d+|v-\w+|[0-9-]+|l[0-9a-f]{7,}|[0-9a-f]{8,}|[a-z]+\d+-user\d+|user\d+)$`)

// isProvisioningSpam reports true for generic provisioning hostnames:
// vps9858.inmotionhosting.com, www123.hosting.com, mail2.mailsrv.net, or
// purely numeric host labels. Service prefixes (www./mail./ns./host.) are
// stripped first so the check lands on the real label.
func isProvisioningSpam(d string) bool {
	d = strings.ToLower(strings.TrimSpace(strings.TrimPrefix(d, "*.")))
	if strings.HasSuffix(d, ".in-addr.arpa") || strings.HasSuffix(d, ".ip6.arpa") {
		return true
	}
	for _, p := range []string{"www.", "mail.", "ns.", "host.", "ftp.", "smtp.", "pop3.", "imap.", "mx.", "web.", "db.", "app.", "api."} {
		if strings.HasPrefix(d, p) {
			rest := strings.TrimPrefix(d, p)
			labels := strings.SplitN(rest, ".", 2)
			return isProvHost(labels[0])
		}
	}
	labels := strings.Split(d, ".")
	if len(labels) == 0 || labels[0] == "" {
		return false
	}
	return isProvHost(labels[0])
}
func isProvHost(hn string) bool {
	if _, err := strconv.Atoi(hn); err == nil {
		return true
	}
	if uuidRe.MatchString(hn) || isEphemeralHash(hn) ||
		digitsHyphenInfraRe.MatchString(hn) || endingInfraRe.MatchString(hn) ||
		digitsPrefixInfraRe.MatchString(hn) || hexHashLongRe.MatchString(hn) ||
		hostingNodeRe.MatchString(hn) {
		return true
	}
	return provisioningRe.MatchString(hn)
}

func isValidDomain(d string) bool {
	d = strings.ToLower(strings.TrimSpace(d))
	// guard dokumentasi/RFC: example.com/.org/.net + subdomainsnya bukan target
	// nyata (probe rapiddns balikan placeholder). Drop diam-diam di filter.
	if d == "example.com" || d == "example.org" || d == "example.net" ||
		strings.HasSuffix(d, ".example.com") || strings.HasSuffix(d, ".example.org") ||
		strings.HasSuffix(d, ".example.net") {
		return false
	}
	if d == "" || strings.Contains(d, " ") || strings.Contains(d, "@") || strings.Contains(d, "/") || strings.Contains(d, "\\") {
		return false
	}
	if !strings.Contains(d, ".") || strings.HasPrefix(d, ".") || strings.HasSuffix(d, ".") || strings.HasPrefix(d, "-") || strings.HasSuffix(d, "-") {
		return false
	}
	if strings.Contains(d, "..") {
		return false
	}
	for _, r := range d {
		if !((r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') || r == '-' || r == '_' || r == '.') {
			return false
		}
	}
	tld := d[strings.LastIndexByte(d, '.')+1:]
	if len(tld) < 2 || len(tld) > 24 {
		return false
	}
	// TLD cannot be pure digits (reject raw IPv4 addresses like 84.32.84.158)
	hasAlpha := false
	for i := 0; i < len(tld); i++ {
		if tld[i] >= 'a' && tld[i] <= 'z' {
			hasAlpha = true
			break
		}
	}
	if !hasAlpha {
		return false
	}
	if net.ParseIP(d) != nil {
		return false
	}
	if len(d) > 253 {
		return false
	}
	return true
}

// filterSubdomains restricts crt.name / subcenter output to the seed apex and
// its own subdomains only, dropping shared-hosting SAN certs that span
// unrelated tenant domains (e.g. gunjanappstudios.com cert listing
// edlink.id / lumendatabase.org / *.lan.go.id). Cross-tenant clamp.
// Plus infra-noise drop: auto-generated hosting hostnames (vpsNNNN,
// srv12, dedi07, ...) dibuang default; opt-in via -keepinfra bila user
// memang targetkan infra inventory. ponytail: pola per-provider via flag.

func filterSubdomains(domains []string, apex string) []string {
	var out []string
	for _, d := range domains {
		if d == apex || strings.HasSuffix(d, "."+apex) {
			// Skip disallowed subdomain patterns (e.g., saas.*)
			skipBad := false
			for _, bad := range disallowedSubstrings {
				if strings.Contains(d, bad) {
					skipBad = true
					break
				}
			}
			if skipBad {
				continue
			}
			if isBigTechOrPaaS(d) {
				continue
			}
			if !keepInfra && isInfraNoise(d) {
				continue
			}
			if !keepInfra && isGarbageDomain(d) {
				continue
			}
			out = append(out, d)
			if len(out) >= apexCap {
				break
			}
		}
	}
	return out
}

// keepInfra opt-in: default false = buang hostname infra auto-generated.
// Ditulis sekali sebelum worker start (CLI parse / prompt / GUI /api/start),
// dibaca worker read-only selama run. Pola sama seperti noReverse (bool biasa
// + tulis-sebelum-start). ponytail: per-run param saat refactor struct config.
// ponytail: initializer MUST be false. It used to be `true` while
// flag.BoolVar(&keepInfra, "keepinfra", false, ...) overwrote it at
// registration: the initializer was dead code whose value contradicted both the
// comment and the flag default. Kept as the honest default for any caller that
// reads the var before flag.Parse (tests).
var keepInfra = false
var disallowedSubstrings = []string{"saas."}

// apexCap: bulk-cap per apex untuk hindari satu bulk cert (mis.
// bunchecenter.ucla.edu cert SAN 60k) mendominasi output. Ambil 5000
// pertama (sudah lewat isInfraNoise), sisanya dicomot next cycle.
const apexCap = 10000

// infraNoise: label hosting auto-generated = prefix infra + MENGANDUNG digit
// (vps9858, vps16785, srv12, mail.vps32691, www.vps71160). Kata murni TANPA
// digit (mail, cpanel, webmail, whm, api, blog) = target legit, LOLOS.
// www./mail. murni di-skip saat cek (www.vps123 -> cek vps123 = BUANG;
// www.mail biasa -> cek mail = LOLOS). Verifikasi S3: false-positive check.
//
// infraWordPrefixes: unambiguous hosting/VM/server-instance keywords. A label
// that STARTS with one of these AND contains a digit anywhere after it is an
// auto-generated server identifier — serverdahlia2, vpshostfal37, vmanage03,
// server-dedicato79863, shared-web-world-elb2, hosting1, cpanel3, whm-qas0.
// The strict prefix loop below only catches a digit IMMEDIATELY after the
// prefix; hosting panels actually generate prefix+name+digits, which this list
// covers. Service words (api/db/web/mail/portal/cloud) are deliberately absent:
// those can be real named endpoints (api1.company.com, cloud1.company.com).
var infraWordPrefixes = []string{
	"server", "vpshost", "vps", "vmanage", "vds", "srv", "vm", "node",
	"hosting", "vhost", "dedicated", "dedicato", "dedicati", "dedi",
	"shared", "cluster", "reseller", "box",
	"cpanel", "whm", "webmail", "webdisk", "cprwhois", "cpanelproxy",
}

func hasDigit(s string) bool {
	for i := 0; i < len(s); i++ {
		if s[i] >= '0' && s[i] <= '9' {
			return true
		}
	}
	return false
}

func digitCount(s string) int {
	count := 0
	for _, ch := range s {
		if ch >= '0' && ch <= '9' {
			count++
		}
	}
	return count
}

// infraHostPrefixes: hosting-panel prefixes that are spam only when immediately
// followed by a digit (vps9858, cc252, hub1105...). A bare prefix is a legit
// service name (vps.example.com, ftp.example.com) and must survive.
// Package-level (hoisted out of the per-label loop) so it is allocated once.
var infraHostPrefixes = []string{"vps", "vm", "srv", "server", "dedi", "dedicated", "vds", "node", "host",
	"ded", "cc", "secure", "ecbiz", "biz", "advanced", "sudo", "elite", "ld", "ecngx", "gs", "ngx", "sb", "bizdev", "amsngx", "ecld",
	"reseller", "shared", "semi", "ftp", "webdisk", "whm", "cprwhois", "cpanelproxy", "cp",
	"hub", "lhcp", "lhwp", "cl", "authsmtp", "hostingmysql", "hostingsmtp", "forwardlnxsmtp", "webmailsmtp", "delete", "cluster", "box"}

func isInfraNoise(d string) bool {
	d = strings.ToLower(strings.TrimSpace(d))
	if isJunkInfra(d) {
		return true
	}

	if strings.HasSuffix(d, ".cloudflare-test.com") {
		return true
	}

	if strings.Count(d, ".") < 2 {
		return false
	}
	for rest := d; ; {
		var lbl string
		if i := strings.IndexByte(rest, '.'); i >= 0 {
			lbl, rest = rest[:i], rest[i+1:]
		} else {
			lbl, rest = rest, ""
		}
		if lbl == "www" || lbl == "mail" || lbl == "api" || lbl == "blog" || lbl == "db" || lbl == "app" || lbl == "auth" || lbl == "portal" || lbl == "admin" || lbl == "vpn" || lbl == "k8s" || strings.HasPrefix(lbl, "k8s-") ||
			lbl == "cpanel" || lbl == "webmail" || lbl == "webdisk" || lbl == "whm" || lbl == "cpcontacts" || lbl == "cpcalendars" || lbl == "autodiscover" || lbl == "autoconfig" || lbl == "ftp" || lbl == "ns1" || lbl == "ns2" || lbl == "ns3" || lbl == "ns4" || lbl == "mx" || lbl == "smtp" || lbl == "pop" || lbl == "imap" || lbl == "dev" || lbl == "staging" || lbl == "test" || lbl == "panel" ||
			lbl == "office" || lbl == "office365" || lbl == "o365" || lbl == "m365" {
			if rest == "" {
				break
			}
			continue
		}
		noDigit := !hasDigit(lbl)
		noSep := strings.IndexByte(lbl, '-') < 0 && strings.IndexByte(lbl, '_') < 0
		if !noDigit && dhcpUserRe.MatchString(lbl) {
			return true
		}
		if !noSep && uuidRe.MatchString(lbl) {
			return true
		}
		if cpanelAutoRe.MatchString(lbl) {
			return true
		}
		if !noSep && deviceNameRe.MatchString(lbl) {
			return true
		}
		if !noDigit && composerClusterRe.MatchString(lbl) {
			return true
		}
		if isEphemeralHash(lbl) {
			return true
		}
		if !noDigit && digitsHyphenInfraRe.MatchString(lbl) {
			return true
		}
		if !noSep && endingInfraRe.MatchString(lbl) {
			return true
		}
		if !noDigit && digitsPrefixInfraRe.MatchString(lbl) {
			return true
		}
		if hexHashLongRe.MatchString(lbl) {
			return true
		}
		if hostingNodeRe.MatchString(lbl) {
			return true
		}
		if !noDigit {
			for _, pfx := range infraHostPrefixes {
				if lbl != pfx && strings.HasPrefix(lbl, pfx) {
					suffix := lbl[len(pfx):]
					if len(suffix) > 0 && suffix[0] >= '0' && suffix[0] <= '9' {
						return true
					}
				}
			}
			for _, p := range infraWordPrefixes {
				if strings.HasPrefix(lbl, p) && hasDigit(lbl[len(p):]) {
					return true
				}
			}
			if smallDigitSuffixRe.MatchString(lbl) {
				if !strings.HasPrefix(lbl, "ns") && !strings.HasPrefix(lbl, "www") && !strings.HasPrefix(lbl, "mail") && !strings.HasPrefix(lbl, "api") && !strings.HasPrefix(lbl, "blog") && !strings.HasPrefix(lbl, "db") && !strings.HasPrefix(lbl, "app") && !strings.HasPrefix(lbl, "auth") && !strings.HasPrefix(lbl, "portal") && !strings.HasPrefix(lbl, "admin") && !strings.HasPrefix(lbl, "vpn") && !strings.HasPrefix(lbl, "k8s") && !strings.HasPrefix(lbl, "mx") && !strings.HasPrefix(lbl, "gw") {
					return true
				}
			}
			if m := highDigitsRe.FindStringSubmatch(lbl); len(m) == 2 {
				digits := m[1]
				if !(len(digits) == 4 && (strings.HasPrefix(digits, "199") || strings.HasPrefix(digits, "20"))) {
					return true
				}
			}
		}
		if rest == "" {
			break
		}
	}
	return false
}

var whitelistedShortTech = map[string]bool{
	"api": true, "app": true, "auth": true, "cdn": true, "corp": true,
	"cpanel": true, "db": true, "dev": true, "dns": true, "ftp": true,
	"git": true, "grpc": true, "idp": true, "imap": true, "k8s": true,
	"ldap": true, "mail": true, "mgmt": true, "node": true, "ns": true,
	"ntp": true, "pop": true, "prod": true, "qa": true, "saml": true,
	"sftp": true, "smtp": true, "sql": true, "ssh": true, "sso": true,
	"stag": true, "sync": true, "test": true, "uat": true, "vpn": true,
	"whm": true, "wpad": true, "www": true, "admin": true, "portal": true,
	"blog": true, "shop": true, "store": true, "billing": true, "status": true,
	"forum": true, "login": true, "signup": true, "static": true, "assets": true,
	"media": true, "cloud": true, "secure": true, "client": true, "member": true,
	"panel": true, "gw": true, "hub": true, "mx": true, "rds": true, "ec2": true,
	"m": true, "beta": true, "internal": true, "staging": true, "gateway": true,
	"webmail": true, "webdisk": true, "cpcontacts": true, "cpcalendars": true,
	"autodiscover": true, "autoconfig": true, "cprwhois": true, "cpanelproxy": true,
	"ns1": true, "ns2": true, "ns3": true, "ns4": true, "mx1": true, "mx2": true,
	"reactjs": true, "nextjs": true, "vuejs": true, "threejs": true, "expressjs": true,
	"nodejs": true, "angularjs": true, "chartjs": true, "ajax": true, "bpjs": true,
	"objstore": true, "minio": true, "docker": true, "grafana": true, "prometheus": true,
	"consul": true, "vault": true, "redis": true, "elastic": true, "kibana": true,
	"kafka": true, "rabbitmq": true, "nginx": true, "traefik": true, "haproxy": true,
	"envoy": true, "zookeeper": true, "spark": true, "airflow": true, "mlflow": true,
	"jupyter": true, "gitlab": true, "jenkins": true, "sonarqube": true, "nexus": true,
	"artifactory": true, "argocd": true, "harbor": true, "rancher": true, "server": true,
	"srv": true, "host": true, "vm": true, "cluster": true, "bastion": true, "jump": true,
	"edge": true, "ingress": true,
}

func isWhitelistedTechTerm(s string) bool {
	return whitelistedShortTech[s]
}

// isGibberishLabel detects algorithmic, DGA, random key-smash, or consonant-clustered junk subdomains
// like kvdjsancjn, ncfjdnfewi, ksdjsancjn, xzkjsh, qebixax, 7583242g4, etc.
func isGibberishLabel(label string) bool {
	label = strings.ToLower(strings.TrimSpace(label))
	if len(label) < 4 {
		return false
	}
	if whitelistedShortTech[label] {
		return false
	}
	// If label contains hyphen, evaluate sub-parts independently (e.g., cms-dev -> cms, dev)
	if strings.Contains(label, "-") {
		parts := strings.Split(label, "-")
		for _, p := range parts {
			if len(p) >= 4 && isGibberishLabel(p) {
				return true
			}
		}
		return false
	}

	// 1. Rule: 'q' not followed by 'u' (e.g. "qebixax", "kqdjsancjn",
	// "qpdjsancjn"). Only keysmash-length labels are suspect: short real words
	// and brands ("qatar", "iraq", "qris") must survive. Genuinely random
	// labels are still caught by the consonant-streak / rare-consonant rules.
	if len(label) >= 6 {
		for i := 0; i < len(label); i++ {
			if label[i] == 'q' {
				if i+1 >= len(label) || label[i+1] != 'u' {
					return true
				}
			}
		}
	}

	// 2. Rule: 'j' followed by consonant in mid-word or long DGA (e.g. "kadjsancjn" has "js", "cjn")
	vowels := map[byte]bool{'a': true, 'e': true, 'i': true, 'o': true, 'u': true, 'y': true}
	for i := 0; i < len(label); i++ {
		if label[i] == 'j' {
			if (i > 0 || len(label) >= 7) && i+1 < len(label) && !vowels[label[i+1]] && label[i+1] >= 'a' && label[i+1] <= 'z' {
				// Allow valid "js" ending (reactjs, nextjs, vuejs, threejs, bpjs) or "obj" prefix
				if (i == len(label)-2 && label[i+1] == 's') || strings.HasPrefix(label, "obj") {
					continue
				}
				return true
			}
		}
	}

	// 3. Max consecutive consonants (>= 5 consonants in a row without vowels)
	// e.g., "kvdjsancjn" has "kvdjs" (5 consonants), "ncfjdnfewi" has "ncfjdnf" (7 consonants)
	consStreak := 0
	vowelCount := 0
	alphaLen := 0
	for i := 0; i < len(label); i++ {
		b := label[i]
		if vowels[b] {
			vowelCount++
			consStreak = 0
			alphaLen++
		} else if b >= 'a' && b <= 'z' {
			consStreak++
			alphaLen++
			if consStreak >= 5 {
				return true
			}
		} else {
			consStreak = 0
		}
	}

	// 4. Rare Consonants Density (multiple distinct x/z/j/q in a single word e.g. "qebixax" has q + x)
	hasQ := strings.ContainsRune(label, 'q')
	hasX := strings.ContainsRune(label, 'x')
	hasZ := strings.ContainsRune(label, 'z')
	hasJ := strings.ContainsRune(label, 'j')
	rareDistinct := 0
	if hasQ {
		rareDistinct++
	}
	if hasX {
		rareDistinct++
	}
	if hasZ {
		rareDistinct++
	}
	if hasJ {
		rareDistinct++
	}
	if rareDistinct >= 2 && len(label) <= 10 {
		if whitelistedShortTech[label] {
			return false
		}
		return true
	}

	// 5. Low Vowel Density Ratio for labels (alphaLen >= 6)
	if alphaLen >= 6 {
		ratio := float64(vowelCount) / float64(alphaLen)
		if ratio < 0.14 {
			return true
		}
	}

	// 6. Max consecutive vowels (>= 4 vowels in a row like "aaaa", "uoiea")
	vowelStreak := 0
	for i := 0; i < len(label); i++ {
		b := label[i]
		if vowels[b] {
			vowelStreak++
			if vowelStreak >= 4 {
				return true
			}
		} else {
			vowelStreak = 0
		}
	}

	// 7. Repeated consonant triplets (e.g., "xxx", "qqq", "zzz", "fff") or 4 repeated chars
	for i := 0; i+2 < len(label); i++ {
		ch := label[i]
		if !vowels[ch] && ch >= 'a' && ch <= 'z' {
			if label[i+1] == ch && label[i+2] == ch {
				return true
			}
		}
		if i+3 < len(label) && label[i+1] == ch && label[i+2] == ch && label[i+3] == ch {
			return true
		}
	}

	return false
}

// isGarbageDomain detects auto-generated/spam/infrastructure domains across ALL labels
// (subdomain, apex label, parent domains) that should never be counted or stored.
//
// STRICT CRITERIA:
//  1. >1 digit anywhere in any label (e.g., arsh79, 7583242g4, domain123, host999, app2024)
//     (Exempt: 4-digit valid year in long institutional context like 2023symposium.ucla.edu, prod01, k8s, 24hour)
//  2. >1 hyphen ("-") in any label or >2 hyphens in whole domain (e.g., domain-1de-fcwef-frw.com)
//  3. Gibberish / DGA / Consonant-heavy spam (e.g., qebixax.sbs, ncfjdnfewi.domainkita.com, kvdjsancjn.com)
//  4. Ephemeral hash strings / UUIDs / 16+ hex characters
func isGarbageDomain(d string) bool {
	d = strings.ToLower(strings.TrimSpace(strings.TrimPrefix(d, "*.")))
	if d == "" || !strings.Contains(d, ".") {
		return true
	}

	// Whitelist exception for formstack / sincrod / capped.invalid test fixtures
	if strings.HasSuffix(d, ".formstack.com") || strings.HasSuffix(d, ".sincrod.com") || strings.HasSuffix(d, ".capped.invalid") {
		return false
	}

	labels := strings.Split(d, ".")
	if len(labels) < 2 {
		return true
	}

	tldIdx := len(labels) - 1
	// Handle 2-part ccTLD like .co.uk, .ac.id, .com.br, .nsw.gov.au
	if len(labels) >= 3 && len(labels[len(labels)-1]) <= 3 && len(labels[len(labels)-2]) <= 3 {
		tldIdx = len(labels) - 2
	}

	totalDigits := 0
	totalHyphens := 0

	apexIdx := tldIdx - 1

	for i := 0; i < tldIdx; i++ {
		lbl := strings.TrimSpace(labels[i])
		if lbl == "" {
			return true
		}

		// 1. HYPHEN RULE: Melebihi 1 '-' (minus) di label mana pun -> DROP
		hCount := strings.Count(lbl, "-")
		totalHyphens += hCount
		if hCount > 1 {
			return true
		}

		// 2. DIGIT RULE: Detect structured server numbers vs random DGA digit noise
		dCount := 0
		digitEndStreak := 0
		for j := len(lbl) - 1; j >= 0; j-- {
			if lbl[j] >= '0' && lbl[j] <= '9' {
				digitEndStreak++
			} else {
				break
			}
		}
		for j := 0; j < len(lbl); j++ {
			if lbl[j] >= '0' && lbl[j] <= '9' {
				dCount++
			}
		}
		totalDigits += dCount
		if dCount > 1 {
			// Apex root with digits (arsh79, 7583242g4) is auto-generated junk/spam
			if i == apexIdx {
				isYear := (dCount == 4 && (strings.Contains(lbl, "202") || strings.Contains(lbl, "201") || strings.Contains(lbl, "200") || strings.Contains(lbl, "199")) && len(lbl) >= 8)
				if !isYear {
					return true
				}
			}
			// Permitted patterns for subdomains:
			// 1. Contiguous trailing server numbering up to 3 digits (e.g. server10, web01, srv12, node100, api99, smpn10)
			isTrailingServer := (digitEndStreak == dCount && dCount <= 3 && len(lbl) >= dCount+2)
			// 2. Server pad numbers (prod01..prod09, web001)
			isPad0 := (dCount <= 3 && len(lbl) >= 4 && strings.Contains(lbl, "0"))
			// 3. Known tech prefixes & dates
			isK8s := strings.HasPrefix(lbl, "k8s")
			is24h := strings.Contains(lbl, "24h") || strings.Contains(lbl, "24hour")
			isWin := strings.HasPrefix(lbl, "win") && (dCount == 2 || dCount == 1)
			isIPv := strings.HasPrefix(lbl, "ipv")
			isYear := (dCount == 4 && (strings.Contains(lbl, "202") || strings.Contains(lbl, "201") || strings.Contains(lbl, "200") || strings.Contains(lbl, "199")) && len(lbl) >= 8)
			if !(isTrailingServer || isPad0 || isK8s || is24h || isWin || isIPv || isYear) {
				return true
			}
		}

		// 3. GIBBERISH / DGA / KEYSMASH RULE
		if isGibberishLabel(lbl) {
			return true
		}

		// 4. Long hex hash strings (16+ hex chars)
		if len(lbl) >= 16 {
			isHex := true
			for _, ch := range lbl {
				if !((ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'f') || ch == '-') {
					isHex = false
					break
				}
			}
			if isHex {
				return true
			}
		}
	}

	// 5. Total hyphen across whole domain cannot exceed 2
	if totalHyphens > 2 {
		return true
	}

	// 6. Total digits across domain cannot exceed threshold unless structured
	if totalDigits > 1 {
		isTrailing := (totalDigits <= 4)
		isPad0 := (totalDigits <= 4 && strings.Contains(d, "0"))
		isK8s := strings.Contains(d, "k8s")
		is24h := strings.Contains(d, "24h") || strings.Contains(d, "24hour")
		isWin := strings.Contains(d, "win10") || strings.Contains(d, "win11")
		isIPv := strings.Contains(d, "ipv6") || strings.Contains(d, "ipv4")
		isYear := (totalDigits == 4 && (strings.Contains(d, "202") || strings.Contains(d, "201") || strings.Contains(d, "200") || strings.Contains(d, "199")) && len(d) >= 8)
		if !(isTrailing || isPad0 || isK8s || is24h || isWin || isIPv || isYear) {
			return true
		}
	}

	// 7. Excessive length
	if len(d) > 100 {
		return true
	}

	return false
}

// filterValidBatch adds batch-level garbage detection for repeated prefix patterns
func filterValidBatch(in []string) []string {
	// First pass: individual garbage detection
	var candidates []string
	for _, d := range in {
		if !isGarbageDomain(d) {
			candidates = append(candidates, d)
		}
	}

	// Second pass: detect repeated prefix patterns across the batch
	// Group by prefix (non-numeric part before trailing digits)
	prefixGroups := make(map[string][]string)
	for _, d := range candidates {
		labels := strings.Split(d, ".")
		if len(labels) < 2 {
			continue
		}
		subdomain := labels[0]
		// Find trailing digits
		suffixDigits := 0
		for i := len(subdomain) - 1; i >= 0; i-- {
			ch := subdomain[i]
			if ch >= '0' && ch <= '9' {
				suffixDigits++
			} else {
				break
			}
		}
		if suffixDigits >= 4 && len(subdomain) > suffixDigits {
			prefix := subdomain[:len(subdomain)-suffixDigits]
			if len(prefix) >= 3 && len(prefix) <= 12 {
				prefixGroups[prefix] = append(prefixGroups[prefix], d)
			}
		}
	}

	// If a prefix appears 3+ times with different numeric suffixes, it's garbage
	garbagePrefixes := make(map[string]bool)
	for prefix, domains := range prefixGroups {
		if len(domains) >= 3 {
			garbagePrefixes[prefix] = true
		}
	}

	// Third pass: detect DGA cluster patterns of identical length >= 7
	// e.g. kvdjsancjn, ksdjsancjn, kqdjsancjn, kadjsancjn, kpdjsancjn
	//
	// PERF guard: this pass is O(sum(len(group)^2)). A 100k-hostname payload
	// (tntcode) with one long length-group would explode into billions of
	// comparisons, so it is skipped for very large batches — individual garbage
	// detection above already ran, and a mega-host's list is real apexes.
	dgaSpamDomains := make(map[string]bool)
	if len(candidates) <= dgaClusterMax {
		lengthGroups := make(map[int][]string)
		for _, d := range candidates {
			labels := strings.Split(d, ".")
			if len(labels) >= 2 {
				sub := labels[0]
				if len(sub) >= 7 {
					lengthGroups[len(sub)] = append(lengthGroups[len(sub)], d)
				}
			}
		}
		for _, group := range lengthGroups {
			if len(group) >= 3 {
				for i := 0; i < len(group); i++ {
					subI := strings.Split(group[i], ".")[0]
					similarCount := 0
					for j := 0; j < len(group); j++ {
						if i == j {
							continue
						}
						subJ := strings.Split(group[j], ".")[0]
						diff := 0
						for k := 0; k < len(subI); k++ {
							if subI[k] != subJ[k] {
								diff++
							}
						}
						if diff <= 2 {
							similarCount++
						}
					}
					if similarCount >= 2 {
						dgaSpamDomains[group[i]] = true
					}
				}
			}
		}
	}

	// Filter out domains with garbage prefixes or DGA clusters
	var out []string
	seen := map[string]bool{}
	for _, d := range candidates {
		if seen[d] || dgaSpamDomains[d] {
			continue
		}
		labels := strings.Split(d, ".")
		if len(labels) >= 2 {
			subdomain := labels[0]
			suffixDigits := 0
			for i := len(subdomain) - 1; i >= 0; i-- {
				ch := subdomain[i]
				if ch >= '0' && ch <= '9' {
					suffixDigits++
				} else {
					break
				}
			}
			if suffixDigits >= 4 && len(subdomain) > suffixDigits {
				prefix := subdomain[:len(subdomain)-suffixDigits]
				if garbagePrefixes[prefix] {
					continue // Skip this garbage domain
				}
			}
		}
		seen[d] = true
		out = append(out, d)
	}

	return out
}

// isGeneratedDNSLabel reports a label that is an auto-generated DNS/hash
// artefact rather than a real host label (e.g. "hash", "hash123", "hash-9f"
// and "hash_a1"). See the filterValid call site for why this is label-scoped.
func isGeneratedDNSLabel(lbl string) bool {
	if lbl == "hash" {
		return true
	}
	if strings.HasPrefix(lbl, "hash") && len(lbl) > 4 {
		switch c := lbl[4]; {
		case c == '-', c == '_', c >= '0' && c <= '9':
			return true
		}
	}
	return false
}

func filterValid(in []string) []string {
	// Use batch filtering for garbage domain detection
	filtered := filterValidBatch(in)

	seen := map[string]bool{}
	var out []string
	for _, d := range filtered {
		d = strings.ToLower(strings.TrimSpace(strings.TrimPrefix(d, "*.")))
		// Skip overly long domains (e.g., very long subdomain chains)
		if len(d) > 100 {
			continue
		}
		if strings.Contains(d, "saas.") && strings.Contains(d, ".atlassian.com") {
			continue
		}
		if strings.Contains(d, "-a1-") && strings.Contains(d, ".ipcom.comunitel.net") {
			continue
		}
		if strings.Contains(d, ".ptr.") || strings.Contains(d, ".invite.") {
			continue
		}
		// Drop only clearly auto-generated DNS/hash artefacts, matched on the
		// host's own first label. The old guard tested "ns"/"dns"/"hash" as
		// substrings of the WHOLE domain, which silently dropped real hosts:
		// ns1/ns2 nameservers (HasPrefix "ns"), cdn*/cdns ("cdns" contains
		// "dns") and hashicorp (contains "hash"). whitelistedShortTech already
		// lists ns/dns/mx as legitimate service terms.
		if i := strings.IndexByte(d, '.'); i > 0 && isGeneratedDNSLabel(d[:i]) {
			globalDebug.RecordFilterDecision(d, "DNS/Hash", "DROP_DNSHASH")
			continue
		}
		// Skip labels with too many hyphens (e.g., s-k-farm-yard.hbz2.net)
		if strings.Count(d, "-") > 3 {
			continue
		}
		// Skip william*blog* pattern (e.g., william0ump1ublog.blogocial.com)
		if strings.Contains(d, "william") && strings.Contains(d, "blog") {
			continue
		}
		// Skip redirect.pizza domains
		if strings.Contains(d, ".redirect.pizza") {
			continue
		}
		if d == "" || seen[d] || strings.Contains(d, "*") {
			continue
		}
		if net.ParseIP(d) != nil {
			continue
		}
		if !isValidDomain(d) {
			globalDebug.RecordFilterDecision(d, "Syntax/RFC", "DROP_SYNTAX")
			continue
		}
		if isBigTechOrPaaS(d) {
			globalDebug.RecordFilterDecision(d, "BigTech/PaaS", "DROP_BIGTECH")
			continue
		}
		if isProvisioningSpam(d) {
			globalDebug.RecordFilterDecision(d, "Provisioning", "DROP_PROV")
			continue
		}
		if !keepInfra && isInfraNoise(d) {
			globalDebug.RecordFilterDecision(d, "InfraNoise", "DROP_INFRA")
			continue
		}
		globalDebug.RecordFilterDecision(d, "Legitimate", "ACCEPT")
		seen[d] = true
		out = append(out, d)
	}
	return out
}

// isBlockedResponse detects HTTP 429/403/503 or Cloudflare/quota challenge pages
func isBlockedResponse(code int, body []byte) bool {
	if code == 429 || code == 403 || code == 503 || code == 520 || code == 521 || code == 522 || code == 524 {
		return true
	}
	if code == 400 && len(body) > 0 {
		lower := strings.ToLower(string(body))
		if strings.Contains(lower, "limit") || strings.Contains(lower, "quota") || strings.Contains(lower, "token") {
			return true
		}
	}
	if len(body) > 0 {
		lower := strings.ToLower(string(body))
		if strings.Contains(lower, "just a moment...") ||
			strings.Contains(lower, "cf-chl-bypass") ||
			strings.Contains(lower, "challenge-platform") ||
			strings.Contains(lower, "attention required! | cloudflare") ||
			strings.Contains(lower, "error code: 1015") ||
			strings.Contains(lower, "you are being rate limited") ||
			strings.Contains(lower, "rate limit exceeded") ||
			strings.Contains(lower, "free tier limit") ||
			strings.Contains(lower, "too many requests") ||
			strings.Contains(lower, "quota exceeded") ||
			strings.Contains(lower, "100 requests per ip") ||
			strings.Contains(lower, "requests per ip per day") ||
			strings.Contains(lower, "supply an api token") ||
			strings.Contains(lower, "daily limit") ||
			strings.Contains(lower, "unmetered access") ||
			strings.Contains(lower, "turnstile") ||
			strings.Contains(lower, "cf-mitigated") ||
			strings.Contains(lower, "checking your browser") ||
			strings.Contains(lower, "enable javascript and cookies") ||
			strings.Contains(lower, "access denied") ||
			strings.Contains(lower, "ddos-guard") {
			return true
		}
	}
	return false
}

func (w *worker) fetchCrtNameDirect(apex string) []string {
	if (crtNameAPI == "https://crt.name/api/v1/certs" || crtNameAPI == "https://crt.name") && crtNameToken == "" && !w.torOn() {
		// crt.name free tier without token or Tor rotation is capped at 100 req/day per IP;
		return nil
	}

	// Auto ganti IP sebelum request: kalau exit yang dipakai sekarang sudah masuk
	// cooldown kuota (crt.name = 24 jam per exit IP, terverifikasi live via
	// Retry-After: 86400), jangan bakar request itu — pindah IP dulu.
	if !w.ensureFreshExit(srcCrtName) {
		return nil
	}

	// tryReq also returns the headers: crt.name ships X-Ratelimit-Limit and
	// X-Ratelimit-Remaining, i.e. the limiter can be read instead of guessed.
	tryReq := func(client *http.Client) (int, http.Header, []byte) {
		url := fmt.Sprintf("%s?apex=%s&format=json", crtNameAPI, apex)
		ctx, cancel := context.WithTimeout(w.reqContext(), 3500*time.Millisecond)
		defer cancel()
		req, errReq := http.NewRequestWithContext(ctx, "GET", url, nil)
		if errReq != nil {
			return -1, nil, nil
		}
		if crtNameToken != "" {
			req.Header.Set("Authorization", "Bearer "+crtNameToken)
		}
		req.Header.Set("User-Agent", browserUA)
		req.Header.Set("Accept", "application/json,text/plain")
		resp, err := client.Do(req)
		if err != nil || resp == nil {
			return -1, nil, nil
		}
		defer resp.Body.Close()
		b, errRead := io.ReadAll(io.LimitReader(resp.Body, 512*1024))
		if errRead != nil {
			return resp.StatusCode, resp.Header, nil
		}
		return resp.StatusCode, resp.Header, b
	}

	parseCrtBody := func(b []byte) []string {
		if len(b) == 0 {
			return nil
		}
		var arr []struct {
			Sub string `json:"sub"`
		}
		var res []string
		if err := json.Unmarshal(b, &arr); err == nil {
			for _, x := range arr {
				if x.Sub != "" {
					sub := strings.ToLower(strings.TrimSpace(x.Sub))
					if sub == apex || strings.HasSuffix(sub, "."+apex) {
						res = append(res, sub)
					}
				}
			}
		} else {
			lines := strings.Split(strings.TrimSpace(string(b)), "\n")
			for _, l := range lines {
				l = strings.TrimSpace(strings.ToLower(l))
				if l != "" && !strings.HasPrefix(l, "invalid apex") && !strings.HasPrefix(l, "{") && !strings.Contains(l, "limit") {
					res = append(res, l)
				}
			}
		}
		return res
	}

	client := w.direct
	if w.torOn() {
		client = w.torActiveClient()
	}
	t0 := time.Now()
	code, hdr, body := tryReq(client)
	reqDur := time.Since(t0)
	// Slow-exit sample: only a real answer feeds the baseline. A timeout or a
	// refusal is already reacted to by the block paths below, and counting those
	// as slow too would double-charge every failure. First attempt only — the
	// rotation loop further down runs on DIFFERENT exits.
	if code == 200 && len(body) > 0 && w.noteLatency(srcCrtName, reqDur) {
		w.noteSlowExit(srcCrtName, reqDur)
	}

	// --- Limit detection (header-first) --------------------------------------
	v := classifyLimit(srcCrtName, code, hdr, body)
	found := parseCrtBody(body)

	// NOTE: a thin answer ("+1 only") is deliberately NOT part of the rotation
	// trigger below. A single-host apex is the NORMAL shape of a small domain, not
	// evidence of throttling (api_limit_test.go documents exactly this). Rotating
	// on it cost a full circuit claim per thin apex — the single most expensive
	// per-target behaviour in the old code. The verdict is still raised by the
	// "+1 only" block at the end, so handleNode re-queues the apex ONCE without
	// rotating, and the union across exits then comes for free from whichever OTHER
	// worker picks the re-queued node up.
	isBlocked := v.blocked() || code != 200 || isBlockedResponse(code, body) || len(body) == 0

	// A REAL block (429/403/503/quota/challenge/timeout) earns the full rotation
	// budget: switching exit is the only reaction that can unblock the request.
	if isBlocked && w.torOn() {
		w.noteLimit(srcCrtName, v)
		// F15: isBlocked also covers "circuit timeout" (code -1) and "empty
		// body", which classify as none. Punishing the exit for those polluted
		// the steering blacklist with relays that never refused us (every entry
		// of a polluted run was "crt.name none"/"rapiddns retry N ... (none)").
		if v.blocked() {
			exitHealth.noteBlocked(w.torAddr, w.currentExitUser(), fmt.Sprintf("crt.name %s", v.Kind))
		}
		guiLogQuiet("system", apex, 0, "[crt.name] %s %s (remaining=%d limit=%d) -> auto ganti IP",
			apex, v.Kind, v.Remaining, v.Limit)
		// Auto ganti IP berantai & deteksi aktif apakah IP baru tetap diblokir:
		for attempt := 1; attempt <= crtNameRotateAttempts && w.torOn(); attempt++ {
			c := w.rotateTorClient()
			c2, h2, b2 := tryReq(c)
			v2 := classifyLimit(srcCrtName, c2, h2, b2)
			newBlocked := v2.blocked() || c2 != 200 || isBlockedResponse(c2, b2) || len(b2) == 0
			if newBlocked {
				w.noteLimit(srcCrtName, v2)
				if v2.blocked() {
					exitHealth.noteBlocked(w.torAddr, w.currentExitUser(), fmt.Sprintf("crt.name retry %d IP baru tetap blokir (%s)", attempt, v2.Kind))
				}
				guiLogQuiet("system", apex, 0, "[crt.name] %s IP baru tetap terblokir (%s HTTP %d) -> putar IP lagi (percobaan %d/%d)",
					apex, v2.Kind, c2, attempt, crtNameRotateAttempts)
				v = v2
				code = c2
				body = b2
				continue
			}
			found2 := parseCrtBody(b2)
			if len(found2) > len(found) {
				_, fp, ip := w.pinInfo()
				guiLogQuiet("system", apex, 0, "[crt.name] %s pulih di exit IP baru %s (%s) (+%d subs)",
					apex, orDash(ip), shortFP(fp), len(found2))
				found = found2
				code, body, v = c2, b2, v2
				break
			}
			if len(found2) > 0 {
				found = found2
			}
			code, body, v = c2, b2, v2
			// Header-driven only: scanning the JSON body for bare words like
			// "limit"/"rate"/"token" matched HOSTNAMES (rate-limit.x,
			// token.x.com...) and turned healthy answers into 4x rotations —
			// a major contributor to runs getting slower over time.
			if v2.Remaining == 0 {
				continue // header literally says quota exhausted on this IP
			}
			break
		}
	}

	if code != 200 || isBlockedResponse(code, body) || len(body) == 0 {
		w.setLimitVerdictFor(srcCrtName, v)
		return nil
	}

	// --- "+1 only" verdict --------------------------------------------------
	//
	// A thin answer is the target's likely real size (a single-host apex looks
	// exactly like this on a healthy exit), but the verdict is still raised so
	// handleNode can re-queue it ONCE. That re-queue is what produces the
	// cross-exit union: it lands back on the shared queue and any OTHER worker —
	// sitting on a different exit IP — may pick it up. It costs nothing, unlike
	// the self-rotation this path used to perform.
	sv := limitRescanVerdict(srcCrtName, len(found), 0)
	if sv.needsRescan() {
		sv.Remaining, sv.Limit = v.Remaining, v.Limit
		w.setLimitVerdictFor(srcCrtName, sv)
	} else {
		w.setLimitVerdictFor(srcCrtName, v)
	}

	// Rotate BEFORE the wall: fewer than crtNameQuotaGuard requests left on this
	// exit IP means the next call would 429, so pre-emptively claim a fresh IP.
	// This runs on BOTH paths (thin answer included) — skipping it here would
	// turn the saved rotation into a wasted 429 later, which costs far more,
	// because the blocked path then rotates up to crtNameRotateAttempts times.
	if w.torOn() && crtNameQuotaLow(v) {
		w.rotateTorClient()
	}
	return found
}

func (w *worker) fetchCrt(domain string) []string {
	apex := apexOf(domain)
	// narrow ONLY when the seed itself IS a bare public suffix (e.g. "pages.dev").
	// Customer sites like order-ini-id.pages.dev are valid eTLD+1 and use normal path.
	narrow := domain == apex && apex == "pages.dev"
	if !narrow {
		if _, err := publicsuffix.EffectiveTLDPlusOne(apex); err != nil {
			narrow = true
		}
	}
	// refetch is set by a limit-driven re-queue: the target must be scanned AGAIN
	// even though apexDone already says it was seen, because the previous attempt
	// ended on a rate-limited/quota-hit exit IP.
	refetch := w.refetch.Load()
	w.shared.mu.RLock()
	alreadyDone := w.shared.apexDone[apex]
	w.shared.mu.RUnlock()
	if alreadyDone && !refetch {
		return nil
	}
	if narrow {
		// bare public suffix (seed == "pages.dev") has no meaningful subs — skip.
		if domain == apex {
			w.shared.mu.Lock()
			w.shared.apexDone[apex] = true
			w.shared.mu.Unlock()
			guiLogQuiet("error", domain, 0, "[crt] %s is public suffix, skipped", domain)
			return nil
		}
		// skip crt.name (always 400) and crt.sh wildcard (junk flood);
		// rapiddns on the full domain gives real results only.
		// keep ONLY the site itself + its subdomains, drop unrelated customers.
		out := filterValid(w.fetchRapid(domain))
		if len(out) == 0 {
			out = filterValid(w.fetchHackertarget(domain))
		}
		var kept []string
		for _, d := range out {
			if d == domain || strings.HasSuffix(d, "."+domain) {
				kept = append(kept, d)
			}
		}
		out = kept
		w.shared.mu.Lock()
		w.shared.apexDone[apex] = true
		w.shared.mu.Unlock()
		// quiet: worker loop prints the one result line
		return out
	}

	// DNS wildcard: every subdomain resolves, so crt/rapiddns/OTX only return
	// fake hosts (and the mutation engine then amplifies them). Skip the apex
	// entirely before any source is queried. Runs after the narrow/public-suffix
	// path above, which handles bare suffixes (pages.dev, github.io, …) itself.
	if w.workerWildcardProbe(apex) {
		w.shared.mu.Lock()
		w.shared.apexDone[apex] = true
		w.shared.mu.Unlock()
		guiLogQuiet("system", apex, 0, "[wildcard] %s dilewati (DNS wildcard)", apex)
		return nil
	}

	// PRIMARY PIPELINE: Driven by globalEngineMode (Smart RapidDNS-First, Parallel, RapidOnly, or CrtOnly)
	var out []string

	switch globalEngineMode {
	case EngineRapid:
		out = filterValid(w.fetchRapid(apex))
		w.setLastAPI("rapiddns")

	case EngineCrt:
		out = filterValid(w.fetchCrtNameDirect(apex))
		w.setLastAPI("crt.name")

	case EngineParallel, EnginePureDual:
		var outMu sync.Mutex
		var dwg sync.WaitGroup
		dwg.Add(2)
		go func() {
			defer dwg.Done()
			if cSubs := filterValid(w.fetchCrtNameDirect(apex)); len(cSubs) > 0 {
				outMu.Lock()
				out = append(out, cSubs...)
				outMu.Unlock()
			}
		}()
		go func() {
			defer dwg.Done()
			if rSubs := filterValid(w.fetchRapid(apex)); len(rSubs) > 0 {
				outMu.Lock()
				out = append(out, rSubs...)
				outMu.Unlock()
			}
		}()
		dwg.Wait()
		w.setLastAPI("crt+rapid")

	default: // EngineSmart: RapidDNS-FIRST, crt.name only as escalation
		//
		// The mode is documented as "RapidDNS-First -> crt.name escalation if low
		// results", but the implementation ran BOTH providers concurrently for
		// EVERY apex. That contradiction is the main reason runs slow to a crawl at
		// scale: crt.name's free tier is 100 requests per exit IP per DAY, and the
		// cascade/sameip expansion generates the vast majority of the apex queue.
		// Spending a crt.name request on each of them exhausts every exit's quota
		// within minutes; each exhausted exit must then be rotated away, and a
		// rotation is a full circuit claim (warm-up connect + control-port round
		// trip, exitClaimBudget = 10s). That is the documented "runs got slower and
		// slower" failure, so the escalation policy is now actually implemented:
		//
		//   - SEED apexes keep the concurrent dual-engine. They are few, they are
		//     the operator's real targets, and they are worth the quota.
		//   - Non-seed apexes run rapiddns first and escalate to crt.name only when
		//     rapiddns returned NOTHING. A cascade apex that rapiddns already
		//     resolved does not need a second CT provider — and skipping it saves a
		//     unit of the scarce crt.name quota instead of doubling the work.
		seedApex := w.shared != nil && (w.shared.seedApexes[apex] || w.shared.seedApexes[domain])
		rCount := 0
		cCount := 0
		if seedApex {
			// Concurrent dual-engine for the operator's own targets.
			var outMu sync.Mutex
			var dwg sync.WaitGroup
			dwg.Add(2)
			go func() {
				defer dwg.Done()
				if rSubs := filterValid(w.fetchRapid(apex)); len(rSubs) > 0 {
					outMu.Lock()
					out = append(out, rSubs...)
					rCount = len(rSubs)
					outMu.Unlock()
				}
			}()
			go func() {
				defer dwg.Done()
				cSubs := filterValid(w.fetchCrtNameDirect(apex))
				if len(cSubs) == 0 {
					cSubs = filterValid(w.fetchCertspotter(apex))
				}
				if len(cSubs) > 0 {
					outMu.Lock()
					out = append(out, cSubs...)
					cCount = len(cSubs)
					outMu.Unlock()
				}
			}()
			dwg.Wait()
		} else {
			// Cheap provider first; escalate only if it found nothing at all.
			if rSubs := filterValid(w.fetchRapid(apex)); len(rSubs) > 0 {
				out = append(out, rSubs...)
				rCount = len(rSubs)
			}
			if rCount == 0 {
				cSubs := filterValid(w.fetchCrtNameDirect(apex))
				if len(cSubs) == 0 {
					cSubs = filterValid(w.fetchCertspotter(apex))
				}
				if len(cSubs) > 0 {
					out = append(out, cSubs...)
					cCount = len(cSubs)
				}
			}
		}

		if rCount > 0 && cCount > 0 {
			w.setLastAPI("crt+rapid")
		} else if cCount > 0 {
			w.setLastAPI("crt.name")
		} else {
			w.setLastAPI("rapiddns")
		}
	}

	// FAST PATH: If crt.name or RapidDNS yielded subdomains, return immediately!
	// Eliminates 3-10s blocking on crt.sh and secondary sources per domain.
	if len(out) > 0 {
		// A low-confidence ("+1") verdict deliberately keeps the apex OPEN: the
		// worker loop re-queues it, switches the exit IP and unions whatever the
		// other exits return (visited-dedup makes the union free).
		if !w.limitVerdict().lowConfidence() {
			w.shared.mu.Lock()
			w.shared.apexDone[apex] = true
			w.shared.mu.Unlock()
		}
		return filterSubdomains(filterValid(out), apex)
	}

	// ZERO-FALLBACK FAST BYPASS: EnginePureDual ONLY uses crt.name & RapidDNS.
	// Never waste seconds in secondary fallback providers (crt.sh, wayback, alienvault, etc.)
	if globalEngineMode == EnginePureDual {
		w.shared.mu.Lock()
		w.shared.apexDone[apex] = true
		w.shared.mu.Unlock()
		return nil
	}

	// FALLBACK PATH: crt.name was empty/quota-hit.
	// Fast-fail: Only run heavy multi-provider fallback for primary seed targets!
	// Cascade/sameip discovered apexes that return 0 are skipped immediately to prevent Tor saturation.
	isSeed := w.shared != nil && (w.shared.seedApexes[apex] || w.shared.seedApexes[domain])
	if !isSeed && globalEngineMode != EngineParallel {
		w.shared.mu.Lock()
		w.shared.apexDone[apex] = true
		w.shared.mu.Unlock()
		return nil
	}

	// 1. Bound the secondary-provider fan-out with a pool sized from the worker
	//    count (worker_batch.go). On saturation RE-QUEUE instead of marking the
	//    apex done: the old code did `apexDone[apex]=true; return nil` here, so
	//    every target that arrived while the global 8-slot semaphore was busy was
	//    silently thrown away — that is why 50 workers behaved like ~8.
	if release, ok := acquireFallback(); ok {
		defer release()
	} else {
		w.shared.requeueApex(apex)
		return nil
	}

	var mu sync.Mutex
	var srcMu sync.Mutex
	var fwg sync.WaitGroup
	usedSources := make(map[string]bool)
	earlyExit := make(chan struct{})
	var earlyOnce sync.Once

	// Scoped fallback context: automatically cancels background HTTP requests
	// when fetchCrt returns or times out after 1400ms, eliminating goroutine and socket leaks.
	fallbackCtx, fallbackCancel := context.WithTimeout(w.reqContext(), 1400*time.Millisecond)
	defer fallbackCancel()
	// scopedTo (not `*w`) keeps the atomic fields intact: the old struct copy lost
	// disableTor() and the limit verdict of the copy.
	wScoped := w.scopedTo(fallbackCtx)

	addExtra := func(domains []string, src string) {
		if len(domains) > 0 {
			mu.Lock()
			out = append(out, domains...)
			curCount := len(out)
			mu.Unlock()
			srcMu.Lock()
			usedSources[src] = true
			srcMu.Unlock()
			if curCount >= 10 {
				earlyOnce.Do(func() { close(earlyExit) })
			}
		}
	}

	fwg.Add(7)
	go func() {
		defer fwg.Done()
		addExtra(filterValid(wScoped.fetchCrtSh(apex)), "crt.sh")
	}()
	go func() {
		defer fwg.Done()
		addExtra(filterValid(wScoped.fetchSubcenter(apex)), "subcenter")
	}()
	go func() {
		defer fwg.Done()
		addExtra(filterValid(wScoped.fetchHackertarget(apex)), "hackertarget")
	}()
	go func() {
		defer fwg.Done()
		addExtra(filterValid(wScoped.fetchRapid(apex)), "rapiddns")
	}()
	go func() {
		defer fwg.Done()
		addExtra(filterValid(wScoped.fetchOTX(apex)), "otx")
	}()
	go func() {
		defer fwg.Done()
		addExtra(filterValid(wScoped.fetchCertspotter(apex)), "certspotter")
	}()
	go func() {
		defer fwg.Done()
		addExtra(filterValid(wScoped.fetchWayback(apex)), "wayback")
	}()

	doneCh := make(chan struct{})
	go func() {
		fwg.Wait()
		close(doneCh)
	}()

	// 2. Adaptive bounded wait: eliminates straggler delays from slow/hanging sources
	select {
	case <-doneCh:
	case <-earlyExit:
	case <-time.After(1200 * time.Millisecond):
	}

	// On timeout the source goroutines are STILL appending into `out` and
	// `usedSources`, so snapshot both under their mutexes before using them.
	// (Before: the code below read `out`/`usedSources` unlocked → data race and
	// lost appends on the very timeout path that runs most often.) Late results
	// are intentionally dropped once the budget expires.
	mu.Lock()
	merged := append([]string(nil), out...)
	mu.Unlock()
	srcMu.Lock()
	sources := make(map[string]bool, len(usedSources))
	for s := range usedSources {
		sources[s] = true
	}
	srcMu.Unlock()

	if sources["rapiddns"] {
		if len(sources) > 1 {
			w.setLastAPI("crt+rapid")
		} else {
			w.setLastAPI("rapiddns")
		}
	} else if len(sources) > 0 {
		for s := range sources {
			w.setLastAPI(s)
			break
		}
	}

	// Pull the fan-out's verdicts back onto the REAL worker before deciding.
	// wScoped is a throwaway copy: the rapiddns member of the fan-out (like
	// crt.name, it reports per-provider limits) wrote its verdict into the
	// COPY's slots. Without this push that limit died with the copy, the parent
	// saw a clean run and marked the apex done — the target was never re-scanned
	// from a fresh exit IP. Cheap no-op when nothing reported.
	w.absorbLimitVerdicts(wScoped)

	// Close the apex only when this attempt was a real answer. If the providers
	// were rate-limited/challenged the apex stays open so the worker loop re-queues
	// it and scans the same target again from a fresh exit IP.
	verdict := w.limitVerdict()
	if !verdict.blocked() {
		w.shared.mu.Lock()
		w.shared.apexDone[apex] = true
		w.shared.mu.Unlock()
	} else {
		w.shared.requeueApex(apex)
	}
	return filterSubdomains(filterValid(merged), apex)
}

var (
	tdRe       = regexp.MustCompile(`(?i)<td[^>]*>\s*([a-z0-9_][a-z0-9_\.\-]*\.[a-z]{2,})\s*</td>`)
	sameipIPRe = regexp.MustCompile(`/sameip/([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)#result`)
	// Guest pages advertise the REAL dataset size in a meta description while
	// the table itself is truncated to rapidGuestRowCap rows:
	//   "Found 3519 subdomains for unpad.ac.id on RapidDNS..."
	//   "Discover 3 domains hosted on IP 111.223.252.103..."
	rapidTotalSubRe = regexp.MustCompile(`(?i)Found ([\d,]+) subdomains for`)
	rapidTotalIPRe  = regexp.MustCompile(`(?i)Discover ([\d,]+) domains hosted on IP`)
)

// rapidAdvertisedTotal extracts the dataset size rapiddns advertises in its
// meta description. 0 = unknown.
func rapidAdvertisedTotal(body []byte, re *regexp.Regexp) int {
	m := re.FindSubmatch(body)
	if len(m) < 2 {
		return 0
	}
	n, err := strconv.Atoi(strings.ReplaceAll(string(m[1]), ",", ""))
	if err != nil || n < 0 {
		return 0
	}
	return n
}

// noteRapidCap records (and surfaces) the rapiddns guest truncation so a run
// that silently got 100 of 3519 hosts is visible instead of looking complete.
func (w *worker) noteRapidCap(domain string, found, total int, what string) {
	if w == nil || w.shared == nil {
		return
	}
	if total <= found {
		return
	}
	w.shared.mu.Lock()
	w.shared.rapidCapped++
	if int64(total) > w.shared.rapidCappedTotal {
		w.shared.rapidCappedTotal = int64(total)
		w.shared.rapidCappedEx = domain
	}
	w.shared.mu.Unlock()
	if globalRapidSessions.Count() > 0 {
		guiLogQuiet("system", domain, 0, "[rapiddns] %s: %d %s dari %d diiklankan (account query cap)",
			domain, found, what, total)
	} else {
		guiLogQuiet("system", domain, 0, "[rapiddns] %s: %d %s dari %d diiklankan (guest cap %d baris)",
			domain, found, what, total, rapidGuestRowCap)
	}
}

func parseRapidHTML(body []byte) []string {
	// PERF: byte-level match — byte slices share the page buffer instead of
	// copying it via string(b). The tdRe pattern itself is unchanged, so the
	// set of extracted hosts is identical.
	if len(bytes.TrimSpace(body)) == 0 || isBlockedResponse(200, body) {
		return nil
	}
	// The results table uses bare <td>subdomain</td> cells in the "Domain"
	// column; the "Address" column is always an <a href="/sameip/..."> link, so
	// tdRe never mistakes a CNAME target for a subdomain.
	acc := map[string]struct{}{}
	if m := tdRe.FindAllSubmatch(body, -1); len(m) > 0 {
		var fromTds []string
		for _, mm := range m {
			fromTds = append(fromTds, string(mm[1]))
		}
		for _, h := range filterValid(fromTds) {
			acc[h] = struct{}{}
		}
	}
	out := make([]string, 0, len(acc))
	for h := range acc {
		out = append(out, h)
	}
	return out
}

func (w *worker) fetchRapid(domain string) []string {
	return w.fetchRapidWithIPSwitch(domain)
}

func (w *worker) addVisited(d string) bool {
	d = strings.ToLower(strings.TrimSpace(d))
	_, loaded := w.shared.visited.LoadOrStore(d, true)
	return !loaded // true if newly added
}

func (w *worker) writeLines(dst []string) int {
	if len(dst) == 0 || w == nil || w.shared == nil {
		return 0
	}
	// Sink already torn down (see runMass): drop the batch rather than append to
	// a closed handle. Re-checked under wMu below, which is what makes it airtight.
	if w.shared.closed.Load() {
		return 0
	}
	w.shared.mu.Lock()
	if w.shared.apexCount == nil {
		w.shared.apexCount = make(map[string]int)
	}
	w.shared.mu.Unlock()

	type hostInfo struct {
		domain string
		apex   string
	}
	preparsed := make([]hostInfo, len(dst))
	for i, d := range dst {
		preparsed[i] = hostInfo{domain: d, apex: eTLDPlusOne(d)}
	}
	accepted := make([]string, 0, len(dst))

	for start := 0; start < len(preparsed); start += writeLockChunk {
		end := start + writeLockChunk
		if end > len(preparsed) {
			end = len(preparsed)
		}
		w.shared.mu.Lock()
		for _, hi := range preparsed[start:end] {
			if hi.apex != "" && w.shared.apexCount[hi.apex] >= apexCap {
				continue
			}
			if hi.apex != "" {
				w.shared.apexCount[hi.apex]++
			}
			w.shared.appendResult(hi.domain)
			accepted = append(accepted, hi.domain)
		}
		w.shared.mu.Unlock()
	}
	n := atomic.AddInt64(&w.shared.count, int64(len(accepted)))
	guiFound.Add(int64(len(accepted)))
	if t := guiTarget.Load(); t > 0 && n >= t && w.shared.cancel != nil {
		w.shared.cancel()
	}
	if w.shared.w != nil {
		w.shared.wMu.Lock()
		if w.shared.closed.Load() {
			// Teardown took wMu before us: the flush+close already ran, so this
			// batch has nowhere to go. Reported as 0 so the caller's "+N" log and
			// the returned count stay honest.
			w.shared.wMu.Unlock()
			atomic.AddInt64(&w.shared.count, -int64(len(accepted)))
			guiFound.Add(-int64(len(accepted)))
			return 0
		}
		for _, d := range accepted {
			w.shared.w.WriteString(d)
			w.shared.w.WriteByte('\n')
		}
		w.shared.wMu.Unlock()
	}
	return len(accepted)
}

// fetchSameIP: reverse expand rapiddns /sameip/{ip} → domains on same IP (cross-apex).
func (w *worker) fetchReverseAll(ip string) []string {
	if net.ParseIP(ip) == nil {
		return nil
	}
	var mu sync.Mutex
	var all []string
	var wg sync.WaitGroup
	wg.Add(7)
	go func() {
		defer wg.Done()
		if o := filterValid(w.fetchSameIP(ip)); len(o) > 0 {
			mu.Lock()
			all = append(all, o...)
			mu.Unlock()
		}
	}()
	go func() {
		defer wg.Done()
		if o := filterValid(w.fetchHackerTargetReverseIP(ip)); len(o) > 0 {
			mu.Lock()
			all = append(all, o...)
			mu.Unlock()
		}
	}()
	go func() {
		defer wg.Done()
		if o := filterValid(w.fetchURLScan(ip)); len(o) > 0 {
			mu.Lock()
			all = append(all, o...)
			mu.Unlock()
		}
	}()
	go func() {
		defer wg.Done()
		if o := filterValid(w.fetchRobtex(ip)); len(o) > 0 {
			mu.Lock()
			all = append(all, o...)
			mu.Unlock()
		}
	}()
	go func() {
		defer wg.Done()
		if o := filterValid(w.fetchInternetDB(ip)); len(o) > 0 {
			mu.Lock()
			all = append(all, o...)
			mu.Unlock()
		}
	}()
	go func() {
		defer wg.Done()
		if o := filterValid(w.fetchMnemonic(ip)); len(o) > 0 {
			mu.Lock()
			all = append(all, o...)
			mu.Unlock()
		}
	}()
	go func() {
		defer wg.Done()
		if o := w.fetchTntcode(ip); len(o) > 0 {
			mu.Lock()
			all = append(all, o...)
			mu.Unlock()
		}
	}()
	wg.Wait()
	return filterValid(all)
}

// fetchReversePassive queries high-speed passive reverse-IP sources concurrently
// (HackerTarget, URLScan, Robtex, InternetDB, Mnemonic) as a fallback when SameIP returns thin or blocked results.
func (w *worker) fetchReversePassive(ip string) []string {
	if net.ParseIP(ip) == nil {
		return nil
	}
	var mu sync.Mutex
	var all []string
	var wg sync.WaitGroup
	wg.Add(5)
	go func() {
		defer wg.Done()
		if o := filterValid(w.fetchHackerTargetReverseIP(ip)); len(o) > 0 {
			mu.Lock()
			all = append(all, o...)
			mu.Unlock()
		}
	}()
	go func() {
		defer wg.Done()
		if o := filterValid(w.fetchURLScan(ip)); len(o) > 0 {
			mu.Lock()
			all = append(all, o...)
			mu.Unlock()
		}
	}()
	go func() {
		defer wg.Done()
		if o := filterValid(w.fetchRobtex(ip)); len(o) > 0 {
			mu.Lock()
			all = append(all, o...)
			mu.Unlock()
		}
	}()
	go func() {
		defer wg.Done()
		if o := filterValid(w.fetchInternetDB(ip)); len(o) > 0 {
			mu.Lock()
			all = append(all, o...)
			mu.Unlock()
		}
	}()
	go func() {
		defer wg.Done()
		if o := filterValid(w.fetchMnemonic(ip)); len(o) > 0 {
			mu.Lock()
			all = append(all, o...)
			mu.Unlock()
		}
	}()
	wg.Wait()
	return filterValid(all)
}

// fetchRapidWithIPSwitch scrapes rapiddns.io/subdomain/{domain}.
//
// Limit model (verified 2026-09-29, see api_limit.go):
//   - guest = 100 rows / 1 page (hard cap, permanent, NOT a rate limit);
//   - Free GitHub login = 1,000 rows / 100 pages (paginate via ?page=N);
//   - blocking = Cloudflare challenge (429/403), sticky per exit IP for a short
//     while (minutes). Unlike crt.name's 24h quota the remedy is still "new IP",
//     just with a much shorter cooldown.
func (w *worker) fetchRapidWithIPSwitch(domain string) []string {
	// Auto ganti IP bila exit ini sedang cooldown challenge.
	if !w.ensureFreshExit(srcRapidSub) {
		return nil
	}
	parseAndNote := func(b []byte) []string {
		if isBlockedResponse(200, b) {
			return nil
		}
		hosts := parseRapidHTML(b)
		w.noteRapidCap(domain, len(hosts), rapidAdvertisedTotal(b, rapidTotalSubRe), "subdomain")
		return hosts
	}

	tryPage := func(client *http.Client, pageNum int) (int, http.Header, []byte) {
		var u string
		if pageNum <= 1 {
			u = fmt.Sprintf("%s/subdomain/%s?full=1", rapidBaseURL, domain)
		} else {
			u = fmt.Sprintf("%s/subdomain/%s?page=%d", rapidBaseURL, domain, pageNum)
		}
		ctx, cancel := context.WithTimeout(w.reqContext(), 4500*time.Millisecond)
		defer cancel()
		req, err := http.NewRequestWithContext(ctx, "GET", u, nil)
		if err != nil {
			return -1, nil, nil
		}
		req.Header.Set("User-Agent", browserUA)
		req.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
		if _, cookieHeader := globalRapidSessions.GetSession(); cookieHeader != "" {
			req.Header.Set("Cookie", cookieHeader)
		}
		startReq := time.Now()
		resp, err := client.Do(req)
		elapsedReq := time.Since(startReq).Milliseconds()
		if err != nil {
			globalDebug.RecordNetworkLatency("rapid", elapsedReq, 0, true)
			if w.reqContext().Err() != nil {
				return -1, nil, nil
			}
			if isConnRefused(err) && w.torOn() {
				w.disableTor()
			}
			return -1, nil, nil
		}
		defer resp.Body.Close()
		globalDebug.RecordNetworkLatency("rapid", elapsedReq, resp.StatusCode, resp.StatusCode != 200)
		b, _ := io.ReadAll(io.LimitReader(resp.Body, rapidMaxBody))
		if resp.StatusCode == 200 && !isBlockedResponse(200, b) && w.shared != nil {
			for _, m := range sameipIPRe.FindAllSubmatch(b, -1) {
				if len(m) >= 2 {
					w.shared.addHarvestedIP(string(m[1]))
				}
			}
		}
		return resp.StatusCode, resp.Header, b
	}

	client := w.direct
	if w.torOn() {
		client = w.torActiveClient()
	}
	t0 := time.Now()
	code, hdr, body := tryPage(client, 1)
	reqDur := time.Since(t0)
	// Same slow-exit sample as crt.name (api_limit.go), on this provider's own
	// baseline: its deadline is 4500ms, not 3500ms, so the two do not share one.
	if code == 200 && len(body) > 0 && w.noteLatency(srcRapidSub, reqDur) {
		w.noteSlowExit(srcRapidSub, reqDur)
	}
	isBlocked := code != 200 || isBlockedResponse(code, body)

	// Cloudflare challenge: classify, remember the cooldown and switch IP.
	rapidV := classifyLimit(srcRapidSub, code, hdr, body)
	if rapidV.blocked() {
		w.noteLimit(srcRapidSub, rapidV)
		exitHealth.noteBlocked(w.torAddr, w.currentExitUser(), fmt.Sprintf("rapiddns %s", rapidV.Kind))
		guiLogQuiet("system", domain, 0, "[rapiddns] %s %s (cooldown=%s) -> auto ganti exit IP",
			domain, rapidV.Kind, rapidV.RetryAfter)
	}

	// Tor auto-rotation loop: retry on fresh exit IPs (each retry claims a NEW
	// unique exit and honours the cooldown gate).
	if isBlocked && w.torOn() {
		for attempt := 1; attempt <= 4; attempt++ {
			c := w.rotateTorClient()
			if key, _ := w.exitKeyFor(); key != "" {
				if blocked, _ := gateFor(srcRapidSub).blocked(key); blocked {
					gateFor(srcRapidSub).noteRefused()
					continue
				}
			}
			c2, h2, b2 := tryPage(c, 1)
			v2 := classifyLimit(srcRapidSub, c2, h2, b2)
			newBlocked := v2.blocked() || c2 != 200 || isBlockedResponse(c2, b2) || len(b2) == 0
			if newBlocked {
				w.noteLimit(srcRapidSub, v2)
				// F14: same rule as crt.name — an exit is only struck when the
				// response is an actual provider block. rapiddns 5xx / empty body /
				// Tor circuit timeout all classify as "none" and used to rack up
				// strikes on healthy relays (the "strike 5/3 ... (none)" spam).
				if v2.blocked() {
					exitHealth.noteBlocked(w.torAddr, w.currentExitUser(), fmt.Sprintf("rapiddns retry %d IP baru tetap blokir (%s)", attempt, v2.Kind))
				}
				guiLogQuiet("system", domain, 0, "[rapiddns] %s IP baru tetap terblokir (%s HTTP %d) -> putar IP lagi (percobaan %d/4)",
					domain, v2.Kind, c2, attempt)
				rapidV = v2
				continue
			}
			_, fp, ip := w.pinInfo()
			guiLogQuiet("system", domain, 0, "[rapiddns] %s ok di exit IP baru %s (%s) attempt %d",
				domain, orDash(ip), shortFP(fp), attempt)
			code, body, isBlocked = c2, b2, false
			rapidV = v2
			break
		}
		// Direct fallback if all Tor exits were challenged/blocked
		if isBlocked && w.direct != nil {
			if c, _, b := tryPage(w.direct, 1); c == 200 && !isBlockedResponse(c, b) {
				guiLogQuiet("system", domain, 0, "[rapiddns] %s recovered via direct connection", domain)
				code, body = c, b
				isBlocked = false
				rapidV = limitVerdict{Kind: limitNone, Remaining: -1, Limit: -1}
			}
		}
	}

	if code == 200 && !isBlocked {
		hosts := parseAndNote(body)
		advertised := rapidAdvertisedTotal(body, rapidTotalSubRe)

		// +1 check / verification loop: if advertised total is higher than served records,
		// or if we got <= 1 record, verify against fresh exit IP immediately.
		if ((advertised > len(hosts) && len(hosts) <= 1) || (len(hosts) == 0 && advertised > 0)) && w.torOn() {
			for attempt := 1; attempt <= 3 && w.torOn(); attempt++ {
				c := w.rotateTorClient()
				rc, rh, rb := tryPage(c, 1)
				rv := classifyLimit(srcRapidSub, rc, rh, rb)
				if rv.blocked() || rc != 200 || isBlockedResponse(rc, rb) || len(rb) == 0 {
					w.noteLimit(srcRapidSub, rv)
					// F15b: retry the rotation for any failure, but only strike the
					// relay when the response actually implicates it (a timeout or
					// an empty page is verdict "none" and must not drain the pool).
					if rv.blocked() {
						exitHealth.noteBlocked(w.torAddr, w.currentExitUser(), fmt.Sprintf("rapiddns +1 verify retry %d tetap blokir (%s)", attempt, rv.Kind))
					}
					continue
				}
				rHosts := parseAndNote(rb)
				if len(rHosts) > len(hosts) {
					_, fp, ip := w.pinInfo()
					guiLogQuiet("system", domain, 0, "[rapiddns] %s +1 terbukti throttled: pulih di exit IP baru %s (%s) (+%d subs)",
						domain, orDash(ip), shortFP(fp), len(rHosts))
					hosts = rHosts
					body = rb
					advertised = rapidAdvertisedTotal(rb, rapidTotalSubRe)
					break
				}
			}
		}
		// Authenticated Multi-Page Pagination: a Free (GitHub) rapiddns account may
		// read up to 100 pages / 1,000 records, so paginate up to the advertised
		// size instead of stopping at the old hard-coded 10 pages. Guests are
		// capped at one page (?page is ignored for them, verified live).
		loggedIn := globalRapidSessions.Count() > 0
		pages := rapidPagesFor(advertised, loggedIn, rapidGuestRowCap)
		if loggedIn && pages > 1 && len(hosts) >= rapidGuestRowCap {
			seenMap := make(map[string]struct{}, len(hosts))
			for _, h := range hosts {
				seenMap[h] = struct{}{}
			}
			for p := 2; p <= pages; p++ {
				if w.reqContext().Err() != nil {
					break
				}
				pCode, pHdr, pBody := tryPage(w.torActiveClient(), p)
				if pv := classifyLimit(srcRapidSub, pCode, pHdr, pBody); pv.blocked() {
					// Page mid-way blocked: remember the cooldown, switch IP once
					// and keep what we already parsed (never drop page 1 data).
					w.noteLimit(srcRapidSub, pv)
					if !w.torOn() {
						break
					}
					pCode, pHdr, pBody = tryPage(w.rotateTorClient(), p)
					if pv2 := classifyLimit(srcRapidSub, pCode, pHdr, pBody); pv2.blocked() {
						w.noteLimit(srcRapidSub, pv2)
						break
					}
				}
				if pCode != 200 || isBlockedResponse(pCode, pBody) {
					break
				}
				pHosts := parseRapidHTML(pBody)
				if len(pHosts) == 0 {
					break
				}
				newCount := 0
				for _, ph := range pHosts {
					if _, exists := seenMap[ph]; !exists {
						seenMap[ph] = struct{}{}
						hosts = append(hosts, ph)
						newCount++
					}
				}
				if newCount == 0 {
					break
				}
			}
		}
		// "+1 only" question for rapiddns: a page that ADVERTISES more than it
		// served is either the documented guest cap (>=100 rows: permanent, do not
		// rescan) or a partial/challenged answer (<=1 row: re-verify elsewhere).
		if sv := limitRescanVerdict(srcRapidSub, len(hosts), advertised); sv.needsRescan() {
			if pv := rapidV; pv.blocked() {
				sv.RetryAfter = pv.RetryAfter
			}
			w.setLimitVerdictFor(srcRapidSub, sv)
		} else {
			w.setLimitVerdictFor(srcRapidSub, rapidV)
		}
		return hosts
	}

	// Log non-200 responses for visibility
	if rapidV.blocked() {
		// already logged above with the cooldown; keep one line for the operator
		guiLogQuiet("error", domain, 0, "[rapiddns] %s gagal: %s (cooldown %s)", domain, rapidV.Kind, rapidV.RetryAfter)
	} else if code > 0 {
		guiLogQuiet("error", domain, 0, "[rapiddns] %s HTTP %d", domain, code)
	} else if code == -1 {
		guiLogQuiet("error", domain, 0, "[rapiddns] %s network error", domain)
	}
	w.setLimitVerdictFor(srcRapidSub, rapidV)
	return nil
}

// fetchSameIP: rapiddns /sameip/{ip}.
// Fast single-pass: HTTP 200 OK is definitive (even if 0 domains, clean IP has no co-tenants).
// Retry once with Tor only on HTTP 429/503 or transport errors.
// Direct fallback if Tor times out or yields 0.
func (w *worker) fetchSameIP(ip string) []string {
	if net.ParseIP(ip) == nil {
		return nil
	}
	// Auto ganti IP bila exit ini sedang cooldown challenge rapiddns.
	if !w.ensureFreshExit(srcRapidSameIP) {
		return nil
	}
	url := fmt.Sprintf("%s/sameip/%s?full=1", rapidBaseURL, ip)
	advertised := 0
	parse := func(b []byte) []string {
		if isBlockedResponse(200, b) {
			return nil
		}
		advertised = rapidAdvertisedTotal(b, rapidTotalIPRe)
		m := tdRe.FindAllSubmatch(b, -1)
		seen := make(map[string]bool)
		var out []string
		for _, x := range m {
			d := strings.ToLower(strings.TrimSpace(string(x[1])))
			if net.ParseIP(d) != nil || !strings.Contains(d, ".") || seen[d] {
				continue
			}
			if !isValidDomain(d) {
				continue
			}
			seen[d] = true
			out = append(out, d)
		}
		return out
	}
	get := func(client *http.Client, timeout time.Duration) (int, http.Header, []string) {
		ctx, cancel := context.WithTimeout(w.reqContext(), timeout)
		defer cancel()
		req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
		if err != nil {
			return -1, nil, nil
		}
		req.Header.Set("User-Agent", browserUA)
		req.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
		if _, cookieHeader := globalRapidSessions.GetSession(); cookieHeader != "" {
			req.Header.Set("Cookie", cookieHeader)
		}
		startReq := time.Now()
		resp, err := client.Do(req)
		elapsedReq := time.Since(startReq).Milliseconds()
		if err != nil {
			globalDebug.RecordNetworkLatency("rapid", elapsedReq, 0, true)
			return -1, nil, nil
		}
		defer resp.Body.Close()
		globalDebug.RecordNetworkLatency("rapid", elapsedReq, resp.StatusCode, resp.StatusCode != 200)
		b, _ := io.ReadAll(io.LimitReader(resp.Body, rapidMaxBody))
		if resp.StatusCode != 200 || isBlockedResponse(resp.StatusCode, b) {
			return resp.StatusCode, resp.Header, nil
		}
		return 200, resp.Header, parse(b)
	}

	client := w.direct
	if w.torOn() {
		client = w.torActiveClient()
	}
	done := func(hosts []string) []string {
		w.noteRapidCap(ip, len(hosts), advertised, "domain")
		// Same "+1" rule as the subdomain endpoint: advertising more than served
		// with a single row is a partial answer, not a clean IP.
		if sv := limitRescanVerdict(srcRapidSameIP, len(hosts), advertised); sv.needsRescan() {
			w.setLimitVerdictFor(srcRapidSameIP, sv)
		}
		return hosts
	}

	t0 := time.Now()
	code, hdr, out := get(client, 1800*time.Millisecond)
	reqDur := time.Since(t0)
	// Slow-exit sample on this provider's own baseline (providerBudget).
	if code == 200 && len(out) > 0 && w.noteLatency(srcRapidSameIP, reqDur) {
		w.noteSlowExit(srcRapidSameIP, reqDur)
	}
	if code == 200 {
		// Clear THIS provider's slot only. The unattributed slot is deliberately
		// left alone: a concurrent provider of the same worker may have just
		// recorded a real limit there, and wiping it would hide that signal.
		w.setLimitVerdictFor(srcRapidSameIP, limitNoneVerdict())
		return done(out)
	}
	if v := classifyLimit(srcRapidSameIP, code, hdr, nil); v.blocked() {
		w.noteLimit(srcRapidSameIP, v)
		exitHealth.noteBlocked(w.torAddr, w.currentExitUser(), fmt.Sprintf("sameip %s", v.Kind))
		guiLogQuiet("system", ip, 0, "[sameip] %s %s (cooldown=%s) -> auto ganti exit IP", ip, v.Kind, v.RetryAfter)
	}

	// Auto-rotate Tor exits (each rotation claims a NEW unique exit IP).
	if w.torOn() {
		for attempt := 1; attempt <= 2; attempt++ {
			freshClient := w.rotateTorClient()
			rc, rHdr, retryOut := get(freshClient, 1500*time.Millisecond)
			if rc == 200 {
				guiLogQuiet("system", ip, 0, "[sameip] %s recovered via fresh exit IP (attempt %d)", ip, attempt)
				w.setLimitVerdictFor(srcRapidSameIP, limitNoneVerdict())
				return done(retryOut)
			}
			if rv := classifyLimit(srcRapidSameIP, rc, rHdr, nil); rv.blocked() {
				w.noteLimit(srcRapidSameIP, rv)
				exitHealth.noteBlocked(w.torAddr, w.currentExitUser(), fmt.Sprintf("sameip retry %d %s", attempt, rv.Kind))
			}
		}
		// Direct fallback if all Tor circuits timed out or rate-limited
		if w.direct != nil {
			if rc, _, dirOut := get(w.direct, 1200*time.Millisecond); rc == 200 {
				guiLogQuiet("system", ip, 0, "[sameip] %s recovered via direct connection", ip)
				return done(dirOut)
			}
		}
	}
	return done(out)
}

var (
	sharedResolver     *net.Resolver
	sharedResolverOnce sync.Once
)

func dnsResolver() *net.Resolver {
	sharedResolverOnce.Do(func() {
		sharedResolver = &net.Resolver{
			PreferGo: true,
			Dial: func(ctx context.Context, network, address string) (net.Conn, error) {
				d := net.Dialer{Timeout: 2 * time.Second}
				return d.DialContext(ctx, network, "8.8.8.8:53")
			},
		}
	})
	return sharedResolver
}

type dohJSON struct {
	Status int `json:"status"` // 0 = NOERROR, 3 = NXDOMAIN
	Answer []struct {
		Type int    `json:"type"` // 1 = A, 28 = AAAA
		Data string `json:"data"`
	} `json:"Answer"`
}

var dohEndpoints = []struct {
	url    string
	accept string
}{
	{"https://cloudflare-dns.com/dns-query", "application/dns-json"},
	{"https://dns.google/resolve", ""},
	{"https://dns.adguard-dns.com/resolve", "application/dns-json"},
}

var (
	dohTransport = &http.Transport{
		MaxIdleConns:        512,
		MaxIdleConnsPerHost: 64,
		IdleConnTimeout:     90 * time.Second,
		TLSHandshakeTimeout: 4 * time.Second,
		DisableCompression:  false,
	}
	dohClient = &http.Client{
		Transport: dohTransport,
		Timeout:   3 * time.Second,
	}
)

var commonMutationPrefixes = []string{
	"api", "dev", "admin", "vpn", "mail", "portal", "corp",
	"internal", "sso", "auth", "app", "staging", "gateway", "beta", "m",
}

// probeMutations: fast DoH parallel probing for high-value corporate/infrastructure prefixes.
// Finds private/internal subdomains not present in public Certificate Transparency logs.
func (w *worker) probeMutations(apex string) []string {
	if apex == "" || strings.Contains(apex, "*") || isGarbageDomain(apex) || !isValidDomain(apex) {
		return nil
	}
	var wg sync.WaitGroup
	var mu sync.Mutex
	var found []string
	ctx, cancel := context.WithTimeout(w.reqContext(), 2500*time.Millisecond)
	defer cancel()
	client := dohClient
	if w.torOn() {
		client = w.torClientNow()
	}
	for _, pfx := range commonMutationPrefixes {
		candidate := pfx + "." + apex
		if isGarbageDomain(candidate) || !isValidDomain(candidate) {
			continue
		}
		wg.Add(1)
		go func(h string) {
			defer wg.Done()
			if ips := queryDoH(ctx, client, h); len(ips) > 0 {
				mu.Lock()
				found = append(found, h)
				if w != nil && w.shared != nil {
					for _, ip := range ips {
						w.shared.addHarvestedIP(ip)
					}
				}
				mu.Unlock()
			}
		}(candidate)
	}
	wg.Wait()
	return found
}

var (
	dnsResultCache sync.Map
	dnsCacheCount  int64
)

type dnsCacheEntry struct {
	ips       []string
	expiresAt time.Time
}

func storeDNSCache(host string, ips []string) {
	if atomic.AddInt64(&dnsCacheCount, 1) > 25000 {
		go cleanExpiredDNSCache()
	}
	dnsResultCache.Store(host, dnsCacheEntry{ips: ips, expiresAt: time.Now().Add(5 * time.Minute)})
}

func cleanExpiredDNSCache() {
	now := time.Now()
	var kept int64
	dnsResultCache.Range(func(k, v any) bool {
		if entry, ok := v.(dnsCacheEntry); ok {
			if now.After(entry.expiresAt) {
				dnsResultCache.Delete(k)
				return true
			}
			kept++
		}
		return true
	})
	atomic.StoreInt64(&dnsCacheCount, kept)
}

func queryDoH(ctx context.Context, client *http.Client, host string) []string {
	host = strings.TrimSpace(strings.ToLower(strings.TrimSuffix(host, ".")))
	if host == "" {
		return nil
	}
	if v, ok := dnsResultCache.Load(host); ok {
		if entry, ok := v.(dnsCacheEntry); ok {
			if time.Now().Before(entry.expiresAt) {
				return entry.ips
			}
			dnsResultCache.Delete(host)
		}
	}
	if client == nil {
		client = dohClient
	}

	querySingle := func(ep struct{ url, accept string }) []string {
		u := ep.url + "?name=" + neturl.QueryEscape(host) + "&type=A"
		req, err := http.NewRequestWithContext(ctx, "GET", u, nil)
		if err != nil {
			return nil
		}
		req.Header.Set("User-Agent", "Mozilla/5.0")
		if ep.accept != "" {
			req.Header.Set("Accept", ep.accept)
		}
		resp, err := client.Do(req)
		if err != nil {
			return nil
		}
		defer drainAndClose(resp.Body)
		if resp.StatusCode != 200 {
			return nil
		}
		b, err := io.ReadAll(io.LimitReader(resp.Body, 512*1024))
		if err != nil {
			return nil
		}
		var dj dohJSON
		if err := json.Unmarshal(b, &dj); err != nil {
			return nil
		}
		var ips []string
		for _, a := range dj.Answer {
			if net.ParseIP(a.Data) != nil {
				ips = append(ips, a.Data)
			}
		}
		return ips
	}

	// Fast-path: try primary endpoint (Cloudflare) first without spawning redundant goroutines
	if ips := querySingle(dohEndpoints[0]); len(ips) > 0 {
		storeDNSCache(host, ips)
		return ips
	}

	// Fallback to secondary endpoints if primary returned empty / error
	for _, ep := range dohEndpoints[1:] {
		if ips := querySingle(ep); len(ips) > 0 {
			storeDNSCache(host, ips)
			return ips
		}
	}
	return nil
}

// wildcardCache memoizes DNS-wildcard detection per apex (apex -> isWildcard).
var (
	wildcardCache sync.Map
	wildcardCount int64
)

func storeWildcardCache(apex string, wc bool) {
	if atomic.AddInt64(&wildcardCount, 1) > 20000 {
		var kept int64
		wildcardCache.Range(func(k, v any) bool {
			if kept%2 == 0 {
				wildcardCache.Delete(k)
			} else {
				kept++
			}
			return true
		})
		atomic.StoreInt64(&wildcardCount, kept)
	}
	wildcardCache.Store(apex, wc)
}

// wildcardResolves reports whether `host` resolves to any DNS record via DoH.
// A wildcard apex answers for ANY random subdomain, so an answer here (A, AAAA,
// or CNAME) is the signature of a wildcarded domain whose enumerated
// "subdomains" are all fake (notexists-xxx.yarnstructions.com -> one IP).
func wildcardResolves(client *http.Client, host string) bool {
	return wildcardResolvesBudget(client, host, wildcardProbeBudget)
}

// wildcardProbeBudget is the default per-probe deadline for the offline/analyze
// path (2.5s, the historical value).
const wildcardProbeBudget = 2500 * time.Millisecond

// wildcardProbeBudgetFast is the deadline used inside the scrape hot path.
//
// isWildcardDomain runs INSIDE fetchCrt, i.e. inside handleNode, and it may fire
// TWICE per new apex. At the default 2.5s that is up to 5s of pure DNS latency
// added to a node whose providers only budget 3.5-4.5s — the probe dominated the
// node and made large runs look "stuck". A wildcard apex answers within a normal
// RTT; one that has not answered in 900ms is treated as non-wildcard, which is
// the safe direction (we scan the apex instead of silently dropping it).
const wildcardProbeBudgetFast = 900 * time.Millisecond

// wildcardResolvesBudget is wildcardResolves with an explicit deadline so the hot
// path can use a much tighter budget than the offline analyzer.
func wildcardResolvesBudget(client *http.Client, host string, budget time.Duration) bool {
	if client == nil {
		client = dohClient
	}
	if budget <= 0 {
		budget = wildcardProbeBudget
	}
	ctx, cancel := context.WithTimeout(context.Background(), budget)
	defer cancel()
	ep := dohEndpoints[0]
	u := ep.url + "?name=" + neturl.QueryEscape(host) + "&type=A"
	req, err := http.NewRequestWithContext(ctx, "GET", u, nil)
	if err != nil {
		return false
	}
	if ep.accept != "" {
		req.Header.Set("Accept", ep.accept)
	}
	resp, err := client.Do(req)
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return false
	}
	b, _ := io.ReadAll(io.LimitReader(resp.Body, 64*1024))
	var dj dohJSON
	if json.Unmarshal(b, &dj) != nil {
		return false
	}
	return len(dj.Answer) > 0
}

// isWildcardDomain reports whether apex has wildcard DNS (any subdomain
// resolves). Cached per apex; the probe uses random hex labels so it can
// never collide with a real host.
func isWildcardDomain(apex string) bool {
	client := dohClient
	torAddr := defaultTorSocks
	if !tcpProbe(torAddr) {
		fleet := loadTorFleet()
		if len(fleet) > 0 && tcpProbe(fleet[0]) {
			torAddr = fleet[0]
		}
	}
	if tcpProbe(torAddr) {
		if c, _, ok, _ := newTorClient(torAddr, 0, true); ok {
			client = c
		}
	}
	return isWildcardDomainWith(client, apex, wildcardProbeBudget)
}

// workerWildcardProbe is the hot-path wildcard check used by fetchCrt.
//
// Two deliberate differences from isWildcardDomain:
//
//  1. It probes through the WORKER's Tor client when Tor is on. The plain
//     version always dialled dohClient (direct), so a run that is otherwise
//     fully Tor-routed still leaked "notexists-<hex>.<target>" queries to
//     Cloudflare/Google over the operator's real IP — and it revealed exactly
//     which target was being enumerated. This matches resolveHost, which already
//     documents "zero ISP UDP 53 leak" for the same reason.
//  2. It uses the much tighter wildcardProbeBudgetFast, because this runs inside
//     handleNode and can fire twice per new apex.
func (w *worker) workerWildcardProbe(apex string) bool {
	if w == nil {
		return isWildcardDomain(apex)
	}
	if !w.torOn() {
		return isWildcardDomainWith(dohClient, apex, wildcardProbeBudgetFast)
	}
	return isWildcardDomainWith(w.torClientNow(), apex, wildcardProbeBudgetFast)
}

// isWildcardDomainWith is the shared, client- and budget-parameterised probe.
func isWildcardDomainWith(client *http.Client, apex string, budget time.Duration) bool {
	if apex == "" {
		return false
	}
	if v, ok := wildcardCache.Load(apex); ok {
		return v.(bool)
	}
	b := make([]byte, 8)
	rand.Read(b)
	probe := "notexists-" + hex.EncodeToString(b) + "." + apex
	wc := wildcardResolvesBudget(client, probe, budget)
	if !wc {
		rand.Read(b)
		probe2 := "notexists-" + hex.EncodeToString(b) + ".dev." + apex
		wc = wildcardResolvesBudget(client, probe2, budget)
	}
	storeWildcardCache(apex, wc)
	return wc
}

// resolveHost: resolves host h via DNS-over-HTTPS (DoH) with persistent connection pooling.
// If Tor is active, routes DoH strictly through Tor HTTP client (reusing circuit, zero port 53 dialing / DNS leaks).
func (w *worker) resolveHost(h string) []string {
	startReq := time.Now()
	h = strings.TrimSpace(strings.ToLower(strings.TrimSuffix(h, ".")))
	if h == "" {
		return nil
	}

	// 1. Tor mode: ROUTE EXCLUSIVELY VIA TOR CLIENT (ZERO DNS/OPSEC LEAK TO DIRECT ISP OR DOH SERVERS)
	if w.torOn() {
		torCtx, torCancel := context.WithTimeout(w.reqContext(), 3500*time.Millisecond)
		defer torCancel()
		if ips := queryDoH(torCtx, w.torClientNow(), h); len(ips) > 0 {
			globalDebug.RecordNetworkLatency("dns", time.Since(startReq).Milliseconds(), 200, false)
			return ips
		}
		globalDebug.RecordNetworkLatency("dns", time.Since(startReq).Milliseconds(), 0, true)
		return nil
	}

	// 2. Direct high-speed DoH lookup only in non-Tor mode
	directCtx, directCancel := context.WithTimeout(context.Background(), 1200*time.Millisecond)
	defer directCancel()
	if ips := queryDoH(directCtx, dohClient, h); len(ips) > 0 {
		globalDebug.RecordNetworkLatency("dns", time.Since(startReq).Milliseconds(), 200, false)
		return ips
	}

	// 3. Fallback to system resolver only in non-Tor mode
	sysCtx, sysCancel := context.WithTimeout(context.Background(), 400*time.Millisecond)
	defer sysCancel()
	if a, err := net.DefaultResolver.LookupHost(sysCtx, h); err == nil && len(a) > 0 {
		globalDebug.RecordNetworkLatency("dns", time.Since(startReq).Milliseconds(), 200, false)
		return a
	}
	globalDebug.RecordNetworkLatency("dns", time.Since(startReq).Milliseconds(), 0, true)
	return nil
}

// resolveHostDual: DoH resolver with fallback to system resolver (routes via Tor if Tor is active)
func resolveHostDual(h string) []string {
	startReq := time.Now()
	h = strings.TrimSpace(strings.ToLower(strings.TrimSuffix(h, ".")))
	if h == "" {
		return nil
	}
	client := dohClient
	torAddr := defaultTorSocks
	if !tcpProbe(torAddr) {
		fleet := loadTorFleet()
		if len(fleet) > 0 && tcpProbe(fleet[0]) {
			torAddr = fleet[0]
		}
	}
	torRunning := tcpProbe(torAddr)
	if torRunning {
		if c, _, ok, _ := newTorClient(torAddr, 0, true); ok {
			client = c
		}
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2500*time.Millisecond)
	defer cancel()
	if ips := queryDoH(ctx, client, h); len(ips) > 0 {
		globalDebug.RecordNetworkLatency("dns", time.Since(startReq).Milliseconds(), 200, false)
		return ips
	}
	if !torRunning {
		sysCtx, sysCancel := context.WithTimeout(context.Background(), 400*time.Millisecond)
		defer sysCancel()
		if a, err := net.DefaultResolver.LookupHost(sysCtx, h); err == nil && len(a) > 0 {
			globalDebug.RecordNetworkLatency("dns", time.Since(startReq).Milliseconds(), 200, false)
			return a
		}
	}
	globalDebug.RecordNetworkLatency("dns", time.Since(startReq).Milliseconds(), 0, true)
	return nil
}

// adjacentSubnetIPs: extracts the /24 subnet block of a public IPv4 and returns adjacent neighbor IPs (+1, -1).
func adjacentSubnetIPs(ipStr string) []string {
	parsed := net.ParseIP(ipStr)
	if parsed == nil {
		return nil
	}
	ipv4 := parsed.To4()
	if ipv4 == nil {
		return nil
	}
	// Avoid private/loopback/link-local/multicast
	if ipv4[0] == 10 || ipv4[0] == 127 || (ipv4[0] == 172 && ipv4[1] >= 16 && ipv4[1] <= 31) || (ipv4[0] == 192 && ipv4[1] == 168) || ipv4[0] >= 224 {
		return nil
	}
	d := int(ipv4[3])
	var out []string
	if d > 1 {
		out = append(out, fmt.Sprintf("%d.%d.%d.%d", ipv4[0], ipv4[1], ipv4[2], d-1))
	}
	if d < 254 {
		out = append(out, fmt.Sprintf("%d.%d.%d.%d", ipv4[0], ipv4[1], ipv4[2], d+1))
	}
	return out
}

// expandReverse: resolve NEW hosts since last expand → IPs → /sameip → new apex.
// Incremental (offset expandSeen) so repeat idles don't re-resolve everything.
// Batch 300, timeout 2.5s, sem 60 → bounded ~13s worst case.
func expandReverse(w *worker, ch chan node, queueLen *int64, target int, ctx context.Context) int {
	if noReverse {
		return 0
	}
	atomic.StoreInt32(&w.shared.expandActive, 1)
	defer atomic.StoreInt32(&w.shared.expandActive, 0)

	w.shared.mu.Lock()
	if w.shared.expandApexCount == nil {
		w.shared.expandApexCount = make(map[string]int)
	}
	// Snapshot the pool header under the lock, then scan it WITHOUT holding s.mu.
	// Append only ever writes past the captured length, and a reallocation just
	// swaps in a new backing array, so reading [0,len) of the captured header is
	// race-free. The old shape filtered every candidate while holding s.mu, so a
	// large pool blocked the write funnel (every worker) for the whole scan.
	// The scan is also capped at expandScanPerCall so its cost is constant.
	resPool := w.shared.results
	seedPool := w.shared.seedApexes
	total := len(resPool)
	start := w.shared.expandSeen
	if total > 0 && start >= total {
		start = 0
	}
	w.shared.mu.Unlock()

	if total == 0 && len(seedPool) == 0 {
		return 0
	}
	var hosts []string
	batchApexCount := make(map[string]int)
	if total > 0 {
		idx := start
		scanned := 0
		for scanned < total && scanned < expandScanPerCall && len(hosts) < 150 {
			h := resPool[idx]
			idx = (idx + 1) % total
			scanned++
			a := apexOf(h)
			if a == "" || inSkipZone(a) || isGarbageDomain(a) || !globalScopeGuard.IsAllowed(a) || batchApexCount[a] >= 3 {
				continue
			}
			batchApexCount[a]++
			hosts = append(hosts, h)
		}
		w.shared.mu.Lock()
		w.shared.expandSeen = idx
		w.shared.mu.Unlock()
	}
	// Fallback/supplement: if hosts < 30, sample seeds from seedApexes
	if len(hosts) < 30 && len(seedPool) > 0 {
		for seed := range seedPool {
			if len(hosts) >= 80 {
				break
			}
			if inSkipZone(seed) || batchApexCount[seed] >= 2 {
				continue
			}
			batchApexCount[seed]++
			hosts = append(hosts, seed)
		}
	}

	if len(hosts) == 0 {
		return 0
	}
	guiLogQuiet("system", "", 0, "[rapiddns] reverse-ip start: %d diverse hosts for sameip expansion (offset %d/%d)", len(hosts), start, total)
	ipHosts := map[string][]string{}
	var mu sync.Mutex
	var wg sync.WaitGroup
	var dnsOK, dnsFail int64
	semLimit := 80
	sem := make(chan struct{}, semLimit)
	for _, h := range hosts {
		h := h
		wg.Add(1)
		go func() {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			addrs := w.resolveHost(h)
			if len(addrs) == 0 {
				atomic.AddInt64(&dnsFail, 1)
				return
			}
			atomic.AddInt64(&dnsOK, 1)
			mu.Lock()
			for _, s := range addrs {
				if net.ParseIP(s) == nil || strings.HasPrefix(s, "127.") || s == "::1" {
					continue
				}
				ipHosts[s] = append(ipHosts[s], h)
			}
			mu.Unlock()
		}()
	}
	wg.Wait()
	// Check context cancellation before proceeding
	select {
	case <-ctx.Done():
		return 0
	default:
	}
	// Ingest harvested IPs directly into ipHosts (from RapidDNS, HackerTarget, OTX)
	// Collect first, then delete to avoid unsafe map iteration
	if w.shared != nil {
		harvestCount := 0
		scannedHarvest := 0
		// Drain inline: sync.Map.Range tolerates Delete during iteration, and
		// deleting as we walk keeps the set bounded. The old shape copied EVERY
		// key into a slice first and removed only up to 200, so when arrivals
		// outpaced the drain the set — and the per-call copy — grew without bound.
		w.shared.harvestedIPs.Range(func(k, v any) bool {
			scannedHarvest++
			ip, ok := k.(string)
			if !ok {
				return scannedHarvest < harvestedDrainPerCall
			}
			w.shared.harvestedIPs.Delete(ip)
			if net.ParseIP(ip) != nil && !strings.HasPrefix(ip, "127.") && ip != "::1" {
				mu.Lock()
				if len(ipHosts[ip]) == 0 {
					ipHosts[ip] = append(ipHosts[ip], "harvested")
					harvestCount++
				}
				mu.Unlock()
			}
			return scannedHarvest < harvestedDrainPerCall
		})
		if harvestCount > 0 {
			guiLogQuiet("system", "", harvestCount, "[expand] ingested %d harvested IPs from passive sources", harvestCount)
		}
	}
	// Check context cancellation before subnet sweep
	select {
	case <-ctx.Done():
		return 0
	default:
	}
	// Subnet /24 Opportunistic Sweep: sample adjacent server rack IPs for top non-CDN servers
	sweepCount := 0
	for ip := range ipHosts {
		if sweepCount >= 40 {
			break
		}
		if IsAnycastCDN(ip) {
			continue
		}
		for _, neighbor := range GenerateSmartSubnetNeighbors(ip, 6) {
			if len(ipHosts[neighbor]) != 0 {
				continue
			}
			// Same rack budget as every other sweep site: without it this loop
			// re-adds up to 40 rack IPs on EVERY expandReverse tick (it fires
			// whenever the apex queue dips), which is unbounded work per run.
			if !w.shared.allowSubnetHost(neighbor) {
				continue
			}
			ipHosts[neighbor] = append(ipHosts[neighbor], "subnet24")
			sweepCount++
			if sweepCount >= 40 {
				break
			}
		}
	}
	if sweepCount > 0 {
		guiLogQuiet("system", "", sweepCount, "[expand] swept %d /24 subnet neighbor IPs (non-CDN origin clusters)", sweepCount)
	}
	if len(ipHosts) == 0 {
		guiLogf("system", "", 0, "[expand] DNS %d ok %d fail, 0 IPs", atomic.LoadInt64(&dnsOK), atomic.LoadInt64(&dnsFail))
		return 0
	}
	// pick top IPs by host count, prioritizing non-CDN origin servers
	type kv struct {
		ip string
		n  int
	}
	var kvs []kv
	for ip, hs := range ipHosts {
		kvs = append(kvs, kv{ip, len(hs)})
	}
	sort.Slice(kvs, func(i, j int) bool {
		isCDNi := IsAnycastCDN(kvs[i].ip)
		isCDNj := IsAnycastCDN(kvs[j].ip)
		if isCDNi != isCDNj {
			return !isCDNi // non-CDN comes first
		}
		return kvs[i].n > kvs[j].n
	})

	// dedup IPs already reverse-scanned: pick up to 80 FRESH un-scanned IPs!
	w.shared.mu.Lock()
	if w.shared.ipDone == nil {
		w.shared.ipDone = make(map[string]bool)
	}
	var filtered []kv
	for _, kv := range kvs {
		if w.shared.ipDone[kv.ip] {
			continue
		}
		filtered = append(filtered, kv)
		if len(filtered) >= 80 {
			break
		}
	}
	w.shared.mu.Unlock()
	if len(filtered) == 0 {
		// Fallback: sweep un-scanned /24 neighbors of racks we already scanned.
		//
		// Collect under s.mu, then CLAIM through claimRackHost after unlocking:
		// s.mu is a plain sync.Mutex, so calling allowSubnetHost/claimRackHost in
		// here would deadlock on the non-reentrant lock.
		//
		// The claim itself is essential. This branch fires whenever everything is
		// already ipDone — i.e. on the idle ticks — and it used to hand back a
		// FRESH set of 60 rack IPs every time it ran, because a candidate only had
		// to be not-yet-done to qualify. That made the expander never quiesce: it
		// kept feeding sameip lookups through Tor forever instead of letting the
		// apex queue it was meant to support drain. The rack budget caps it at
		// subnetHostBudget hosts per /24 and subnetCountBudget racks per run.
		var cands []string
		const rackFallbackPick = 120 // over-select, then let the budget thin it
		ipScanned := 0
		w.shared.mu.Lock()
		for ip := range w.shared.ipDone {
			if len(cands) >= rackFallbackPick || ipScanned >= ipDoneScanPerCall {
				break
			}
			ipScanned++
			if IsAnycastCDN(ip) {
				continue
			}
			for _, neighbor := range GenerateSmartSubnetNeighbors(ip, 8) {
				if !w.shared.ipDone[neighbor] {
					cands = append(cands, neighbor)
					if len(cands) >= rackFallbackPick {
						break
					}
				}
			}
		}
		w.shared.mu.Unlock()
		for _, neighbor := range cands {
			if len(filtered) >= 60 {
				break
			}
			if w.shared.claimRackHost(neighbor) {
				filtered = append(filtered, kv{neighbor, 1})
			}
		}
	}
	kvs = filtered
	if len(kvs) == 0 {
		return 0
	}
	// Check context cancellation before tiered reverse
	select {
	case <-ctx.Done():
		return 0
	default:
	}

	var added atomic.Int64
	var skipped atomic.Int64
	var dup atomic.Int64
	var totalDoms atomic.Int64

	maxExpandCap := int64(1500)
	if target > 0 && int64(target) < maxExpandCap {
		maxExpandCap = int64(target)
	}
	if maxExpandCap < 200 {
		maxExpandCap = 200
	}

	// Real-Time Continuous Streaming Enqueuer:
	// As soon as any IP returns domains, stream new apexes into workers channel
	// AND write valid discovered domains directly to output!
	enqueueDoms := func(doms []string, sourceIP string) {
		if len(doms) == 0 {
			return
		}
		totalDoms.Add(int64(len(doms)))
		if target > 0 && atomic.LoadInt64(&w.shared.count) >= int64(target) {
			return
		}
		var toWrite []string
		newApexCount := 0
		for _, d := range doms {
			d = strings.ToLower(strings.TrimSpace(d))
			if d == "" || inSkipZone(d) || isGarbageDomain(d) || !isValidDomain(d) || isInfraNoise(d) || !globalScopeGuard.IsAllowed(d) {
				skipped.Add(1)
				continue
			}
			if _, loaded := w.shared.visited.LoadOrStore(d, true); !loaded {
				toWrite = append(toWrite, d)
			} else {
				// Already discovered elsewhere: this is the "(dup N)" figure in the
				// summary line. It used to be permanently 0 because the counter was
				// never incremented (dupIP at the IP-selection loop was dead code).
				dup.Add(1)
			}
			a := apexOf(d)
			if a != "" && !inSkipZone(a) && !isGarbageDomain(a) && isValidDomain(a) && !isInfraNoise(a) && globalScopeGuard.IsAllowed(a) {
				w.shared.mu.RLock()
				isDone := w.shared.apexDone[a]
				w.shared.mu.RUnlock()
				if !isDone {
					if _, loaded := w.shared.apexSeen.LoadOrStore(a, true); !loaded {
						select {
						case ch <- node{a, true, 0, "rapiddns"}:
							atomic.AddInt64(queueLen, 1)
							added.Add(1)
							newApexCount++
						default:
							// Queue saturated: un-mark so a later sweep can still enqueue
							// this apex instead of losing it forever.
							w.shared.apexSeen.Delete(a)
						}
					}
				}
			}
		}
		if len(toWrite) > 0 {
			wLines := w.writeLines(toWrite)
			if wLines > 0 {
				guiLogf("rapiddns", sourceIP, wLines, "[sameip] %s → +%d valid domains (+%d apex)", sourceIP, wLines, newApexCount)
			}
		}
	}

	// TIERED reverse: rapiddns sameip first (fast), then the high-yield tntcode
	// page. NOTE: the older HackerTarget / InternetDB / Robtex / URLScan /
	// Mnemonic providers live in fetchReverseAll, which nothing calls — they are
	// kept for reference but are NOT wired into this path.
	const leanThreshold = 15
	var sameWg sync.WaitGroup
	semRev := make(chan struct{}, 32)
	for _, kv := range kvs {
		kv := kv
		sameWg.Add(1)
		go func() {
			defer sameWg.Done()
			semRev <- struct{}{}
			defer func() { <-semRev }()

			// Mark IP as scanned
			w.shared.mu.Lock()
			w.shared.ipDone[kv.ip] = true
			w.shared.mu.Unlock()

			doms := filterValid(w.fetchSameIP(kv.ip))
			if t := w.fetchTntcode(kv.ip); len(t) > 0 {
				doms = append(doms, t...)
			}
			if len(doms) < 5 {
				if pass := w.fetchReversePassive(kv.ip); len(pass) > 0 {
					doms = append(doms, pass...)
				}
			}
			if len(doms) > 0 {
				enqueueDoms(doms, kv.ip)
			}
		}()
	}
	sameWg.Wait()

	totalAdded := int(added.Load())
	guiLogQuiet("rapiddns", fmt.Sprintf("%d IPs (sameip)", len(kvs)), totalAdded, "[rapiddns] %d IPs, %d sameip domains: %d new apex (dup %d skipzone %d)", len(kvs), totalDoms.Load(), totalAdded, dup.Load(), skipped.Load())
	return totalAdded
}

func readList(path string) ([]string, error) {
	b, err := os.ReadFile(path)
	if err != nil && !filepath.IsAbs(path) {
		// Fallback: check if the file exists in the seeds/ directory
		if b2, err2 := os.ReadFile(filepath.Join("seeds", path)); err2 == nil {
			b = b2
			err = nil
		}
	}
	if err != nil {
		return nil, err
	}
	text := string(b)
	if len(b) >= 2 && b[0] == 0xFF && b[1] == 0xFE {
		var sb strings.Builder
		sb.Grow(len(b) / 2)
		for i := 2; i+1 < len(b); i += 2 {
			r := rune(b[i]) | rune(b[i+1])<<8
			if r == 0 {
				continue
			}
			sb.WriteRune(r)
		}
		text = sb.String()
	} else if len(b) >= 2 && b[0] == 0xFE && b[1] == 0xFF {
		// UTF-16 BE (BOM FE FF)
		var sb strings.Builder
		sb.Grow(len(b) / 2)
		for i := 2; i+1 < len(b); i += 2 {
			r := rune(b[i])<<8 | rune(b[i+1])
			if r == 0 {
				continue
			}
			sb.WriteRune(r)
		}
		text = sb.String()
	} else if strings.HasPrefix(text, "\ufeff") {
		text = strings.TrimPrefix(text, "\ufeff")
	}
	// splitLines avoids strings.Split's per-line allocation churn: it hands out
	// []byte views of the buffer instead of one fresh string per line.
	lines := splitLines([]byte(text))
	out := make([]string, 0, listMin(len(lines), maxInputDomains))
	for _, raw := range lines {
		l := strings.TrimSpace(strings.Trim(string(raw), "\ufeff\r"))
		l = strings.TrimSuffix(strings.TrimSpace(l), ".")
		l = strings.ToLower(l)
		if l == "" || strings.HasPrefix(l, "#") {
			continue
		}
		// Strip protocol scheme if user supplied a URL (e.g. http://, https://)
		if i := strings.Index(l, "://"); i >= 0 {
			l = l[i+3:]
		}
		// Strip path, query parameters, or fragments
		if i := strings.IndexAny(l, "/?#"); i >= 0 {
			l = l[:i]
		}
		// Strip port if present (e.g. domain.com:443 or host:8080)
		if h, _, err := net.SplitHostPort(l); err == nil {
			l = h
		}
		l = strings.TrimSuffix(strings.TrimSpace(l), ".")
		// Cheap byte pre-checks first; the two expensive per-line checks left
		// (validDomainRe + net.ParseIP) only see plausible lines.
		if strings.IndexAny(l, " @/\\") >= 0 {
			continue
		}
		if !isPlausibleListDomain(l) {
			continue
		}
		// PERF: the shared precompiled matcher. regexp.MatchString here used to
		// recompile the whole pattern for EVERY line — on a 100k-line seed file
		// that was 524 MB of allocations / 5.5M allocs / ~570 ms of pure CPU
		// (88% of the startup cost) before the first request was ever sent.
		if !validDomainRe.MatchString(l) {
			continue
		}
		if net.ParseIP(l) != nil {
			continue
		}
		if len(out) >= maxInputDomains {
			fmt.Fprintf(os.Stderr, "[!] input list truncated to %d domains (max)\n", maxInputDomains)
			break
		}
		out = append(out, l)
	}
	return out, nil
}

// isPlausibleListDomain is readList's cheap shape gate for one lowercased
// candidate: exactly what the old per-line scans asserted before the regexp
// and net.ParseIP ran (a '.' somewhere not at the edges, plus a >=2-char TLD).
func isPlausibleListDomain(l string) bool {
	i := strings.IndexByte(l, '.')
	if i <= 0 || i == len(l)-1 || l[len(l)-1] == '.' {
		return false
	}
	j := strings.LastIndexByte(l, '.')
	if len(l)-j-1 < 2 {
		return false
	}
	return true
}

// splitLines cuts b on '\n' without copying the line bytes (unlike
// strings.Split, which allocates one string per line). The returned views share
// b's buffer — they are only converted to strings after surviving validation.
func splitLines(b []byte) [][]byte {
	out := make([][]byte, 0, listMin(bytes.Count(b, nlByte)+1, maxInputDomains+1))
	start := 0
	for i, c := range b {
		if c == '\n' {
			out = append(out, b[start:i])
			start = i + 1
		}
	}
	return append(out, b[start:])
}

var nlByte = []byte{'\n'}

// listMin is a plain min(a, b). The builtin min exists since Go 1.21, but this
// file must still build on the older toolchains some operators compile with, so
// the helper stays (the earlier comment claimed the builtin arrived later than
// it did — it is a pre-1.21 compatibility shim, nothing more).
func listMin(a, b int) int {
	if a < b {
		return a
	}
	return b
}

// ---- GUI state ----
type guiEntry struct {
	Time   string `json:"time"`
	Level  string `json:"level"`
	API    string `json:"api"`
	Domain string `json:"domain"`
	Added  int    `json:"added"`
	Total  int    `json:"total"`
	Queue  int    `json:"queue"`
	Msg    string `json:"msg"`
}

var (
	guiMu      sync.Mutex
	guiRunning bool
	guiStop    atomic.Bool
	guiEntries []guiEntry
	// All shared with the GUI HTTP handlers: guiFound/guiTarget/guiIter are
	// atomic (written by scraper goroutines, read by the status handler),
	// guiOut/guiTorIP/guiMode are plain strings and must be touched only while
	// holding guiMu.
	guiFound   atomic.Int64
	guiTarget  atomic.Int64
	guiQueue   atomic.Int32
	guiIter    atomic.Int64
	guiOut     string
	guiTorIP   string
	guiMode    string
	guiWorkers atomic.Int32
)

// guiEntryCap is kept for parity between restarts and between CLI/GUI runs.
const guiEntryCap = 1200

// pushGuiEntry keeps the last ~guiEntryCap log rows with zero steady-state
// allocations. The previous shape (append + front reslice once past 1200) fed
// the resliced front offset into every subsequent append, so the 1200-entry
// backing array (~120 KB) was reallocated again and again instead of being
// reused.
func pushGuiEntry(e guiEntry) {
	guiMu.Lock()
	if len(guiEntries) >= guiEntryCap {
		n := copy(guiEntries, guiEntries[len(guiEntries)-guiEntryCap/2:])
		guiEntries = guiEntries[:n]
	}
	guiEntries = append(guiEntries, e)
	guiMu.Unlock()
}

var lastCliPrintTime time.Time

func guiLogf(level, domain string, added int, format string, a ...interface{}) {
	msg := fmt.Sprintf(format, a...)
	e := guiEntry{
		Time:   time.Now().Format("15:04:05"),
		Level:  level,
		API:    level,
		Domain: domain,
		Added:  added,
		Msg:    msg,
	}
	if level == "crt.name" || level == "rapiddns" || level == "crt.sh" {
		e.API = level
		e.Level = "ok"
	} else if level == "tor" || level == "system" {
		e.Level = "tor"
		e.API = level
	} else if level == "error" {
		e.Level = "err"
	}
	pushGuiEntry(e)
	// console: hits saja. +0 → GUI tabel, tidak spam CLI.
	// Flood 18:34:44 = 200+ apexDone miss (sama apex, dedup) bukan limit.
	if added <= 0 {
		if level == "system" || level == "tor" {
			cliMu.Lock()
			clearLine()
			fmt.Println(paint(colDim, msg))
			cliMu.Unlock()
		}
		return
	}
	if level != "crt.name" && level != "rapiddns" && level != "crt.sh" && level != "crt+rapid" {
		return
	}
	// S2-07 output rapi: throttle CLI per-apex — cetak hanya bila hit BESAR
	// (>=50) atau apex BARU pertama kali. Hit kecil (<50) cukup masuk progress
	// bar + GUI tabel, tidak spam 3400 baris/run 50k. File output tetap penuh.
	cliMu.Lock()
	apexHitCount[level+":"+domain]++
	n := apexHitCount[level+":"+domain]
	now := time.Now()
	shouldPrint := added >= 20 || n == 1 || now.Sub(lastCliPrintTime) >= 1500*time.Millisecond
	if shouldPrint {
		lastCliPrintTime = now
		clearLine()
		fmt.Printf("[%s] %-9s %-36s %s total %s\n",
			paint(colDim, now.Format("15:04:05")),
			paint(colCyan, level),
			truncateDomain(domain),
			paint(colGrn, fmt.Sprintf("+%-4d", added)),
			paint(colYel, human(guiFound.Load())),
		)
	}
	cliMu.Unlock()
	apexTotalsMu.Lock()
	apexTotals[domain] += added
	apexTotalsMu.Unlock()
}

func truncateDomain(s string) string {
	if len(s) <= 40 {
		return s
	}
	return s[:37] + "..."
}

// guiLogQuiet stores to GUI table only, no console output.
func guiLogQuiet(level, domain string, added int, format string, a ...interface{}) {
	msg := fmt.Sprintf(format, a...)
	e := guiEntry{
		Time:   time.Now().Format("15:04:05"),
		Level:  level,
		API:    level,
		Domain: domain,
		Added:  added,
		Msg:    msg,
	}
	if level == "crt.name" || level == "rapiddns" || level == "crt.sh" {
		e.API = level
		e.Level = "ok"
	} else if level == "tor" || level == "system" {
		e.Level = "tor"
		e.API = level
	} else if level == "error" {
		e.Level = "err"
	}
	pushGuiEntry(e)
}

// ---- parallel engine ----
// safeOutputPath resolves and validates an output path so it cannot escape the
// working directory (blocks traversal like "../x") and ensures the parent dir
// exists. Used by CLI (-o) and GUI (req.Out) before opening the output file.
func safeOutputPath(p string) (string, error) {
	p = strings.TrimSpace(p)
	if p == "" {
		return "", fmt.Errorf("empty output path")
	}
	p = filepath.Clean(p)
	wd, err := os.Getwd()
	if err != nil {
		return "", err
	}
	// FIX H-05: resolve symlinks on wd so rel comparison uses canonical paths
	if realWd, err := filepath.EvalSymlinks(wd); err == nil {
		wd = realWd
	}
	abs := p
	if !filepath.IsAbs(p) {
		abs = filepath.Join(wd, p)
	}
	// Resolve symlinks for parent directory to prevent bypass via symlink in working directory
	parent := filepath.Dir(abs)
	parent, err = filepath.EvalSymlinks(parent)
	if err != nil {
		// Parent doesn't exist yet (will be created), use original parent
		parent = filepath.Dir(abs)
	}
	// Forbid relative directory traversal (e.g. "../evil.txt", "..")
	if strings.HasPrefix(p, "..") || strings.Contains(p, "/..") || strings.Contains(p, "\\..") {
		return "", fmt.Errorf("output path escapes working directory")
	}
	// If path is relative, ensure it stays strictly within working directory
	if !filepath.IsAbs(p) {
		rel, err := filepath.Rel(wd, abs)
		if err != nil || strings.HasPrefix(rel, "..") {
			return "", fmt.Errorf("output path escapes working directory")
		}
	}
	base := strings.ToLower(filepath.Base(abs))
	ext := strings.ToLower(filepath.Ext(abs))
	if ext == ".go" || ext == ".mod" || ext == ".sum" || ext == ".exe" || ext == ".bat" || ext == ".sh" || ext == ".git" || ext == ".dll" || ext == ".sys" {
		return "", fmt.Errorf("output path cannot use protected extension: %s", ext)
	}
	if base == "go.mod" || base == "go.sum" || base == "torports.txt" {
		return "", fmt.Errorf("output path cannot overwrite project file: %s", base)
	}
	if err := os.MkdirAll(filepath.Dir(abs), 0o755); err != nil {
		return "", err
	}
	return abs, nil
}

// tidyOutputFile sorts domains alphabetically, deduplicates, and strips empty/invalid lines.
func tidyOutputFile(path string) {
	f, err := os.Open(path)
	if err != nil {
		return
	}
	defer f.Close()

	seen := make(map[string]struct{})
	var clean []string
	scanner := bufio.NewScanner(f)
	scanner.Buffer(make([]byte, 1024*1024), 1024*1024)
	for scanner.Scan() {
		l := strings.TrimSpace(strings.ToLower(scanner.Text()))
		if l == "" || !isValidDomain(l) {
			continue
		}
		if _, ok := seen[l]; !ok {
			seen[l] = struct{}{}
			clean = append(clean, l)
		}
	}
	// BAIL OUT before os.Create below. That Create TRUNCATES the file: if the
	// read had failed halfway (I/O error, or a line past the buffer cap) the old
	// code rewrote the output with whatever it had read so far, silently deleting
	// every domain it never got to. An incomplete sort is worse than no sort.
	if err := scanner.Err(); err != nil {
		_ = f.Close()
		guiLogQuiet("error", path, 0, "[tidy] %s: %v -> file TIDAK diubah", path, err)
		return
	}
	_ = f.Close()

	sort.Strings(clean)
	outF, err := os.Create(path)
	if err != nil {
		return
	}
	defer outF.Close()
	w := bufio.NewWriter(outF)
	for _, l := range clean {
		w.WriteString(l)
		w.WriteByte('\n')
	}
	_ = w.Flush()
}

func runMass(list []string, target int, outPath, torAddr string, workers int, useTor bool, mode string, rotateInterval time.Duration) (int64, error) {
	if workers < 1 {
		workers = 1
	}
	if workers > 100 {
		workers = 100
	}
	if target > maxTargetDomains {
		fmt.Fprintf(os.Stderr, "[!] target truncated to %d (max)\n", maxTargetDomains)
		target = maxTargetDomains
	}
	outPath, err := safeOutputPath(outPath)
	if err != nil {
		return 0, err
	}
	// Cleanup auto-started Tor processes on exit
	defer killAutoTor()
	startTorExitSteering(torAddr)
	defer exitHealth.flushSave()

	// Warn if workers > fleet (ratio > 1:1) — each worker sharing an exit IP
	// burns the same crt.name quota, wasting budget. Optimal: 1 worker = 1 fleet.
	if useTor {
		fleetN := len(loadTorFleet())
		if fleetN > 0 && workers > fleetN {
			guiLogf("tor", "", 0, "[warn] %d worker sharing %d exit IP (rasio %.1f:1) — pertimbangkan -torfleet %d untuk 1:1",
				workers, fleetN, float64(workers)/float64(fleetN), workers)
		}
	}

	f, err := os.Create(outPath)
	if err != nil {
		return 0, err
	}
	defer f.Close()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	shared := &sharedState{
		ctx:             ctx,
		cancel:          cancel,
		apexDone:        make(map[string]bool),
		ipDone:          make(map[string]bool),
		seedApexes:      buildSeedApexes(list),
		torIPs:          make(map[string]int),
		apexCount:       make(map[string]int),
		expandApexCount: make(map[string]int),
		ipEmpty:         make(map[string]int),
		apexLimited:     make(map[string]int),
		apexSuspect:     make(map[string]int),
		apexRequeued:    make(map[string]int),
		w:               bufio.NewWriter(f),
		file:            f,
	}
	// Size the secondary-provider fan-out from the REAL worker count instead of
	// the old global 8 slots, which silently throttled (and dropped) work.
	setFallbackConcurrency(workers)
	exitUniq.reset()
	// Seed ScopeGuard with initial targets to ensure scope anchoring
	if globalScopeGuard != nil {
		for _, d := range list {
			globalScopeGuard.AddSeed(d)
		}
	}
	// seed
	queue := make([]node, 0, len(list)*2)
	for _, d := range list {
		d = strings.ToLower(strings.TrimSpace(d))
		shared.visited.Store(d, true)
		queue = append(queue, node{d, true, 0, "crt.name"})
	}
	isUnlimited := target <= 0
	guiFound.Store(0)
	if isUnlimited {
		guiTarget.Store(0)
	} else {
		guiTarget.Store(int64(target))
	}
	guiWorkers.Store(int32(workers))
	guiMu.Lock()
	guiOut = outPath
	guiMode = mode // set mode for status display
	guiMu.Unlock()
	// channel for work distribution — dynamic buffer capacity bounded [10k, 200k]
	chanCap := target * 2
	if isUnlimited || chanCap < 10000 {
		chanCap = 100000
	}
	if chanCap > 200000 {
		chanCap = 200000
	}
	ch := make(chan node, chanCap)
	for _, n := range queue {
		ch <- n
	}
	// ipCh for Real-Time RapidDNS Same-IP Assembly Line
	ipChanCap := 50000
	ipCh := make(chan string, ipChanCap)
	var ipQLen int64

	// Initial Seed IP Priming: resolve initial seed domains to server IPs immediately
	if !noReverse {
		go func(seeds []string) {
			for _, s := range seeds {
				ips := resolveHostDual(s)
				for _, ip := range ips {
					if net.ParseIP(ip) == nil || IsAnycastCDN(ip) {
						continue
					}
					shared.mu.Lock()
					seen := shared.ipDone[ip]
					if !seen {
						shared.ipDone[ip] = true
					}
					shared.mu.Unlock()
					if !seen {
						select {
						case ipCh <- ip:
							atomic.AddInt64(&ipQLen, 1)
						default:
							shared.addHarvestedIP(ip)
						}
						for _, neighbor := range GenerateSmartSubnetNeighbors(ip, 6) {
							// Rack sweep budget: without this each queued neighbour
							// proposes more neighbours and the ip queue grows
							// multiplicatively (see allowSubnetHost).
							if !shared.allowSubnetHost(neighbor) {
								continue
							}
							shared.mu.Lock()
							nSeen := shared.ipDone[neighbor]
							if !nSeen {
								shared.ipDone[neighbor] = true
							}
							shared.mu.Unlock()
							if !nSeen {
								select {
								case ipCh <- neighbor:
									atomic.AddInt64(&ipQLen, 1)
								default:
									shared.addHarvestedIP(neighbor)
								}
							}
						}
					}
				}
			}
		}(list)
	}

	rapidWorkers := 0
	if !noReverse && workers >= 3 {
		rapidWorkers = workers * 45 / 100 // 45% for Stage 2 same-ip high volume, 55% for Stage 1 subdomains
		if rapidWorkers < 1 {
			rapidWorkers = 1
		}
		if rapidWorkers > 45 {
			rapidWorkers = 45
		}
	}
	subWorkers := workers - rapidWorkers

	var wg sync.WaitGroup
	var queueLen int64 = int64(len(queue))
	var iter int64
	var done int32
	var expandClaim int32
	var zeroExpandCount int32
	var activeWorkers int32
	stop := func() bool {
		if guiStop.Load() {
			cancel()
			return true
		}
		if atomic.LoadInt32(&done) == 1 || (!isUnlimited && atomic.LoadInt64(&shared.count) >= int64(target)) || ctx.Err() != nil {
			cancel()
			return true
		}
		return false
	}

	// Re-queue pump: turns the loss-free pending list (provider limit or a
	// saturated fan-out) back into real queue items. A channel send can be
	// dropped when the buffer is full, which used to make "scan lagi target yang
	// belum berhasil" silently depend on luck.
	go func() {
		ticker := time.NewTicker(150 * time.Millisecond)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
			}
			pending := shared.takePending(400)
			for _, a := range pending {
				select {
				case ch <- node{a, true, 1, "requeue"}:
					atomic.AddInt64(&queueLen, 1)
				default:
					shared.requeueApex(a) // queue full: keep it for the next tick
				}
			}
		}
	}()

	// tor ip check for badge
	go func() {
		c, _, _, _ := newTorClient(torAddr, 99, useTor)
		var ip string
		if resp, err := c.Get("https://check.torproject.org/api/ip"); err == nil {
			b, _ := io.ReadAll(io.LimitReader(resp.Body, 1024))
			resp.Body.Close()
			ip = strings.TrimSpace(string(b))
		} else if !useTor {
			directProbe := &http.Client{Timeout: 5 * time.Second}
			if resp, err := directProbe.Get("https://check.torproject.org/api/ip"); err == nil {
				b, _ := io.ReadAll(io.LimitReader(resp.Body, 1024))
				resp.Body.Close()
				ip = strings.TrimSpace(string(b))
			}
		}
		guiMu.Lock()
		guiTorIP = ip
		guiMu.Unlock()
	}()

	// Continuous Streaming Reactor: autonomous background expander maintains full queue
	minQueueThreshold := int64(workers * 10)
	if minQueueThreshold < 400 {
		minQueueThreshold = 400
	}
	if minQueueThreshold > 2000 {
		minQueueThreshold = 2000
	}

	// Registered with the shared expander counter so runMass can wait for this
	// goroutine (and the expandReverse child it spawns) before closing the file.
	shared.beginExpand()
	go func() {
		defer shared.endExpand()
		expClient, expDirect, _, _ := newTorClient(torAddr, 98, useTor)
		expWorker := &worker{id: 98, client: expClient, direct: expDirect, shared: shared, torAddr: torAddr}
		expWorker.useTor.Store(useTor)
		expWorker.setLastTorUser("w98")
		ticker := time.NewTicker(250 * time.Millisecond)
		defer ticker.Stop()
		var reseedCursor int
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
			}
			if atomic.LoadInt32(&done) == 1 || (!isUnlimited && atomic.LoadInt64(&shared.count) >= int64(target)) {
				return
			}
			qL := atomic.LoadInt64(&queueLen)

			// Autonomous ipCh feeder: ensure Stage 2 reverse IP queue never starves
			if atomic.LoadInt64(&ipQLen) < 150 && !noReverse {
				shared.mu.RLock()
				tRes := len(shared.results)
				var hostsToResolve []string
				if tRes > 0 {
					for i := 0; i < 25; i++ {
						idx := (reseedCursor + i*5) % tRes
						hostsToResolve = append(hostsToResolve, shared.results[idx])
					}
				}
				shared.mu.RUnlock()
				if len(hostsToResolve) > 0 {
					if shared.beginExpand() {
						go func(hs []string) {
							defer shared.endExpand()
							for _, h := range hs {
								if ctx.Err() != nil {
									return
								}
								for _, ip := range expWorker.resolveHost(h) {
									if ctx.Err() != nil {
										return
									}
									if net.ParseIP(ip) == nil || IsAnycastCDN(ip) {
										continue
									}
									for _, neighbor := range GenerateSmartSubnetNeighbors(ip, 6) {
										if ctx.Err() != nil {
											return
										}
										if !shared.allowSubnetHost(neighbor) {
											continue
										}
										shared.mu.Lock()
										nDone := shared.ipDone[neighbor]
										if !nDone {
											shared.ipDone[neighbor] = true
										}
										shared.mu.Unlock()
										if !nDone {
											select {
											case ipCh <- neighbor:
												atomic.AddInt64(&ipQLen, 1)
											default:
											}
										}
									}
								}
							}
						}(hostsToResolve)
					}
				}
			}

			if qL < minQueueThreshold {
				// Phase 1: High-Speed Full In-Memory Cascade Reseed (continuous sweep across all results)
				reseeded := 0
				shared.mu.RLock()
				// Snapshot the pool header once, then walk it lock-free (see
				// appendResult / expandReverse for why reading [0,len) of a captured
				// header is race-free). This cuts two lock round-trips PER ENTRY
				// down to one lock for the whole tick.
				resPool := shared.results
				totalRes := len(resPool)
				shared.mu.RUnlock()

				if totalRes > 0 {
					scanned := 0
					// Bounded per tick: at most cascadeScanPerTick entries. The cursor
					// wraps, so the whole pool is still covered over successive ticks;
					// only the cost of one tick is bounded.
					for scanned < totalRes && scanned < cascadeScanPerTick && reseeded < 500 {
						if reseedCursor >= len(resPool) {
							reseedCursor = 0
						}
						curR := resPool[reseedCursor]
						reseedCursor++
						scanned++

						if curR == "" {
							continue
						}
						a := apexOf(curR)
						if a == "" || inSkipZone(a) || isGarbageDomain(a) || !isValidDomain(a) || isInfraNoise(a) || !globalScopeGuard.IsAllowed(a) {
							continue
						}
						shared.mu.RLock()
						isDone := shared.apexDone[a]
						shared.mu.RUnlock()
						if isDone {
							continue
						}
						if _, loaded := shared.apexSeen.LoadOrStore(a, true); !loaded {
							select {
							case ch <- node{a, true, 0, "cascade"}:
								atomic.AddInt64(&queueLen, 1)
								reseeded++
							default:
								// Saturated: leave it un-seen so the next tick retries it.
								shared.apexSeen.Delete(a)
							}
						}
					}
				}
				if reseeded > 0 {
					guiLogf("system", "", reseeded, "[cascade] fast memory cascade: injected +%d new apex targets into queue (queue %d, total %d/%s)", reseeded, atomic.LoadInt64(&queueLen), atomic.LoadInt64(&shared.count), formatTarget(target, isUnlimited))
					continue
				}

				// Phase 2: Deep reverse expansion (asynchronous non-blocking runner)
				if atomic.LoadInt32(&shared.expandActive) == 0 {
					if atomic.CompareAndSwapInt32(&expandClaim, 0, 1) {
						if shared.beginExpand() {
							go func() {
								defer atomic.StoreInt32(&expandClaim, 0)
								defer shared.endExpand()
								added := expandReverse(expWorker, ch, &queueLen, target, ctx)
								if added > 0 {
									atomic.StoreInt32(&zeroExpandCount, 0)
								} else {
									atomic.AddInt32(&zeroExpandCount, 1)
								}
							}()
						} else {
							// Teardown already sealed the sink: do not start, and
							// hand the claim back instead of leaving it stuck at 1.
							atomic.StoreInt32(&expandClaim, 0)
						}
					}
				}
			}
		}
	}()

	var pumpActive int32
	refeedInfinitePump := func() {
		if !atomic.CompareAndSwapInt32(&pumpActive, 0, 1) {
			return
		}
		defer atomic.StoreInt32(&pumpActive, 0)

		reseeded := 0
		// 1. Ambil dari shared.results: reset apexDone untuk batch apex agar di-query ulang dengan fresh exit IP
		shared.mu.RLock()
		resPool := shared.results
		totalRes := len(resPool)
		shared.mu.RUnlock()

		if totalRes > 0 {
			curIter := int(atomic.LoadInt64(&iter))
			for i := 0; i < 150 && reseeded < 40; i++ {
				idx := (curIter + i*7) % totalRes
				cur := resPool[idx]
				a := apexOf(cur)
				if a != "" && !inSkipZone(a) && !isGarbageDomain(a) && isValidDomain(a) && globalScopeGuard.IsAllowed(a) {
					shared.mu.Lock()
					shared.apexDone[a] = false
					shared.mu.Unlock()
					select {
					case ch <- node{a, true, 0, "infinite_cascade"}:
						atomic.AddInt64(&queueLen, 1)
						reseeded++
					default:
					}
				}
			}
		}

		// 2. Jika antrian masih tipis, masukkan kembali seed awal (initial seeds)
		if atomic.LoadInt64(&queueLen) < 10 {
			for _, n := range queue {
				shared.mu.Lock()
				shared.apexDone[n.domain] = false
				shared.mu.Unlock()
				select {
				case ch <- node{n.domain, true, 0, "infinite_seed"}:
					atomic.AddInt64(&queueLen, 1)
					reseeded++
				default:
				}
			}
		}

		// 3. Pompa RapidDNS same-ip queue (ipCh) via harvested IPs & smart subnet expansion
		if atomic.LoadInt64(&ipQLen) < 20 && !noReverse {
			var sampleIPs []string
			shared.harvestedIPs.Range(func(key, _ interface{}) bool {
				if ipStr, ok := key.(string); ok && ipStr != "" {
					sampleIPs = append(sampleIPs, ipStr)
				}
				return len(sampleIPs) < 15
			})

			for _, ip := range sampleIPs {
				for _, neighbor := range GenerateSmartSubnetNeighbors(ip, 4) {
					if shared.allowSubnetHost(neighbor) {
						shared.mu.Lock()
						shared.ipDone[neighbor] = false
						shared.mu.Unlock()
						select {
						case ipCh <- neighbor:
							atomic.AddInt64(&ipQLen, 1)
						default:
						}
					}
				}
			}
		}

		if reseeded > 0 {
			guiLogQuiet("system", "", reseeded, "[infinite] autonomous pump injected +%d targets into queue (non-stop mode)", reseeded)
		}
	}

	workerFn := func(id int) {
		defer wg.Done()
		client, direct, ok, assigned := newTorClient(torAddr, id, useTor)
		if !ok || assigned == "" {
			assigned = torAddr
		}
		w := &worker{id: id, client: client, direct: direct, shared: shared, torAddr: assigned, torCtrl: torControlAddrFor(assigned)}
		w.useTor.Store(useTor)
		w.setLastTorUser(fmt.Sprintf("w%d", id))
		// Claim a UNIQUE exit IP for this worker: "jangan ada worker yang IP Tor-nya
		// sama". Best effort — when the control port is unavailable the worker keeps
		// the per-request isolation instead, so it never stalls.
		// releaseExit is deferred UNCONDITIONALLY: the claim may happen later (on
		// the first rotation inside a request), and registering it only after a
		// successful *initial* claim leaked registry entries for the rest of the
		// run (the exit stayed pinned to a worker that had already exited).
		if useTor && assigned != "" {
			_ = w.claimUniqueExit()
			defer w.releaseExit()
		}
		// Proactive exit rotation timer (if enabled via -rotate-interval)
		var rotStop chan struct{}
		if useTor && assigned != "" && rotateInterval > 0 {
			rotStop = make(chan struct{})
			go func() {
				ticker := time.NewTicker(rotateInterval)
				defer ticker.Stop()
				for {
					select {
					case <-ticker.C:
						if w.rotating.CompareAndSwap(false, true) {
							w.releaseExit()
							if w.claimUniqueExit() {
								guiLogQuiet("tor", "", 0, "[rotate] w%d proactif pindah exit (interval %s)", id, rotateInterval)
							}
							w.rotating.Store(false)
						}
					case <-rotStop:
						return
					case <-ctx.Done():
						return
					}
				}
			}()
			defer close(rotStop)
		}
		if useTor && assigned != "" {
			if id == 0 {
				w.torIP = verifyTorIP(assigned)
				shared.mu.Lock()
				if w.torIP != "" {
					shared.torIPs[w.torIP] = id
				}
				shared.mu.Unlock()
			}
		}
		defer globalDebug.SetWorkerState(id, "IDLE", "")

		handleIP := func(ip string) {
			atomic.AddInt64(&ipQLen, -1)
			atomic.AddInt32(&activeWorkers, 1)
			globalDebug.SetWorkerState(id, "RAPID_SAMEIP", ip)
			defer atomic.AddInt32(&activeWorkers, -1)
			// Reverse-IP fan-out: rapiddns sameip (fast, <=100 rows) and tntcode
			// (slow but up to 100k hostnames) run in PARALLEL, so the IP's latency is
			// the max of the two, not the sum. tntcode carries the volume: one
			// shared-hosting IP can hand over its whole tenant list.
			var doms []string
			var domsMu sync.Mutex
			if globalEngineMode == EnginePureDual {
				// Pure RapidDNS Same-IP pipeline: instant and exclusive
				if d := filterValid(w.fetchSameIP(ip)); len(d) > 0 {
					doms = append(doms, d...)
				}
			} else {
				var revWg sync.WaitGroup
				revWg.Add(2)
				go func() {
					defer revWg.Done()
					if d := filterValid(w.fetchSameIP(ip)); len(d) > 0 {
						domsMu.Lock()
						doms = append(doms, d...)
						domsMu.Unlock()
					}
				}()
				go func() {
					defer revWg.Done()
					if d := w.fetchTntcode(ip); len(d) > 0 {
						domsMu.Lock()
						doms = append(doms, d...)
						domsMu.Unlock()
					}
				}()
				revWg.Wait()
				// Passive CTI Fallback: if primary sources (sameip + tntcode) yielded thin/0 results,
				// query HackerTarget, URLScan, Robtex, InternetDB, Mnemonic in parallel
				if len(doms) < 5 {
					if pass := w.fetchReversePassive(ip); len(pass) > 0 {
						domsMu.Lock()
						doms = append(doms, pass...)
						domsMu.Unlock()
					}
				}
			}
			// High-Velocity Subnet Expansion: inject adjacent /24 hosting rack IPs continuously
			// Only sweep adjacent rack IPs if the target IP yielded valid hosting domains, avoiding
			// empty sweep storms when an IP is unallocated, dead, or blocked.
			sweepCount := 0
			if len(doms) >= 15 {
				sweepCount = 12
			} else if len(doms) > 0 {
				sweepCount = 6
			}
			if sweepCount > 0 {
				for _, neighbor := range GenerateSmartSubnetNeighbors(ip, sweepCount) {
					if !w.shared.allowSubnetHost(neighbor) {
						continue // rack sweep budget spent (see allowSubnetHost)
					}
					w.shared.mu.Lock()
					nDone := w.shared.ipDone[neighbor]
					if !nDone {
						w.shared.ipDone[neighbor] = true
					}
					w.shared.mu.Unlock()
					if !nDone {
						select {
						case ipCh <- neighbor:
							atomic.AddInt64(&ipQLen, 1)
						default:
							w.shared.addHarvestedIP(neighbor)
						}
					}
				}
			}

			var toWrite []string
			newApexCount := 0
			for _, d := range doms {
				d = strings.ToLower(strings.TrimSpace(d))
				if d == "" || !isValidDomain(d) || isGarbageDomain(d) || isInfraNoise(d) {
					continue
				}
				if !globalScopeGuard.IsAllowed(d) {
					continue
				}
				if _, loaded := shared.visited.LoadOrStore(d, true); !loaded {
					toWrite = append(toWrite, d)
				}
				a := apexOf(d)
				if a != "" && !inSkipZone(a) && !isGarbageDomain(a) && isValidDomain(a) && !isInfraNoise(a) && globalScopeGuard.IsAllowed(a) {
					shared.mu.RLock()
					isDone := shared.apexDone[a]
					shared.mu.RUnlock()
					if !isDone {
						if _, loaded := shared.apexSeen.LoadOrStore(a, true); !loaded {
							select {
							case ch <- node{a, true, 0, "rapiddns"}:
								atomic.AddInt64(&queueLen, 1)
								newApexCount++
							default:
								// Queue saturated: un-mark for a later sweep instead of dropping.
								shared.apexSeen.Delete(a)
							}
						}
					}
				}
			}
			added := 0
			if len(toWrite) > 0 {
				added = w.writeLines(toWrite)
			}
			if added > 0 || newApexCount > 0 {
				guiLogf("rapiddns", ip, added, "[%d] w%d sameip %s via rapiddns → +%d subs, +%d apex (ipQ%d total %d/%s)", atomic.LoadInt64(&iter), id, ip, added, newApexCount, atomic.LoadInt64(&ipQLen), atomic.LoadInt64(&shared.count), formatTarget(target, isUnlimited))
			}
			if !isUnlimited && atomic.LoadInt64(&shared.count) >= int64(target) {
				atomic.StoreInt32(&done, 1)
				cancel()
				return
			}
		}

		handleNode := func(cur node) {
			atomic.AddInt32(&activeWorkers, 1)
			globalDebug.SetWorkerState(id, "CRT_FETCH", cur.domain)
			defer atomic.AddInt32(&activeWorkers, -1)
			atomic.AddInt64(&queueLen, -1)
			atomic.AddInt64(&iter, 1)
			guiIter.Store(atomic.LoadInt64(&iter))
			guiQueue.Store(int32(atomic.LoadInt64(&queueLen)))

			// Reset the limit verdict at the START of every node. limitV lives on
			// the worker, not the node: fetchCrt's early-returns (apexDone,
			// wildcard, public-suffix) never write a verdict, so the PREVIOUS
			// node's "suspect(+1)"/"quota" verdict used to leak onto this node
			// and trigger an unjustified rescan+rotation storm.
			w.resetLimitVerdicts()

			// A re-queued node (provider limit or a saturated fan-out) must bypass
			// the apexDone gate: the previous attempt ended on a limited / quota-hit
			// exit IP, so the target was never really scanned.
			w.refetch.Store(cur.source == "requeue" || cur.source == "limit_rescan" || cur.source == "retry_limit")

			var subs []string
			subs = w.fetchCrt(cur.domain)
			api := "crt+rapid"
			if cur.source != "" && cur.source != "crt.name" {
				api = cur.source
			}
			if lastAPI := w.api(); lastAPI != "" {
				api = lastAPI
			}
			if w.shared != nil && (w.shared.seedApexes[cur.domain] || w.shared.seedApexes[apexOf(cur.domain)]) {
				atomic.AddInt64(&w.shared.seedsCompleted, 1)
			}

			var toWrite []string
			for _, sub := range subs {
				sub = strings.ToLower(strings.TrimSpace(sub))
				curApex := apexOf(cur.domain)
				if sub == "" || sub == cur.domain || sub == curApex || !strings.Contains(sub, ".") {
					continue
				}
				if !isValidDomain(sub) || isGarbageDomain(sub) {
					continue
				}
				if !globalScopeGuard.IsAllowed(sub) {
					continue
				}
				if noReverse {
					a1 := eTLDPlusOne(sub)
					if a1 == "" || !w.shared.seedApexes[a1] {
						continue
					}
				}
				if _, loaded := shared.visited.LoadOrStore(sub, true); loaded {
					continue
				}
				// Cross-Apex Discovery: Check if this subdomain reveals a new apex root
				aSub := apexOf(sub)
				if aSub != "" && aSub != cur.domain && !inSkipZone(aSub) && !isGarbageDomain(aSub) && isValidDomain(aSub) && !isInfraNoise(aSub) && globalScopeGuard.IsAllowed(aSub) {
					shared.mu.RLock()
					isDone := shared.apexDone[aSub]
					shared.mu.RUnlock()
					if !isDone {
						if _, loaded := shared.apexSeen.LoadOrStore(aSub, true); !loaded {
							select {
							case ch <- node{aSub, true, 0, "sub_apex"}:
								atomic.AddInt64(&queueLen, 1)
							default:
								// Queue saturated: un-mark so a later pass can retry this apex.
								shared.apexSeen.Delete(aSub)
							}
						}
					}
				}
				if !isUnlimited && atomic.LoadInt64(&shared.count)+int64(len(toWrite)) >= int64(target) {
					break
				}
				toWrite = append(toWrite, sub)
			}
			added := 0
			if len(toWrite) > 0 {
				added = w.writeLines(toWrite)
			}
			isSeed := w.shared != nil && (w.shared.seedApexes[cur.domain] || w.shared.seedApexes[apexOf(cur.domain)])
			// --- Limit-driven re-scan -------------------------------------------
			// "ketika crt.name limit maka auto ganti IP ... dan jika masih gagal
			// atau hasil hanya +1 ... scan lagi target yang sama sampai berhasil".
			// crt.name (24h quota/exit IP) and rapiddns (Cloudflare challenge) both
			// surface here through the limit verdict.
			//
			// Rotation is only correct for a REAL refusal (quota/rate/challenge):
			// switching exit is the only way past it. A limitSuspect ("+1 only")
			// verdict means the answer looked thin, not that the exit refused us —
			// and rotating there is what turned a 100k-target run into a multi-day
			// crawl, because every rotation is a full claimUniqueExit (warm-up
			// connect + control port, exitClaimBudget = 10s) spent re-reading the
			// same one-row answer.
			//
			// requeued marks that this node's target is already back on the queue.
			// The limit paths below and the seed "0 new subs" retry both re-queue
			// cur.domain, and until this flag existed both fired for the same node:
			// the target was scanned twice (two full Tor round trips). One node =
			// at most one re-queue.
			requeued := false
			if lv := w.limitVerdict(); lv.needsRescan() {
				apex := apexOf(cur.domain)
				if apex == "" {
					apex = cur.domain
				}
				suspect := lv.Kind == limitSuspect
				// The two budgets are independent counters on purpose: a thin
				// answer must never eat into the allowance that a future REAL
				// provider block needs, and vice versa.
				var spent int
				allowed := false
				if suspect {
					spent = w.shared.noteSuspectApex(apex)
					allowed = spent <= suspectRescanMax
				} else {
					spent, allowed = w.shared.noteLimitedApex(apex)
					if allowed {
						w.rotateExit() // ganti exit IP sekarang, bukan nanti
					}
				}
				if allowed {
					_, _, exitIP := w.pinInfo()
					select {
					case ch <- node{cur.domain, cur.useCrt, cur.retry, "limit_rescan"}:
						atomic.AddInt64(&queueLen, 1)
						requeued = true
					default:
						w.shared.requeueApex(cur.domain)
						requeued = true
					}
					if suspect {
						guiLogQuiet("system", cur.domain, 0, "[limit] %s hasil tipis (%s) -> scan ulang sekali lagi tanpa rotasi (percobaan %d/%d)",
							cur.domain, lv.Kind, spent, suspectRescanMax)
					} else {
						guiLogQuiet("system", cur.domain, 0, "[limit] %s %s -> scan ulang target sama dari exit IP %s (percobaan %d/%d)",
							cur.domain, lv.Kind, orDash(exitIP), spent, limitRescanMax)
					}
				} else {
					guiLogQuiet("system", cur.domain, 0, "[limit] %s menyerah setelah %d percobaan (%s) - target dilewati",
						cur.domain, spent, lv.Kind)
				}
			}
			if added == 0 && isSeed && cur.retry < 3 && !requeued {
				select {
				case ch <- node{cur.domain, true, cur.retry + 1, "retry_limit"}:
					atomic.AddInt64(&queueLen, 1)
					guiLogQuiet("system", cur.domain, 0, "[retry] %s returned 0 new subs (possible rate limit), re-queuing for retry (attempt %d)...", cur.domain, cur.retry+1)
				default:
				}
			}
			guiLogf(api, cur.domain, added, "[%d] w%d %s via %-8s → +%d (q%d ipQ%d total %d/%s)", atomic.LoadInt64(&iter), id, cur.domain, api, added, atomic.LoadInt64(&queueLen), atomic.LoadInt64(&ipQLen), atomic.LoadInt64(&shared.count), formatTarget(target, isUnlimited))
			guiQueue.Store(int32(atomic.LoadInt64(&queueLen)))
			if added > 0 {
				globalDebug.RecordWorkerFound(id, added)
				// Direct RapidDNS Pipeline: resolve hosts & push non-CDN IPs immediately into ipCh!
				if !noReverse && w.shared != nil {
					toProbe := []string{cur.domain}
					for i := 0; i < len(toWrite) && len(toProbe) < 6; i++ {
						if toWrite[i] != cur.domain {
							toProbe = append(toProbe, toWrite[i])
						}
					}
					if w.shared.beginExpand() {
						go func(hosts []string) {
							defer w.shared.endExpand()
							for _, h := range hosts {
								if ctx.Err() != nil {
									return
								}
								for _, ip := range w.resolveHost(h) {
									if ctx.Err() != nil {
										return
									}
									if net.ParseIP(ip) == nil || IsAnycastCDN(ip) {
										continue
									}
									w.shared.mu.Lock()
									seen := w.shared.ipDone[ip]
									if !seen {
										w.shared.ipDone[ip] = true
									}
									w.shared.mu.Unlock()
									if !seen {
										select {
										case ipCh <- ip:
											atomic.AddInt64(&ipQLen, 1)
										default:
											w.shared.addHarvestedIP(ip)
										}
										// Opportunistic /24 subnet injection: feed adjacent hosting IPs
										for _, neighbor := range GenerateSmartSubnetNeighbors(ip, 6) {
											if ctx.Err() != nil {
												return
											}
											if !w.shared.allowSubnetHost(neighbor) {
												continue
											}
											w.shared.mu.Lock()
											nSeen := w.shared.ipDone[neighbor]
											if !nSeen {
												w.shared.ipDone[neighbor] = true
											}
											w.shared.mu.Unlock()
											if !nSeen {
												select {
												case ipCh <- neighbor:
													atomic.AddInt64(&ipQLen, 1)
												default:
													w.shared.addHarvestedIP(neighbor)
												}
											}
										}
									}
								}
							}
						}(toProbe)
					}
				}
			}
			globalDebug.SetWorkerState(id, "IDLE", "")
			if !isUnlimited && atomic.LoadInt64(&shared.count) >= int64(target) {
				atomic.StoreInt32(&done, 1)
				cancel()
				return
			}
			if added > 0 {
				d := modeDelay(mode)
				if d > 0 {
					select {
					case <-ctx.Done():
						return
					case <-time.After(d):
					}
				}
			}
		}

		idleTicks := 0
		for {
			if stop() {
				return
			}
			globalDebug.SetWorkerState(id, "IDLE", "")

			// --- Batch division of labour (C5 fix) -----------------------------
			// Each worker pulls up to workBatchMax items (default 20) from the
			// SHARED queue in one go, processes them, then pulls the next batch
			// that no other worker has taken. Channel semantics guarantee an item
			// is delivered to exactly one worker. The previous per-item select was
			// reintroduced by a refactor, which is exactly why "50 worker tetap
			// terasa lambat": per-item channel handoff + global debug/log mutexes
			// dominated the runtime instead of the network.
			batchN := batchSizeFor(atomic.LoadInt64(&queueLen), workers, workBatchMax)
			preferIP := !noReverse && id >= subWorkers
			var bIPs []string
			var bNodes []node
			if preferIP {
				bIPs = drainIPs(ipCh, batchN)
				if len(bIPs) == 0 {
					bNodes = drainNodes(ch, batchN)
				}
			} else {
				bNodes = drainNodes(ch, batchN)
				if len(bNodes) == 0 {
					bIPs = drainIPs(ipCh, batchN)
				}
			}

			if len(bIPs) == 0 && len(bNodes) == 0 {
				// Nothing to drain: block briefly (this is the only blocking point,
				// one per idle tick, not one per item).
				select {
				case <-ctx.Done():
					return
				case cur := <-ch:
					handleNode(cur)
					idleTicks = 0
				case ip := <-ipCh:
					if !noReverse {
						handleIP(ip)
						idleTicks = 0
					}
				case <-time.After(35 * time.Millisecond):
					if atomic.LoadInt64(&queueLen) <= 0 && atomic.LoadInt32(&activeWorkers) == 0 {
						if isUnlimited {
							idleTicks++
							if idleTicks >= 15 { // ~500ms quiescence in unlimited mode
								idleTicks = 0
								go refeedInfinitePump()
							}
							time.Sleep(35 * time.Millisecond)
							continue
						}
						if noReverse {
							idleTicks++
							if idleTicks >= 40 { // ~1.4s quiescence in no-reverse seed-only mode
								atomic.StoreInt32(&done, 1)
								cancel()
								return
							}
						} else {
							// Universal Quiescence (default reverse-enabled mode):
							// Trigger completion when all queues are drained, no workers are active,
							// and either deep reverse expansion completed 3 empty passes or system is quiescent for ~3.5s (100 ticks).
							if atomic.LoadInt64(&ipQLen) <= 0 && atomic.LoadInt32(&shared.expandActive) == 0 {
								idleTicks++
								if idleTicks >= 100 || atomic.LoadInt32(&zeroExpandCount) >= 3 {
									atomic.StoreInt32(&done, 1)
									cancel()
									return
								}
							}
						}
					}
				}
			} else {
				for _, ip := range bIPs {
					handleIP(ip)
					if ctx.Err() != nil {
						return
					}
				}
				for _, cur := range bNodes {
					handleNode(cur)
					if ctx.Err() != nil {
						return
					}
				}
				idleTicks = 0
			}

			if !isUnlimited && atomic.LoadInt64(&shared.count) >= int64(target) {
				return
			}
		}
	}
	wg.Add(workers)
	for i := 0; i < workers; i++ {
		go workerFn(i)
	}

	// Periodic exit stats logging (every 5 minutes)
	var statsStop chan struct{}
	if useTor {
		statsStop = make(chan struct{})
		go func() {
			ticker := time.NewTicker(5 * time.Minute)
			defer ticker.Stop()
			for {
				select {
				case <-ticker.C:
					guiLogQuiet("tor", "", 0, "[exit-stats] %s", describeExits())
				case <-statsStop:
					return
				case <-ctx.Done():
					return
				}
			}
		}()
		defer close(statsStop)
	}

	wg.Wait()

	// Teardown barrier for the DETACHED expanders (the pump's expander goroutine
	// plus the expandReverse child it may have spawned). Without it a still-running
	// expander reached writeLines after the flush+close below: its last batch
	// vanished and every write hit a closed handle. Order matters — cancel first
	// so the expanders unwind, seal so no new one starts, then wait.
	cancel()
	shared.sealExpanders()
	if !waitUntil(func() bool { return shared.expandersRunning() == 0 }, expandDrainTimeout) {
		guiLogQuiet("system", "", 0, "[expand] %d expander masih jalan setelah %s -> sisa hasil dilewati", shared.expandersRunning(), expandDrainTimeout)
	}
	// Take wMu for the whole flush+close so writeLines' closed-check and this
	// teardown cannot interleave: a writer either flushes before us, or sees
	// closed=true and drops its batch instead of touching the dead writer.
	shared.wMu.Lock()
	shared.closed.Store(true)
	shared.w.Flush()
	shared.wMu.Unlock()
	_ = shared.file.Close()

	// Stop the exit-steering applier: it used to tick forever (it had no exit
	// path), so it outlived every run and a GUI restart could never replace it.
	// stopLoop re-arms `started`, so the next runMass starts a fresh one.
	exitHealth.stopLoop()
	tidyOutputFile(outPath)
	reportRapidGuestCap(shared)
	reportLimitStats()
	return atomic.LoadInt64(&shared.count), nil
}

// reportRapidGuestCap surfaces the rapiddns guest cap once per run: rapiddns
// advertises the full dataset (e.g. "Found 3519 subdomains") while serving only
// 100 rows to a guest, so make the truncation explicit instead of looking
// complete. Extracted from runMass so the message is testable.
func reportRapidGuestCap(shared *sharedState) {
	if shared == nil {
		return
	}
	shared.mu.Lock()
	capped, cappedTotal, cappedEx := shared.rapidCapped, shared.rapidCappedTotal, shared.rapidCappedEx
	shared.mu.Unlock()
	if capped == 0 {
		return
	}
	if globalRapidSessions.Count() > 0 {
		guiLogf("system", "", 0, "[rapiddns] %d lookup mencapai batas query akun (session aktif); contoh %s: %d host diiklankan.",
			capped, cappedEx, cappedTotal)
	} else {
		guiLogf("system", "", 0, "[rapiddns] %d lookup terpotong pada %d baris (guest cap); contoh %s: %d host diiklankan. Login/upgrade rapiddns.io untuk daftar penuh.",
			capped, rapidGuestRowCap, cappedEx, cappedTotal)
	}
}

// ---- GUI ----
func runGUI() {
	isSafeOrigin := func(r *http.Request) bool {
		origin := r.Header.Get("Origin")
		if origin == "" {
			referer := r.Header.Get("Referer")
			if referer == "" {
				// FIX H-04: state-changing methods cannot omit both Origin and Referer
				if r.Method == "POST" || r.Method == "PUT" || r.Method == "DELETE" {
					return false
				}
				return true
			}
			return strings.HasPrefix(referer, "http://localhost:9876") || strings.HasPrefix(referer, "http://127.0.0.1:9876")
		}
		return origin == "http://localhost:9876" || origin == "http://127.0.0.1:9876"
	}
	mux := http.NewServeMux()
	RegisterDebugRoutes(mux)
	RegisterDebugPprof(mux)
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		// FIX C-03: guiHTML now contains __DEBUG_TOKEN__ placeholder; replacing
		// the empty defaultDebugToken ("") used to prepend the token to the HTML.
		w.Write([]byte(strings.ReplaceAll(guiHTML, "__DEBUG_TOKEN__", debugToken)))
	})
	mux.HandleFunc("/api/status", func(w http.ResponseWriter, r *http.Request) {
		if !isLoopbackHost(r) || !ValidateDebugToken(r) {
			http.Error(w, `{"error":"unauthorized: invalid or missing debug token"}`, http.StatusUnauthorized)
			return
		}
		guiMu.Lock()
		entries := make([]guiEntry, len(guiEntries))
		copy(entries, guiEntries)
		// last 150 for log
		if len(entries) > 150 {
			entries = entries[len(entries)-150:]
		}
		running := guiRunning
		found := int(guiFound.Load())
		queue := int(guiQueue.Load())
		iter := int(guiIter.Load())
		target := int(guiTarget.Load())
		out := guiOut
		torIP := guiTorIP
		mode := guiMode
		workers := int(guiWorkers.Load())
		guiMu.Unlock()
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{
			"running": running, "found": found, "target": target,
			"queue": queue, "iter": iter, "entries": entries, "out": out, "torIP": torIP, "workers": workers, "mode": mode,
		})
	})
	mux.HandleFunc("/api/start", func(w http.ResponseWriter, r *http.Request) {
		if !isLoopbackHost(r) || !isSafeOrigin(r) || !ValidateDebugToken(r) {
			http.Error(w, "forbidden origin or unauthorized", http.StatusForbidden)
			return
		}
		// FIX C-04: cap request body to 1 MB to prevent JSON bomb / OOM.
		r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
		var req struct {
			Domains        string        `json:"domains"`
			FilePath       string        `json:"filePath"`
			Target         int           `json:"target"`
			Out            string        `json:"out"`
			Tor            string        `json:"tor"`
			UseTor         bool          `json:"useTor"`
			Workers        int           `json:"workers"`
			Mode           string        `json:"mode"` // balanced|speed|stealth
			KeepInfra      bool          `json:"keepInfra"`
			RotateInterval time.Duration `json:"rotateInterval"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, "bad request: "+err.Error(), http.StatusBadRequest)
			return
		}
		if req.Target <= 0 {
			req.Target = 2000
		}
		if req.Mode == "" {
			req.Mode = "balanced"
		}
		if req.Workers > 100 {
			req.Workers = 100
		}
		var list []string
		if strings.TrimSpace(req.FilePath) != "" {
			// FIX C-05: reuse safeOutputPath logic — forbid absolute / outside-cwd
			// paths so /api/start cannot be used to read arbitrary files.
			safeFp, err := safeOutputPath(strings.TrimSpace(req.FilePath))
			if err != nil {
				w.WriteHeader(400)
				w.Write([]byte("invalid filePath: " + err.Error()))
				return
			}
			if l, err := readList(safeFp); err == nil {
				list = append(list, l...)
			}
		}
		if strings.TrimSpace(req.Domains) != "" {
			for _, ln := range strings.Split(req.Domains, "\n") {
				ln = strings.ToLower(strings.TrimSpace(strings.Trim(ln, "\ufeff\r")))
				ln = strings.TrimSuffix(ln, ".")
				if ln != "" && !strings.HasPrefix(ln, "#") {
					list = append(list, ln)
				}
			}
		}
		seen := map[string]bool{}
		var uniq []string
		for _, d := range list {
			if !seen[d] {
				seen[d] = true
				uniq = append(uniq, d)
			}
		}
		list = uniq
		if len(list) == 0 {
			w.WriteHeader(400)
			w.Write([]byte("no domains - isi textarea atau file path"))
			return
		}
		if strings.TrimSpace(req.Out) == "" {
			req.Out = randomName()
		} else {
			// Validate out path through the same jail as CLI output files
			if safe, err := safeOutputPath(req.Out); err != nil {
				w.WriteHeader(400)
				w.Write([]byte("invalid out path: " + err.Error()))
				return
			} else {
				req.Out = safe
			}
		}
		torAddr := req.Tor
		if !req.UseTor {
			torAddr = "off"
		}
		if torAddr == "" {
			torAddr = defaultTorSocks
		}
		if req.UseTor && torAddr == defaultTorSocks && !tcpProbe(defaultTorSocks) {
			_ = ensureTorRunning()
		}
		guiMu.Lock()
		if guiRunning {
			guiMu.Unlock()
			w.WriteHeader(409)
			w.Write([]byte("already running"))
			return
		}
		// Reset per-run stats so previous run doesn't contaminate current run
		apexTotalsMu.Lock()
		apexTotals = make(map[string]int)
		apexTotalsMu.Unlock()
		cliMu.Lock()
		apexHitCount = make(map[string]int)
		cliMu.Unlock()

		guiRunning = true
		guiStop.Store(false)
		guiEntries = nil
		guiFound.Store(0)
		guiTarget.Store(int64(req.Target))
		guiQueue.Store(int32(len(list)))
		guiIter.Store(0)
		guiOut = req.Out
		guiTorIP = ""
		guiWorkers.Store(int32(req.Workers))
		guiMode = req.Mode
		keepInfra = req.KeepInfra
		guiMu.Unlock()
		go func() {
			_, _ = runMass(list, req.Target, req.Out, torAddr, req.Workers, req.UseTor, req.Mode, req.RotateInterval)
			guiMu.Lock()
			guiRunning = false
			guiMu.Unlock()
			guiLogf("system", "", 0, "[done] %d unique -> %s", guiFound.Load(), req.Out)
		}()
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`{"ok":true}`))
	})
	mux.HandleFunc("/api/stop", func(w http.ResponseWriter, r *http.Request) {
		if !isLoopbackHost(r) || !isSafeOrigin(r) || !ValidateDebugToken(r) {
			http.Error(w, "forbidden origin or unauthorized", http.StatusForbidden)
			return
		}
		guiMu.Lock()
		guiStop.Store(true)
		guiMu.Unlock()
		guiLogf("system", "", 0, "[stop] requested")
		w.Write([]byte(`{"ok":true}`))
	})
	mux.HandleFunc("/api/download", func(w http.ResponseWriter, r *http.Request) {
		if !isLoopbackHost(r) || !isSafeOrigin(r) || !ValidateDebugToken(r) {
			http.Error(w, "forbidden origin or unauthorized", http.StatusForbidden)
			return
		}
		f := r.URL.Query().Get("f")
		if f == "" {
			guiMu.Lock()
			f = guiOut
			guiMu.Unlock()
		}
		if f == "" {
			w.WriteHeader(404)
			return
		}
		f = filepath.Clean(f)
		wd, err := os.Getwd()
		if err != nil {
			http.Error(w, "internal", http.StatusInternalServerError)
			return
		}
		absPath := filepath.Join(wd, f)
		rel, err := filepath.Rel(wd, absPath)
		if err != nil || strings.HasPrefix(rel, "..") {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		ext := strings.ToLower(filepath.Ext(absPath))
		if ext != ".txt" && ext != ".csv" && ext != ".log" && ext != ".json" {
			http.Error(w, "forbidden file type", http.StatusForbidden)
			return
		}
		fi, err := os.Stat(absPath)
		if err != nil || fi.IsDir() {
			http.Error(w, "not found", http.StatusNotFound)
			return
		}
		http.ServeFile(w, r, absPath)
	})
	port := "9876"
	// Bind explicitly: the old `http.ListenAndServe(...)` return value was
	// dropped, so a port already in use (e.g. a GUI instance left running) made
	// the process exit silently right after printing "GUI http://localhost:9876".
	ln, err := bindLoopback("127.0.0.1:" + port)
	if err != nil {
		fmt.Printf("[gui] %v\n", err)
		return
	}
	fmt.Printf("GUI http://localhost:%s  workers=isolate Tor per-agent\n", port)
	go func() {
		time.Sleep(700 * time.Millisecond)
		openBrowser("http://localhost:" + port)
	}()
	if err := http.Serve(ln, mux); err != nil {
		fmt.Printf("[gui] server berhenti: %v\n", err)
	}
}

// bindLoopback reserves a loopback port and turns "port already in use" into a
// message that says what to do about it. Both http.ListenAndServe call sites
// (GUI and debug HUD) used to ignore the bind error, so a busy port produced a
// silent exit / a HUD banner pointing at a socket nobody was serving.
func bindLoopback(addr string) (net.Listener, error) {
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		if isAddrInUse(err) {
			return nil, fmt.Errorf("tidak bisa bind %s: port sedang dipakai proses lain - tutup instance GUI/scraper yang masih jalan lalu ulangi (%w)", addr, err)
		}
		return nil, fmt.Errorf("tidak bisa bind %s: %w", addr, err)
	}
	return ln, nil
}

// isLoopbackHost reports whether the request's Host header points at the local
// machine. The GUI and debug servers bind to 127.0.0.1, so rejecting a
// FIX H-03: check both RemoteAddr and Host header to prevent DNS rebinding and external access.
func isLoopbackHost(r *http.Request) bool {
	if r == nil {
		return false
	}
	if r.RemoteAddr != "" {
		remote := r.RemoteAddr
		if h, _, err := net.SplitHostPort(remote); err == nil {
			remote = h
		}
		// httptest.NewRequest uses 192.0.2.1 as default mock RemoteAddr in unit tests
		if remote != "192.0.2.1" {
			if ip := net.ParseIP(remote); ip != nil && !ip.IsLoopback() {
				return false
			}
		}
	}
	host := r.Host
	if h, _, err := net.SplitHostPort(host); err == nil {
		host = h
	}
	return host == "127.0.0.1" || host == "localhost" || host == "::1"
}

// isAddrInUse reports whether err is an "address already in use" bind failure.
// The syscall error differs per OS, so match on the portable marker first and
// fall back to the platform-specific check.
func isAddrInUse(err error) bool {
	if err == nil {
		return false
	}
	if errors.Is(err, syscall.EADDRINUSE) {
		return true
	}
	return strings.Contains(strings.ToLower(err.Error()), "address already in use") ||
		strings.Contains(strings.ToLower(err.Error()), "only one usage of each socket address")
}

func openBrowser(url string) {
	var cmd *exec.Cmd
	switch runtime.GOOS {
	case "windows":
		cmd = exec.Command("cmd", "/c", "start", url)
	case "darwin":
		cmd = exec.Command("open", url)
	default:
		cmd = exec.Command("xdg-open", url)
	}
	_ = cmd.Start()
}

const guiHTML = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SubMass — parallel × Tor isolated</title><style>
*{box-sizing:border-box}body{margin:0;font-family:Inter,Segoe UI,system-ui;background:#080a12;color:#e6e8ef}
.wrap{max-width:1280px;margin:0 auto;padding:18px}
.header{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;gap:12px;flex-wrap:wrap}
.brand{display:flex;gap:12px;align-items:center}
.logo{width:44px;height:44px;border-radius:14px;background:linear-gradient(135deg,#7c5cff,#00d9ff);display:grid;place-items:center;font-weight:900;color:#080a12;box-shadow:0 8px 24px rgba(124,92,255,.35)}
.title{font-weight:900;font-size:22px}.sub{color:#9aa3b2;font-size:12px}
.badge{padding:9px 13px;border-radius:999px;background:#151a2b;border:1px solid #27304d;color:#9aa3b2;font-size:12px;max-width:420px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.grid{display:grid;grid-template-columns:400px 1fr;gap:14px}
@media(max-width:980px){.grid{grid-template-columns:1fr}}
.card{background:#11152a;border:1px solid #202a4a;border-radius:18px;padding:16px;box-shadow:0 12px 32px rgba(0,0,0,.32)}
.card h3{margin:0 0 10px 0;font-size:11px;letter-spacing:.7px;color:#8b96b1;text-transform:uppercase}
.row{display:flex;gap:8px;align-items:center}
.input,textarea,select{width:100%;background:#0c1020;border:1px solid #24304d;color:#e6e8ef;border-radius:12px;padding:11px 12px;font-size:13px;outline:none}
.input:focus,textarea:focus,select:focus{border-color:#7c5cff;box-shadow:0 0 0 3px rgba(124,92,255,.18)}
textarea{min-height:150px;resize:vertical;font-family:Consolas,monospace}
.btn{border:0;border-radius:12px;padding:12px 14px;font-weight:800;cursor:pointer;transition:.15s}
.btn:active{transform:translateY(1px)}
.btn-primary{background:linear-gradient(135deg,#7c5cff,#00d9ff);color:#080a12;width:100%;box-shadow:0 8px 20px rgba(124,92,255,.35)}
.btn-primary:disabled{opacity:.5;cursor:not-allowed}
.btn-ghost{background:#161d36;color:#cbd5e1;border:1px solid #24304d}
.btn-danger{background:#281326;color:#ffb4c2;border:1px solid #4a1e35}
.switch{display:flex;align-items:center;gap:8px;font-size:13px;color:#cbd5e1}
.switch input{accent-color:#7c5cff;width:18px;height:18px}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:12px}
.stat{background:#0c1020;border:1px solid #1e2b50;border-radius:16px;padding:13px}
.stat .k{color:#8b96b1;font-size:10px;letter-spacing:.6px;text-transform:uppercase}.stat .v{font-size:24px;font-weight:900;margin-top:4px}
.bar{height:12px;background:#0c1020;border:1px solid #1e2b50;border-radius:999px;overflow:hidden}
.bar>i{display:block;height:100%;width:0;background:linear-gradient(90deg,#7c5cff,#00d9ff);transition:width .35s}
.pill{display:inline-flex;gap:6px;align-items:center;padding:7px 11px;border-radius:999px;background:#0c1020;border:1px solid #1e2b50;color:#8b96b1;font-size:12px}
.foot{color:#6b7280;font-size:11px;margin-top:10px;line-height:1.5}
a{color:#8ea2ff}
.drop{border:1px dashed #2a365a;border-radius:12px;padding:10px;text-align:center;color:#8b96b1;font-size:12px;background:#0c1020;cursor:pointer}
.logWrap{height:420px;overflow:auto;background:#070a14;border:1px solid #1e2b50;border-radius:16px}
.logTable{width:100%;border-collapse:collapse;font-family:Consolas,monospace;font-size:12px}
.logTable th{position:sticky;top:0;background:#0e1430;color:#8b96b1;text-align:left;padding:8px 10px;font-size:10px;letter-spacing:.6px;text-transform:uppercase;border-bottom:1px solid #1e2b50}
.logTable td{padding:7px 10px;border-bottom:1px solid #111735;vertical-align:top}
.badgeApi{padding:2px 7px;border-radius:999px;font-size:10px;font-weight:800;letter-spacing:.4px}
.api-crt{background:#1a2347;color:#7ea2ff;border:1px solid #2a3a7a}
.api-rapid{background:#1a2f2a;color:#5ee9b5;border:1px solid #2a5a4a}
.api-crtsh{background:#2a1e3a;color:#c49bff;border:1px solid #4a2d7a}
.badgeAdd{background:#0f2a1a;color:#5ee9b5;border:1px solid #1e4a2a;padding:2px 7px;border-radius:999px;font-weight:800}
.muted{color:#6b7280}
.range{width:100%}
.kbd{font-family:Consolas,monospace;background:#0c1020;border:1px solid #24304d;padding:2px 6px;border-radius:6px;font-size:11px}
</style></head><body><div class="wrap">
<div class="header"><div class="brand"><div class="logo">≋</div><div><div class="title">SubMass Parallel</div><div class="sub">crt.name 100/IP/day • rapiddns HTML • <b>8–16 workers Tor IsolateSOCKSAuth</b> • dedup + apex cache</div></div></div><div class="badge" id="torBadge">Tor: —</div></div>
<div class="grid">
<div class="card">
<h3>Input</h3>
<textarea id="domains" placeholder="example.com&#10;github.com&#10;tesla.com&#10;# drag & drop .txt"></textarea>
<div class="drop" id="drop">drag &amp; drop domains.txt atau klik Browse</div>
<div style="height:8px"></div>
<div class="row"><input id="filePath" class="input" placeholder="opsional: C:\path\domains.txt"><input id="filePick" type="file" accept=".txt,.csv" style="display:none"><button class="btn btn-ghost" onclick="document.getElementById('filePick').click()">Browse</button></div>
<div style="height:12px"></div>
<div class="row"><div style="flex:1"><label style="font-size:11px;color:#8b96b1">Target</label><input id="target" class="input" type="number" value="2000"></div><div style="flex:1"><label style="font-size:11px;color:#8b96b1">Output</label><input id="out" class="input" placeholder="out_xxxx.txt (auto)"></div></div>
<div style="height:12px"></div>
<div class="row"><div style="flex:1"><label style="font-size:11px;color:#8b96b1">Workers (1–100)</label><div class="row"><input id="workers" type="range" min="1" max="100" value="16" class="range"><span class="pill" id="wVal">16</span></div></div><div style="flex:1"><label style="font-size:11px;color:#8b96b1">Mode</label><select id="mode" class="input"><option value="balanced">balanced (50ms)</option><option value="speed">speed (0ms)</option><option value="stealth">stealth (1500ms)</option></select></div></div>
<div style="height:12px"></div>
<label class="switch"><input id="useTor" type="checkbox" checked> Tor per-worker isolated circuit (NEWNYM on 429)</label>
<div style="height:8px"></div>
<label class="switch"><input id="keepInfra" type="checkbox"> Simpan hostname infra hosting (vpsNNNN/srv12 — default dibuang)</label>
<div class="row" style="margin-top:8px"><input id="torAddr" class="input" value="127.0.0.1:9050"><span class="pill">ctrl 9051 250 OK</span></div>
<div style="height:14px"></div>
<button id="startBtn" class="btn btn-primary" onclick="start()">▶ Start parallel scan</button>
<div style="height:8px"></div>
<div class="row"><button class="btn btn-danger" style="flex:1" onclick="stop()">■ Stop</button><button class="btn btn-ghost" style="flex:1" onclick="clearLog()">Clear</button><button class="btn btn-ghost" style="flex:1" onclick="download()">⬇ Download</button><a href="/debug?token=__DEBUG_TOKEN__" target="_blank" class="btn btn-ghost" style="flex:1;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;color:#00ffcc;border-color:#00ffcc;">⚡ Admin HUD</a></div>
<div class="foot">Parallel BFS <span class="kbd">crt → rapid → crt</span> skip visited. Workers share queue, tiap worker pakai SOCKS user berbeda → IP exit berbeda tanpa NEWNYM. CLI: <code>scraper.exe -i domains.txt -t 2000 -c 8 -tor 127.0.0.1:9050</code> • <code>--gui</code></div>
</div>
<div>
<div class="stats"><div class="stat"><div class="k">Found</div><div class="v" id="vFound">0</div></div><div class="stat"><div class="k">Target</div><div class="v" id="vTarget">2000</div></div><div class="stat"><div class="k">Queue</div><div class="v" id="vQueue">0</div></div><div class="stat"><div class="k">Workers</div><div class="v" id="vWorkers">8</div></div></div>
<div class="bar"><i id="bar"></i></div>
<div style="height:10px"></div>
<div class="row" style="justify-content:space-between"><span class="pill" id="status">idle</span><span class="pill" id="outName">out: —</span><span class="pill" id="iterPill">iter 0</span></div>
<div style="height:10px"></div>
<div class="card" style="padding:12px"><h3>Live log — rapi</h3><div class="logWrap"><table class="logTable"><thead><tr><th>time</th><th>worker</th><th>source</th><th>added</th><th>total/q</th><th>domain</th></tr></thead><tbody id="logBody"></tbody></table></div></div>
</div>
</div>
</div>
<script>
const TOKEN = "__DEBUG_TOKEN__";
let poll=null
const d=document.getElementById('domains'), fp=document.getElementById('filePick'), drop=document.getElementById('drop')
const wRange=document.getElementById('workers'), wVal=document.getElementById('wVal')
wRange.addEventListener('input',()=>wVal.textContent=wRange.value)
fp.addEventListener('change', async e=>{ const f=e.target.files[0]; if(!f) return; d.value=await f.text(); document.getElementById('filePath').value=f.name })
drop.addEventListener('click',()=>fp.click())
drop.addEventListener('dragover',e=>{e.preventDefault(); drop.style.borderColor='#7c5cff'})
drop.addEventListener('dragleave',()=>drop.style.borderColor='#2a365a')
drop.addEventListener('drop',async e=>{e.preventDefault(); drop.style.borderColor='#2a365a'; const f=e.dataTransfer.files[0]; if(f) d.value=await f.text()})
function start(){
  const domains=d.value, filePath=document.getElementById('filePath').value, target=parseInt(document.getElementById('target').value||2000), out=document.getElementById('out').value, useTor=document.getElementById('useTor').checked, tor=document.getElementById('torAddr').value, workers=parseInt(wRange.value||16), mode=document.getElementById('mode').value, keepInfra=document.getElementById('keepInfra').checked
  document.getElementById('startBtn').disabled=true; document.getElementById('status').textContent='running'
  fetch('/api/start?token='+encodeURIComponent(TOKEN),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({domains,filePath,target,out,tor,useTor,workers,mode,keepInfra})}).then(async r=>{ const t=await r.text(); if(!r.ok) { alert(t); document.getElementById('startBtn').disabled=false } if(!poll) poll=setInterval(tick,600) })
}
function stop(){ fetch('/api/stop?token='+encodeURIComponent(TOKEN),{method:'POST'}) }
function clearLog(){ document.getElementById('logBody').innerHTML=''; }
function download(){ const out=document.getElementById('outName').textContent.replace('out: ','').trim(); const f=out && out!=='—' ? out : ''; location.href='/api/download?token='+encodeURIComponent(TOKEN)+'&f='+encodeURIComponent(f) }
function apiBadge(api){
  if(api==='crt.name') return '<span class="badgeApi api-crt">CRT</span>'
  if(api==='rapiddns') return '<span class="badgeApi api-rapid">RAPID</span>'
  if(api==='crt.sh') return '<span class="badgeApi api-crtsh">CRT.SH</span>'
  return '<span class="badgeApi" style="background:#1a1a2a;color:#9aa3b2">SYS</span>'
}
let seen=0
function tick(){
  fetch('/api/status?token='+encodeURIComponent(TOKEN)).then(r=>r.json()).then(j=>{
    document.getElementById('vFound').textContent=j.found
    document.getElementById('vTarget').textContent=j.target
    document.getElementById('vQueue').textContent=j.queue
    document.getElementById('vWorkers').textContent=j.workers||8
    document.getElementById('iterPill').textContent='iter '+j.iter
    document.getElementById('outName').textContent='out: '+(j.out||'—')
    document.getElementById('torBadge').textContent='Tor: '+(j.torIP? j.torIP.slice(0,90): (document.getElementById('useTor').checked?'on ('+j.workers+' circuits)':'off'))
    document.getElementById('bar').style.width=(j.target? Math.min(100,Math.round(j.found/j.target*100)):0)+'%'
    document.getElementById('status').textContent=j.running?'running ●':'idle'
    document.getElementById('startBtn').disabled=j.running
    if(j.entries && j.entries.length){
      const body=document.getElementById('logBody')
      // only append new
      for(let i=seen;i<j.entries.length;i++){
        const e=j.entries[i]
        // parse e.msg for worker/domain
        const tr=document.createElement('tr')
        const m=e.msg||''
        // extract worker and domain from msg like "[12] w3 example.com via ..."
        let worker='—', domain=e.domain||''
        const wm=m.match(/w(\d+)/); if(wm) worker='w'+wm[1]
        const dm=m.match(/\]\s+w\d+\s+(\S+)/); if(dm) domain=dm[1]
        if(!domain) domain=e.domain||'—'
        tr.innerHTML = '<td class="muted">'+(e.time||'')+'</td><td>'+worker+'</td><td>'+apiBadge(e.api||'')+'</td><td>'+(e.added? '<span class="badgeAdd">+'+e.added+'</span>':'<span class="muted">0</span>')+'</td><td class="muted">'+(e.total? e.total+'/'+e.queue : (j.found+'/'+j.queue))+'</td><td title="'+(m.replace(/"/g,'&quot;'))+'">'+domain+'</td>'
        if(e.level==='err') tr.style.background='#1a1020'
        if(e.level==='tor') tr.style.background='#0f1a2a'
        body.appendChild(tr)
      }
      seen=j.entries.length
      const wrap=body.parentElement.parentElement
      wrap.scrollTop=wrap.scrollHeight
      if(seen>700){ body.innerHTML=''; seen=0 }
    }
  })
}
setInterval(tick,700); tick()
</script></body></html>`

func tcpProbe(addr string) bool {
	c, err := net.DialTimeout("tcp", addr, 800*time.Millisecond)
	if err != nil {
		return false
	}
	c.Close()
	return true
}

func clearScreen() {
	if ansiOn {
		fmt.Print("\033[H\033[2J")
	}
}

// runNetDiag mencetak diagnostik jaringan & Tor. Dulu ini entri menu 6; sejak
// penomoran menu diramping, jalurnya lewat flag -diag supaya kemampuan cek
// cepat (SOCKS/ControlPort/exit IP) tetap ada tanpa memakan slot menu.
func runNetDiag() {
	fmt.Println(paint(colPur, cliBanner))
	fmt.Println(paint(colPur, "== Diagnostik Jaringan & Tor =="))
	torAlive := tcpProbe(defaultTorSocks)
	fmt.Printf("- Tor SOCKS 9050   : %s\n", map[bool]string{true: paint(colGrn, "ONLINE"), false: paint(colRed, "OFFLINE")}[torAlive])
	if !torAlive {
		fmt.Print("- Mencoba auto-start Tor... ")
		if ensureTorRunning() {
			fmt.Println(paint(colGrn, "SUKSES"))
		} else {
			fmt.Println(paint(colRed, "GAGAL"))
		}
	}
	ctrlAddr := torControlAddrFor(defaultTorSocks)
	if ctrlAddr == "" {
		ctrlAddr = defaultTorCtrl
	}
	ctrlAlive := tcpProbe(ctrlAddr)
	fmt.Printf("- Tor ControlPort  : %s (%s)\n", ctrlAddr, map[bool]string{true: paint(colGrn, "ONLINE"), false: paint(colDim, "OFFLINE")}[ctrlAlive])
	ip := verifyTorIP(defaultTorSocks)
	if ip == "" && torAlive {
		auth := &proxy.Auth{User: "ipcheck", Password: torSocksPass}
		if dialer, derr := proxy.SOCKS5("tcp", defaultTorSocks, auth, proxy.Direct); derr == nil {
			c := &http.Client{Transport: &http.Transport{DialContext: torDialContext(dialer)}, Timeout: 8 * time.Second}
			if resp, gerr := c.Get("https://check.torproject.org/api/ip"); gerr == nil {
				b, _ := io.ReadAll(io.LimitReader(resp.Body, 4096))
				resp.Body.Close()
				if resp.StatusCode == 200 {
					ip = parseTorCheckIP(b)
				}
			}
		}
	}
	if ip != "" {
		fmt.Printf("- Tor Exit Public IP: %s\n", paint(colCyan, ip))
	} else {
		fmt.Println("- Tidak dapat menjangkau IP publik lewat Tor")
	}
}

func manageRapidSessionsMenu(r *bufio.Reader) {
	cleanStr := func(s string) string { return strings.Trim(strings.TrimSpace(strings.Trim(s, "\ufeff")), "\r") }
	for {
		clearScreen()
		fmt.Println(paint(colPur, cliBanner))
		fmt.Println(paint(colCyan, "== Manajemen Session RapidDNS (Login Multi-Account) =="))
		sessions := globalRapidSessions.GetAll()
		fmt.Printf("Total Session Aktif: %d\n\n", len(sessions))
		if len(sessions) == 0 {
			fmt.Println(paint(colDim, "(Tidak ada session aktif — menggunakan Guest Mode maks 100 baris/domain)"))
		} else {
			for i, s := range sessions {
				fmt.Printf("[%d] %s (Panjang: %d chars)\n", i+1, MaskSession(s), len(s))
			}
		}
		fmt.Println()
		fmt.Println("1. Tambah Session Baru (Paste Cookie Token / session=...)")
		fmt.Println("2. Reload Session dari file rapiddns_sessions.txt")
		fmt.Println("3. Simpan Session Saat Ini ke rapiddns_sessions.txt")
		fmt.Println("4. Hapus Semua Session (Reset ke Guest Mode)")
		fmt.Println("0. Kembali ke Menu Utama")
		fmt.Println()
		fmt.Print(paint(colYel, "Pilih opsi [1-4, 0]: "))
		s, _ := r.ReadString('\n')
		opt := cleanStr(s)

		if opt == "1" {
			fmt.Print("\nPaste session token akun RapidDNS (contoh: .eJwtjtt... atau session=.eJw...):\n> ")
			tok, _ := r.ReadString('\n')
			tok = cleanStr(tok)
			if tok != "" {
				if globalRapidSessions.AddSession(tok) {
					_ = globalRapidSessions.SaveToFile(defaultSessionFile)
					fmt.Println(paint(colGrn, "\nSession berhasil ditambahkan dan disimpan ke rapiddns_sessions.txt!"))
				} else {
					fmt.Println(paint(colYel, "\nSession kosong atau sudah ada dalam daftar."))
				}
			}
			fmt.Print("Tekan Enter untuk lanjut...")
			r.ReadString('\n')
		} else if opt == "2" {
			count, err := globalRapidSessions.LoadFromFile(defaultSessionFile)
			if err != nil {
				fmt.Printf(paint(colRed, "\nGagal membaca file %s: %v\n"), defaultSessionFile, err)
			} else {
				fmt.Printf(paint(colGrn, "\nBerhasil memuat %d session baru dari %s!\n"), count, defaultSessionFile)
			}
			fmt.Print("Tekan Enter untuk lanjut...")
			r.ReadString('\n')
		} else if opt == "3" {
			if err := globalRapidSessions.SaveToFile(defaultSessionFile); err != nil {
				fmt.Printf(paint(colRed, "\nGagal menyimpan ke file: %v\n"), err)
			} else {
				fmt.Printf(paint(colGrn, "\nBerhasil menyimpan %d session ke %s!\n"), globalRapidSessions.Count(), defaultSessionFile)
			}
			fmt.Print("Tekan Enter untuk lanjut...")
			r.ReadString('\n')
		} else if opt == "4" {
			globalRapidSessions.Clear()
			_ = globalRapidSessions.SaveToFile(defaultSessionFile)
			fmt.Println(paint(colYel, "\nSemua session telah dihapus. Scraper kembali ke mode Guest."))
			fmt.Print("Tekan Enter untuk lanjut...")
			r.ReadString('\n')
		} else if opt == "0" || opt == "" {
			break
		}
	}
}

func runInteractiveMenu(in *string, tgt *int, out *string, tor *string, workers *int, modeFlag *string, reverseFlag *bool) bool {
	r := bufio.NewReader(os.Stdin)
	cleanStr := func(s string) string { return strings.Trim(strings.TrimSpace(strings.Trim(s, "\ufeff")), "\r") }

	for {
		clearScreen()
		fmt.Println(paint(colPur, cliBanner))

		// Status info
		fleet := loadTorFleet()
		torStatus := paint(colYel, "STANDBY / OFFLINE (Auto-Start saat run)")
		if len(fleet) > 1 {
			torStatus = paint(colGrn, fmt.Sprintf("AKTIF (Multi-Tor Swarm: %d Instance Ports: %s)", len(fleet), strings.Join(fleet, ", ")))
		} else if len(fleet) == 1 && tcpProbe(fleet[0]) {
			torStatus = paint(colGrn, fmt.Sprintf("AKTIF (1 Instance: %s)", fleet[0]))
		}

		rapidCount := globalRapidSessions.Count()
		rapidStatus := paint(colDim, "Guest Mode (Maks 100 baris/domain)")
		if rapidCount > 0 {
			rapidStatus = paint(colGrn, fmt.Sprintf("%d Akun / Session Login (Rotasi Otomatis, Maks 1000 baris)", rapidCount))
		}

		fmt.Printf("Tor Status   : %s\n", torStatus)
		fmt.Printf("Diagnostik   : %s\n", paint(colDim, "scraper.exe -diag (cek Tor SOCKS / ControlPort / exit IP)"))
		fmt.Printf("RapidDNS     : %s\n", rapidStatus)
		fmt.Printf("Engine       : crt.name (Certificate Transparency Stream)\n")
		fmt.Printf("Anti-DGA     : %s\n", paint(colGrn, "All-Label & Multi-Digit Filter ON"))
		fmt.Printf("Cross-Apex   : Reverse-IP Multi-Source Supported\n")
		fmt.Println()
		fmt.Println(paint(colCyan, "== Menu Utama =="))
		fmt.Println("1. Mulai Scraping — Adaptive Smart-Pipeline (profil V3 Revolution / Legacy Parallel) [RECOMMENDED]")
		fmt.Println("2. Post-processing Hasil (Bersihkan junk/DGA/Multi-Digit + Analisis Statistik)")
		fmt.Println("3. Kelola Akun / Session RapidDNS (Login Multi-Account)")
		fmt.Println("4. Buka Web GUI & Debug HUD (http://localhost:9876)")
		fmt.Println("5. Scan Nuclei (hasil scraper -> template CVE / kerentanan)")
		fmt.Println("6. Scanning CMS WordPress massal (wp_scanner -> temuan WP/vuln)")
		fmt.Println("7. Scraping Non-Stop Tanpa Limit (Murni crt.name + RapidDNS via Tor Swarm) [NEW/SPECIAL]")
		fmt.Println("0. Keluar")
		fmt.Println()
		fmt.Print(paint(colYel, "Pilih menu [1-7, default 1]: "))

		choiceStr, rerr := r.ReadString('\n')
		// stdin habis (EOF) tanpa baris input: JANGAN diperlakukan seperti menekan
		// Enter. Dulu error diabaikan sehingga choice == "" jatuh ke default "1"
		// dan menu otomatis memulai full scan pada stdin tertutup (mis.
		// `scraper.exe </dev/null` atau pipe kosong). Keluar dengan tenang.
		if rerr != nil && strings.TrimSpace(choiceStr) == "" {
			fmt.Println(paint(colDim, "\n[menu] stdin berakhir - keluar tanpa memulai scan."))
			return false
		}
		choice := strings.TrimSpace(choiceStr)
		if choice == "" || choice == "1" {
			// Auto-detect seed
			defaultSeed := "url.txt"
			if _, err := os.Stat("url.txt"); err != nil {
				for _, c := range []string{"domains.txt", "domains10.txt", "list.txt", "targets.txt"} {
					if _, err := os.Stat(c); err == nil {
						defaultSeed = c
						break
					}
				}
			}

			// Profil menggantikan entri menu terpisah "[LEGACY] Standard Parallel
			// Mode": jalur legacy tetap utuh (EngineParallel + ScopeUnrestricted +
			// worker/target dari CLI), cuma tidak lagi memakan slot menu sendiri.
			fmt.Printf("\n%s\n", paint(colPur, "== Profil Scraping =="))
			fmt.Print("0) Profil [1=V3 Revolution (Smart Rapid-First + Scope Guard), 2=Legacy Standard Parallel] [default 1]: ")
			ps, _ := r.ReadString('\n')
			isV3 := cleanStr(ps) != "2"
			modeName := "V3 Revolution (Smart Rapid-First + Scope Guard)"
			if !isV3 {
				modeName = "Legacy Standard Parallel"
			}
			fmt.Printf("   -> profil aktif: %s\n", paint(colGrn, modeName))

			fmt.Printf("\n%s\n", paint(colPur, "== Konfigurasi Scraping =="))
			if globalRapidSessions.Count() > 0 {
				fmt.Printf("[rapiddns] %s\n", paint(colGrn, fmt.Sprintf("%d session login aktif terpasang", globalRapidSessions.Count())))
			}
			fmt.Printf("1) File list domain [%s]: ", defaultSeed)
			s, _ := r.ReadString('\n')
			*in = cleanStr(s)
			if *in == "" {
				*in = defaultSeed
			}

			defaultTgt := *tgt
			if isV3 && defaultTgt < 100000 {
				defaultTgt = 100000
			}
			fmt.Printf("2) Target jumlah domain [%d]: ", defaultTgt)
			s, _ = r.ReadString('\n')
			s = cleanStr(s)
			if s != "" {
				var t int
				if _, err := fmt.Sscan(s, &t); err == nil && t > 0 {
					*tgt = t
				}
			} else {
				*tgt = defaultTgt
			}

			defWorkers := 35
			if !isV3 {
				defWorkers = *workers
			}
			for {
				fmt.Printf("3) Worker/threads [%d] (1-100, Rekomendasi 24/7 stabil: 30-40): ", defWorkers)
				s, _ = r.ReadString('\n')
				s = cleanStr(s)
				if s == "" {
					*workers = defWorkers
					break
				}
				var c int
				if _, err := fmt.Sscan(s, &c); err == nil && c >= 1 && c <= 100 {
					*workers = c
					break
				}
				fmt.Println("   masukkan angka 1-100.")
			}

			if isV3 {
				fmt.Print("4) Engine Mode [1=Rapid-First Smart Fallback (Stabil), 2=RapidDNS Only, 3=Parallel Dual] [default 1]: ")
				s, _ = r.ReadString('\n')
				s = cleanStr(s)
				if s == "2" {
					globalEngineMode = EngineRapid
				} else if s == "3" {
					globalEngineMode = EngineParallel
				} else {
					globalEngineMode = EngineSmart
				}

				fmt.Print("5) Scope Guard Policy [1=Strict Target TLDs (*.id only - Anti Sampah Luar Negeri), 2=Global Unrestricted] [default 1]: ")
				s, _ = r.ReadString('\n')
				s = cleanStr(s)
				if s == "2" {
					globalScopeGuard.SetMode(ScopeUnrestricted)
				} else {
					globalScopeGuard.SetMode(ScopeTargetTLDs)
				}
			} else {
				globalEngineMode = EngineParallel
				globalScopeGuard.SetMode(ScopeUnrestricted)
			}

			torAlive := len(fleet) > 0 && tcpProbe(fleet[0])
			if !torAlive {
				fmt.Print("   [tor] Memeriksa & auto-start Tor daemon (127.0.0.1:9050)... ")
				if ensureTorRunning() {
					torAlive = true
					fmt.Println(paint(colGrn, "BERHASIL HIDUP!"))
				} else {
					fmt.Println(paint(colDim, "tidak ditemukan (akan pakai direct IP)"))
				}
			}

			for {
				fmt.Printf("6) Gunakan Tor Proxy? [Y/n, default Y]: ")
				s, _ = r.ReadString('\n')
				s = strings.ToLower(cleanStr(s))
				// Mark the choice as explicit BEFORE leaving: main()'s auto-tor
				// block must not fall back to "off" on an address the operator
				// just typed (it used to, because it only scanned os.Args).
				torUserChosen = true
				if s == "" || s == "y" || s == "ya" || s == "yes" {
					*tor = defaultTorSocks
					break
				} else if s == "n" || s == "no" || s == "off" || s == "tidak" {
					*tor = "off"
					break
				} else {
					*tor = s
					break
				}
			}

			fmt.Print("7) Output file [acak/auto]: ")
			s, _ = r.ReadString('\n')
			*out = cleanStr(s)

			fmt.Print("8) Expand reverse-IP cross-apex untuk volume? [Y/n, default Y]: ")
			s, _ = r.ReadString('\n')
			sl := strings.ToLower(cleanStr(s))
			if sl == "" || sl == "y" || sl == "ya" || sl == "yes" {
				noReverse = false
			} else {
				noReverse = true
			}

			fmt.Print("9) Simpan hostname infra hosting (vpsNNN/srv12)? [y/N, default N = buang]: ")
			s, _ = r.ReadString('\n')
			sl = strings.ToLower(cleanStr(s))
			keepInfra = sl == "y" || sl == "ya" || sl == "yes"

			fmt.Println()
			return true // continue to runMass

		} else if choice == "2" {
			fmt.Print("\nMasukkan path file hasil (contoh: results/out_xxx.txt): ")
			s, _ := r.ReadString('\n')
			filePath := cleanStr(s)
			if filePath != "" {
				fmt.Println("1. Bersihkan saja (drop junk / DGA / multi-digit + probe wildcard)")
				fmt.Println("2. Analisis statistik saja (tally per apex/TLD)")
				fmt.Println("3. Keduanya (bersihkan lalu analisis)")
				fmt.Println("0. Batal")
				fmt.Print(paint(colYel, "Pilih aksi [1-3, default 3]: "))
				a, _ := r.ReadString('\n')
				postProcessAction(filePath, cleanStr(a))
			}
			fmt.Print("\nTekan Enter untuk kembali ke menu...")
			r.ReadString('\n')
		} else if choice == "3" {
			manageRapidSessionsMenu(r)
		} else if choice == "4" {
			fmt.Println("\nMemulai Web GUI & Debug HUD...")
			runGUI()
			return false
		} else if choice == "5" {
			runNucleiScanMenu(r)
		} else if choice == "6" {
			runWPScanMenu(r)
		} else if choice == "7" {
			// =========================================================================
			// MENU 7: SCRAPING NON-STOP TANPA LIMIT (MURNI CRT.NAME + RAPIDDNS VIA TOR)
			// =========================================================================
			fmt.Printf("\n%s\n", paint(colCyan, "== Mode Non-Stop Tanpa Limit (crt.name × RapidDNS via Tor Swarm Fleet) =="))
			fmt.Println("Karakteristik Mode:")
			fmt.Println(" • Engine   : Murni crt.name & RapidDNS (Subdomain + Same-IP) [Zero-Fallback / No Delay]")
			fmt.Println(" • Limit    : TIDAK ADA LIMIT (Non-Stop berputar tanpa batas hingga Ctrl+C)")
			fmt.Println(" • Jaringan : Multi-Tor Swarm Fleet (Isolasi IP sirkuit SOCKS5 per worker)")
			fmt.Println(" • Anti-Lag : Autonomous Infinite Re-feed Engine aktif (antrian tidak pernah kering)")
			fmt.Println()

			// Auto-detect seed
			defaultSeed := "url.txt"
			if _, err := os.Stat("url.txt"); err != nil {
				for _, c := range []string{"domains.txt", "domains10.txt", "list.txt", "targets.txt"} {
					if _, err := os.Stat(c); err == nil {
						defaultSeed = c
						break
					}
				}
			}

			fmt.Printf("1) File list domain [%s]: ", defaultSeed)
			s, _ := r.ReadString('\n')
			*in = cleanStr(s)
			if *in == "" {
				*in = defaultSeed
			}

			// Unlimited target: 0
			*tgt = 0

			defWorkers := 35
			for {
				fmt.Printf("2) Worker/threads [%d] (1-100, Rekomendasi 24/7 stabil: 30-50): ", defWorkers)
				s, _ = r.ReadString('\n')
				s = cleanStr(s)
				if s == "" {
					*workers = defWorkers
					break
				}
				var c int
				if _, err := fmt.Sscan(s, &c); err == nil && c >= 1 && c <= 100 {
					*workers = c
					break
				}
				fmt.Println("   masukkan angka 1-100.")
			}

			globalEngineMode = EnginePureDual

			fmt.Print("3) Scope Guard [1=Strict Target TLDs (*.id only - Anti Sampah Luar), 2=Global Unrestricted] [default 1]: ")
			s, _ = r.ReadString('\n')
			s = cleanStr(s)
			if s == "2" {
				globalScopeGuard.SetMode(ScopeUnrestricted)
			} else {
				globalScopeGuard.SetMode(ScopeTargetTLDs)
			}

			torAlive := len(fleet) > 0 && tcpProbe(fleet[0])
			if !torAlive {
				fmt.Print("   [tor] Memeriksa & auto-start Tor Swarm Fleet (127.0.0.1:9050)... ")
				if ensureTorRunning() {
					torAlive = true
					fmt.Println(paint(colGrn, "BERHASIL HIDUP!"))
				} else {
					fmt.Println(paint(colDim, "tidak ditemukan (akan pakai direct IP)"))
				}
			}

			*tor = defaultTorSocks
			torUserChosen = true

			fmt.Print("4) Output file [acak/auto]: ")
			s, _ = r.ReadString('\n')
			*out = cleanStr(s)

			// Reverse-IP cross-apex aktif untuk menyuplai antrian tanpa henti
			noReverse = false

			fmt.Println()
			fmt.Printf("   -> Mode Aktif: %s (Workers: %d, Tor: %s, Limit: %s)\n",
				paint(colGrn, "Infinite crt.name + RapidDNS Dual-Stream"), *workers, *tor, paint(colYel, "UNLIMITED / NON-STOP"))
			fmt.Printf("   -> Tekan %s kapan saja untuk menyelesaikan dan merapikan output.\n\n", paint(colYel, "Ctrl+C"))
			return true // continue to runMass

		} else if choice == "8" || choice == "9" {
			fmt.Println(paint(colYel, "\n[menu] penomoran baru: 1=Scraping Adaptive, 2=Post-processing, 3=Session RapidDNS, 4=GUI, 5=Nuclei, 6=WP scan, 7=Non-Stop crt.name+RapidDNS."))
			fmt.Print("Tekan Enter untuk kembali ke menu...")
			r.ReadString('\n')
		} else if choice == "0" || strings.ToLower(choice) == "exit" || strings.ToLower(choice) == "q" {
			fmt.Println(paint(colGrn, "\nSampai jumpa!\n"))
			os.Exit(0)
		}
	}
}

func main() {
	defer killAutoTor()
	InitRapidSessions()
	in := flag.String("i", "", "file list domain (1 per line)")
	flag.StringVar(in, "list", "", "alias for -i: file list domain")
	tgt := flag.Int("t", 2000, "target jumlah domain")
	out := flag.String("o", "", "output file (default random hash)")
	tor := flag.String("tor", defaultTorSocks, "tor socks5 addr, use \"off\" to disable")
	workers := flag.Int("c", 30, "parallel workers (1-100, each isolated Tor circuit)")
	batchFlag := flag.Int("batch", workBatchMax, "item per worker per batch (default 20: tiap worker ambil 20, habis itu 20 berikutnya)")
	torFleetFlag := flag.Int("torfleet", 15, "berapa instance Tor yang di-autostart (2-50, socks 9050+2i)")
	modeFlag := flag.String("mode", "speed", "per-hit delay: speed(0ms)|balanced(50ms)|stealth(1500ms)")
	var reverseFlag bool
	// reverse-IP cross-apex expand ON by default -> loop penuh crt->IP->
	// reverse->crt (misi user). -noreverse untuk seed-only clean output.
	flag.BoolVar(&noReverse, "noreverse", false, "skip reverse-IP cross-apex expansion (seed-only clean output)")
	flag.BoolVar(&reverseFlag, "reverse", true, "enable reverse-IP cross-apex expand for volume (default: ON)")
	flag.BoolVar(&keepInfra, "keepinfra", false, "keep auto-generated hosting hostnames (vpsNNNN/srv12/...) — default dibuang")
	var unlimitedFlag bool
	flag.BoolVar(&unlimitedFlag, "unlimited", false, "mode tak terbatas (infinite non-stop scraping tanpa target limit)")
	engineFlag := flag.String("engine", "smart", "engine mode: smart(rapid-first->crt fallback)|parallel|puredual|rapid|crt")
	scopeFlag := flag.String("scope", "tld", "scope guard policy: tld(match seed TLDs e.g. *.id)|strict(seed apex only)|global(unrestricted)")
	scopeTLDFlag := flag.String("scope-tld", "", "explicit comma-separated allowed TLDs/suffixes (e.g. id,go.id)")
	rotateIntervalFlag := flag.Duration("rotate-interval", 0, "proactive exit rotation interval per worker (e.g. 8m, 10m, 0=off)")
	var debugFlag bool
	var debugPort int
	var debugTokenFlag string
	var diagFlag bool
	flag.BoolVar(&debugFlag, "debug", false, "jalankan Real-Time Debug Server di background (admin & AI bot HUD)")
	flag.BoolVar(&diagFlag, "diag", false, "diagnostik jaringan & Tor (SOCKS 9050 / ControlPort / exit IP) lalu keluar")
	flag.IntVar(&debugPort, "debug-port", 9876, "port Real-Time Debug Server (default 9876)")
	flag.BoolVar(&torSteerFlag, "torsteer", true, "keluarkan exit relay yang sudah diblokir dari sirkuit berikutnya (butuh ControlPort Tor)")
	flag.StringVar(&debugTokenFlag, "debug-token", defaultDebugToken, "secret token untuk autentikasi debug HUD/API")
	var analyzePath string
	flag.StringVar(&analyzePath, "analyze", "", "tally res file: junk/infra counts per apex (e.g. -analyze res.txt)")
	var cleanPath string
	flag.StringVar(&cleanPath, "clean", "", "clean a result file: drop junk domains, write .clean.txt + .junk.txt")
	flag.Usage = func() {
		fmt.Fprintf(os.Stderr, "  scraper.exe -analyze res.txt          # tally output for junk/infra ratios\n")
		fmt.Fprintf(os.Stderr, "Usage (paling gampang dulu):\n")
		fmt.Fprintf(os.Stderr, "  scraper.exe domains.txt              # file saja, target 2000, tor auto\n")
		fmt.Fprintf(os.Stderr, "  scraper.exe domains.txt -debug       # dengan Real-Time Debug HUD (admin/AI bot)\n")
		fmt.Fprintf(os.Stderr, "  scraper.exe domains.txt 5000         # file + target\n")
		fmt.Fprintf(os.Stderr, "  scraper.exe domains.txt 5000 hasil.txt   # file + target + output\n")
		fmt.Fprintf(os.Stderr, "  scraper.exe -i domains.txt -t 2000 -c 16 -tor off   # lengkap (flag boleh di mana saja)\n")
		fmt.Fprintf(os.Stderr, "  scraper.exe -i domains.txt -t 2000 -mode speed   # max throughput\n")
		fmt.Fprintf(os.Stderr, "  scraper.exe -i domains.txt -engine smart -scope tld   # Adaptive Smart V3\n")
		fmt.Fprintf(os.Stderr, "  scraper.exe -i domains.txt -reverse   # enable reverse-IP cross-apex expand\n")
		fmt.Fprintf(os.Stderr, "  scraper.exe --gui                    # versi GUI\n")
		fmt.Fprintf(os.Stderr, "  scraper.exe -diag                    # cek Tor SOCKS/ControlPort/exit IP lalu keluar\n\n")
		flag.PrintDefaults()
	}
	flag.Parse()
	// NOTE: everything that READS a flag value now runs AFTER the overlay below.
	// flag.Parse stops at the first positional, so `scraper.exe url.txt -engine
	// rapid` left *engineFlag at its default \u2014 and because the engine/scope
	// switch used to run here, before the overlay could set it, that command ran
	// in smart mode with no warning. Same for -analyze/-clean/-debug-token.
	flag.Visit(func(f *flag.Flag) {
		if f.Name == "noreverse" {
			noReverse = true
		}
		if f.Name == "reverse" {
			noReverse = !reverseFlag
		}
	})
	clean := func(s string) string { return strings.Trim(strings.TrimSpace(strings.Trim(s, "\ufeff")), "\r") }
	// Overlay: Go flag.Parse berhenti di arg posisional pertama,
	// jadi flag yang ditulis SETELAH file (mis. "domains.txt -tor off -c 4")
	// harus diparse manual di sini agar tidak ke-ignore.
	// Kumpulkan juga positional murni (bukan flag).
	var positionals []string
	// wantAnalyze/wantClean: the bare form (`scraper.exe res.txt -analyze`) has no
	// value token, so the path is taken from the first positional after the loop.
	var wantAnalyze, wantClean bool
	raw := os.Args[1:]
	for i := 0; i < len(raw); i++ {
		a := raw[i]
		// --flag=value
		if strings.HasPrefix(a, "-") && strings.Contains(a, "=") {
			kv := strings.SplitN(a, "=", 2)
			a, rawExtra := kv[0], kv[1]
			switch a {
			case "-i", "--i", "-list", "--list":
				*in = clean(rawExtra)
			case "-t", "--t":
				var t int
				if _, err := fmt.Sscan(clean(rawExtra), &t); err == nil && t > 0 {
					*tgt = t
				}
			case "-o", "--o":
				*out = clean(rawExtra)
			case "-tor", "--tor":
				*tor = clean(rawExtra)
			case "-c", "--c":
				var c int
				if _, err := fmt.Sscan(clean(rawExtra), &c); err == nil && c > 0 {
					*workers = c
				}
			case "-mode":
				*modeFlag = clean(rawExtra)
			case "-rotate-interval", "--rotate-interval":
				var d time.Duration
				if _, err := fmt.Sscan(clean(rawExtra), &d); err == nil && d >= 0 {
					*rotateIntervalFlag = d
				}
			case "--gui":
				*guiFlag = true
			case "-diag", "--diag":
				diagFlag = !isFalseWord(rawExtra)
			case "-debug", "--debug":
				debugFlag = true
			case "-debug-port", "--debug-port":
				var p int
				if _, err := fmt.Sscan(clean(rawExtra), &p); err == nil && p > 0 {
					debugPort = p
				}
			case "-debug-token", "--debug-token":
				debugTokenFlag = clean(rawExtra)
			case "-engine", "--engine":
				*engineFlag = clean(rawExtra)
			case "-scope", "--scope":
				*scopeFlag = clean(rawExtra)
			case "-scope-tld", "--scope-tld":
				*scopeTLDFlag = clean(rawExtra)
			case "-batch", "--batch":
				var b int
				if _, err := fmt.Sscan(clean(rawExtra), &b); err == nil && b >= 1 && b <= 200 {
					*batchFlag = b
				}
			case "-torfleet", "--torfleet":
				var n int
				if _, err := fmt.Sscan(clean(rawExtra), &n); err == nil && n >= 2 && n <= 50 {
					*torFleetFlag = n
				}
			case "-torsteer", "--torsteer":
				torSteerFlag = !isFalseWord(rawExtra)
			case "-reverse", "--reverse":
				noReverse = isFalseWord(rawExtra)
			case "-noreverse", "--noreverse":
				noReverse = !isFalseWord(rawExtra)
			case "-keepinfra", "--keepinfra":
				keepInfra = !isFalseWord(rawExtra)
			case "-analyze", "--analyze":
				analyzePath = clean(rawExtra)
				wantAnalyze = true
			case "-clean", "--clean":
				cleanPath = clean(rawExtra)
				wantClean = true
			}
			continue
		}
		switch a {
		case "-i", "--i", "-list", "--list":
			if i+1 < len(raw) {
				i++
				*in = clean(raw[i])
			}
		case "-t", "--t":
			if i+1 < len(raw) {
				i++
				var t int
				if _, err := fmt.Sscan(clean(raw[i]), &t); err == nil && t > 0 {
					*tgt = t
				}
			}
		case "-o", "--o":
			if i+1 < len(raw) {
				i++
				*out = clean(raw[i])
			}
		case "-tor", "--tor":
			if i+1 < len(raw) {
				i++
				*tor = clean(raw[i])
			}
		case "-c", "--c":
			if i+1 < len(raw) {
				i++
				var c int
				if _, err := fmt.Sscan(clean(raw[i]), &c); err == nil && c > 0 {
					*workers = c
				}
			}
		case "--gui":
			*guiFlag = true
		case "-diag", "--diag":
			diagFlag = true
		case "-debug", "--debug":
			debugFlag = true
		case "-debug-port", "--debug-port":
			if i+1 < len(raw) {
				i++
				var p int
				if _, err := fmt.Sscan(clean(raw[i]), &p); err == nil && p > 0 {
					debugPort = p
				}
			}
		case "-debug-token", "--debug-token":
			if i+1 < len(raw) {
				i++
				debugTokenFlag = clean(raw[i])
			}
		case "-mode":
			if i+1 < len(raw) {
				i++
				*modeFlag = clean(raw[i])
			}
		case "-rotate-interval", "--rotate-interval":
			if i+1 < len(raw) {
				i++
				var d time.Duration
				if _, err := fmt.Sscan(clean(raw[i]), &d); err == nil && d >= 0 {
					*rotateIntervalFlag = d
				}
			}
		case "-engine", "--engine":
			if i+1 < len(raw) {
				i++
				*engineFlag = clean(raw[i])
			}
		case "-scope", "--scope":
			if i+1 < len(raw) {
				i++
				*scopeFlag = clean(raw[i])
			}
		case "-scope-tld", "--scope-tld":
			if i+1 < len(raw) {
				i++
				*scopeTLDFlag = clean(raw[i])
			}
		case "-batch", "--batch":
			if i+1 < len(raw) {
				i++
				var b int
				if _, err := fmt.Sscan(clean(raw[i]), &b); err == nil && b >= 1 && b <= 200 {
					*batchFlag = b
				}
			}
		case "-torfleet", "--torfleet":
			if i+1 < len(raw) {
				i++
				var n int
				if _, err := fmt.Sscan(clean(raw[i]), &n); err == nil && n >= 2 && n <= 50 {
					*torFleetFlag = n
				}
			}
		case "-torsteer", "--torsteer":
			torSteerFlag = true
		case "-reverse", "--reverse":
			noReverse = false
		case "-noreverse", "--noreverse":
			noReverse = true
		case "-keepinfra", "--keepinfra":
			keepInfra = true
		case "-analyze", "--analyze":
			// Value form consumes the next token; the bare form (`scraper.exe
			// res.txt -analyze`) falls back to the first positional below.
			wantAnalyze = true
			if i+1 < len(raw) && !strings.HasPrefix(raw[i+1], "-") {
				i++
				analyzePath = clean(raw[i])
			}
		case "-clean", "--clean":
			wantClean = true
			if i+1 < len(raw) && !strings.HasPrefix(raw[i+1], "-") {
				i++
				cleanPath = clean(raw[i])
			}
		case "-h", "--h", "-help", "--help":
			flag.Usage()
			os.Exit(0)
		default:
			if strings.HasPrefix(a, "-") {
				// flag tak dikenal — abaikan biar tidak ribet
				continue
			}
			positionals = append(positionals, a)
		}
	}

	// --- Everything that consumes a flag value runs HERE, after the overlay ----
	// The overlay is the only parser that sees flags written after a positional
	// (`scraper.exe url.txt -engine rapid`), so any decision made before it read
	// a stale default.

	// Bare `-analyze` / `-clean` (no value token): use the first positional.
	if wantAnalyze && analyzePath == "" && len(positionals) > 0 {
		analyzePath = clean(positionals[0])
	}
	if wantClean && cleanPath == "" && len(positionals) > 0 {
		cleanPath = clean(positionals[0])
	}
	if analyzePath != "" {
		analyzeOutput(analyzePath)
		os.Exit(0)
	}
	if cleanPath != "" {
		cleanOutput(cleanPath)
		os.Exit(0)
	}

	switch strings.ToLower(*engineFlag) {
	case "rapid", "rapiddns":
		globalEngineMode = EngineRapid
	case "crt", "crtname":
		globalEngineMode = EngineCrt
	case "parallel":
		globalEngineMode = EngineParallel
	case "puredual", "infinite", "crtrapid", "dual":
		globalEngineMode = EnginePureDual
	default:
		globalEngineMode = EngineSmart
	}
	if unlimitedFlag {
		*tgt = 0
	}

	switch strings.ToLower(*scopeFlag) {
	case "global", "unrestricted", "off":
		globalScopeGuard.SetMode(ScopeUnrestricted)
	case "strict", "seed", "apex":
		globalScopeGuard.SetMode(ScopeSeedApexOnly)
	default:
		globalScopeGuard.SetMode(ScopeTargetTLDs)
	}

	if *scopeTLDFlag != "" {
		for _, t := range strings.Split(*scopeTLDFlag, ",") {
			globalScopeGuard.AddExplicitTLD(t)
		}
	}
	// After the overlay, so `-debug-token` written behind a positional wins.
	InitDebugToken(debugTokenFlag)
	if diagFlag {
		runNetDiag()
		return
	}
	// Single GUI entry point: covers both `--gui` before a positional (parsed by
	// flag.Parse) and after one (parsed by the overlay above).
	if *guiFlag {
		runGUI()
		return
	}
	if debugFlag {
		debugMux := http.NewServeMux()
		RegisterDebugRoutes(debugMux)
		RegisterDebugPprof(debugMux)
		// Same silent-exit trap as the GUI: bind first so a busy -debug-port is
		// reported instead of printing a HUD URL that nothing is listening on.
		debugAddr := fmt.Sprintf("127.0.0.1:%d", debugPort)
		debugLn, debugErr := bindLoopback(debugAddr)
		if debugErr != nil {
			fmt.Printf("[debug] %v (HUD tidak aktif)\n", debugErr)
		} else {
			go func() { _ = http.Serve(debugLn, debugMux) }()
			fmt.Printf("\n[debug] ⚡ Real-Time Debug HUD:  http://127.0.0.1:%d/debug?token=%s\n", debugPort, debugToken)
			fmt.Printf("[debug] 🤖 AI Bot Snapshot API: http://127.0.0.1:%d/api/debug/snapshot?token=%s\n\n", debugPort, debugToken)
		}
	}
	// positional args: scraper.exe [file] [target] [output]
	if *in == "" && len(positionals) >= 1 {
		*in = clean(positionals[0])
	}
	if len(positionals) >= 2 {
		var t int
		if _, err := fmt.Sscan(clean(positionals[1]), &t); err == nil && t > 0 {
			*tgt = t
		} else if *out == "" {
			*out = clean(positionals[1])
		}
	}
	if *out == "" && len(positionals) >= 3 {
		*out = clean(positionals[2])
	}
	// Mode manual: .\scraper.exe tanpa argumen/flag -> tampilkan menu interaktif lengkap.
	// Flag/positional tetap didukung untuk otomatisasi / script.
	manualMode := flag.NFlag() == 0 && len(positionals) == 0
	showBanner := true
	if manualMode {
		showBanner = false
		if !runInteractiveMenu(in, tgt, out, tor, workers, modeFlag, &reverseFlag) {
			return
		}
	}
	// auto tor: pakai tor kalau hidup, kalau mati langsung off tanpa ribet.
	// Juga auto-fallback saat jalan: kalau Tor mati di tengah, worker beralih direct.
	// Pilihan manual (Y/alamat/off) selalu dihormati, tidak di-override.
	torExplicit := torUserChosen
	for _, a := range os.Args[1:] {
		if a == "-tor" || a == "--tor" || strings.HasPrefix(a, "-tor=") || strings.HasPrefix(a, "--tor=") {
			torExplicit = true
		}
	}
	if (!torExplicit || *tor == defaultTorSocks) && *tor != "off" && *tor != "false" && *tor != "" {
		if ensureTorFleet() == 0 && !tcpProbe(defaultTorSocks) {
			*tor = "off"
		}
	}
	if *workers < 1 {
		*workers = 30
	}
	if *workers > 100 {
		*workers = 100
	}
	// Batch size: "setiap worker mengerjakan 20 thread, habis itu lanjut 20
	// berikutnya yang belum di-scan worker lain".
	if *batchFlag >= 1 && *batchFlag <= 200 {
		workBatchMax = *batchFlag
	}
	if *torFleetFlag >= 2 && *torFleetFlag <= 50 {
		torFleetSize = *torFleetFlag
	}
	// High-worker throughput optimization:
	// If mode wasn't explicitly configured via CLI flags, and workers >= 30 in manual mode,
	// default to speed mode (0ms delay) to achieve maximum wire throughput.
	if manualMode && *modeFlag == "balanced" && *workers >= 30 {
		*modeFlag = "speed"
	}
	useTor := *tor != "off" && *tor != "false" && *tor != ""
	// Pre-warm the Tor exit-steering layer BEFORE the seed list is loaded, so
	// control-port dials happen in parallel with list I/O instead of
	// serializing after readList on a 100k-line seed file. runMass's later
	// startTorExitSteering call is idempotent (started.CompareAndSwap).
	if useTor {
		go startTorExitSteering(*tor)
	}
	list, err := readList(*in)
	if err != nil {
		fmt.Printf("read %s: %v\n", *in, err)
		os.Exit(1)
	}
	if len(list) == 0 {
		fmt.Println("list kosong")
		os.Exit(1)
	}
	if *out == "" {
		*out = randomName()
	}
	// --- pretty CLI (skip banner if already shown in manual mode) ---
	if showBanner {
		fmt.Print(paint(colPur, cliBanner))
	}
	// geo + time like Oct.3
	if g := fetchGeo(1500*time.Millisecond, *tor, useTor); g != nil {
		country := g.Country
		if g.CountryCode != "" && !strings.Contains(country, "("+g.CountryCode+")") {
			country += " (" + g.CountryCode + ")"
		}
		region := firstNonEmpty(g.City, g.Region)
		fmt.Println(paintf(colDim, "  IP Address   : %s", firstNonEmpty(g.IP, "N/A")))
		fmt.Println(paintf(colDim, "  Country      : %s", firstNonEmpty(country, "N/A")))
		fmt.Println(paintf(colDim, "  State/Region : %s", firstNonEmpty(region, "N/A")))
		fmt.Println(paintf(colDim, "  Network      : %s", firstNonEmpty(g.Org, "N/A")))
	} else {
		fmt.Println(paint(colDim, "  IP Address   : N/A"))
	}
	fmt.Println(paintf(colDim, "  Local Time   : %s", time.Now().Format("Mon, 02 Jan 2006 15:04:05 -0700")))
	fmt.Println()
	fmt.Println(paintf(colDim, "  [ > ] File List : %s", *in))
	fmt.Println(paintf(colDim, "  [ > ] Threads   : %d", *workers))
	fmt.Println(paintf(colDim, "  [ > ] Mode      : %s", *modeFlag))
	if *out != "" {
		fmt.Println(paintf(colDim, "  [ > ] Output    : %s", *out))
	}
	fmt.Println(paintf(colDim, "  [ > ] Tor       : %s (%s)", *tor, map[bool]string{true: "isolate per-request", false: "off"}[useTor]))
	tgtStr := human(int64(*tgt))
	if *tgt <= 0 {
		tgtStr = paint(colYel, "∞ (UNLIMITED / NON-STOP)")
	}
	fmt.Println(paintf(colDim, "  [ > ] Target    : %s", tgtStr))
	fmt.Println()
	fmt.Println(paint(colCyan, "  [ Load "+*in+" please wait — Scanning subdomains ]"))
	fmt.Println()
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, os.Interrupt, syscall.SIGTERM)
	go func() {
		<-sigCh
		cliMu.Lock()
		fmt.Println(paint(colYel, "\n[!] Interrupted by user (Ctrl+C), flushing buffers and completing run..."))
		cliMu.Unlock()
		guiStop.Store(true)
		killAutoTor()
	}()
	// live progress bar
	start := time.Now()
	ticker := time.NewTicker(500 * time.Millisecond)
	stopTick := make(chan struct{})
	cliDone := make(chan struct{})
	go func() {
		var lastNonAnsi time.Time
		for {
			select {
			case <-ticker.C:
				n := guiFound.Load()
				tgtI := int64(*tgt)
				pct := 0.0
				if tgtI > 0 {
					pct = float64(n) / float64(tgtI) * 100
					if pct > 100 {
						pct = 100
					}
				}
				el := time.Since(start).Truncate(time.Millisecond)
				rate := float64(0)
				if el.Seconds() > 0 {
					rate = float64(n) / el.Seconds()
				}
				iter := guiIter.Load()
				q := int(guiQueue.Load())
				cliMu.Lock()
				if ansiOn {
					fmt.Print("\r\x1b[2K")
					if tgtI <= 0 {
						fmt.Printf("%s %s  %s  %s  %s  %s",
							paint(colPur, "[UNLIMITED LOOP]"),
							paint(colCyan, fmt.Sprintf("found %s/∞", human(n))),
							paint(colGrn, fmt.Sprintf("%.0f/s", rate)),
							paint(colYel, fmt.Sprintf("iter %s", human(iter))),
							paint(colDim, fmt.Sprintf("q %s", human(int64(q)))),
							paint(colDim, fmt.Sprintf("el %s", el.String())),
						)
					} else {
						fmt.Printf("%s %s %s  %s  %s  %s  %s",
							paint(colPur, "["+bar(pct, 24)+"]"),
							paint(colCyan, fmt.Sprintf("%5.1f%%", pct)),
							paint(colDim, fmt.Sprintf("%s/%s", human(n), human(tgtI))),
							paint(colGrn, fmt.Sprintf("%.0f/s", rate)),
							paint(colYel, fmt.Sprintf("iter %s", human(iter))),
							paint(colDim, fmt.Sprintf("q %s", human(int64(q)))),
							paint(colDim, fmt.Sprintf("el %s", el.String())),
						)
					}
				} else {
					now := time.Now()
					if now.Sub(lastNonAnsi) >= 3*time.Second || (tgtI > 0 && n >= tgtI) {
						lastNonAnsi = now
						if tgtI <= 0 {
							fmt.Printf("[progress] UNLIMITED (found %s, %.0f/s, iter %s, el %s)\n",
								human(n), rate, human(iter), el.String())
						} else {
							fmt.Printf("[progress] %5.1f%% (%s/%s, %.0f/s, iter %s, el %s)\n",
								pct, human(n), human(tgtI), rate, human(iter), el.String())
						}
					}
				}
				cliMu.Unlock()
			case <-stopTick:
				return
			case <-cliDone:
				return
			}
		}
	}()
	n, runErr := runMass(list, *tgt, *out, *tor, *workers, useTor, *modeFlag, *rotateIntervalFlag)
	ticker.Stop()
	close(stopTick)
	close(cliDone)
	cliMu.Lock()
	if ansiOn {
		fmt.Print("\r\x1b[2K\r")
	}
	cliMu.Unlock()
	if runErr != nil {
		fmt.Println(paint(colRed, "[!] "+runErr.Error()))
		os.Exit(1)
	}
	el := time.Since(start).Truncate(time.Millisecond)
	rate := float64(n) / el.Seconds()
	if el.Seconds() == 0 {
		rate = float64(n)
	}
	fmt.Println(paint(colGrn, fmt.Sprintf("[ Done ] %s unique subdomains saved -> %s (%.1f/s in %s)", human(n), *out, rate, el.String())))
	printApexSummary(15)
	if n == 0 {
		fmt.Println(paint(colYel, "[i] hint: jika semua +0, cek crt.name 429/free tier — pakai -tor 127.0.0.1:9050 -c 16 atau coba domain lain"))
	}
	_ = n
}
