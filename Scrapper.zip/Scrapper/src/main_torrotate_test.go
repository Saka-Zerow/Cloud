package main

import (
	"sync"
	"testing"
	"time"
)

// Kompromi S1/S2: singleflight per-ctrl harus non-blocking.
// Worker kedua yang datang saat ctrl sibuk / cooldown HARUS skip (false),
// bukan antri nunggu worker pertama.

// Guard: ctrl sedang in-flight -> skip tanpa dial.
func TestTorRotateCtrlSkipsWhenInFlight(t *testing.T) {
	ctrl := "127.0.0.1:19991"
	torRotateMu.Lock()
	torRotateFlight[ctrl] = true
	torRotateMu.Unlock()
	defer func() {
		torRotateMu.Lock()
		delete(torRotateFlight, ctrl)
		delete(torRotateLast, ctrl)
		torRotateMu.Unlock()
	}()
	start := time.Now()
	if torRotateCtrl(ctrl) {
		t.Fatalf("torRotateCtrl during in-flight should return false (skip)")
	}
	if el := time.Since(start); el > 500*time.Millisecond {
		t.Fatalf("skip harus cepat, got %v", el)
	}
}

// Guard: cooldown 10s -> skip tanpa dial.
func TestTorRotateCtrlSkipsDuringCooldown(t *testing.T) {
	ctrl := "127.0.0.1:19992"
	torRotateMu.Lock()
	torRotateLast[ctrl] = time.Now()
	torRotateMu.Unlock()
	defer func() {
		torRotateMu.Lock()
		delete(torRotateLast, ctrl)
		torRotateMu.Unlock()
	}()
	start := time.Now()
	if torRotateCtrl(ctrl) {
		t.Fatalf("torRotateCtrl during cooldown should return false (skip)")
	}
	if el := time.Since(start); el > 500*time.Millisecond {
		t.Fatalf("skip harus cepat, got %v", el)
	}
}

// Concurrent: N worker panggil ctrl sama -> maksimal 1 yang dial (sisanya skip).
// Ctrl tidak reachable sehingga yang dial pun return false; yang penting tidak ada yang blokir lama.
func TestTorRotateCtrlConcurrentNoBlock(t *testing.T) {
	ctrl := "127.0.0.1:19993"
	torRotateMu.Lock()
	delete(torRotateFlight, ctrl)
	delete(torRotateLast, ctrl)
	torRotateMu.Unlock()
	defer func() {
		torRotateMu.Lock()
		delete(torRotateFlight, ctrl)
		delete(torRotateLast, ctrl)
		torRotateMu.Unlock()
	}()
	var wg sync.WaitGroup
	start := time.Now()
	for i := 0; i < 5; i++ {
		wg.Add(1)
		go func() { defer wg.Done(); _ = torRotateCtrl(ctrl) }()
	}
	wg.Wait()
	// batas longgar: dial refused lokal cepat; yang penting 5 goroutine selesai tanpa deadlock.
	if el := time.Since(start); el > 15*time.Second {
		t.Fatalf("5 concurrent rotate terlalu lama: %v (potensi blocking)", el)
	}
}
