package main

import (
	"crypto/rand"
	"crypto/subtle"
	"encoding/hex"
	"fmt"
	"net/http"
	"os"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// Default secret token for admin, developer tools, and AI bot
// Empty default means a random token will be generated on first InitDebugToken call
const defaultDebugToken = ""

// Global debug token (can be overridden via flag or environment variable)
var debugToken = defaultDebugToken

// InitDebugToken configures the debug token with precedence: CLI flag > Env > Random.
//
// If no token is supplied and the CSPRNG fails, this is FAIL-CLOSED: the token
// stays empty so every token check rejects, instead of falling back to a
// predictable value (constant / PID / timestamp) an attacker could guess.
func InitDebugToken(flagToken string) {
	if flagToken != "" {
		debugToken = flagToken
		return
	}
	if env := os.Getenv("DEBUG_SECRET_TOKEN"); env != "" {
		debugToken = env
		return
	}
	if debugToken != "" {
		// Already initialised (e.g. by an earlier explicit call); keep it.
		return
	}

	// Generate a secure random token on first run if not explicitly set.
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		// FAIL-CLOSED: a broken CSPRNG must not degrade into a derivable
		// token (constant, PID, or clock based) — any of those would hand an
		// attacker a valid admin token. Leave it empty so secureTokenEqual
		// rejects every request until the operator supplies an explicit token
		// via -debug-token or DEBUG_SECRET_TOKEN.
		debugToken = ""
		fmt.Fprintf(os.Stderr, "[debug] WARNING: crypto/rand failed (%v); debug endpoints disabled until DEBUG_SECRET_TOKEN or -debug-token is set\n", err)
		return
	}
	debugToken = hex.EncodeToString(b)
}

// secureTokenEqual is constant-time comparison to prevent timing-oracle extraction
// of the debug token byte-by-byte. crypto/subtle guarantees the compare time
// does NOT early-exit on first mismatched byte.
func secureTokenEqual(a, b string) bool {
	if len(a) != len(b) {
		// still do a dummy compare so length alone doesn't leak via fast-path
		_ = subtle.ConstantTimeCompare([]byte(a), []byte(a))
		return false
	}
	return subtle.ConstantTimeCompare([]byte(a), []byte(b)) == 1
}

// ValidateDebugToken checks whether the incoming HTTP request has valid admin/bot authorization
func ValidateDebugToken(r *http.Request) bool {
	// 1. Check query parameter: ?token=...
	if tok := r.URL.Query().Get("token"); tok != "" && secureTokenEqual(tok, debugToken) {
		return true
	}
	// 2. Check HTTP header: X-Debug-Token: ...
	if tok := r.Header.Get("X-Debug-Token"); tok != "" && secureTokenEqual(tok, debugToken) {
		return true
	}
	// 3. Check Authorization: Bearer <token>
	auth := r.Header.Get("Authorization")
	if strings.HasPrefix(auth, "Bearer ") {
		if secureTokenEqual(strings.TrimPrefix(auth, "Bearer "), debugToken) {
			return true
		}
	}
	return false
}

// WorkerTelemetry tracks live status of an individual scraping worker thread
type WorkerTelemetry struct {
	ID           int       `json:"id"`
	State        string    `json:"state"` // IDLE, DNS_LOOKUP, CRT_FETCH, RAPID_FETCH, REVERSE_EXPAND, BACKOFF_429
	Domain       string    `json:"domain"`
	StartedAt    time.Time `json:"-"`
	ElapsedMs    int64     `json:"elapsedMs"`
	DomainsFound int64     `json:"domainsFound"`
	Errors       int64     `json:"errors"`
}

// FilterDecision records a single filter event for live audit inspection.
// at is the raw event time; Time is filled in when the snapshot is built so
// hot-path recording never pays for string formatting.
type FilterDecision struct {
	Time    string `json:"time"`
	Domain  string `json:"domain"`
	Rule    string `json:"rule"`
	Verdict string `json:"verdict"` // ACCEPT, DROP_INFRA, DROP_BIGTECH, DROP_PAAS, DROP_CPANEL, DROP_DHCP, DROP_PROV
	at      time.Time
}

// NetworkMetrics holds live network metrics
type NetworkMetrics struct {
	CRTRequests       int64  `json:"crtRequests"`
	CRTErrors         int64  `json:"crtErrors"`
	CRTLatencyMs      int64  `json:"crtLatencyMs"`
	CRT429Count       int64  `json:"crt429Count"`
	RapidRequests     int64  `json:"rapidRequests"`
	RapidErrors       int64  `json:"rapidErrors"`
	RapidLatencyMs    int64  `json:"rapidLatencyMs"`
	DNSRequests       int64  `json:"dnsRequests"`
	DNSErrors         int64  `json:"dnsErrors"`
	DNSLatencyMs      int64  `json:"dnsLatencyMs"`
	TorExitIP         string `json:"torExitIP"`
	TorSwitches       int64  `json:"torSwitches"`
	LastTorSwitchTime string `json:"lastTorSwitchTime"`
}

// SystemTelemetry holds Go runtime metrics
type SystemTelemetry struct {
	Goroutines  int     `json:"goroutines"`
	HeapAllocMB float64 `json:"heapAllocMB"`
	HeapSysMB   float64 `json:"heapSysMB"`
	NumGC       uint32  `json:"numGC"`
	GCPauseMs   float64 `json:"gcPauseMs"`
	GoVersion   string  `json:"goVersion"`
}

// DebugSnapshot represents the complete real-time JSON dump for AI bots and developer tools
type DebugSnapshot struct {
	Timestamp       string            `json:"timestamp"`
	UptimeSec       int64             `json:"uptimeSec"`
	ActiveWorkers   int               `json:"activeWorkers"`
	Workers         []WorkerTelemetry `json:"workers"`
	TotalEvaluated  int64             `json:"totalEvaluated"`
	TotalAccepted   int64             `json:"totalAccepted"`
	TotalDropped    int64             `json:"totalDropped"`
	DropBreakdown   map[string]int64  `json:"dropBreakdown"`
	RecentDecisions []FilterDecision  `json:"recentDecisions"`
	Network         NetworkMetrics    `json:"network"`
	QueueLen        int32             `json:"queueLen"`
	UniqueFound     int64             `json:"uniqueFound"`
	Target          int               `json:"target"`
	SpeedPerSec     float64           `json:"speedPerSec"`
	System          SystemTelemetry   `json:"system"`
}

// DebugHub manages in-memory telemetry, thread-safe rings, and atomic counters
type DebugHub struct {
	mu        sync.RWMutex
	startTime time.Time
	workers   map[int]*WorkerTelemetry
	// recentDecisions is a FIXED-LENGTH ring: new entries overwrite position
	// decNext, the oldest entry when decCount is full. This replaced an
	// append-on-slice with a front reslice each time the cap was hit, which
	// reallocated the whole 200-entry array roughly every 200th decision (and
	// also formatted the timestamp eagerly per call; the time is now a time.Time
	// formatted only when the snapshot serialises it).
	recentDecisions []FilterDecision
	ringSize        int
	decNext         int // next write slot
	decCount        int // valid entries (capped at ringSize)
	network         NetworkMetrics

	// Atomic counters for high-speed filter evaluation
	totalEvaluated int64
	totalAccepted  int64
	droppedInfra   int64
	droppedBigTech int64
	droppedPaaS    int64
	droppedCPanel  int64
	droppedDHCP    int64
	droppedProv    int64
	droppedSyntax  int64
}

var globalDebug = NewDebugHub(200)

// NewDebugHub initializes the central telemetry hub
func NewDebugHub(ringSize int) *DebugHub {
	if ringSize <= 0 {
		ringSize = 200
	}
	return &DebugHub{
		startTime:       time.Now(),
		workers:         make(map[int]*WorkerTelemetry),
		recentDecisions: make([]FilterDecision, ringSize),
		ringSize:        ringSize,
		network: NetworkMetrics{
			TorExitIP: "detecting...",
		},
	}
}

// SetWorkerState updates the current operation of a worker thread
func (h *DebugHub) SetWorkerState(id int, state, domain string) {
	h.mu.Lock()
	defer h.mu.Unlock()

	w, exists := h.workers[id]
	if !exists {
		w = &WorkerTelemetry{ID: id}
		h.workers[id] = w
	}
	w.State = state
	w.Domain = domain
	w.StartedAt = time.Now()
	w.ElapsedMs = 0
}

// RecordWorkerFound increments found counter for a worker
func (h *DebugHub) RecordWorkerFound(id int, count int) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if w, exists := h.workers[id]; exists {
		w.DomainsFound += int64(count)
	}
}

// RecordWorkerError increments error counter for a worker
func (h *DebugHub) RecordWorkerError(id int) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if w, exists := h.workers[id]; exists {
		w.Errors++
	}
}

// RecordFilterDecision logs a domain evaluation into the ring buffer and atomic tallies
func (h *DebugHub) RecordFilterDecision(domain, rule, verdict string) {
	atomic.AddInt64(&h.totalEvaluated, 1)
	switch verdict {
	case "ACCEPT":
		atomic.AddInt64(&h.totalAccepted, 1)
	case "DROP_INFRA":
		atomic.AddInt64(&h.droppedInfra, 1)
	case "DROP_BIGTECH":
		atomic.AddInt64(&h.droppedBigTech, 1)
	case "DROP_PAAS":
		atomic.AddInt64(&h.droppedPaaS, 1)
	case "DROP_CPANEL":
		atomic.AddInt64(&h.droppedCPanel, 1)
	case "DROP_DHCP":
		atomic.AddInt64(&h.droppedDHCP, 1)
	case "DROP_PROV":
		atomic.AddInt64(&h.droppedProv, 1)
	default:
		atomic.AddInt64(&h.droppedSyntax, 1)
	}

	h.mu.Lock()
	n := len(h.recentDecisions)
	if n > 0 {
		h.recentDecisions[h.decNext%n] = FilterDecision{
			Domain:  domain,
			Rule:    rule,
			Verdict: verdict,
			at:      time.Now(),
		}
		h.decNext = (h.decNext + 1) % n
		if h.decCount < n {
			h.decCount++
		}
	}
	h.mu.Unlock()
}

// RecordTorSwitch records a circuit change
func (h *DebugHub) RecordTorSwitch(newIP string) {
	h.mu.Lock()
	defer h.mu.Unlock()
	h.network.TorSwitches++
	if newIP != "" {
		h.network.TorExitIP = newIP
	}
	h.network.LastTorSwitchTime = time.Now().Format("15:04:05")
}

// RecordNetworkLatency records endpoint performance
func (h *DebugHub) RecordNetworkLatency(target string, latencyMs int64, statusCode int, isErr bool) {
	h.mu.Lock()
	defer h.mu.Unlock()
	switch target {
	case "crt":
		h.network.CRTRequests++
		if isErr {
			h.network.CRTErrors++
		}
		if statusCode == 429 {
			h.network.CRT429Count++
		}
		if latencyMs > 0 {
			if h.network.CRTLatencyMs == 0 {
				h.network.CRTLatencyMs = latencyMs
			} else {
				h.network.CRTLatencyMs = (h.network.CRTLatencyMs*4 + latencyMs) / 5
			}
		}
	case "rapid":
		h.network.RapidRequests++
		if isErr {
			h.network.RapidErrors++
		}
		if latencyMs > 0 {
			if h.network.RapidLatencyMs == 0 {
				h.network.RapidLatencyMs = latencyMs
			} else {
				h.network.RapidLatencyMs = (h.network.RapidLatencyMs*4 + latencyMs) / 5
			}
		}
	case "dns":
		h.network.DNSRequests++
		if isErr {
			h.network.DNSErrors++
		}
		if latencyMs > 0 {
			if h.network.DNSLatencyMs == 0 {
				h.network.DNSLatencyMs = latencyMs
			} else {
				h.network.DNSLatencyMs = (h.network.DNSLatencyMs*4 + latencyMs) / 5
			}
		}
	}
}

// cachedMemStats keeps one ReadMemStats result fresh for memStatsTTL so bursty
// Snapshot() callers (the 500ms debug SSE, /api/debug/snapshot, status polls)
// cannot force a stop-the-world ReadMemStats on every call. ReadMemStats stops
// all 100 worker goroutines to get its consistent view, so an uncached call on
// every HUD refresh was stalling the whole scraper twice a second in GUI mode.
// Values are identical; they are simply at most memStatsTTL old.
var (
	memStatsMu   sync.Mutex
	memStatsVal  runtime.MemStats
	memStatsWhen time.Time
)

const memStatsTTL = 2 * time.Second

func cachedMemStats() runtime.MemStats {
	now := time.Now()
	memStatsMu.Lock()
	defer memStatsMu.Unlock()
	if memStatsVal.HeapAlloc != 0 && now.Sub(memStatsWhen) < memStatsTTL {
		return memStatsVal
	}
	m := memStatsVal
	runtime.ReadMemStats(&m)
	memStatsVal, memStatsWhen = m, now
	return m
}

// Snapshot generates a complete point-in-time telemetry snapshot
func (h *DebugHub) Snapshot() DebugSnapshot {
	h.mu.RLock()
	defer h.mu.RUnlock()

	now := time.Now()
	uptime := int64(now.Sub(h.startTime).Seconds())

	// Build workers slice and calculate elapsed time
	workersSlice := make([]WorkerTelemetry, 0, len(h.workers))
	activeCount := 0
	for _, w := range h.workers {
		cp := *w
		if !w.StartedAt.IsZero() {
			cp.ElapsedMs = time.Since(w.StartedAt).Milliseconds()
		}
		if cp.State != "IDLE" && cp.State != "" {
			activeCount++
		}
		workersSlice = append(workersSlice, cp)
	}

	// Copy recent decisions (oldest first), filling Time from the raw stamp
	// recorded at capture time so the hot path never pays for formatting.
	decisionsCopy := make([]FilterDecision, 0, h.decCount)
	if n := len(h.recentDecisions); n > 0 && h.decCount > 0 {
		count := h.decCount
		if count > n {
			count = n
		}
		for i := 0; i < count; i++ {
			idx := (h.decNext - count + i + n*2) % n
			cp := h.recentDecisions[idx]
			cp.Time = cp.at.Format("15:04:05.000")
			decisionsCopy = append(decisionsCopy, cp)
		}
	}

	// Memory & runtime stats (cached: ReadMemStats stops the world, so a
	// fresh STW read for every Snapshot would stall all workers 2x/second).
	m := cachedMemStats()
	sys := SystemTelemetry{
		Goroutines:  runtime.NumGoroutine(),
		HeapAllocMB: float64(m.HeapAlloc) / 1024 / 1024,
		HeapSysMB:   float64(m.HeapSys) / 1024 / 1024,
		NumGC:       m.NumGC,
		GCPauseMs:   float64(m.PauseTotalNs) / 1e6,
		GoVersion:   runtime.Version(),
	}

	totalEval := atomic.LoadInt64(&h.totalEvaluated)
	totalAcc := atomic.LoadInt64(&h.totalAccepted)
	totalDrop := totalEval - totalAcc

	// Scraper progress values
	guiMu.Lock()
	found := guiFound.Load()
	queue := guiQueue.Load()
	target := int(guiTarget.Load())
	guiMu.Unlock()

	speed := 0.0
	if uptime > 0 && found > 0 {
		speed = float64(found) / float64(uptime)
	}

	return DebugSnapshot{
		Timestamp:      now.Format(time.RFC3339),
		UptimeSec:      uptime,
		ActiveWorkers:  activeCount,
		Workers:        workersSlice,
		TotalEvaluated: totalEval,
		TotalAccepted:  totalAcc,
		TotalDropped:   totalDrop,
		DropBreakdown: map[string]int64{
			"infra":   atomic.LoadInt64(&h.droppedInfra),
			"bigtech": atomic.LoadInt64(&h.droppedBigTech),
			"paas":    atomic.LoadInt64(&h.droppedPaaS),
			"cpanel":  atomic.LoadInt64(&h.droppedCPanel),
			"dhcp":    atomic.LoadInt64(&h.droppedDHCP),
			"prov":    atomic.LoadInt64(&h.droppedProv),
			"syntax":  atomic.LoadInt64(&h.droppedSyntax),
		},
		RecentDecisions: decisionsCopy,
		Network:         h.network,
		QueueLen:        queue,
		UniqueFound:     found,
		Target:          target,
		SpeedPerSec:     speed,
		System:          sys,
	}
}

// Reset clears per-run telemetry data
func (h *DebugHub) Reset() {
	h.mu.Lock()
	defer h.mu.Unlock()
	h.startTime = time.Now()
	h.workers = make(map[int]*WorkerTelemetry)
	h.decNext = 0
	h.decCount = 0
	atomic.StoreInt64(&h.totalEvaluated, 0)
	atomic.StoreInt64(&h.totalAccepted, 0)
	atomic.StoreInt64(&h.droppedInfra, 0)
	atomic.StoreInt64(&h.droppedBigTech, 0)
	atomic.StoreInt64(&h.droppedPaaS, 0)
	atomic.StoreInt64(&h.droppedCPanel, 0)
	atomic.StoreInt64(&h.droppedDHCP, 0)
	atomic.StoreInt64(&h.droppedProv, 0)
	atomic.StoreInt64(&h.droppedSyntax, 0)
}
