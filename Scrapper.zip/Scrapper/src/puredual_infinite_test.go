package main

import (
	"context"
	"sync/atomic"
	"testing"
)

func TestFormatTarget(t *testing.T) {
	if got := formatTarget(5000, false); got != "5000" {
		t.Fatalf("expected 5000, got %s", got)
	}
	if got := formatTarget(0, true); got != "∞" {
		t.Fatalf("expected ∞, got %s", got)
	}
	if got := formatTarget(-1, true); got != "∞" {
		t.Fatalf("expected ∞, got %s", got)
	}
}

func TestEnginePureDualConstant(t *testing.T) {
	if EnginePureDual != "puredual" {
		t.Fatalf("expected EnginePureDual to be 'puredual', got '%s'", EnginePureDual)
	}
}

func TestUnlimitedStopCondition(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	var done int32
	var count int64 = 5000
	target := 0 // Unlimited mode
	isUnlimited := target <= 0

	stop := func() bool {
		if atomic.LoadInt32(&done) == 1 || (!isUnlimited && atomic.LoadInt64(&count) >= int64(target)) || ctx.Err() != nil {
			cancel()
			return true
		}
		return false
	}

	if stop() {
		t.Fatalf("stop() returned true in unlimited mode with count=5000 and target=0")
	}

	// Verify it still stops on explicit done
	atomic.StoreInt32(&done, 1)
	if !stop() {
		t.Fatalf("stop() failed to return true when done flag is explicitly set")
	}
}
