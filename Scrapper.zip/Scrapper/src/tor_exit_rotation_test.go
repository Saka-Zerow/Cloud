package main

import (
	"net/http"
	"testing"
)

// F11 regression: EngineSmart runs fetchRapid + fetchCrtNameDirect as two
// goroutines on the SAME worker. When both hit a provider limit they both try to
// rotate. The loser must bail out of the rotation WITHOUT releasing the winner's
// claim — otherwise the release wipes the exit the winner just pinned and two
// workers can end up sharing one exit IP.
func TestRotationTryLockKeepsWinnerPin(t *testing.T) {
	defer exitUniq.release(41)
	w := &worker{id: 41, direct: &http.Client{}, client: &http.Client{}}
	w.useTor.Store(true)

	if !exitUniq.claim("$FP41", "203.0.113.41", 41) {
		t.Fatal("test setup: claim failed")
	}
	w.pinExit("w41_1_1", "$FP41", "203.0.113.41")

	// Simulate the sibling goroutine mid-rotation.
	w.rotating.Store(true)

	if w.rotateExit() {
		t.Error("rotateExit must no-op while a rotation is already in flight")
	}
	if !w.hasPin() {
		t.Error("blocked rotateExit released the pin it did not own")
	}
	if owner := exitUniq.owner("$FP41", "203.0.113.41"); owner != 41 {
		t.Errorf("blocked rotateExit unclaimed the winner's exit (owner=%d)", owner)
	}
	if c := w.rotateTorClient(); c == nil {
		t.Error("blocked rotateTorClient must still hand back a usable client")
	}
	if !w.hasPin() || exitUniq.owner("$FP41", "203.0.113.41") != 41 {
		t.Error("blocked rotateTorClient disturbed the in-flight rotation")
	}
	w.rotating.Store(false)

	// Lock free again: rotation proceeds. Without a control port the claim fails,
	// so the worker must end up unpinned and the registry entry freed.
	if w.rotateExit() {
		t.Error("rotateExit must report false when no unique exit could be claimed")
	}
	if w.hasPin() {
		t.Error("failed rotation left a stale pin")
	}
	if owner := exitUniq.owner("$FP41", "203.0.113.41"); owner != 0 {
		t.Errorf("exit stayed claimed after release (owner=%d)", owner)
	}
}

// F10 regression: a worker that fails its INITIAL claim still claims later (on
// the first limit-driven rotation), and workerFn now defers releaseExit
// unconditionally — which must be a safe no-op for a worker that never pinned.
func TestReleaseExitIsSafeWithoutPin(t *testing.T) {
	w := &worker{id: 42, direct: &http.Client{}, client: &http.Client{}}
	w.useTor.Store(true)

	w.releaseExit() // never claimed: must not panic nor touch the registry
	w.releaseExit() // idempotent

	// A claim happening LATER (during a rotation) must still be released.
	if !exitUniq.claim("$FP42", "203.0.113.42", 42) {
		t.Fatal("test setup: claim failed")
	}
	w.pinExit("w42_1_1", "$FP42", "203.0.113.42")
	w.releaseExit()
	if owner := exitUniq.owner("$FP42", "203.0.113.42"); owner != 0 {
		t.Errorf("late claim leaked in the registry (owner=%d)", owner)
	}
}

// F14 regression: the rotation loops derive `newBlocked` from
// `v2.blocked() || code != 200 || empty body`, then used to feed THAT into
// exitHealth.noteBlocked. A Tor circuit timeout (code -1) or a provider 5xx with
// no challenge markers therefore racked up strikes on a healthy exit relay — the
// "strike 5/3 ... (none)" spam seen in a live run. The rotation loops now strike
// only when v2.blocked() is true, which rests on this classification contract.
func TestTransportFailureDoesNotImplicateExit(t *testing.T) {
	for _, tc := range []struct {
		name      string
		src       apiSource
		code      int
		body      []byte
		wantBlock bool
	}{
		{"crt circuit timeout", srcCrtName, -1, nil, false},
		{"crt empty 200", srcCrtName, 200, nil, false},
		// A provider 5xx IS a verdict (classifyLimit maps code >= 500 to
		// rate-limit on purpose: through Tor those codes are what an unhappy
		// edge answers), so striking the exit stays allowed here. The bug this
		// test guards is the "none" verdict being punished.
		{"crt provider 500", srcCrtName, 500, []byte("<html>server error</html>"), true},
		{"rapid circuit timeout", srcRapidSub, -1, nil, false},
		{"rapid empty 200", srcRapidSub, 200, nil, false},
		{"rapid clean short page", srcRapidSub, 200, []byte("<html><body>no data</body></html>"), false},
		{"rapid 429 challenge", srcRapidSub, 429, nil, true},
		{"rapid cloudflare page", srcRapidSub, 200, []byte("<h1>Just a moment</h1>"), true},
		{"crt 429 rate", srcCrtName, 429, nil, true},
		{"crt cloudflare page", srcCrtName, 403, []byte("Attention Required! | Cloudflare"), true},
	} {
		v := classifyLimit(tc.src, tc.code, nil, tc.body)
		if got := v.blocked(); got != tc.wantBlock {
			t.Errorf("%s: blocked()=%v want=%v (kind=%q reason=%q)", tc.name, got, tc.wantBlock, v.Kind, v.Reason)
		}
	}
}

