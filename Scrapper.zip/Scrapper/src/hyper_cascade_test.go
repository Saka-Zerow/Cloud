package main

import (
	"context"
	"testing"
)

func TestHyperCascadeApexSeenDedup(t *testing.T) {
	shared := &sharedState{
		apexDone: make(map[string]bool),
		results: []string{
			"admin.corp-finance.co.id",
			"vpn.corp-finance.co.id",
			"portal.univ-brawijaya.ac.id",
			"api.fintech-gateway.com",
		},
	}

	ch := make(chan node, 100)
	reseeded := 0

	shared.mu.RLock()
	resSnapshot := append([]string(nil), shared.results...)
	shared.mu.RUnlock()

	for _, r := range resSnapshot {
		a := apexOf(r)
		if a == "" || inSkipZone(a) || isGarbageDomain(a) || !isValidDomain(a) || isInfraNoise(a) {
			continue
		}
		shared.mu.RLock()
		isDone := shared.apexDone[a]
		shared.mu.RUnlock()
		if isDone {
			continue
		}
		if _, loaded := shared.apexSeen.LoadOrStore(a, true); !loaded {
			select {
			case ch <- node{a, true, 0, "cascade"}:
				reseeded++
			default:
			}
		}
	}

	if reseeded != 3 {
		t.Fatalf("expected 3 unique apexes to be reseeded, got %d", reseeded)
	}

	// Secondary cascade on the same results should yield 0 because apexSeen is already populated
	reseeded2 := 0
	for _, r := range resSnapshot {
		a := apexOf(r)
		if a == "" || inSkipZone(a) || isGarbageDomain(a) || !isValidDomain(a) || isInfraNoise(a) {
			continue
		}
		if _, loaded := shared.apexSeen.LoadOrStore(a, true); !loaded {
			reseeded2++
		}
	}

	if reseeded2 != 0 {
		t.Fatalf("expected 0 reseeded on second run, got %d", reseeded2)
	}
}

func TestExpandReverseCDNPrioritization(t *testing.T) {
	// Verify that IsAnycastCDN correctly classifies Cloudflare and non-CDN
	if !IsAnycastCDN("104.21.45.10") {
		t.Errorf("104.21.45.10 should be CDN")
	}
	if IsAnycastCDN("103.247.12.45") {
		t.Errorf("103.247.12.45 should NOT be CDN")
	}
}

func TestAutonomousInfinityFeedSimulation(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	shared := &sharedState{
		apexDone: make(map[string]bool),
		results:  []string{"sub1.company.org", "sub2.enterprise.co.id"},
	}

	ch := make(chan node, 10)
	var qLen int64

	// Simulate re-seeder
	for _, r := range shared.results {
		a := apexOf(r)
		if _, loaded := shared.apexSeen.LoadOrStore(a, true); !loaded {
			ch <- node{a, true, 0, "cascade"}
			qLen++
		}
	}

	if qLen != 2 {
		t.Errorf("expected queue length 2, got %d", qLen)
	}

	// Drain
	select {
	case n := <-ch:
		if n.source != "cascade" {
			t.Errorf("expected source cascade, got %s", n.source)
		}
	case <-ctx.Done():
		t.Fatal("context canceled")
	}
}
