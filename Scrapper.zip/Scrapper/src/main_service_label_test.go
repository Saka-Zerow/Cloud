package main

import "testing"

// Regression for the filter audit (2026-09-27): several filters matched on the
// WHOLE domain string and dropped legitimate hosts that merely *contained* a
// noise token — the same class of bug as the cPanel service names.
//
//   - filterValid: strings.Contains(d,"dns")/("hash")/HasPrefix(d,"ns") dropped
//     cdn*/cdns ("cdns" contains "dns"), hashicorp (contains "hash") and the
//     ns1/ns2 nameservers (whitelistedShortTech already lists ns/dns/mx as
//     legitimate service terms).
//   - isGibberishLabel rule 1 dropped real short words with 'q' (qatar/iraq/qris).
//   - isInfraNoise flagged "mx1"/"gw1" although those are ordinary mail services.
func TestLegitServiceLabelsSurviveFilter(t *testing.T) {
	oldKeep := keepInfra
	keepInfra = false
	defer func() { keepInfra = oldKeep }()

	legit := []string{
		"cdn.acme.co.id",
		"cdnservice.acme.co.id",
		"cdns.acme.co.id",
		"cdn-edge.acme.co.id",
		"dns.acme.co.id",
		"dns1.acme.co.id",
		"ns1.acme.co.id",
		"ns2.acme.co.id",
		"nss.acme.co.id",
		"nsa.acme.co.id",
		"hashicorp.acme.co.id",
		"qatar.acme.co.id",
		"iraq.acme.co.id",
		"qris.acme.co.id",
		"mx1.acme.co.id",
		"gw1.acme.co.id",
	}

	kept := map[string]bool{}
	for _, d := range filterValid(legit) {
		kept[d] = true
	}
	for _, d := range legit {
		if !kept[d] {
			t.Errorf("legitimate host %q was dropped by the filters", d)
		}
	}

	// The reverse must still hold: auto-generated hash labels are dropped.
	gen := []string{
		"hash.acme.co.id",
		"hash1234.acme.co.id",
		"hash-9f2c.acme.co.id",
	}
	for _, d := range gen {
		if !isGeneratedDNSLabel(d[:len(d)-len("acme.co.id")-1]) {
			t.Errorf("isGeneratedDNSLabel(%q) = false, want true", d)
		}
		if got := filterValid([]string{d}); len(got) != 0 {
			t.Errorf("auto-generated hash host %q survived filterValid: %v", d, got)
		}
	}

	// DGA keysmash with 'q' must still be caught.
	for _, d := range []string{"qebixax.acme.co.id", "zxgqjkl.acme.co.id"} {
		if !isGarbageDomain(d) {
			t.Errorf("isGarbageDomain(%q) = false, want true (DGA keysmash)", d)
		}
	}
}
