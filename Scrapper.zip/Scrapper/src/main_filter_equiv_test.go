package main

import (
	"bufio"
	"math/rand"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// ── Filter equivalence guard (PERF round, 2026-09-22) ────────────────────────
//
// isInfraNoise / isBigTechOrPaaS / inSkipZone / isValidDomain were rewritten for
// speed (suffix sets instead of ~190 HasSuffix scans, digit/separator guards on
// the anchored regexes, no strings.Split allocations). Behaviour must stay
// identical — these tests compare the new code against verbatim copies of the
// previous implementations over a real-world corpus plus randomised and
// adversarial inputs.
//
// If you touch the filter, extend the corpus; do not "fix" the reference.

// ---- reference (pre-optimisation) implementations ----

func isValidDomainRef(d string) bool {
	d = strings.ToLower(strings.TrimSpace(d))
	if d == "example.com" || d == "example.org" || d == "example.net" ||
		strings.HasSuffix(d, ".example.com") || strings.HasSuffix(d, ".example.org") ||
		strings.HasSuffix(d, ".example.net") {
		return false
	}
	if d == "" || strings.Contains(d, " ") || strings.Contains(d, "@") || strings.Contains(d, "/") || strings.Contains(d, "\\") {
		return false
	}
	if !strings.Contains(d, ".") || strings.HasPrefix(d, ".") || strings.HasSuffix(d, ".") || strings.HasPrefix(d, "-") || strings.HasSuffix(d, "-") {
		return false
	}
	if strings.Contains(d, "..") {
		return false
	}
	for _, r := range d {
		if !((r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') || r == '-' || r == '_' || r == '.') {
			return false
		}
	}
	parts := strings.Split(d, ".")
	if len(parts[len(parts)-1]) < 2 || len(parts[len(parts)-1]) > 24 {
		return false
	}
	if len(d) > 253 {
		return false
	}
	return true
}

func isBigTechOrPaaSRef(d string) bool {
	d = strings.ToLower(strings.TrimSpace(d))
	d = strings.TrimPrefix(d, "*.")
	d = strings.TrimSuffix(d, ".")
	if d == "" {
		return false
	}
	for _, sfx := range freePaaSSuffixes {
		if d == sfx || strings.HasSuffix(d, "."+sfx) {
			return true
		}
	}
	for _, sfx := range spamBlogSuffixes {
		if d == sfx || strings.HasSuffix(d, "."+sfx) {
			return true
		}
	}
	apex := apexOf(d)
	if bigTechApexes[apex] {
		return true
	}
	if strings.HasPrefix(apex, "google.") || strings.HasPrefix(apex, "amazon.") || strings.HasPrefix(apex, "blogspot.") {
		return true
	}
	return false
}

func inSkipZoneRef(d string) bool {
	if isBigTechOrPaaSRef(d) {
		return true
	}
	d = strings.ToLower(d)
	for _, z := range expandSkipZones {
		if d == z || strings.HasSuffix(d, "."+z) {
			return true
		}
	}
	return false
}

func isInfraNoiseRef(d string) bool {
	d = strings.ToLower(strings.TrimSpace(d))
	parts := strings.Split(d, ".")
	if len(parts) < 3 {
		return false
	}
	for _, lbl := range parts {
		if lbl == "www" || lbl == "mail" || lbl == "api" || lbl == "blog" || lbl == "db" || lbl == "app" || lbl == "auth" || lbl == "portal" || lbl == "admin" || lbl == "vpn" || lbl == "k8s" || strings.HasPrefix(lbl, "k8s-") ||
			lbl == "cpanel" || lbl == "webmail" || lbl == "webdisk" || lbl == "whm" || lbl == "cpcontacts" || lbl == "cpcalendars" || lbl == "autodiscover" || lbl == "autoconfig" || lbl == "ftp" || lbl == "ns1" || lbl == "ns2" || lbl == "ns3" || lbl == "ns4" || lbl == "mx" || lbl == "smtp" || lbl == "pop" || lbl == "imap" || lbl == "dev" || lbl == "staging" || lbl == "test" || lbl == "panel" {
			continue
		}
		if dhcpUserRe.MatchString(lbl) {
			return true
		}
		if uuidRe.MatchString(lbl) {
			return true
		}
		if cpanelAutoRe.MatchString(lbl) {
			return true
		}
		if deviceNameRe.MatchString(lbl) {
			return true
		}
		if composerClusterRe.MatchString(lbl) {
			return true
		}
		if isEphemeralHash(lbl) {
			return true
		}
		if digitsHyphenInfraRe.MatchString(lbl) {
			return true
		}
		if endingInfraRe.MatchString(lbl) {
			return true
		}
		if digitsPrefixInfraRe.MatchString(lbl) {
			return true
		}
		if hexHashLongRe.MatchString(lbl) {
			return true
		}
		if hostingNodeRe.MatchString(lbl) {
			return true
		}
		for _, pfx := range []string{"vps", "vm", "srv", "server", "dedi", "dedicated", "vds", "node", "host",
			"ded", "cc", "secure", "ecbiz", "biz", "advanced", "sudo", "elite", "ld", "ecngx", "gs", "ngx", "sb", "bizdev", "amsngx", "ecld",
			"reseller", "shared", "semi", "ftp", "webdisk", "whm", "cprwhois", "cpanelproxy", "cp",
			"hub", "lhcp", "lhwp", "cl", "authsmtp", "hostingmysql", "hostingsmtp", "forwardlnxsmtp", "webmailsmtp", "delete", "cluster", "box"} {
			if lbl != pfx && strings.HasPrefix(lbl, pfx) {
				suffix := lbl[len(pfx):]
				if len(suffix) > 0 && suffix[0] >= '0' && suffix[0] <= '9' {
					return true
				}
			}
		}
		for _, p := range infraWordPrefixes {
			if strings.HasPrefix(lbl, p) && hasDigit(lbl[len(p):]) {
				return true
			}
		}
		if smallDigitSuffixRe.MatchString(lbl) {
			if !strings.HasPrefix(lbl, "ns") && !strings.HasPrefix(lbl, "www") && !strings.HasPrefix(lbl, "mail") && !strings.HasPrefix(lbl, "api") && !strings.HasPrefix(lbl, "blog") && !strings.HasPrefix(lbl, "db") && !strings.HasPrefix(lbl, "app") && !strings.HasPrefix(lbl, "auth") && !strings.HasPrefix(lbl, "portal") && !strings.HasPrefix(lbl, "admin") && !strings.HasPrefix(lbl, "vpn") && !strings.HasPrefix(lbl, "k8s") && !strings.HasPrefix(lbl, "mx") && !strings.HasPrefix(lbl, "gw") {
				return true
			}
		}
		if m := highDigitsRe.FindStringSubmatch(lbl); len(m) == 2 {
			digits := m[1]
			if !(len(digits) == 4 && (strings.HasPrefix(digits, "199") || strings.HasPrefix(digits, "20"))) {
				return true
			}
		}
	}
	return false
}

// ---- corpus ----

// filterEquivCorpus returns real-world + adversarial + randomised domains.
func filterEquivCorpus(t *testing.T) []string {
	t.Helper()
	seen := map[string]bool{}
	var out []string
	add := func(s string) {
		s = strings.Trim(s, "\r")
		s = strings.TrimSpace(s)
		if s == "" || len(s) > 260 || seen[s] {
			return
		}
		seen[s] = true
		out = append(out, s)
	}

	// 1. Real hostnames scraped by this tool (out_*.txt / res*.txt artifacts).
	dirs := []string{".", "..", filepath.Join("..", "lab"), filepath.Join("..", "results"), filepath.Join("..", "seeds")}
	scanned := 0
	for _, dir := range dirs {
		entries, err := os.ReadDir(dir)
		if err != nil {
			continue
		}
		for _, e := range entries {
			if e.IsDir() || scanned >= 400000 {
				continue
			}
			n := e.Name()
			if !strings.HasPrefix(n, "out_") && !strings.HasPrefix(n, "res") && !strings.HasSuffix(n, ".txt") {
				continue
			}
			f, err := os.Open(filepath.Join(dir, n))
			if err != nil {
				continue
			}
			sc := bufio.NewScanner(f)
			sc.Buffer(make([]byte, 0, 64*1024), 1<<20)
			for sc.Scan() {
				line := strings.TrimSpace(sc.Text())
				if line == "" || strings.HasPrefix(line, "#") || strings.ContainsAny(line, " \t|[]()") {
					continue
				}
				add(line)
				scanned++
			}
			f.Close()
		}
	}

	// 2. Adversarial edge cases around the exact checks that were optimised.
	for _, d := range filterEquivEdgeCases() {
		add(d)
	}

	// 3. Randomised labels/domains biased towards the patterns under test.
	rnd := rand.New(rand.NewSource(20260922))
	for i := 0; i < 30000; i++ {
		add(genRandomDomain(rnd))
	}
	return out
}

func filterEquivEdgeCases() []string {
	return []string{
		"", ".", "..", "...", "a", "a.b", "a.b.c", "a..b.c", ".a.b.c", "a.b.c.", "-a.b.c", "a.b.c-",
		"*.a.b.c", "*.pages.dev", "pages.dev", "sub.pages.dev", "x.y.pages.dev",
		"example.com", "www.example.com", "sub.example.org", "example.net",
		"1e100.net", "x.1e100.net", "google.com", "a.google.com", "google.co.id", "a.google.co.id",
		"cdn.example.co.uk", "A.B.C.D", "MiXeD.CaSe.ExAmPlE.CoM", "a.b.c.d.e.f.g.h.i.j.k.l",
		"l02f00a2.webpac.example.com", "lf36ac31.ezproxy.example.com", "tempurl.a.b",
		"vps.example.com", "vps9858.example.com", "v.example.com", "v1.example.com", "ww1.example.com",
		"ns4.example.com", "hosting-01.a.b", "webpac.a.b", "ezproxy.a.b",
		"net2-user1.a.b", "user12.a.b", "hauser99.a.b", "husstudent3.a.b", "dorm4.a.b",
		"1797edfa-99ee-4751-a06d-c8cb25751a08.a.b", "39df27aa95f14a23b3f68b231afcda82-ro.a.b",
		"android-53d0119dd87ad8c5.a.b", "laptop-du6it9pr.a.b", "erins-iphone.a.b",
		"schumann02.a.b", "vivaldi47.a.b", "serverdahlia2.a.b", "vpshostfal37.a.b",
		"hub1105.a.b", "dev101.a.b", "icls2024.a.b", "cacs2020.a.b", "a2024.b",
		"aa.a.b", "z9.a.b", "9z.a.b", "zz99.a.b", "abcdefgh.a.b", "abcdef77777777.a.b",
		"a_b.c.d", "a-b.c.d", "a-b-c-d.e.f", "s-k-farm-yard.hbz2.net",
		"cpanel.a.b", "webmail.a.b", "whm.a.b", "cpcalendars.a.b", "cyberpanel-x.a.b", "vm-soundwave.a.b",
		"220-server.a.b", "0110api.a.b", "5045aovpn.a.b", "vmsrv05-node06.a.b", "vmsrv-server.a.b",
		"saas.a.b", "x.y.duckdns.org", "foo.freehostia.com", "a.no-ip.org", "a.eu.cc",
		"blog.example.hr", "x.wixsite.com", "a.mpeblog.com", "aaa.camzania.com",
		"verylonglabel-" + strings.Repeat("x", 200) + ".a.b",
	}
}

// genRandomDomain builds a domain that stresses the filter's auto-generated
// hostname heuristics (digits, hashes, separators, panel prefixes).
func genRandomDomain(rnd *rand.Rand) string {
	words := []string{"www", "mail", "api", "blog", "db", "app", "auth", "portal", "admin", "vpn", "k8s",
		"vps", "vm", "srv", "server", "host", "node", "dedi", "shared", "cp", "cl", "cc", "box", "hub",
		"cpanel", "webmail", "whm", "tempurl", "webpac", "ezproxy", "hosting", "panel", "school", "assets"}
	tlds := []string{"com", "id", "co.id", "ac.id", "go.id", "co.uk", "net", "org", "io", "dev", "my"}
	const hexChars = "0123456789abcdef"

	n := 1 + rnd.Intn(3)
	labels := make([]string, 0, n+2)
	for i := 0; i < n; i++ {
		switch rnd.Intn(9) {
		case 0:
			labels = append(labels, words[rnd.Intn(len(words))])
		case 1:
			labels = append(labels, words[rnd.Intn(len(words))]+itoa(rnd.Intn(99999)))
		case 2:
			labels = append(labels, words[rnd.Intn(len(words))]+"-"+words[rnd.Intn(len(words))])
		case 3:
			b := make([]byte, 4+rnd.Intn(30))
			for j := range b {
				b[j] = hexChars[rnd.Intn(len(hexChars))]
			}
			labels = append(labels, string(b))
		case 4:
			labels = append(labels, "l"+strings.Repeat("f", 7+rnd.Intn(3)))
		case 5:
			b := make([]byte, 36)
			for j := range b {
				if j == 8 || j == 13 || j == 18 || j == 23 {
					b[j] = '-'
					continue
				}
				b[j] = hexChars[rnd.Intn(len(hexChars))]
			}
			labels = append(labels, string(b))
		case 6:
			labels = append(labels, strings.Repeat(string(rune('a'+rnd.Intn(26))), 1+rnd.Intn(2))+itoa(1+rnd.Intn(99)))
		case 7:
			labels = append(labels, "android-"+strings.Repeat("a", 8))
		default:
			b := make([]byte, 1+rnd.Intn(12))
			for j := range b {
				b[j] = byte('a' + rnd.Intn(26))
				if rnd.Intn(6) == 0 {
					b[j] = byte('0' + rnd.Intn(10))
				}
				if rnd.Intn(12) == 0 {
					b[j] = "-_"[rnd.Intn(2)]
				}
			}
			labels = append(labels, string(b))
		}
	}
	labels = append(labels, "example"+itoa(rnd.Intn(50)), tlds[rnd.Intn(len(tlds))])
	return strings.Join(labels, ".")
}

// itoa lives in main_task002_validation_test.go (shared test helper).

// ---- equivalence tests ----

func TestFilterCorpusIsReal(t *testing.T) {
	corpus := filterEquivCorpus(t)
	if len(corpus) < 1000 {
		t.Fatalf("equivalence corpus looks degenerate (%d entries) — the guard tests below would be meaningless", len(corpus))
	}
}

func TestIsInfraNoiseMatchesReference(t *testing.T) {
	for _, d := range filterEquivCorpus(t) {
		if got, want := isInfraNoise(d), isInfraNoiseRef(d); got != want {
			t.Fatalf("isInfraNoise(%q) = %v, reference = %v", d, got, want)
		}
	}
}

func TestIsBigTechOrPaaSSuffixMatchesReference(t *testing.T) {
	for _, d := range filterEquivCorpus(t) {
		if got, want := isBigTechOrPaaS(d), isBigTechOrPaaSRef(d); got != want {
			t.Fatalf("isBigTechOrPaaS(%q) = %v, reference = %v", d, got, want)
		}
	}
}

func TestInSkipZoneMatchesReference(t *testing.T) {
	for _, d := range filterEquivCorpus(t) {
		if got, want := inSkipZone(d), inSkipZoneRef(d); got != want {
			t.Fatalf("inSkipZone(%q) = %v, reference = %v", d, got, want)
		}
	}
}

func TestIsValidDomainMatchesReference(t *testing.T) {
	for _, d := range filterEquivCorpus(t) {
		if got, want := isValidDomain(d), isValidDomainRef(d); got != want {
			t.Fatalf("isValidDomain(%q) = %v, reference = %v", d, got, want)
		}
	}
}

// TestSuffixSetMatchesHasSuffix pins the suffixSet semantics directly.
func TestSuffixSetMatchesHasSuffix(t *testing.T) {
	lists := map[string][]string{
		"expandSkipZones": expandSkipZones,
		"freePaaS":        freePaaSSuffixes,
		"spamBlog":        spamBlogSuffixes,
	}
	probes := []string{"", ".", "a", "google.com", "x.google.com", "xgoogle.com", "google.com.evil.net",
		"UP.GOOGLE.COM", "a.b.pages.dev", "pages.dev", "notpages.dev", "x.duckdns.org", "duckdns.org",
		"blog.hr", "sub.blog.hr", "notblog.hr", "a.up.railway.app", "up.railway.app", "x.up.railway.app."}
	for name, list := range lists {
		set := newSuffixSet(list)
		for _, d := range probes {
			want := false
			for _, z := range list {
				if d == z || strings.HasSuffix(d, "."+z) {
					want = true
					break
				}
			}
			if got := set.has(d); got != want {
				t.Errorf("%s.has(%q) = %v, want %v", name, d, got, want)
			}
		}
	}
}
