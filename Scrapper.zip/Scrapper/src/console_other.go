//go:build !windows

package main

import "os/exec"

// enableVirtualTerminal: on non-Windows platforms the terminal already speaks
// ANSI, so initTerminal only needs the generic isatty check.
func enableVirtualTerminal() bool { return false }

// hideWindow is a no-op off Windows (no console-window flag to set).
func hideWindow(cmd *exec.Cmd) { _ = cmd }
