package main

import (
	"os"
	"sync"
	"testing"
)

// Live contract check for the rapiddns scraper. Opt-in because it needs a real
// local Tor SOCKS port and outbound network:
//
//	RAPIDDNS_LIVE=1 go test -run TestLiveFetchRapid -v
//
// It asserts the behavior the scraper is built around: a single request per
// apex (rapiddns ignores ?page for guests), the guest table is parsed, and the
// /sameip/ links are harvested for reverse-IP expansion.
func TestLiveFetchRapidThroughTor(t *testing.T) {
	if os.Getenv("RAPIDDNS_LIVE") != "1" {
		t.Skip("set RAPIDDNS_LIVE=1 with local Tor on 127.0.0.1:9050 to run")
	}
	client, direct, ok, addr := newTorClient(defaultTorSocks, 0, true)
	if !ok {
		t.Skipf("Tor not reachable at %s", defaultTorSocks)
	}
	w := &worker{
		client:  client,
		direct:  direct,
		shared:  &sharedState{harvestedIPs: sync.Map{}},
		torAddr: addr,
	}
	w.useTor.Store(true)

	got := w.fetchRapidWithIPSwitch("unpad.ac.id")
	if len(got) == 0 {
		t.Fatalf("live rapiddns returned 0 hosts (Cloudflare challenge or parse regression)")
	}
	sample := got
	if len(sample) > 5 {
		sample = sample[:5]
	}
	t.Logf("live rapiddns: %d hosts, sample %v", len(got), sample)

	harvested := 0
	w.shared.harvestedIPs.Range(func(_, _ any) bool { harvested++; return true })
	if harvested == 0 {
		t.Errorf("expected /sameip IPs to be harvested from the subdomain page")
	}

	// unpad.ac.id advertises thousands of subdomains while a guest only gets
	// 100 rows, so the cap detector must fire and remember the worst case.
	if w.shared.rapidCapped == 0 {
		t.Errorf("expected the rapiddns guest cap to be detected for %d hosts", len(got))
	}
	t.Logf("guest cap: %d lookup, largest advertised total %d (example %s)",
		w.shared.rapidCapped, w.shared.rapidCappedTotal, w.shared.rapidCappedEx)
}
