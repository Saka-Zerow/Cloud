package main

import (
	"testing"
	"time"
)

// --- Guards added for "stuck dan lambat di target ratusan ribu" ---------------
//
// Every test here pins ONE of the multiplicative costs that used to appear per
// target or per IP, because at 500k targets even a per-apex 5s stall is days of
// runtime. They are cheap, pure-unit checks (no Tor, no network).

// A "/24 sweep" must stop after subnetHostBudget hosts, otherwise each processed
// neighbour proposes more neighbours and the IP queue grows without bound.
func TestAllowSubnetHostCapsPerSlash24(t *testing.T) {
	s := &sharedState{subnetSwept: map[string]int{}}
	// Four different hosts inside 10.0.0.0/24: the first subnetHostBudget are
	// allowed, the rest are refused.
	allowed := 0
	for i := 2; i < 2+subnetHostBudget+8; i++ {
		ip := "10.0.0." + itoaTest(i)
		if s.allowSubnetHost(ip) {
			allowed++
		}
	}
	if allowed != subnetHostBudget {
		t.Fatalf("allowed %d hosts in one /24, want %d", allowed, subnetHostBudget)
	}
	// A DIFFERENT /24 still has its own budget.
	if !s.allowSubnetHost("10.0.1.2") {
		t.Error("neighbour /24 refused: per-/24 budget must not leak across subnets")
	}
}

// The global ceiling must stop a run that sees thousands of distinct racks.
func TestAllowSubnetHostGlobalBudget(t *testing.T) {
	s := &sharedState{subnetSwept: map[string]int{}, subnetsTaken: subnetCountBudget}
	if s.allowSubnetHost("192.0.2.5") {
		t.Error("host accepted past the global /24 budget")
	}
}

// Non-IPv4 and malformed input must be refused, never swept.
func TestAllowSubnetHostRejectsBadInput(t *testing.T) {
	s := &sharedState{subnetSwept: map[string]int{}}
	for _, ip := range []string{"", "not-an-ip", "2001:db8::1", "example.com"} {
		if s.allowSubnetHost(ip) {
			t.Errorf("allowSubnetHost(%q) = true, want false", ip)
		}
	}
}

// "+1 only" re-scans use their OWN small budget and must not consume the
// limitRescanMax budget that real provider blocks depend on.
func TestNoteSuspectApexSeparateBudget(t *testing.T) {
	s := &sharedState{}
	if got := s.noteSuspectApex("example.com"); got != 1 {
		t.Fatalf("first suspect booking = %d, want 1", got)
	}
	if got := s.noteSuspectApex("example.com"); got != 2 {
		t.Fatalf("second suspect booking = %d, want 2", got)
	}
	// The real-block counter is untouched by the above.
	if spent, allowed := s.noteLimitedApex("example.com"); spent != 1 || !allowed {
		t.Fatalf("noteLimitedApex = (%d,%v), want (1,true): suspect bookings must be tracked separately", spent, allowed)
	}
	// And a nil state must not panic (offline helpers call it).
	var nilState *sharedState
	if got := nilState.noteSuspectApex("example.com"); got != suspectRescanMax {
		t.Errorf("nil state returned %d, want %d", got, suspectRescanMax)
	}
}

// The suspect budget must be far smaller than the real-block budget: this ratio
// IS the fix (one thin answer must not inherit the 24h-quota retry allowance).
func TestSuspectBudgetSmallerThanLimitBudget(t *testing.T) {
	if suspectRescanMax >= limitRescanMax {
		t.Errorf("suspectRescanMax (%d) must be smaller than limitRescanMax (%d)", suspectRescanMax, limitRescanMax)
	}
	if crtNameRotateAttempts >= 4 {
		t.Errorf("crtNameRotateAttempts = %d: the fetch-level rotation budget must stay tight", crtNameRotateAttempts)
	}
}

// The hot-path wildcard probe must be much cheaper than the offline analyzer's,
// because it runs INSIDE handleNode and can fire twice per new apex.
func TestWildcardProbeBudgetsTightenHotPath(t *testing.T) {
	if wildcardProbeBudgetFast >= wildcardProbeBudget {
		t.Errorf("fast probe budget %v must be tighter than the analyzer budget %v",
			wildcardProbeBudgetFast, wildcardProbeBudget)
	}
	if wildcardProbeBudgetFast > time.Second {
		t.Errorf("fast probe budget %v is too large to sit inside a 3.5s provider budget", wildcardProbeBudgetFast)
	}
}

// isWildcardDomainWith must honour an expired/near-zero budget instead of
// blocking: a probe that cannot answer in time is treated as non-wildcard.
func TestIsWildcardDomainWithTinyBudget(t *testing.T) {
	// A budget of 1ns guarantees the request context is already done, so the
	// probe must return fast (false) rather than hang on the network.
	start := time.Now()
	got := isWildcardDomainWith(nil, "probe-budget.example.com", time.Nanosecond)
	if elapsed := time.Since(start); elapsed > 2*time.Second {
		t.Errorf("probe took %v with a 1ns budget: budget is not enforced", elapsed)
	}
	if got {
		t.Error("a failed probe must report non-wildcard (scan the apex, do not drop it)")
	}
}

// claimRackHost is what makes the expander's rack fallback quiesce: it must be
// atomic (dedup + budget in one critical section) and a denied host must stay
// un-scanned so ipDone keeps meaning "actually scanned".
func TestClaimRackHostAtomicDedupAndBudget(t *testing.T) {
	s := &sharedState{ipDone: map[string]bool{}, subnetSwept: map[string]int{}}

	if !s.claimRackHost("198.51.100.10") {
		t.Fatal("first claim refused")
	}
	if !s.ipDone["198.51.100.10"] {
		t.Error("claimed host not marked ipDone")
	}
	if s.claimRackHost("198.51.100.10") {
		t.Error("second claim of the same host succeeded (dedup broken)")
	}

	// Same /24, host #2..#subnetHostBudget allowed.
	allowed := 1
	for i := 11; i < 11+subnetHostBudget+5; i++ {
		if s.claimRackHost("198.51.100." + itoaTest(i)) {
			allowed++
		}
	}
	if allowed != subnetHostBudget {
		t.Errorf("claimed %d hosts in one /24, want %d", allowed, subnetHostBudget)
	}

	// A different rack must still be claimable: the per-/24 budget must not leak
	// into its neighbours, and the global rack budget is nowhere near exhausted.
	if !s.claimRackHost("203.0.113.7") {
		t.Error("fresh /24 refused: per-/24 budget leaked into a neighbouring rack")
	}
	if !s.ipDone["203.0.113.7"] {
		t.Error("cross-rack claim did not mark ipDone")
	}

	// Exhaust the global rack budget and confirm denial leaves ipDone untouched.
	full := &sharedState{ipDone: map[string]bool{}, subnetSwept: map[string]int{}, subnetsTaken: subnetCountBudget}
	if full.claimRackHost("192.0.2.5") {
		t.Error("claim accepted past the global /24 budget")
	}
	if full.ipDone["192.0.2.5"] {
		t.Error("budget-denied host was marked ipDone: it was never scanned")
	}
}

// Malformed input must be refused without panicking.
func TestClaimRackHostRejectsBadInput(t *testing.T) {
	s := &sharedState{ipDone: map[string]bool{}, subnetSwept: map[string]int{}}
	for _, ip := range []string{"", "not-an-ip", "2001:db8::1"} {
		if s.claimRackHost(ip) {
			t.Errorf("claimRackHost(%q) = true, want false", ip)
		}
	}
	var nilState *sharedState
	if nilState.claimRackHost("192.0.2.1") {
		t.Error("nil state must refuse")
	}
}

func itoaTest(n int) string {
	if n == 0 {
		return "0"
	}
	var b [12]byte
	i := len(b)
	for n > 0 {
		i--
		b[i] = byte('0' + n%10)
		n /= 10
	}
	return string(b[i:])
}
