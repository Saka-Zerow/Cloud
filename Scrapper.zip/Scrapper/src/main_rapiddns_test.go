package main

import (
	"fmt"
	"net/http"
	"net/http/httptest"
	"regexp"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
)

// rapiddnsTable renders a page shaped like the live rapiddns guest page:
// a `Domain | Type | Date` table plus the `/sameip/{IP}#result` footer links
// the scraper harvests passive IPs from.
func rapiddnsTable(domains []string, harvestIPs []string) string {
	var b strings.Builder
	b.WriteString("<!doctype html><html><body>")
	b.WriteString("<table><thead><tr><th>Domain</th><th>Type</th><th>Date</th></tr></thead><tbody>")
	for _, d := range domains {
		b.WriteString("<tr><td>" + d + "</td><td>A</td><td>2026-09-14</td></tr>")
	}
	b.WriteString("</tbody></table>")
	for _, ip := range harvestIPs {
		b.WriteString(`<a href="/sameip/` + ip + `#result">` + ip + `</a>`)
	}
	b.WriteString("</body></html>")
	return b.String()
}

// newRapidTestWorker builds a Tor-off worker wired to a test server client.
func newRapidTestWorker(direct *http.Client) *worker {
	return &worker{
		direct: direct,
		client: direct,
		shared: &sharedState{harvestedIPs: sync.Map{}},
	}
}

func withRapidBase(t *testing.T, base string) {
	t.Helper()
	orig := rapidBaseURL
	rapidBaseURL = base
	t.Cleanup(func() { rapidBaseURL = orig })
}

// TestParseRapidHTMLByteLevelMatchesStringLevel pins that the byte-level
// parseRapidHTML extraction (PERF: FindAllSubmatch on the page buffer instead
// of copying it to a string first) returns exactly the same hosts as the
// pattern did before. The table deliberately mixes valid rows with the footer
// false-positive links and malformed cells.
func TestParseRapidHTMLByteLevelMatchesStringLevel(t *testing.T) {
	body := []byte(`<html><body><table>
<tr><td>1</td><td>api.example.com</td><td><a href="/sameip/1.2.3.4#result">1.2.3.4</a></td></tr>
<tr><td>2</td><td>CDN.Example.COM</td><td><a href="/sameip/1.2.3.4#result">1.2.3.4</a></td></tr>
<tr><td>3</td><td>pornhub.com</td><td>footer link noise</td></tr>
<tr><td>4</td><td>not a domain!</td><td>x</td></tr>
<tr><td>5</td><td>vps9858.example.com</td><td>infra spam</td></tr>
</table></body></html>`)
	want := map[string]bool{}
	for _, m := range tdRe.FindAllStringSubmatch(string(body), -1) {
		if len(m) >= 2 {
			want[m[1]] = true
		}
	}
	gotHosts := parseRapidHTML(body)
	if len(gotHosts) == 0 {
		t.Fatalf("parseRapidHTML returned nothing, want a subset of %v", want)
	}
	for _, h := range gotHosts {
		if !want[h] && !want[strings.ToLower(h)] {
			t.Fatalf("parseRapidHTML returned %q, not present in the raw tdRe extraction", h)
		}
	}
}

func TestFetchRapidParsesTableAndHarvestsIPs(t *testing.T) {
	var hits int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		atomic.AddInt32(&hits, 1)
		if !strings.HasPrefix(r.URL.Path, "/subdomain/") {
			http.NotFound(w, r)
			return
		}
		if r.URL.Query().Get("full") != "1" {
			t.Errorf("missing full=1 in query: %q", r.URL.RawQuery)
		}
		if ua := r.Header.Get("User-Agent"); !strings.Contains(ua, "Chrome/") {
			t.Errorf("expected a full browser UA, got %q", ua)
		}
		_, _ = w.Write([]byte(rapiddnsTable(
			[]string{"a.rapidmock.invalid", "b.rapidmock.invalid", "A.RapidMock.Invalid"},
			[]string{"203.0.113.7", "203.0.113.8"},
		)))
	}))
	defer srv.Close()
	withRapidBase(t, srv.URL)

	w := newRapidTestWorker(srv.Client())
	got := w.fetchRapidWithIPSwitch("rapidmock.invalid")

	found := map[string]bool{}
	for _, d := range got {
		found[d] = true
	}
	if !found["a.rapidmock.invalid"] || !found["b.rapidmock.invalid"] {
		t.Errorf("fetchRapid missing expected hosts, got %v", got)
	}
	// rapiddns ignores `page` for guests: exactly ONE request per apex, and the
	// page-1 results must never be dropped (regression: 429 on a second page
	// used to discard them).
	if n := atomic.LoadInt32(&hits); n != 1 {
		t.Errorf("expected exactly 1 rapiddns request, got %d", n)
	}
	harvested := 0
	w.shared.harvestedIPs.Range(func(_, _ any) bool { harvested++; return true })
	if harvested != 2 {
		t.Errorf("expected 2 harvested IPs, got %d", harvested)
	}
}

func TestFetchRapidChallengeYieldsNoData(t *testing.T) {
	var hits int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		atomic.AddInt32(&hits, 1)
		w.WriteHeader(http.StatusTooManyRequests)
		_, _ = w.Write([]byte("<html><body>Just a moment... Enable JavaScript and cookies to continue</body></html>"))
	}))
	defer srv.Close()
	withRapidBase(t, srv.URL)

	// Tor off: one attempt only, no wasted retries, no panic.
	w := newRapidTestWorker(srv.Client())
	if got := w.fetchRapidWithIPSwitch("blocked.invalid"); got != nil {
		t.Errorf("expected nil on Cloudflare challenge, got %v", got)
	}
	if n := atomic.LoadInt32(&hits); n != 1 {
		t.Errorf("expected 1 request when Tor is off, got %d", n)
	}
}

func TestFetchRapidEmptyTableAndServerError(t *testing.T) {
	cases := []struct {
		name string
		code int
		body string
	}{
		{"empty table", http.StatusOK, rapiddnsTable(nil, nil)},
		{"server error", http.StatusInternalServerError, "boom"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				w.WriteHeader(tc.code)
				_, _ = w.Write([]byte(tc.body))
			}))
			defer srv.Close()
			withRapidBase(t, srv.URL)

			if got := newRapidTestWorker(srv.Client()).fetchRapidWithIPSwitch("empty.invalid"); len(got) != 0 {
				t.Errorf("expected no hosts, got %v", got)
			}
		})
	}
}

func TestFetchSameIPParsesRows(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !strings.HasPrefix(r.URL.Path, "/sameip/") {
			http.NotFound(w, r)
			return
		}
		_, _ = w.Write([]byte(rapiddnsTable(
			[]string{"co.tenant.invalid", "other.invalid"},
			nil,
		) + "<table><tr><td>1.2.3.4</td><td>A</td></tr></table>"))
	}))
	defer srv.Close()
	withRapidBase(t, srv.URL)

	got := newRapidTestWorker(srv.Client()).fetchSameIP("203.0.113.7")
	found := map[string]bool{}
	for _, d := range got {
		found[d] = true
	}
	if !found["co.tenant.invalid"] || !found["other.invalid"] {
		t.Errorf("fetchSameIP missing expected hosts, got %v", got)
	}
	for _, d := range got {
		if d == "1.2.3.4" {
			t.Errorf("fetchSameIP must drop IP literals, got %v", got)
		}
	}
}

func TestFetchSameIPNonOKYieldsNoData(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusServiceUnavailable)
	}))
	defer srv.Close()
	withRapidBase(t, srv.URL)

	if got := newRapidTestWorker(srv.Client()).fetchSameIP("203.0.113.7"); len(got) != 0 {
		t.Errorf("expected no hosts on 503, got %v", got)
	}
}

func TestFetchSameIPReportsAdvertisedGap(t *testing.T) {
	// 200 page with NO parseable rows but a large advertised total: the table was
	// truncated/blocked or the layout changed. That must be surfaced, not
	// reported as a "clean IP".
	page := `<meta name="description" content="Discover 5,000 domains hosted on IP 203.0.113.7.">` +
		rapiddnsTable(nil, nil)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(page))
	}))
	defer srv.Close()
	withRapidBase(t, srv.URL)

	w := newRapidTestWorker(srv.Client())
	if got := w.fetchSameIP("203.0.113.7"); len(got) != 0 {
		t.Fatalf("expected 0 hosts, got %v", got)
	}
	if w.shared.rapidCapped != 1 {
		t.Errorf("rapidCapped = %d, want 1 (advertised 5000, parsed 0)", w.shared.rapidCapped)
	}
	if w.shared.rapidCappedTotal != 5000 {
		t.Errorf("rapidCappedTotal = %d, want 5000", w.shared.rapidCappedTotal)
	}
}

func TestFetchSameIPRejectsNonIP(t *testing.T) {
	if got := newRapidTestWorker(http.DefaultClient).fetchSameIP("not-an-ip"); got != nil {
		t.Errorf("expected nil for non-IP input, got %v", got)
	}
}

func TestRapidAdvertisedTotal(t *testing.T) {
	cases := []struct {
		name string
		body string
		re   *regexp.Regexp
		want int
	}{
		{
			"subdomains with thousands separator",
			`<meta name="description" content="Found 3,519 subdomains for unpad.ac.id on RapidDNS. View detailed DNS r">`,
			rapidTotalSubRe, 3519,
		},
		{
			"sameip domains",
			`<meta name="description" content="Discover 3 domains hosted on IP 111.223.252.103.">`,
			rapidTotalIPRe, 3,
		},
		{"no meta", `<html></html>`, rapidTotalSubRe, 0},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if got := rapidAdvertisedTotal([]byte(tc.body), tc.re); got != tc.want {
				t.Errorf("rapidAdvertisedTotal = %d, want %d", got, tc.want)
			}
		})
	}
}

func TestFetchRapidReportsGuestCap(t *testing.T) {
	// 100 numbered rows + an advertised total of 3519 = the live guest-cap shape.
	// Names stay alphabetic so the junk filters (high-digits, ephemeral hash)
	// do not drop the fixture rows.
	domains := make([]string, 0, rapidGuestRowCap)
	for i := 0; i < rapidGuestRowCap; i++ {
		domains = append(domains, fmt.Sprintf("n%c%c%c.capped.invalid",
			'a'+i/676%26, 'a'+i/26%26, 'a'+i%26))
	}
	page := `<meta name="description" content="Found 3,519 subdomains for capped.invalid on RapidDNS.">` +
		rapiddnsTable(domains, nil)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(page))
	}))
	defer srv.Close()
	withRapidBase(t, srv.URL)

	w := newRapidTestWorker(srv.Client())
	if got := w.fetchRapidWithIPSwitch("capped.invalid"); len(got) != rapidGuestRowCap {
		t.Fatalf("expected %d hosts, got %d", rapidGuestRowCap, len(got))
	}
	if w.shared.rapidCapped != 1 {
		t.Errorf("rapidCapped = %d, want 1", w.shared.rapidCapped)
	}
	if w.shared.rapidCappedTotal != 3519 {
		t.Errorf("rapidCappedTotal = %d, want 3519", w.shared.rapidCappedTotal)
	}
	if w.shared.rapidCappedEx != "capped.invalid" {
		t.Errorf("rapidCappedEx = %q, want capped.invalid", w.shared.rapidCappedEx)
	}
}

func TestFetchRapidDoesNotFlagCompleteResults(t *testing.T) {
	page := `<meta name="description" content="Found 2 subdomains for small.invalid on RapidDNS.">` +
		rapiddnsTable([]string{"a.small.invalid", "b.small.invalid"}, nil)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(page))
	}))
	defer srv.Close()
	withRapidBase(t, srv.URL)

	w := newRapidTestWorker(srv.Client())
	if got := w.fetchRapidWithIPSwitch("small.invalid"); len(got) != 2 {
		t.Fatalf("expected 2 hosts, got %d", len(got))
	}
	if w.shared.rapidCapped != 0 {
		t.Errorf("rapidCapped = %d, want 0 (results were complete)", w.shared.rapidCapped)
	}
}

// TestRapidCapMessagesRender guards the two user-facing strings: a wrong number
// of format verbs would surface as "%!d(MISSING)" in the console/GUI.
func TestRapidCapMessagesRender(t *testing.T) {
	// per-apex GUI line
	w := newRapidTestWorker(http.DefaultClient)
	w.shared.mu.Lock()
	w.shared.rapidCappedTotal = 0
	w.shared.mu.Unlock()
	guiMu.Lock()
	guiEntries = nil
	guiMu.Unlock()

	w.noteRapidCap("unpad.ac.id", 100, 3519, "subdomain")
	guiMu.Lock()
	entries := append([]guiEntry(nil), guiEntries...)
	guiEntries = nil
	guiMu.Unlock()
	if len(entries) != 1 {
		t.Fatalf("expected 1 GUI entry, got %d", len(entries))
	}
	if msg := entries[0].Msg; strings.Contains(msg, "%!") || !strings.Contains(msg, "3519") {
		t.Errorf("bad per-apex cap message: %q", msg)
	}

	// end-of-run summary
	reportRapidGuestCap(w.shared)
	guiMu.Lock()
	entries = append([]guiEntry(nil), guiEntries...)
	guiEntries = nil
	guiMu.Unlock()
	if len(entries) != 1 {
		t.Fatalf("expected 1 summary entry, got %d", len(entries))
	}
	msg := entries[0].Msg
	if strings.Contains(msg, "%!") {
		t.Errorf("summary has format verb mismatch: %q", msg)
	}
	for _, want := range []string{"unpad.ac.id", "3519", "guest cap"} {
		if !strings.Contains(msg, want) {
			t.Errorf("summary %q missing %q", msg, want)
		}
	}

	// nothing to report -> no entry, no noise
	reportRapidGuestCap(&sharedState{})
	guiMu.Lock()
	n := len(guiEntries)
	guiEntries = nil
	guiMu.Unlock()
	if n != 0 {
		t.Errorf("expected no summary entry when nothing was capped, got %d", n)
	}
}

func TestWorkerTorAndAPIAccessors(t *testing.T) {
	var nilWorker *worker
	if nilWorker.torOn() {
		t.Error("nil worker must report Tor off")
	}
	if nilWorker.api() != "" {
		t.Error("nil worker must report empty api")
	}
	nilWorker.setLastAPI("x") // must not panic
	nilWorker.disableTor()    // must not panic

	w := &worker{}
	if w.torOn() {
		t.Error("fresh worker must default to Tor off")
	}
	w.useTor.Store(true)
	if !w.torOn() {
		t.Error("torOn must reflect Store(true)")
	}
	w.disableTor()
	if w.torOn() {
		t.Error("disableTor must turn Tor off")
	}
	w.setLastAPI("rapiddns")
	if w.api() != "rapiddns" {
		t.Errorf("api() = %q, want rapiddns", w.api())
	}
}

func TestDataAnalystSubdomainsSurviveFiltering(t *testing.T) {
	domains := []string{
		"www.dataanalyst.id",
		"webmail.dataanalyst.id",
		"webdisk.dataanalyst.id",
		"mail.dataanalyst.id",
		"dataanalyst.id",
		"cpcontacts.dataanalyst.id",
		"cpcalendars.dataanalyst.id",
		"cpanel.dataanalyst.id",
	}
	html := rapiddnsTable(domains, []string{"103.150.190.100"})
	parsed := parseRapidHTML([]byte(html))
	filtered := filterSubdomains(parsed, "dataanalyst.id")

	found := make(map[string]bool)
	for _, d := range filtered {
		found[d] = true
	}

	for _, d := range domains {
		if !found[d] {
			t.Errorf("expected %s to survive filtering and parsing, but was dropped!", d)
		}
	}
	if len(filtered) != len(domains) {
		t.Errorf("expected %d subdomains, got %d (%v)", len(domains), len(filtered), filtered)
	}
}
