//go:build windows

package main

import (
	"os"
	"os/exec"
	"syscall"
	"unsafe"
)

// enableVirtualTerminal turns on ANSI escape processing for the Windows
// console. Returns false when stdout is not a console (or the call fails), in
// which case initTerminal falls back to the generic isatty check.
func enableVirtualTerminal() bool {
	handle := syscall.Handle(os.Stdout.Fd())
	var mode uint32
	k32 := syscall.NewLazyDLL("kernel32.dll")
	getConsoleMode := k32.NewProc("GetConsoleMode")
	setConsoleMode := k32.NewProc("SetConsoleMode")
	r1, _, _ := getConsoleMode.Call(uintptr(handle), uintptr(unsafe.Pointer(&mode)))
	if r1 == 0 {
		return false
	}
	const enableVirtualTerminalProcessing = 0x0004
	setConsoleMode.Call(uintptr(handle), uintptr(mode|enableVirtualTerminalProcessing))
	return true
}

// hideWindow runs a child process without popping up a console window.
func hideWindow(cmd *exec.Cmd) {
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
}
