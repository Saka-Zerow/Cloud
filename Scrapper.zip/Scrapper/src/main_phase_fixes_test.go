package main

import (
	"context"
	"testing"
)

func TestNoReverseFlagReturnsZero(t *testing.T) {
	oldNoReverse := noReverse
	defer func() { noReverse = oldNoReverse }()

	noReverse = true
	w := &worker{
		shared: &sharedState{},
	}
	ch := make(chan node, 10)
	var qLen int64 = 0

	added := expandReverse(w, ch, &qLen, 100, context.Background())
	if added != 0 {
		t.Errorf("expandReverse should return 0 immediately when noReverse is true, got: %d", added)
	}
}

func TestIsValidDomainWithUnderscores(t *testing.T) {
	domains := []string{
		"_dmarc.company.com",
		"_domainkey.company.com",
		"_sip._tcp.company.com",
		"sub_domain.company.com",
	}
	for _, d := range domains {
		if !isValidDomain(d) {
			t.Errorf("isValidDomain(%q) should be true for valid RFC 2181 DNS records with underscore", d)
		}
	}
}

func TestIsProvisioningSpam_PreservesVMAndBoxAndWeb(t *testing.T) {
	legit := []string{
		"vm.company.com",
		"box.company.com",
		"web.company.com",
		"db.company.com",
		"api.company.com",
		"ns1.company.com",
		"ns2.company.com",
	}
	for _, d := range legit {
		if isProvisioningSpam(d) {
			t.Errorf("isProvisioningSpam(%q) should be false (legitimate domain)", d)
		}
	}

	spam := []string{
		"vps1234.hosting.com",
		"vm102.hosting.com",
		"box99.hosting.com",
	}
	for _, d := range spam {
		if !isProvisioningSpam(d) {
			t.Errorf("isProvisioningSpam(%q) should be true for hosting provisioning spam", d)
		}
	}
}
