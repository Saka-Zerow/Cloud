package main

import (
	"fmt"
	"testing"
)

// --- Guards for the "makin lama makin lambat" fix ----------------------------
//
// The scrape must stay fast as the result pool grows. Two properties make that
// true and are pinned here: the pool is ring-bounded (flat memory), and every
// background sweep reads a constant number of entries per tick (flat CPU).

// The sample pool must never exceed resultsSampleCap, and it must keep the most
// recent entries (the ones whose apexes have not been expanded yet).
func TestAppendResultBoundsSamplePool(t *testing.T) {
	s := &sharedState{}
	total := resultsSampleCap * 2
	for i := 0; i < total; i++ {
		s.appendResult(fmt.Sprintf("host%d.example.com", i))
	}
	if len(s.results) > resultsSampleCap {
		t.Fatalf("pool grew to %d, want <= %d", len(s.results), resultsSampleCap)
	}
	if len(s.results) < resultsSampleCap/2 {
		t.Fatalf("pool shrank to %d, want >= %d (must keep a usable sample)", len(s.results), resultsSampleCap/2)
	}
	// Most-recent entry must survive; the oldest must be gone.
	last := fmt.Sprintf("host%d.example.com", total-1)
	if s.results[len(s.results)-1] != last {
		t.Fatalf("last pool entry = %q, want the newest %q", s.results[len(s.results)-1], last)
	}
	seenOldest := false
	for _, d := range s.results {
		if d == "host0.example.com" {
			seenOldest = true
			break
		}
	}
	if seenOldest {
		t.Error("oldest entry survived a full pool: ring is not dropping from the front")
	}
}

// A pool that never crosses the cap must be left completely intact (no data loss
// for runs that stay small).
func TestAppendResultKeepsSmallPoolIntact(t *testing.T) {
	s := &sharedState{}
	for i := 0; i < 1000; i++ {
		s.appendResult(fmt.Sprintf("h%d.example.org", i))
	}
	if len(s.results) != 1000 {
		t.Fatalf("pool len = %d, want 1000 (small pools must not be trimmed)", len(s.results))
	}
}

// The per-tick scan budgets must be positive and smaller than the pool, so a
// single sweep is genuinely constant-cost and not O(pool).
func TestBackgroundScanBudgetsAreConstant(t *testing.T) {
	if cascadeScanPerTick <= 0 || cascadeScanPerTick > resultsSampleCap {
		t.Errorf("cascadeScanPerTick = %d, want 1..%d", cascadeScanPerTick, resultsSampleCap)
	}
	if expandScanPerCall <= 0 || expandScanPerCall > resultsSampleCap {
		t.Errorf("expandScanPerCall = %d, want 1..%d", expandScanPerCall, resultsSampleCap)
	}
	if ipDoneScanPerCall <= 0 {
		t.Errorf("ipDoneScanPerCall = %d, want > 0", ipDoneScanPerCall)
	}
	if harvestedDrainPerCall <= 0 {
		t.Errorf("harvestedDrainPerCall = %d, want > 0", harvestedDrainPerCall)
	}
}

// BenchmarkAppendResultSteadyState measures the per-append cost once the pool is
// full: it must stay flat (amortized O(1)) instead of degrading as the run grows.
func BenchmarkAppendResultSteadyState(b *testing.B) {
	s := &sharedState{}
	// Pre-fill to the cap so every append below is on the steady-state path.
	for i := 0; i < resultsSampleCap; i++ {
		s.appendResult("warmup.example.com")
	}
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		s.appendResult("steady.example.com")
	}
}
