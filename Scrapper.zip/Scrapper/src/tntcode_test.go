package main

import (
	"strings"
	"testing"
	"time"
)

// --- tntcode reverse-IP source (offline unit tests) --------------------------
//
// The live endpoint returns up to ~100k hostnames in a <textarea>. These tests
// pin the parser against a synthetic page so a layout regression is caught
// without network access. Verified live 2026-10-03: 99,919 hostnames, ~3s,
// gzip-served; fetchTntcode yielded 91,644 after filtering.

func TestParseTntcodeTextarea(t *testing.T) {
	page := strings.Join([]string{
		`<!doctype html><html><head><title>Domains on ip 1.2.3.4</title></head>`,
		`<body>`,
		`<h1>100000 domains on IP 1.2.3.4 (4.3.2.1.host.example.net)</h1>`,
		`<table><tbody><tr><td>delicious.com</td></tr></tbody></table>`,
		`<a href="/domain/anchor.example.com">anchor</a>`,
		`    <textarea cols="50" rows="10">first.example.com`,
		`second.co.id`,
		`third-hop.example.org`,
		`not a domain line`,
		`<script>bad tag line</script>`,
		`    </textarea>`,
		`</body></html>`,
	}, "\n")

	got := parseTntcodeTextarea(strings.NewReader(page))
	set := map[string]bool{}
	for _, d := range got {
		set[d] = true
	}
	for _, want := range []string{
		"first.example.com", "second.co.id", "third-hop.example.org", "anchor.example.com",
	} {
		if !set[want] {
			t.Errorf("missing %q in %v", want, got)
		}
	}
	for _, bad := range []string{"not a domain line", "bad tag line"} {
		if set[bad] {
			t.Errorf("parser kept junk line %q", bad)
		}
	}
}

// A page with only the anchor form (no textarea) must still yield data, so a
// layout change does not silently kill the source.
func TestParseTntcodeAnchorsFallback(t *testing.T) {
	page := `<html><body>` +
		`<a href="/domain/delicious.com">x</a>` +
		`<a href="/domain/egypttoday.co.uk">y</a>` +
		`</body></html>`
	got := parseTntcodeTextarea(strings.NewReader(page))
	if len(got) != 2 {
		t.Fatalf("anchor fallback returned %v, want 2 domains", got)
	}
}

// filterValidBatch's DGA clustering is O(sum group^2); a large payload must skip
// that pass so a 100k-hostname list stays fast. This is the guard that keeps
// tntcode's payload from turning into minutes of CPU.
func TestFilterValidBatchLargeInputIsFast(t *testing.T) {
	in := make([]string, 0, 60000)
	// Same-length (>7) alphabetic subdomain labels, which would form one huge
	// length-group. No digits/hyphens so they pass the individual garbage rules.
	for i := 0; i < 60000; i++ {
		lbl := "abcdefgh" + string(rune('a'+i%26)) + string(rune('a'+(i/26)%26))
		in = append(in, lbl+".example.com")
	}
	start := time.Now()
	out := filterValidBatch(in)
	elapsed := time.Since(start)
	if len(out) == 0 {
		t.Fatal("filterValidBatch dropped every domain")
	}
	if elapsed > 5*time.Second {
		t.Fatalf("filterValidBatch took %v on %d inputs: DGA guard missing?", elapsed, len(in))
	}
	t.Logf("filterValidBatch(%d) -> %d in %v", len(in), len(out), elapsed.Round(time.Millisecond))
}
