package main

import (
	"errors"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

// timeUntil reports the remaining seconds of a context deadline.
func timeUntil(dl time.Time) float64 { return time.Until(dl).Seconds() }

// ── getRetry liveness / fallback regression ──────────────────────────────────

type failRoundTripFunc func(*http.Request) (*http.Response, error)

func (f failRoundTripFunc) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

// TestGetRetryDirectFallbackBodyReadable guards the direct-fallback rescue path
// of getRetry. The old code called directCancel() immediately before returning
// the 200 response, and because http.Client.Do only reads the response headers,
// the caller's io.ReadAll(resp.Body) was always cancelled — the rescue path
// returned an "ok" response with an unreadable body, i.e. it could never rescue
// anything (a silent 0-result bug behind a 30s stall).
//
// The worker's Tor endpoint is a listener that accepts and instantly closes
// (SOCKS5 handshake -> EOF). EOF is deliberately neither "connection refused"
// nor in isConnRefused's list, otherwise the first attempt would switch the
// worker to direct mode and bypass the fallback under test.
func TestGetRetryDirectFallbackBodyReadable(t *testing.T) {
	const payload = `[{"sub":"a.example.com"}]`
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte(payload))
	}))
	defer srv.Close()

	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	defer ln.Close()
	go func() {
		for {
			c, err := ln.Accept()
			if err != nil {
				return
			}
			c.Close()
		}
	}()

	ww := &worker{
		id:      1,
		client:  &http.Client{Transport: failRoundTripFunc(func(*http.Request) (*http.Response, error) { return nil, errors.New("i/o timeout") })},
		direct:  srv.Client(),
		torAddr: ln.Addr().String(),
	}
	ww.useTor.Store(true)

	// The URL must be the test server's own URL: httptest.Server.Client()'s
	// transport only rewrites requests addressed to that server.
	resp, err := ww.getRetry(srv.URL + "/v1/search?apex=example.com&format=json")
	if err != nil {
		t.Fatalf("getRetry: %v — the direct fallback should have rescued this", err)
	}
	defer resp.Body.Close()
	b, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatalf("reading fallback body: %v (the context was cancelled before the body read)", err)
	}
	if string(b) != payload {
		t.Fatalf("fallback body = %q, want %q", string(b), payload)
	}
	if !ww.torOn() {
		t.Fatalf("worker must still be on Tor after a non-connection-refused failure")
	}
}

// TestGetRetryAttemptUsesPerRequestDeadline pins that each attempt carries its
// own context deadline (crtAttemptTimeout), so a stalled stream cannot park a
// worker on the client's 30s timeout. A request context with a deadline is what
// makes ctx.Err() observable from inside the transport.
func TestGetRetryAttemptUsesPerRequestDeadline(t *testing.T) {
	var sawDeadline bool
	var budget = -1.0
	ww := &worker{
		direct: &http.Client{Transport: failRoundTripFunc(func(r *http.Request) (*http.Response, error) {
			if dl, ok := r.Context().Deadline(); ok {
				sawDeadline = true
				budget = timeUntil(dl)
			}
			return nil, errors.New("i/o timeout")
		})},
	}
	resp, err := ww.getRetry("https://example.invalid/x")
	if resp != nil {
		resp.Body.Close()
	}
	if err == nil {
		t.Fatalf("expected getRetry to fail against a failing transport")
	}
	if !sawDeadline {
		t.Fatalf("attempt context had no deadline — a stalled request would sit on the 30s client timeout")
	}
	if budget <= 0 || budget > crtAttemptTimeout.Seconds()+1 {
		t.Fatalf("attempt deadline budget = %.1fs, want ~%.0fs", budget, crtAttemptTimeout.Seconds())
	}
}
