package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// TestPostProcessAction_Dispatch mengunci pemetaan aksi menu 2 (post-processing)
// ke fungsi yang dipanggil. Kasus dipilih supaya tidak butuh jaringan: "0" tidak
// menyentuh apa pun, "1" pakai file kosong (tanpa apex -> tanpa probe wildcard),
// "2" murni baca+tally, dan path tak ada hanya menguji nilai baliknya.
func TestPostProcessAction_Dispatch(t *testing.T) {
	dir := t.TempDir()
	missing := filepath.Join(dir, "tidak-ada.txt")

	if cleaned, analyzed := postProcessAction(missing, "0"); cleaned || analyzed {
		t.Fatalf("aksi 0 harus batal, dapat cleaned=%v analyzed=%v", cleaned, analyzed)
	}
	if _, err := os.Stat(missing + ".clean.txt"); !os.IsNotExist(err) {
		t.Fatalf("aksi 0 seharusnya tidak menulis .clean.txt (err=%v)", err)
	}

	empty := filepath.Join(dir, "kosong.txt")
	if err := os.WriteFile(empty, nil, 0o644); err != nil {
		t.Fatal(err)
	}
	cleaned, analyzed := postProcessAction(empty, "1")
	if !cleaned || analyzed {
		t.Fatalf("aksi 1 harus clean saja, dapat cleaned=%v analyzed=%v", cleaned, analyzed)
	}
	// cleanOutput menulis di samping file input dengan ekstensi DIBUANG:
	// kosong.txt -> kosong.clean.txt / kosong.junk.txt.
	base := strings.TrimSuffix(empty, filepath.Ext(empty))
	if _, err := os.Stat(base + ".clean.txt"); err != nil {
		t.Fatalf("aksi 1 tidak menulis .clean.txt: %v", err)
	}
	if _, err := os.Stat(base + ".junk.txt"); err != nil {
		t.Fatalf("aksi 1 tidak menulis .junk.txt: %v", err)
	}

	if cleaned, analyzed := postProcessAction(empty, "2"); cleaned || !analyzed {
		t.Fatalf("aksi 2 harus analisis saja, dapat cleaned=%v analyzed=%v", cleaned, analyzed)
	}

	// "" (Enter) dan "3" sama-sama berarti kedua tahap.
	for _, act := range []string{"", "3"} {
		if cleaned, analyzed := postProcessAction(missing, act); !cleaned || !analyzed {
			t.Fatalf("aksi %q harus dua tahap, dapat cleaned=%v analyzed=%v", act, cleaned, analyzed)
		}
	}
}
