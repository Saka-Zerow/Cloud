package main

import (
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

// Task 001/PERF-001 (Session 2) — verifies retryBackoff pacing and that
// getRetry actually retries transient 429 responses with backoff.

func TestRetryBackoff(t *testing.T) {
	cases := []struct {
		attempt int
		want    time.Duration
	}{
		{0, 200 * time.Millisecond},
		{1, 400 * time.Millisecond},
		{2, 800 * time.Millisecond},
		{3, 1600 * time.Millisecond},
		{4, 2 * time.Second},  // capped
		{5, 2 * time.Second},  // capped
		{10, 2 * time.Second}, // capped
	}
	for _, c := range cases {
		got := retryBackoff(c.attempt)
		if got != c.want {
			t.Errorf("retryBackoff(%d) = %v, want %v", c.attempt, got, c.want)
		}
	}
}

func TestGetRetryRetriesOn429(t *testing.T) {
	var hits int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		hits++
		if hits < 2 {
			w.WriteHeader(http.StatusTooManyRequests)
			return
		}
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("ok"))
	}))
	defer srv.Close()

	// direct client, no Tor: getRetry should retry attempt 0 (fail 429) then succeed on attempt 1.
	ww := &worker{direct: srv.Client(), client: srv.Client()}
	resp, err := ww.getRetry(srv.URL)
	if err != nil {
		t.Fatalf("getRetry: unexpected error after retry: %v", err)
	}
	if resp.StatusCode != 200 {
		t.Fatalf("expected 200 after retry, got %d", resp.StatusCode)
	}
	resp.Body.Close()
	if hits != 2 {
		t.Errorf("expected 2 server hits (1 fail + 1 success), got %d", hits)
	}
}
