package main

import (
	"net/http"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// --- Per-API limit detection & cooldown (limit-detector hardening) -----------
//
// Facts verified live on 2026-09-29 from this machine (curl + local Tor fleet):
//
//	crt.name  (https://crt.name/v1/search?apex=example.com&format=json)
//	  HTTP/1.1 429 Too Many Requests
//	  Retry-After: 86400
//	  X-Ratelimit-Limit: 100
//	  X-Ratelimit-Remaining: 0
//	  free tier limit reached: 100 requests per IP per day. Supply an API token
//	  for unmetered access.
//
//	=> the quota is PER EXIT IP and refreshes after 24h (Retry-After: 86400).
//	   The SAME second, the same request through a fresh Tor SOCKS identity
//	   (socks5h://prod1:x@127.0.0.1:9052) returned 200 OK with
//	   X-Ratelimit-Remaining: 95 — i.e. a NEW IP is a NEW quota. That is
//	   exactly why the scraper must SWITCH IP, not sleep 24h.
//	   X-Ratelimit-Remaining lets us rotate the exit BEFORE the wall
//	   (remaining<=3), so no request is wasted on a doomed 429.
//
//	rapiddns (https://rapiddns.io/pricing, verified)
//	  Anonymous (guest) = "Max 100 records (1 page)" and "First page only";
//	  Free (GitHub login) = "Max 1,000 records (100 pages)".
//	  Live page probe: `Found 3519 subdomains` advertised in the meta
//	  description while the table stops at 100 rows (400 <td> cells) and prints
//	  "Limited Access: You are using RapidDNS as a guest".
//	  => the 100-row ceiling is a HARD service cap for guests, NOT a rate limit,
//	     and ?page=N is ignored (verified byte-identical pages).
//	  Blocking shows up as a Cloudflare challenge (429/403 "Just a moment...")
//	  which is sticky PER EXIT IP for a short while (minutes, not hours).
//	  There is no documented HTML cooldown; when Cloudflare sends Retry-After
//	  we obey it, otherwise we use a small escalating backoff per exit IP.
//
// Summary of the two scales the gate has to keep apart:
//   - crt.name  : 24h per exit IP (daily quota)   -> burn the exit, switch IP now
//   - rapiddns  : 90s..15m per exit IP (challenge) -> switch IP + small wait

type apiSource int

const (
	srcCrtName apiSource = iota
	srcRapidSub
	srcRapidSameIP
	// srcTntcode is domains.tntcode.com (up to 100k hostnames/IP). It showed no
	// per-client-IP rate limit in testing (8 rapid hits -> all 404, never 429),
	// but it sits behind Cloudflare, so it still gets the per-exit-IP gate as a
	// safety net.
	srcTntcode
	// srcReverse is the shared slot for the SECONDARY reverse-IP providers
	// (hackertarget, urlscan, robtex, internetdb, mnemonic). They all enforce a
	// PER EXIT IP limit (rate/challenge/daily-quota) but used to only trip a
	// global circuit breaker, so a block parked the provider for minutes instead
	// of switching to a fresh Tor exit.
	srcReverse
	srcOther
)

func (s apiSource) String() string {
	switch s {
	case srcCrtName:
		return "crt.name"
	case srcRapidSub:
		return "rapiddns"
	case srcRapidSameIP:
		return "rapiddns/sameip"
	case srcTntcode:
		return "tntcode"
	case srcReverse:
		return "reverse"
	default:
		return "api"
	}
}

type limitKind int

const (
	// limitNone: the response was fine (or the target genuinely has that data).
	limitNone limitKind = iota
	// limitQuota: daily per-IP quota exhausted (crt.name free tier).
	limitQuota
	// limitRate: explicit HTTP rate limit (429) without a daily quota.
	limitRate
	// limitChallenge: Cloudflare/bot challenge or a 5xx wall.
	limitChallenge
	// limitSuspect: HTTP 200 but the payload looks truncated / "+1 only", so the
	// answer must be re-verified on a DIFFERENT exit IP before it is trusted.
	limitSuspect
)

func (k limitKind) String() string {
	switch k {
	case limitQuota:
		return "quota-daily"
	case limitRate:
		return "rate-limit"
	case limitChallenge:
		return "challenge"
	case limitSuspect:
		return "suspect(+1)"
	default:
		return "none"
	}
}

// rank orders the kinds by how strongly they demand a reaction. limitVerdict()
// aggregates every provider's slot worst-wins, so the ordering must be a total
// one: quota (24h per IP) > challenge (sticky per IP) > rate (429) >
// suspect(+1) > none.
func (k limitKind) rank() int {
	switch k {
	case limitQuota:
		return 4
	case limitChallenge:
		return 3
	case limitRate:
		return 2
	case limitSuspect:
		return 1
	}
	return 0
}

// numLimitSources sizes the per-provider verdict slots on a worker.
const numLimitSources = int(srcOther) + 1

// limitNoneVerdict is the zero verdict: Remaining/Limit use -1 because the
// headers were absent, matching what the fetch functions emit.
func limitNoneVerdict() limitVerdict {
	return limitVerdict{Kind: limitNone, Remaining: -1, Limit: -1}
}

// limitVerdict is what one provider call told us about limits.
type limitVerdict struct {
	Kind       limitKind
	RetryAfter time.Duration // honour Retry-After when the server sent one
	Remaining  int           // X-Ratelimit-Remaining, -1 = header absent
	Limit      int           // X-Ratelimit-Limit, -1 = header absent
	Reason     string
	At         time.Time
}

func (v limitVerdict) blocked() bool {
	return v.Kind != limitNone && v.Kind != limitSuspect
}

// needsRescan reports whether the caller must switch IP and scan the SAME
// target again — and therefore must NOT mark the apex as finished.
func (v limitVerdict) needsRescan() bool { return v.Kind != limitNone }

// lowConfidence reports whether a limit-free but low-confidence answer ("+1")
// has to be re-verified on a fresh exit IP.
func (v limitVerdict) lowConfidence() bool { return v.Kind == limitSuspect }

const (
	// crtNameDailyQuota mirrors the live crt.name Retry-After (86400s).
	crtNameDailyQuota = 24 * time.Hour
	// crtNameQuotaGuard: rotate the exit while this many requests are left, so
	// the last few are never burned on a 429.
	crtNameQuotaGuard = 3
	// crtNameUnverifiedCooldown: without a control port we cannot key the gate
	// by exit IP, so a quota hit is only remembered briefly instead of locking
	// crt.name out for a whole day.
	crtNameUnverifiedCooldown = 5 * time.Minute

	// rapidChallengeBase is the first cooldown after a rapiddns challenge; it
	// escalates per consecutive hit (90s, 3m, 6m, 12m, 15m cap). Rapiddns has
	// no documented cooldown (unlike crt.name's 24h), and its guest cap of 100
	// rows is permanent — only the Cloudflare challenge decays.
	rapidChallengeBase = 90 * time.Second
	rapidChallengeMax  = 15 * time.Minute
	// rapidFreePlanPages: Free (GitHub) accounts may read up to 100 pages.
	rapidFreePlanPages = 100

	// limitRescanMax bounds the per-apex "switch IP and scan again" loop. Six
	// attempts is generous for a 24h-quota provider (each attempt claims a NEW
	// unique exit IP) while still guaranteeing the run terminates.
	limitRescanMax = 6
	// requeueMax bounds re-queues caused by fan-out saturation (a different
	// failure mode: the target was never actually queried).
	requeueMax = 24

	// --- "+1 only" is NOT a refusal; it deserves one cheap look --------------
	//
	// suspectRescanMax exists because a SINGLE-host apex is the NORMAL shape of a
	// small domain, not evidence of throttling. The old code treated it as a full
	// limit event: up to four exit rotations inside fetchCrtNameDirect, THEN a
	// rotateExit() plus a re-queue in handleNode, repeated limitRescanMax times.
	// Every one of those rotations is a complete Tor circuit claim (warm-up
	// connect + control-port round trip, exitClaimBudget = 10s each), so one
	// ambiguous 1-row answer could burn ~30 circuit claims. At hundreds of
	// thousands of targets that is the difference between hours and days.
	//
	// Now a thin answer earns exactly ONE re-queue and NO rotation at all: the
	// re-queued node is picked up by another worker sitting on a different exit
	// IP, which is where the cross-exit union actually comes from — and it costs
	// nothing, unlike a self-rotation.
	suspectRescanMax = 1
	// crtNameRotateAttempts is the budget for a REAL block (429/403/503/quota/
	// challenge). Rotating is the only reaction that can unblock the request, so
	// this one stays generous — but 4 was more than the evidence warrants.
	crtNameRotateAttempts = 2

	// --- Slow-exit policy ---------------------------------------------------
	//
	// A relay that is alive but slow is invisible today: nothing reacts until a
	// provider finally says 429, so a worker can burn tens of seconds per
	// request with no signal at all (see noteLatency).
	//
	// There is deliberately NO absolute threshold. The per-provider context
	// deadlines are 3.5s (crt.name), 4.5s (rapiddns) and 1.8s (rapiddns/sameip)
	// — see providerBudget — so a "8-12s is slow" rule would never fire: the
	// context cancels first and the sample arrives as a failure, not as a slow
	// success. The budget FRACTION below is what catches the uniformly slow
	// relay instead.
	//
	// slowExitFactor: 2x this worker's own healthy average for that provider.
	// slowExitMinSamples: the relative rule needs a baseline; below this only
	// the budget fraction can condemn a relay.
	// slowExitBudgetFrac: spending this share of a provider's whole request
	// deadline on ONE request is already a losing trade — 0.7 of crt.name's
	// 3500ms = 2.45s, of rapiddns' 4500ms = 3.15s, of sameip's 1800ms = 1.26s.
	// slowExitStrikes: consecutive slow samples on the SAME exit before it is
	// rotated. Above 1 so a single hiccup (a loaded relay, a GC pause) does not
	// eject a working exit; the counter resets when the exit changes.
	slowExitFactor     = 2.0
	slowExitMinSamples = 3
	slowExitBudgetFrac = 0.7
	slowExitStrikes    = 3
	// slowExitCooldown is how long a slow relay is kept out of rotation. Short
	// on purpose: the relay is healthy, just slow right now.
	slowExitCooldown = 3 * time.Minute
)

// providerBudget is the request deadline each provider's own context enforces.
// Kept beside the slow-exit policy because that policy is expressed as a
// fraction of it; when a fetch's deadline is retuned, retune it here too.
//
// These are the deadlines the fetches actually set, not the http.Client
// timeout: the client's is 30s, but every fetch narrows it with a context long
// before that, so 30s is never the number a request is measured against.
func providerBudget(src apiSource) time.Duration {
	switch src {
	case srcCrtName:
		return 3500 * time.Millisecond // fetchCrtNameDirect
	case srcRapidSub:
		return 4500 * time.Millisecond // fetchRapidWithIPSwitch
	case srcRapidSameIP:
		return 1800 * time.Millisecond // fetchSameIP
	case srcTntcode:
		return tntcodeTimeout // fetchTntcode
	}
	return httpTimeout
}

// noteReverseLimit is the secondary-reverse-provider hook: it classifies one
// HTTP response and, when it is a per-exit-IP block, cools that exit so the next
// call rotates first. Returns true when the response was a limit (so the caller
// can skip parsing). Cheap and side-effect-light enough to drop into every
// reverse fetch.
func (w *worker) noteReverseLimit(code int, hdr http.Header, body []byte) bool {
	v := classifyLimit(srcReverse, code, hdr, body)
	if !v.blocked() {
		return false
	}
	w.noteLimit(srcReverse, v)
	return true
}

// parseRetryAfter reads Retry-After in seconds or HTTP-date form.
func parseRetryAfter(raw string) time.Duration {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return 0
	}
	if secs, err := strconv.Atoi(raw); err == nil {
		if secs <= 0 {
			return 0
		}
		return time.Duration(secs) * time.Second
	}
	if t, err := http.ParseTime(raw); err == nil {
		if d := time.Until(t); d > 0 {
			return d
		}
	}
	return 0
}

// hdrInt reads an integer header (-1 when absent/invalid).
func hdrInt(h http.Header, key string) int {
	if h == nil {
		return -1
	}
	raw := strings.TrimSpace(h.Get(key))
	if raw == "" {
		return -1
	}
	n, err := strconv.Atoi(raw)
	if err != nil || n < 0 {
		return -1
	}
	return n
}

// hasAny reports whether lower contains any of the (lower-case) markers.
func hasAny(lower string, markers ...string) bool {
	for _, m := range markers {
		if strings.Contains(lower, m) {
			return true
		}
	}
	return false
}

// classifyLimit turns one provider response into a verdict. It is deliberately
// header-first: crt.name ships machine-readable X-Ratelimit-* headers, which is
// far more reliable than guessing from a body string.
func classifyLimit(src apiSource, code int, h http.Header, body []byte) limitVerdict {
	remaining := hdrInt(h, "X-Ratelimit-Remaining")
	limit := hdrInt(h, "X-Ratelimit-Limit")
	retryAfter := time.Duration(0)
	if h != nil {
		retryAfter = parseRetryAfter(h.Get("Retry-After"))
	}
	v := limitVerdict{Remaining: remaining, Limit: limit, Reason: "http " + strconv.Itoa(code)}
	lower := strings.ToLower(string(body))

	switch src {
	case srcCrtName:
		quotaText := hasAny(lower, "free tier limit", "limit reached",
			"requests per ip per day", "supply an api token", "100 requests per ip", "daily limit", "unmetered access")
		if quotaText || remaining == 0 || (code == 429 && remaining <= 0) {
			v.Kind = limitQuota
			v.Reason = "crt.name free tier quota (100 req/IP/hari)"
			if retryAfter <= 0 {
				retryAfter = crtNameDailyQuota
			}
			v.RetryAfter = retryAfter
			return v
		}
		if code == 429 {
			v.Kind = limitRate
			if retryAfter <= 0 {
				retryAfter = time.Minute
			}
			v.RetryAfter = retryAfter
			return v
		}
		if code == 403 || code == 503 || isBlockedResponse(code, body) {
			v.Kind = limitChallenge
			if retryAfter <= 0 {
				retryAfter = time.Minute
			}
			v.RetryAfter = retryAfter
			return v
		}

	case srcRapidSub, srcRapidSameIP:
		// An HTTP error code is the strongest signal and is checked first: a
		// clean page (even one containing marker-like words such as a "rate
		// limit" blog post) must never be classified as a challenge.
		if code == 429 || code == 403 || code == 503 ||
			code == 520 || code == 521 || code == 522 || code == 524 {
			v.Kind = limitChallenge
			v.Reason = "rapiddns HTTP " + strconv.Itoa(code)
			if retryAfter <= 0 {
				retryAfter = rapidChallengeBase
			}
			if retryAfter > rapidChallengeMax {
				retryAfter = rapidChallengeMax
			}
			v.RetryAfter = retryAfter
			return v
		}
		challengeText := hasAny(lower,
			"just a moment", "cf-chl-bypass", "challenge-platform", "attention required",
			"you are being rate limited", "rate limit exceeded", "too many requests", "error code: 1015",
			"turnstile", "cf-mitigated", "checking your browser", "enable javascript", "access denied", "ddos-guard")
		if challengeText {
			v.Kind = limitChallenge
			v.Reason = "rapiddns cloudflare challenge"
			if retryAfter <= 0 {
				retryAfter = rapidChallengeBase
			}
			if retryAfter > rapidChallengeMax {
				retryAfter = rapidChallengeMax
			}
			v.RetryAfter = retryAfter
			return v
		}

	case srcTntcode, srcReverse:
		// 429/403/503 from a reverse provider is a per-exit-IP block: rotate the
		// exit (handled by noteLimit + ensureFreshExit), do not wait it out.
		if code == 429 || code == 403 || code == 503 {
			v.Kind = limitChallenge
			v.Reason = src.String() + " HTTP " + strconv.Itoa(code)
			if retryAfter <= 0 {
				retryAfter = rapidChallengeBase
			}
			if retryAfter > rapidChallengeMax {
				retryAfter = rapidChallengeMax
			}
			v.RetryAfter = retryAfter
			return v
		}
		// A per-IP daily quota can arrive as HTTP 200 with a marker body
		// (hackertarget: "API count exceeded - Increase Quota with Membership").
		if code == 200 && hasAny(lower, "api count exceeded", "increase quota",
			"quota exceeded", "rate limit exceeded", "too many requests", "account query cap") {
			v.Kind = limitQuota
			v.Reason = src.String() + " per-IP quota"
			if retryAfter <= 0 {
				retryAfter = crtNameDailyQuota
			}
			v.RetryAfter = retryAfter
			return v
		}
	}

	if code >= 500 {
		v.Kind = limitRate
		if retryAfter <= 0 {
			retryAfter = 30 * time.Second
		}
		v.RetryAfter = retryAfter
	}
	return v
}

// limitRescanVerdict decides whether a parsed 200 answer needs a re-scan on a
// new exit IP. This is the "+1 only" question:
//
//   - crt.name: one single row is suspicious. A healthy apex returns the apex
//     itself plus its hosts; a throttled/partial answer returns just the apex or
//     a lone host. Re-verify on a different exit IP before trusting it.
//   - rapiddns: when the page ADVERTISES more hosts than it served, either it is
//     the documented guest cap (100 rows -> permanent, do NOT rescan) or a
//     partial/challenged answer (very few rows -> rescan once on a fresh exit).
func limitRescanVerdict(src apiSource, found, advertised int) limitVerdict {
	none := limitVerdict{Kind: limitNone, Remaining: -1, Limit: -1}
	switch src {
	case srcCrtName:
		if found <= 1 {
			return limitVerdict{Kind: limitSuspect, Remaining: -1, Limit: -1,
				Reason: "crt.name hanya " + strconv.Itoa(found) + " baris, diverifikasi ulang di exit IP lain"}
		}
	case srcRapidSub, srcRapidSameIP:
		if (advertised > found && found <= 1) || (found <= 1 && advertised > 0) {
			return limitVerdict{Kind: limitSuspect, Remaining: -1, Limit: -1,
				Reason: "rapiddns melayani " + strconv.Itoa(found) + " dari " +
					strconv.Itoa(advertised) + " yang diiklankan"}
		}
	}
	return none
}

// ---------------------------------------------------------------------------
// Cooldown gates
// ---------------------------------------------------------------------------

// limitGate remembers "this identity is burned until T". It never blocks a
// worker for the rest of the run: it only tells the caller to switch IP first,
// and only when a fresh IP cannot be obtained does the caller skip the request.
type limitGate struct {
	mu    sync.Mutex
	until map[string]time.Time
	hits  map[string]int

	refused int64 // requests refused while a key was cooling down
	burned  int64 // identities put in cooldown
}

func newLimitGate() *limitGate {
	return &limitGate{until: map[string]time.Time{}, hits: map[string]int{}}
}

var (
	crtNameGate = newLimitGate()
	rapidGate   = newLimitGate()
	// tntcodeGate / reverseGate are keyed by exit IP just like the others: a
	// block on one exit never disables the provider, it only makes the next call
	// rotate to a fresh exit (ensureFreshExit).
	tntcodeGate = newLimitGate()
	reverseGate = newLimitGate()
)

// blocked reports whether key is still cooling down.
func (g *limitGate) blocked(key string) (bool, time.Duration) {
	if g == nil || key == "" {
		return false, 0
	}
	g.mu.Lock()
	defer g.mu.Unlock()
	until, ok := g.until[key]
	if !ok {
		return false, 0
	}
	if d := time.Until(until); d > 0 {
		return true, d
	}
	delete(g.until, key)
	delete(g.hits, key)
	return false, 0
}

// note applies a verdict to key. verifiedIP=true means the key really is an
// exit IP, so a 24h crt.name quota may be trusted; otherwise the cooldown is
// clamped so an unverifiable identity cannot lock the provider out for a day.
func (g *limitGate) note(key string, v limitVerdict, verifiedIP bool) time.Duration {
	if g == nil || key == "" || !v.blocked() {
		return 0
	}
	g.mu.Lock()
	defer g.mu.Unlock()
	g.hits[key]++
	d := v.RetryAfter
	switch v.Kind {
	case limitQuota:
		if d <= 0 {
			d = crtNameDailyQuota
		}
		if !verifiedIP && d > crtNameUnverifiedCooldown {
			d = crtNameUnverifiedCooldown
		}
	case limitChallenge, limitRate:
		if d <= 0 {
			d = rapidChallengeBase
		}
		if g.hits[key] > 1 { // escalate while the same identity keeps getting hit
			d *= time.Duration(1) << uint(minInt(g.hits[key]-1, 4))
		}
		if d > rapidChallengeMax {
			d = rapidChallengeMax
		}
	}
	until := time.Now().Add(d)
	if until.After(g.until[key]) {
		g.until[key] = until
		g.burned++
	}
	return d
}

// cool puts key on cooldown for d with no verdict behind it.
//
// This exists for the slow-exit policy (noteSlowExit), which is a statement
// about a relay's SPEED, not about a provider refusing us. It must not travel
// as a limitVerdict: every kind with blocked()==true also keeps the apex open
// for a rescan (fetchCrt: "if !verdict.blocked() { apexDone[apex]=true }"), and
// a slow relay already gave us its answer — re-queueing the target would spend
// a request to learn what we know, then spend another on the new exit.
//
// Max-wins like note(), so a real 24h quota already on this key is never
// shortened by a 3-minute performance rest.
func (g *limitGate) cool(key string, d time.Duration) time.Duration {
	if g == nil || key == "" || d <= 0 {
		return 0
	}
	g.mu.Lock()
	defer g.mu.Unlock()
	until := time.Now().Add(d)
	if until.After(g.until[key]) {
		g.until[key] = until
		g.burned++
	}
	return d
}

// stats prunes expired entries and returns (burned identities, refused requests,
// identities still cooling down).
func (g *limitGate) stats() (burned, refused int64, cooling int) {
	if g == nil {
		return 0, 0, 0
	}
	g.mu.Lock()
	defer g.mu.Unlock()
	now := time.Now()
	for k, u := range g.until {
		if now.After(u) {
			delete(g.until, k)
			delete(g.hits, k)
		}
	}
	return g.burned, g.refused, len(g.until)
}

// noteRefused books a request that was skipped because its exit was cooling.
func (g *limitGate) noteRefused() {
	if g == nil {
		return
	}
	atomic.AddInt64(&g.refused, 1)
}

func minInt(a, b int) int {
	if a < b {
		return a
	}
	return b
}

// ---------------------------------------------------------------------------
// Worker-facing helpers
// ---------------------------------------------------------------------------

// exitKeyFor returns the identity the gate should key on. When the control port
// is available this is the real exit IP (so a 24h crt.name quota is tracked per
// IP); otherwise it degrades to the SOCKS listener.
func (w *worker) exitKeyFor() (key string, verifiedIP bool) {
	if w == nil {
		return "", false
	}
	w.pinMu.Lock()
	ip, fp := w.exitIP, w.exitFP
	w.pinMu.Unlock()
	if ip != "" {
		return "ip:" + ip, true
	}
	if fp != "" {
		return "fp:" + fp, true
	}
	if w.torAddr != "" && w.torOn() {
		return "socks:" + w.torAddr, false
	}
	return "direct", false
}

// setLimitVerdict / limitVerdict are the race-free hand-off between a fetch
// goroutine and the worker loop that decides "switch IP and rescan".
//
// setLimitVerdict records on the UNATTRIBUTED slot. Prefer setLimitVerdictFor
// when the provider is known — see the per-source note on worker.limitBySrc.
func (w *worker) setLimitVerdict(v limitVerdict) {
	if w == nil {
		return
	}
	v.At = time.Now()
	w.limitV.Store(&v)
}

// setLimitVerdictFor records a verdict against the provider that produced it, so
// two providers running concurrently inside one worker cannot overwrite each
// other's signal.
func (w *worker) setLimitVerdictFor(src apiSource, v limitVerdict) {
	if w == nil {
		return
	}
	i := int(src)
	if i < 0 || i >= numLimitSources {
		w.setLimitVerdict(v)
		return
	}
	v.At = time.Now()
	w.limitBySrc[i].Store(&v)
}

// resetLimitVerdicts clears every slot (unattributed + per-source). Called at
// the start of each node: fetchCrt's early returns (apexDone, wildcard, public
// suffix) write no verdict at all, so without a reset the PREVIOUS node's
// "suspect(+1)"/quota verdict leaked onto this one and triggered an unjustified
// rescan + rotation storm.
func (w *worker) resetLimitVerdicts() {
	if w == nil {
		return
	}
	w.limitV.Store(nil)
	for i := range w.limitBySrc {
		w.limitBySrc[i].Store(nil)
	}
}

// absorbLimitVerdicts merges the verdicts a scoped fan-out copy recorded back
// onto this worker, worst-wins per slot.
//
// The seven fallback providers in fetchCrt run on wScoped (a copy), so their
// "this exit is challenged / out of quota" signals used to die with the copy:
// fetchCrt then read the PARENT's verdict, saw limitNone, and marked the apex
// done — permanently losing a target that every provider had actually refused.
func (w *worker) absorbLimitVerdicts(from *worker) {
	if w == nil || from == nil || w == from {
		return
	}
	for i := range from.limitBySrc {
		p := from.limitBySrc[i].Load()
		if p == nil {
			continue
		}
		if cur := w.limitBySrc[i].Load(); cur != nil && cur.Kind.rank() >= p.Kind.rank() {
			continue
		}
		cp := *p
		w.limitBySrc[i].Store(&cp)
	}
	if p := from.limitV.Load(); p != nil {
		if cur := w.limitV.Load(); cur == nil || cur.Kind.rank() < p.Kind.rank() {
			cp := *p
			w.limitV.Store(&cp)
		}
	}
}

// limitVerdictFor returns one provider's own verdict (limitNone when it has not
// reported yet).
func (w *worker) limitVerdictFor(src apiSource) limitVerdict {
	if w == nil {
		return limitNoneVerdict()
	}
	i := int(src)
	if i < 0 || i >= numLimitSources {
		return limitNoneVerdict()
	}
	if p := w.limitBySrc[i].Load(); p != nil {
		return *p
	}
	return limitNoneVerdict()
}

// limitVerdict is the worst verdict across every slot: "some provider was
// limited" is what the worker loop must react to, and an unlucky last writer
// must not be able to mask a real block.
//
// The per-provider slots WIN over the unattributed one. Every node starts with
// resetLimitVerdicts(), so once any real fetch has written its own slot, the
// unattributed value is by definition a duplicate of an earlier per-source write
// — reading it as well could only resurrect a verdict a later clean answer
// already cleared. The unattributed slot is consulted only when NOTHING has
// reported per-source (the offline helpers and the unit tests drive it directly).
func (w *worker) limitVerdict() limitVerdict {
	if w == nil {
		return limitNoneVerdict()
	}
	worst := limitNoneVerdict()
	attributed := false
	for i := range w.limitBySrc {
		p := w.limitBySrc[i].Load()
		if p == nil {
			continue
		}
		if !attributed || p.Kind.rank() > worst.Kind.rank() {
			worst = *p
		}
		attributed = true
	}
	if attributed {
		return worst
	}
	if p := w.limitV.Load(); p != nil {
		worst = *p
	}
	return worst
}

// noteLimit records a verdict in the matching gate and returns the cooldown.
// The gate is only used when Tor is on: a cooldown is meaningless if the tool
// cannot switch the exit IP anyway (direct mode has exactly one identity), and
// locking "direct" for 15 minutes would silently disable the provider.
func (w *worker) noteLimit(src apiSource, v limitVerdict) time.Duration {
	if w == nil {
		return 0
	}
	if !w.torOn() || !v.blocked() {
		w.setLimitVerdict(v)
		return 0
	}
	key, verified := w.exitKeyFor()
	gate := gateFor(src)
	// Per-source slot AND the unattributed one: limitVerdict() reads both
	// worst-wins, and the unattributed slot keeps the plain setLimitVerdict /
	// limitVerdict contract used by the offline helpers and tests.
	d := gate.note(key, v, verified)
	w.setLimitVerdictFor(src, v)
	w.setLimitVerdict(v)
	return d
}

// --- Slow-exit detection ----------------------------------------------------
//
// A relay that is alive but slow is invisible without this: every reaction in
// this file is triggered by a provider refusing us, so a worker pinned to a
// relay that takes seconds per request just runs slowly and nobody notices
// until something finally 429s. Measured latency is the only signal available
// before that point, and the tool was already throwing it away.

// noteLatency feeds one provider request into that provider's latency baseline
// and reports whether this sample says the serving exit is too slow.
//
// The baseline is an EWMA of HEALTHY samples only. Folding the slow samples in
// would let a degrading relay raise its own bar until its slowness looks normal
// — self-masking, which is precisely the failure this is meant to catch.
//
// Granularity is per worker AND per provider, because the request deadlines
// differ by provider (3.5s vs 4.5s): one shared average would let the provider
// with the more generous deadline drag the bar away from the tighter one.
func (w *worker) noteLatency(src apiSource, d time.Duration) bool {
	if w == nil || d <= 0 {
		return false
	}
	i := int(src)
	if i < 0 || i >= numLimitSources {
		return false
	}
	// Two independent rules, because neither one alone is sufficient:
	//   - the budget fraction catches a UNIFORMLY slow relay, which the relative
	//     rule cannot see (2x an already-slow baseline is still "normal" here);
	//   - the relative rule catches a relay that degrades against a fast
	//     baseline long before it approaches the deadline.
	budget := providerBudget(src)
	secs := d.Seconds()

	w.slowMu.Lock()
	ewma, n := w.slowEWMA[i], w.slowN[i]
	slow := d >= time.Duration(slowExitBudgetFrac*float64(budget)) ||
		(n >= slowExitMinSamples && secs > slowExitFactor*ewma)
	if !slow {
		if n == 0 {
			w.slowEWMA[i] = secs
		} else {
			w.slowEWMA[i] = 0.8*ewma + 0.2*secs
		}
		w.slowN[i] = n + 1
	}
	w.slowMu.Unlock()
	return slow
}

// noteSlowExit books one slow sample against the currently pinned exit and, once
// that exit has produced slowExitStrikes of them in a row, cools it and rotates.
// Reports whether a rotation was triggered.
//
// Deliberately no ban strike: exitHealth.noteBlocked is what blacklists a relay,
// and a slow relay has refused us nothing. Banning on latency would drain the
// exit pool exactly the way the old first-strike ban policy did — which is the
// documented reason long runs used to get slower and slower.
func (w *worker) noteSlowExit(src apiSource, d time.Duration) bool {
	if w == nil || !w.torOn() {
		return false
	}
	_, _, ip := w.pinInfo()
	if ip == "" {
		return false // fallback per-request isolation: no pinned exit, skip strike
	}

	// Strikes are per pinned exit: the counter restarts whenever the exit
	// changes, so three slow samples spread over three relays never add up to a
	// rotation. lock order is pinMu (pinInfo) -> slowMu, never the reverse.
	w.slowMu.Lock()
	if w.slowFor != ip {
		w.slowFor, w.slowStrikes = ip, 0
	}
	w.slowStrikes++
	strikes := w.slowStrikes
	w.slowMu.Unlock()

	if strikes < slowExitStrikes {
		guiLogQuiet("tor", "", 0, "[exit] %s lambat (%s, %s) - strike %d/%d",
			orDash(ip), d.Truncate(time.Millisecond), src, strikes, slowExitStrikes)
		return false
	}

	// Both gates, not gateFor(src): the relay is slow for EVERY provider, and
	// parking the cooldown in one gate would leave the other free to keep using
	// it. Max-wins inside cool(), so a real quota already recorded here stands.
	key, _ := w.exitKeyFor()
	crtNameGate.cool(key, slowExitCooldown)
	rapidGate.cool(key, slowExitCooldown)

	rotated := w.rotateExit()
	guiLogQuiet("tor", "", 0, "[exit] %s lambat %dx berturut-turut (sampel terakhir %s, %s) - cooldown %s, pindah exit (rotasi=%v)",
		orDash(ip), strikes, d.Truncate(time.Millisecond), src, slowExitCooldown, rotated)
	return rotated
}

func gateFor(src apiSource) *limitGate {
	switch src {
	case srcCrtName:
		return crtNameGate
	case srcTntcode:
		return tntcodeGate
	case srcReverse:
		return reverseGate
	}
	return rapidGate
}

// ensureFreshExit is the "auto ganti IP saat limit" gate at the top of every
// provider call:
//
//  1. free identity -> go ahead;
//  2. cooling identity -> rotate the exit IP immediately and claim a NEW unique
//     one (tor_exit_unique.go); if the new identity is free, go ahead;
//  3. rotation impossible (Tor off / no control port and the socks key is
//     burned) -> refuse the request instead of burning it on a known 429.
func (w *worker) ensureFreshExit(src apiSource) bool {
	if w == nil {
		return true
	}
	if !w.torOn() {
		// Direct mode has a single identity: a cooldown cannot be escaped, so the
		// gate must not be applied (it would silently disable the provider).
		return true
	}
	gate := gateFor(src)
	key, _ := w.exitKeyFor()
	if blocked, _ := gate.blocked(key); !blocked {
		return true
	}
	before := key
	for attempt := 0; attempt < rotationAttempts; attempt++ {
		w.rotateTorClient()
		key2, _ := w.exitKeyFor()
		if key2 != before {
			before = key2
			if blocked, _ := gate.blocked(key2); !blocked {
				return true
			}
			// The identity DID move and the fresh exit is cooling too. Break
			// instead of looping: rotateTorClient runs a full claim (warm-ups,
			// relay pick, registry) bounded by exitClaimBudget — 6s — so a second
			// pass here would put a two-claim stall inside a request path. The
			// loop exists to WAIT for a sibling's in-flight rotation, not to keep
			// buying new relays.
			break
		}
		if !w.rotating.Load() {
			break // no rotation in flight and the identity did not move: give up
		}
		// A SIBLING fetch goroutine of this same worker (EngineSmart runs
		// fetchRapid and fetchCrtNameDirect concurrently) holds the rotation
		// try-lock, so rotateTorClient handed back the current client untouched.
		// Reporting a limit here would be inventing one: it made handleNode
		// rotateExit() and re-scan a target no provider had refused. Wait for the
		// sibling's rotation instead and re-check the identity it installs.
		time.Sleep(rotationWait)
	}
	gate.noteRefused()
	w.setLimitVerdictFor(src, limitVerdict{Kind: limitRate, Remaining: -1, Limit: -1,
		Reason: "exit " + before + " masih cooldown, request dilewati"})
	w.setLimitVerdict(limitVerdict{Kind: limitRate, Remaining: -1, Limit: -1,
		Reason: "exit " + before + " masih cooldown, request dilewati"})
	return false
}

const (
	// rotationAttempts bounds the wait for a sibling goroutine's in-flight
	// rotation before ensureFreshExit gives up and refuses the request.
	rotationAttempts = 3
	// rotationWait is one wait step. Worst case added latency is
	// rotationAttempts*rotationWait (180ms) on an already-cooling exit.
	rotationWait = 60 * time.Millisecond
)

// crtNameQuotaLow tells the caller to rotate the exit BEFORE the wall: the free
// tier is 100 requests per IP per day, so spending the last few requests of an
// identity on a guaranteed 429 is pure waste.
func crtNameQuotaLow(v limitVerdict) bool {
	return v.Remaining >= 0 && v.Remaining <= crtNameQuotaGuard
}

// rapidPagesFor returns how many result pages are worth fetching given the
// advertised dataset size. Guests are capped at 1 page (their ?page is ignored),
// logged-in Free accounts at 100 pages / 1,000 records.
func rapidPagesFor(advertised int, loggedIn bool, rowsPerPage int) int {
	if rowsPerPage <= 0 {
		rowsPerPage = rapidGuestRowCap
	}
	if !loggedIn {
		return 1
	}
	if advertised <= 0 {
		return 1
	}
	pages := (advertised + rowsPerPage - 1) / rowsPerPage
	if pages < 1 {
		pages = 1
	}
	if pages > rapidFreePlanPages {
		pages = rapidFreePlanPages
	}
	return pages
}
