package main

import (
	"io"
	"net"
	"net/http"
	"os"
	"strings"
	"sync"
	"testing"
	"time"
)

// ---- unit tests (no network) ----

// TestTorCircuitUserUnique guards the "rotate exit IP per request" mechanism:
// Tor's IsolateSOCKSAuth keys a circuit on the (user, password) pair, so two
// requests sharing a username share an exit IP. The generator must therefore be
// collision-free even under heavy concurrency.
func TestTorCircuitUserUnique(t *testing.T) {
	const workers, perWorker = 16, 400
	var mu sync.Mutex
	seen := make(map[string]int, workers*perWorker)
	var wg sync.WaitGroup
	for wid := 0; wid < workers; wid++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			for i := 0; i < perWorker; i++ {
				u := torCircuitUser(id)
				mu.Lock()
				seen[u]++
				mu.Unlock()
			}
		}(wid)
	}
	wg.Wait()
	if len(seen) != workers*perWorker {
		t.Errorf("torCircuitUser produced %d unique names for %d calls (%d collisions)",
			len(seen), workers*perWorker, workers*perWorker-len(seen))
	}
	// The username must also carry the worker id so the fleet mapping stays
	// deterministic (worker N -> its own circuit pool).
	for u := range seen {
		if !strings.HasPrefix(u, "w") {
			t.Fatalf("unexpected username format: %q", u)
		}
	}
}

// TestTorEffectiveAddr: an explicit -tor address must not be replaced by the
// torports.txt fleet (regression: `-tor 127.0.0.1:9999` still used :9050).
func TestTorEffectiveAddr(t *testing.T) {
	for _, tc := range []struct{ in, want string }{
		{"127.0.0.1:9150", "127.0.0.1:9150"},
		{"127.0.0.1:9999", "127.0.0.1:9999"},
		{"[::1]:9050", "[::1]:9050"},
		// bare-port form, same as torports.txt accepts
		{"9052", "127.0.0.1:9052"},
		{"9150", "127.0.0.1:9150"},
	} {
		if got := torEffectiveAddr(tc.in, 3); got != tc.want {
			t.Errorf("torEffectiveAddr(%q) = %q, want %q", tc.in, got, tc.want)
		}
	}

	// Default address is allowed to be resolved through the fleet, but it must
	// always come back usable (never empty, always dialable host:port).
	got := torEffectiveAddr(defaultTorSocks, 0)
	if got == "" {
		t.Errorf("torEffectiveAddr(default) returned an empty address")
	}
	if _, _, err := net.SplitHostPort(got); err != nil {
		t.Errorf("torEffectiveAddr(default) = %q, not host:port (%v)", got, err)
	}
}

func TestNormalizeTorAddr(t *testing.T) {
	for _, tc := range []struct{ in, want string }{
		{"9050", "127.0.0.1:9050"},
		{"", ""},
		{"127.0.0.1:9050", "127.0.0.1:9050"},
		{"off", "off"},
		{"bukan-port", "bukan-port"},
	} {
		if got := normalizeTorAddr(tc.in); got != tc.want {
			t.Errorf("normalizeTorAddr(%q) = %q, want %q", tc.in, got, tc.want)
		}
	}
}

// resetTorFleetCache clears the once-discovered fleet so a test can exercise the
// first-load path. Safe to call between tests (no goroutine is running then).
func resetTorFleetCache() {
	torFleetMu.Lock()
	torFleetAddrs = nil
	torFleetLoaded = false
	torFleetMu.Unlock()
}

// TestLoadTorFleetConcurrentNoRace guards BUG-011: every worker resolves its Tor
// address through loadTorFleet(), so the cache must be published under a lock.
// The old nil-check + plain assignment raced on the slice header — invisible in
// normal test runs, caught by `go test -race` on the GUI path.
func TestLoadTorFleetConcurrentNoRace(t *testing.T) {
	resetTorFleetCache()
	t.Cleanup(resetTorFleetCache)

	const n = 64
	got := make([]string, n)
	var wg sync.WaitGroup
	for i := 0; i < n; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			got[i] = pickTorAddr(i)
		}(i)
	}
	wg.Wait()

	for i, addr := range got {
		if addr == "" {
			t.Fatalf("pickTorAddr(%d) returned an empty address", i)
		}
		if _, _, err := net.SplitHostPort(addr); err != nil {
			t.Fatalf("pickTorAddr(%d) = %q, not host:port (%v)", i, addr, err)
		}
	}

	// Every concurrent caller must have observed the same, fully published fleet
	// (a torn slice header would have produced an empty or partial address).
	fleet := loadTorFleet()
	if len(fleet) == 0 {
		t.Fatal("loadTorFleet returned no addresses")
	}
	for i, addr := range got {
		if addr != fleet[i%len(fleet)] {
			t.Fatalf("pickTorAddr(%d) = %q, want %q (fleet %v)", i, addr, fleet[i%len(fleet)], fleet)
		}
	}

	// Second load must be a cache hit with identical contents.
	again := loadTorFleet()
	if strings.Join(again, ",") != strings.Join(fleet, ",") {
		t.Fatalf("fleet changed between calls: %v vs %v", fleet, again)
	}
}

// TestTorPickClientConcurrentStress hammers the per-request client path from
// many goroutines while another goroutine flips Tor off/on. It makes no network
// call (the SOCKS dialer is only constructed), so it runs everywhere; it guards
// the mutex-guarded w.torTransport swap and the atomic useTor flag against
// panics/nil-derefs (the -race detector needs CGO, this is the portable stand-in).
func TestTorPickClientConcurrentStress(t *testing.T) {
	w := &worker{
		id:      0,
		client:  http.DefaultClient,
		direct:  http.DefaultClient,
		torAddr: "127.0.0.1:1", // never dialed: no request is issued
	}
	w.useTor.Store(true)

	var wg sync.WaitGroup
	for g := 0; g < 8; g++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := 0; i < 500; i++ {
				if c := w.torPickClient(); c == nil {
					t.Errorf("torPickClient returned nil")
					return
				}
				_ = w.torOn()
				_ = w.api()
			}
		}()
	}
	wg.Add(1)
	go func() {
		defer wg.Done()
		for i := 0; i < 200; i++ {
			w.disableTor()
			w.useTor.Store(true)
			w.setLastAPI("rapiddns")
		}
	}()
	wg.Wait()

	// After the storm the flag must still be a consistent boolean, and the
	// worker must always hand back a usable client either way.
	w.disableTor()
	if w.torOn() {
		t.Error("disableTor left useTor on")
	}
	if w.torPickClient() != w.direct {
		t.Error("with Tor off, torPickClient must return the direct client")
	}
}

// ---- live tests (opt-in: needs local Tor on 127.0.0.1:9050) ----

func torExitIP(c *http.Client) string {
	for _, u := range []string{"https://api.ipify.org", "https://checkip.amazonaws.com", "https://ifconfig.me/ip"} {
		resp, err := c.Get(u)
		if err != nil {
			continue
		}
		b, _ := io.ReadAll(io.LimitReader(resp.Body, 64))
		resp.Body.Close()
		ip := strings.TrimSpace(string(b))
		if net.ParseIP(ip) != nil {
			return ip
		}
	}
	return ""
}

func liveTorWorker(t *testing.T) *worker {
	t.Helper()
	if os.Getenv("TOR_LIVE") != "1" {
		t.Skip("set TOR_LIVE=1 with local Tor on 127.0.0.1:9050 to run")
	}
	client, direct, ok, addr := newTorClient(defaultTorSocks, 0, true)
	if !ok {
		t.Skipf("Tor not reachable at %s", defaultTorSocks)
	}
	w := &worker{client: client, direct: direct, torAddr: addr}
	w.useTor.Store(true)
	return w
}

func TestLiveTorCircuitIsolation(t *testing.T) {
	w := liveTorWorker(t)

	// 1. The pinned client (w.client) must keep ONE stable exit per worker.
	a, b := torExitIP(w.client), torExitIP(w.client)
	if a == "" || b == "" {
		t.Skip("no reachable IP echo service")
	}
	if a != b {
		t.Errorf("pinned circuit changed exit IP: %s -> %s", a, b)
	}
	t.Logf("pinned exit: %s", a)

	// 2. torPickClient() must hand out a NEW circuit (new exit IP) per request.
	seen := map[string]int{}
	start := time.Now()
	for i := 0; i < 6; i++ {
		ip := torExitIP(w.torPickClient())
		if ip == "" {
			t.Fatalf("rotation request %d returned no exit IP", i)
		}
		seen[ip]++
	}
	elapsed := time.Since(start)
	t.Logf("per-request rotation: %d distinct exits / 6 requests in %s (~%s per fresh circuit)",
		len(seen), elapsed.Round(time.Millisecond), (elapsed / 6).Round(time.Millisecond))
	if len(seen) < 5 {
		t.Errorf("circuit isolation too weak: only %d distinct exits out of 6", len(seen))
	}
}

// TestLiveTorRotationBypassesRapiddnsBlock is the actual goal of per-request
// isolation: rapiddns answers a burned exit IP with a Cloudflare 429 challenge,
// so every rapiddns request must leave through a fresh circuit.
func TestLiveTorRotationBypassesRapiddnsBlock(t *testing.T) {
	w := liveTorWorker(t)
	const attempts = 4
	ok, blocked := 0, 0
	for i := 0; i < attempts; i++ {
		req, err := http.NewRequest("GET", rapidBaseURL+"/subdomain/unpad.ac.id?full=1", nil)
		if err != nil {
			t.Fatal(err)
		}
		req.Header.Set("User-Agent", browserUA)
		resp, err := w.torPickClient().Do(req)
		if err != nil {
			t.Logf("attempt %d: transport error: %v", i, err)
			continue
		}
		body, _ := io.ReadAll(io.LimitReader(resp.Body, rapidMaxBody))
		resp.Body.Close()
		switch resp.StatusCode {
		case 200:
			if n := len(parseRapidHTML(body)); n == 0 {
				t.Errorf("attempt %d: 200 but parsed 0 hosts", i)
			}
			ok++
		case 429, 403, 503:
			blocked++
			t.Logf("attempt %d: blocked with %d (certificate challenge)", i, resp.StatusCode)
		default:
			t.Logf("attempt %d: unexpected status %d", i, resp.StatusCode)
		}
	}
	t.Logf("rapiddns via mass rotation: %d/%d OK, %d blocked", ok, attempts, blocked)
	if ok < attempts-1 {
		t.Errorf("mass IP rotation did not defeat the rapiddns block: only %d/%d succeeded", ok, attempts)
	}
}
