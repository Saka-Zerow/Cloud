package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
)

// Samples below are verbatim from a live Tor 0.4.9.11 control session.

// isolateBlacklist keeps a test from writing the real tor_exit_blacklist.txt.
func isolateBlacklist(t *testing.T) {
	t.Helper()
	old := torExitBlacklistFile
	torExitBlacklistFile = filepath.Join(t.TempDir(), "tor_exit_blacklist.txt")
	t.Cleanup(func() { torExitBlacklistFile = old })
}

func TestExitFingerprintFromPath(t *testing.T) {
	for _, tc := range []struct{ path, want string }{
		{"$AA11~a,$BB22~b,$CC33~exit", "$CC33"},
		{"$EE230A2B08246D434457DE3D44D2BDA735E4D2F2~exit1,$5139F96FDB9EDD1033B511164A590D5DABD0FE02~exit2", "$5139F96FDB9EDD1033B511164A590D5DABD0FE02"},
		{"$66E8~only-exit", "$66E8"},
		{"", ""},
	} {
		if got := exitFingerprint(tc.path); got != tc.want {
			t.Errorf("exitFingerprint(%q) = %q, want %q", tc.path, got, tc.want)
		}
	}
}

func TestCtrlFieldParsesSocksUsername(t *testing.T) {
	line := `650 STREAM 85 SENTCONNECT 24 104.26.13.205:443 SOCKS_USERNAME="w7_12_9931" SOCKS_PASSWORD="x" ` +
		`CLIENT_PROTOCOL=SOCKS5 NYM_EPOCH=0 SESSION_GROUP=-4 ISO_FIELDS=SOCKS_USERNAME,SOCKS_PASSWORD`
	if got := ctrlField(line, "SOCKS_USERNAME"); got != "w7_12_9931" {
		t.Errorf("SOCKS_USERNAME = %q, want w7_12_9931", got)
	}
	if got := ctrlField(line, "PURPOSE"); got != "" {
		t.Errorf("missing field should be empty, got %q", got)
	}
}

// exitFromCircuitStatus picks the exit (last hop) of one circuit out of a
// GETINFO circuit-status reply - including pre-built circuits, which is why the
// lookup cannot rely on CIRC BUILT events alone.
func TestExitFromCircuitStatusReply(t *testing.T) {
	reply := strings.Join([]string{
		"250+circuit-status=",
		"24 BUILT $439600DC8013EAF8C8ED9CDB35B9D0C65C3805E4~first,$E5A623879C25B8FE43521D88D5E1A08FCADB7BB1~mid,$EE230A2B08246D434457DE3D44D2BDA735E4D2F2~exit PURPOSE=GENERAL TIME_CREATED=2026-09-20T02:44:13",
		"55 BUILT $395814815798E3DAC526BCE152E1FF11DA10A120~a,$20A8BC8EE8125FE6852C85FD2438CAE1482694FA~b,$5139F96FDB9EDD1033B511164A590D5DABD0FE02~c PURPOSE=GENERAL",
		".",
		"250 OK",
	}, "\n")
	if got, want := exitFromCircuitStatus(reply, "55"), "$5139F96FDB9EDD1033B511164A590D5DABD0FE02"; got != want {
		t.Errorf("exit of circuit 55 = %q, want %q", got, want)
	}
	if got, want := exitFromCircuitStatus(reply, "24"), "$EE230A2B08246D434457DE3D44D2BDA735E4D2F2"; got != want {
		t.Errorf("exit of circuit 24 = %q, want %q", got, want)
	}
	if got := exitFromCircuitStatus(reply, "999"); got != "" {
		t.Errorf("unknown circuit should be empty, got %q", got)
	}
}

func TestRecordBlockStrikesThenBans(t *testing.T) {
	isolateBlacklist(t)
	h := &torExitHealth{bad: map[string]*exitStat{}, ban: map[string]bool{}, ctls: map[string]*torCtl{}, ctlFailAt: map[string]time.Time{}}
	fp := "$EE230A2B08246D434457DE3D44D2BDA735E4D2F2"

	// Transient blocks need 3 strikes inside the TTL before exclusion — banning on
	// the first one burned the whole exit pool and made runs slower and slower.
	h.recordBlock(fp, "192.42.116.142", "rapiddns 429")
	h.recordBlock(fp, "192.42.116.142", "rapiddns 429")
	if got := h.bannedList(); len(got) != 0 {
		t.Fatalf("transient block banned too early: %v", got)
	}
	h.recordBlock(fp, "192.42.116.142", "rapiddns 429")
	if got := h.bannedList(); len(got) != 1 || got[0] != fp {
		t.Fatalf("transient block not banned on 3rd strike: %v", got)
	}
	// Quota-type blocks (crt.name) still ban at once.
	qfp := "$QUOTAFP"
	h.recordBlock(qfp, "192.0.2.1", "crt.name quota-daily")
	if got := h.bannedList(); len(got) != 2 {
		t.Fatalf("quota block did not ban immediately: %v", got)
	}
	if st := h.bad[fp]; st == nil || st.Strikes != 3 || st.IP != "192.42.116.142" {
		t.Fatalf("strike not recorded: %+v", st)
	}
	if !h.dirty {
		t.Error("ban should mark the exclusion list dirty")
	}
}

func TestBanCapDropsOldest(t *testing.T) {
	isolateBlacklist(t)
	h := &torExitHealth{bad: map[string]*exitStat{}, ban: map[string]bool{}, ctls: map[string]*torCtl{}, ctlFailAt: map[string]time.Time{}}
	// With 3 strikes for a transient ban, 3 blocks per relay are needed.
	for i := 0; i < torExitMaxExcluded+5; i++ {
		fp := fmt.Sprintf("$%040d", i)
		h.recordBlock(fp, "", "test 429")
		h.recordBlock(fp, "", "test 429")
		h.recordBlock(fp, "", "test 429")
	}
	if got := len(h.bannedList()); got != torExitMaxExcluded {
		t.Fatalf("ban list = %d, want cap %d", got, torExitMaxExcluded)
	}
}

func TestPruneExpiredForgetsRelay(t *testing.T) {
	fp := "$OLDFP"
	h := &torExitHealth{bad: map[string]*exitStat{}, ban: map[string]bool{}, ctls: map[string]*torCtl{}, ctlFailAt: map[string]time.Time{}}
	h.ban[fp] = true
	h.order = []string{fp}
	h.bad[fp] = &exitStat{FP: fp, Strikes: 5, Last: time.Now().Add(-torExitTTL - time.Minute)}

	h.pruneExpired()

	if len(h.bad) != 0 || len(h.bannedList()) != 0 {
		t.Errorf("expired relay not forgotten: bad=%d ban=%v", len(h.bad), h.bannedList())
	}
	if !h.dirty {
		t.Error("pruning a ban should re-apply the exclusion list")
	}
}

func TestBlacklistPersistence(t *testing.T) {
	isolateBlacklist(t)

	fresh := "$FRESHFP"
	stale := "$STALEFP"
	h := &torExitHealth{bad: map[string]*exitStat{}, ban: map[string]bool{}, ctls: map[string]*torCtl{}, ctlFailAt: map[string]time.Time{}}
	// Three transient blocks of the same relay (torExitStrikesToBan is 3): the
	// counter grows with each strike and the relay is excluded on the 3rd.
	h.recordBlock(fresh, "1.2.3.4", "http 429")
	h.recordBlock(fresh, "1.2.3.4", "http 429")
	h.recordBlock(fresh, "1.2.3.4", "http 429")
	h.lastSave = time.Time{} // bypass the debounce
	h.save()

	raw, err := os.ReadFile(torExitBlacklistFile)
	if err != nil {
		t.Fatalf("blacklist not written: %v", err)
	}
	if !strings.Contains(string(raw), fresh+"|1.2.3.4|3|") {
		t.Fatalf("unexpected blacklist content: %q", raw)
	}
	// an expired entry must be ignored on load
	staleTS := strconv.FormatInt(time.Now().Add(-torExitTTL-time.Hour).Unix(), 10)
	raw = append(raw, []byte(stale+"|9.9.9.9|9|"+staleTS+"|http 429\n")...)
	if err := os.WriteFile(torExitBlacklistFile, raw, 0o600); err != nil {
		t.Fatal(err)
	}

	h2 := &torExitHealth{bad: map[string]*exitStat{}, ban: map[string]bool{}, ctls: map[string]*torCtl{}, ctlFailAt: map[string]time.Time{}}
	h2.load()
	if st := h2.bad[fresh]; st == nil || st.Strikes != torExitStrikesToBan || st.IP != "1.2.3.4" {
		t.Fatalf("reloaded strike lost: %+v", st)
	}
	if got := h2.bannedList(); len(got) != 1 || got[0] != fresh {
		t.Fatalf("reloaded ban lost: %v", got)
	}
	if !h2.dirty {
		t.Error("loaded bans must be re-applied to Tor")
	}
}

func TestBlacklistLoadToleratesLegacyFourColumnLine(t *testing.T) {
	isolateBlacklist(t)

	// Legacy format predating the Reason column: fp|ip|strikes|ts (4 fields).
	// load() documents "best effort: a broken file is ignored" but used to
	// `parts[4:][0]` here, which panicked on a 4-field line. It must load the
	// still-valid ban data (with an empty reason) instead of crashing.
	fp := "$LEGACYFP"
	line := fp + "|1.2.3.4|3|" + strconv.FormatInt(time.Now().Unix(), 10) + "\n"
	if err := os.WriteFile(torExitBlacklistFile, []byte(line), 0o600); err != nil {
		t.Fatal(err)
	}

	h := &torExitHealth{bad: map[string]*exitStat{}, ban: map[string]bool{}, ctls: map[string]*torCtl{}, ctlFailAt: map[string]time.Time{}}
	// Must not panic; the 4-field line is loaded with an empty reason, and 3
	// strikes reinstates the ban under the new policy.
	h.load()
	st := h.bad[fp]
	if st == nil || st.Strikes != 3 || st.IP != "1.2.3.4" || st.Reason != "" {
		t.Fatalf("legacy 4-field line not loaded correctly: %+v", st)
	}
	if got := h.bannedList(); len(got) != 1 || got[0] != fp {
		t.Fatalf("legacy ban not reinstated: %v", got)
	}
}

func TestReadAutoTorCtrlPort(t *testing.T) {
	dir := t.TempDir()
	oldFile, oldAddr := autoTorCtrlFile, autoTorCtrlAddr.Load()
	defer func() {
		autoTorCtrlFile = oldFile
		if oldAddr != nil {
			autoTorCtrlAddr.Store(oldAddr)
		}
	}()

	autoTorCtrlFile = filepath.Join(dir, "control_port")
	if err := os.WriteFile(autoTorCtrlFile, []byte("PORT=127.0.0.1:42751\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	readAutoTorCtrlPort()
	if p := autoTorCtrlAddr.Load(); p == nil || *p != "127.0.0.1:42751" {
		t.Fatalf("control port = %v, want 127.0.0.1:42751", p)
	}

	// garbage must not overwrite a good value
	_ = os.WriteFile(autoTorCtrlFile, []byte("PORT=not-an-address\n"), 0o600)
	readAutoTorCtrlPort()
	if p := autoTorCtrlAddr.Load(); p == nil || *p != "127.0.0.1:42751" {
		t.Fatalf("garbage control port overwrote the good one: %v", p)
	}
	_ = os.Remove(autoTorCtrlFile)
	readAutoTorCtrlPort() // missing file must be a no-op
}

func TestTorControlAddrForUsesAutoPortOnlyForDefaultSocks(t *testing.T) {
	addr := "127.0.0.1:42751"
	autoTorCtrlAddr.Store(&addr)
	defer autoTorCtrlAddr.Store(nilPointerString())

	if got := torControlAddrFor(defaultTorSocks); got != addr {
		t.Errorf("default socks should use the auto control port, got %q", got)
	}
	if got := torControlAddrFor("127.0.0.1:9052"); got != "127.0.0.1:9053" {
		t.Errorf("fleet socks must keep using its own control port, got %q", got)
	}
}

func nilPointerString() *string { s := ""; return &s }

// TestExitHealthConcurrentStress hammers the whole health layer from many
// goroutines at once - noteBlocked is called by every worker's fetch goroutine,
// while the applier goroutine reads the ban list and prunes expired entries. It
// is the portable stand-in for `go test -race` (which needs CGO) and is run
// under the real race detector in CI/WSL.
func TestExitHealthConcurrentStress(t *testing.T) {
	isolateBlacklist(t)
	h := &torExitHealth{bad: map[string]*exitStat{}, ban: map[string]bool{}, ctls: map[string]*torCtl{}, ctlFailAt: map[string]time.Time{}}

	const goroutines = 16
	const iterations = 300
	var wg sync.WaitGroup
	for g := 0; g < goroutines; g++ {
		wg.Add(1)
		go func(g int) {
			defer wg.Done()
			for i := 0; i < iterations; i++ {
				fp := fmt.Sprintf("$%040d", (g*iterations+i)%50)
				h.recordBlock(fp, "10.0.0.1", "stress")
				_ = h.bannedList()
				_ = h.badCount()
				if i%50 == 0 {
					h.pruneExpired()
					h.mu.Lock()
					h.dirty = true
					h.mu.Unlock()
				}
			}
		}(g)
	}
	wg.Wait()

	if got, max := len(h.bannedList()), torExitMaxExcluded; got > max {
		t.Errorf("ban list grew past the cap: %d > %d", got, max)
	}
	if h.badCount() == 0 {
		t.Fatal("no strikes recorded under concurrency")
	}
}

func TestTorUserForAttempt(t *testing.T) {
	w := &worker{id: 3}
	if got := w.torUserForAttempt(0); got != "" {
		t.Errorf("Tor off should give no user, got %q", got)
	}
	w.useTor.Store(true)
	if got, want := w.torUserForAttempt(0), "w3"; got != want {
		t.Errorf("first attempt user = %q, want %q (pinned client)", got, want)
	}
	w.setLastTorUser("w3_77_123")
	if got, want := w.torUserForAttempt(1), "w3_77_123"; got != want {
		t.Errorf("retry user = %q, want %q (rotated circuit)", got, want)
	}
}
