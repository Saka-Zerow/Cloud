package main

import (
	"path/filepath"
	"testing"
)

func TestArchitectAudit_PreservedServices(t *testing.T) {
	// Subdomains that were previously wrongfully dropped by overly strict digit & gibberish rules
	mustKeep := []string{
		"web99.company.com",
		"api01.company.com",
		"smpn10.jakarta.go.id",
		"office365.company.com",
		"win11.company.com",
		"reactjs.company.com",
		"nextjs.company.com",
		"vuejs.company.com",
		"threejs.company.com",
		"bpjs.go.id",
		"ajax.company.com",
		"objstore.company.com",
		"minio.company.com",
		"docker.company.com",
	}

	got := filterValid(mustKeep)
	seen := map[string]bool{}
	for _, d := range got {
		seen[d] = true
	}

	for _, target := range mustKeep {
		if !seen[target] {
			t.Errorf("FAIL: Subdomain %q should be preserved, but was dropped by filter", target)
		}
	}
}

func TestArchitectAudit_KeepInfraHosts(t *testing.T) {
	old := keepInfra
	keepInfra = true
	defer func() { keepInfra = old }()

	infraServers := []string{
		"server10.company.com",
		"srv12.company.com",
		"node100.company.com",
	}

	got := filterValid(infraServers)
	seen := map[string]bool{}
	for _, d := range got {
		seen[d] = true
	}

	for _, target := range infraServers {
		if !seen[target] {
			t.Errorf("FAIL: Infra host %q should be preserved under keepInfra=true, but was dropped", target)
		}
	}
}

func TestArchitectAudit_SpamStillDropped(t *testing.T) {
	// Spams and DGA that must strictly remain dropped
	mustDrop := []string{
		"mail.arsh79.me",
		"portal.7583242g4.shop",
		"kvdjsancjn.domain.com",
		"qebixax.sbs",
		"vmanage-931399.geod.kddi.com",
		"server-dedicato79863.jaiblogs.com",
	}

	for _, target := range mustDrop {
		if !isGarbageDomain(target) {
			t.Errorf("FAIL: Spam domain %q was not detected as garbage", target)
		}
	}
}

func TestArchitectAudit_ScopeGuardGenericTLDIsolation(t *testing.T) {
	// Seeds with generic TLD (.com) should NOT whitelist all .com in the world
	seeds := []string{"target.com"}
	sg := NewScopeGuard(seeds, ScopeTargetTLDs)

	if !sg.IsAllowed("sub.target.com") {
		t.Errorf("FAIL: sub.target.com should be allowed")
	}

	// Unrelated .com domain must NOT be allowed
	if sg.IsAllowed("unrelated-random.com") {
		t.Errorf("FAIL: unrelated-random.com should be REJECTED under ScopeTargetTLDs")
	}
}

func TestArchitectAudit_SafeOutputPathAbsoluteAndTraversal(t *testing.T) {
	// Path traversal must fail
	traversal := "../escape.txt"
	if _, err := safeOutputPath(traversal); err == nil {
		t.Errorf("FAIL: safeOutputPath should reject %q", traversal)
	}

	// Valid absolute path with safe extension should succeed
	tmp := t.TempDir()
	absValid := filepath.Join(tmp, "results.txt")
	got, err := safeOutputPath(absValid)
	if err != nil {
		t.Errorf("FAIL: safeOutputPath unexpectedly rejected valid absolute path %q: %v", absValid, err)
	}
	if got != absValid {
		t.Errorf("FAIL: expected %q, got %q", absValid, got)
	}
}
