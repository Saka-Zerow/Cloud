package main

import (
	"fmt"
	"testing"
)

// Hosting-panel AUTO placeholders must be dropped; the bare cPanel service
// hostnames (cpanel/webmail/whm/webdisk/cpcalendars/cpcontacts/cprwhois/
// cpanelproxy) are REAL target subdomains and must survive. See
// main_cpanel_service_test.go for the dataanalyst.id regression.
func TestCpanelJunkFiltered(t *testing.T) {
	oldKeep := keepInfra
	keepInfra = false
	defer func() { keepInfra = oldKeep }()

	shouldDrop := []string{
		"defaultwebpage.example.net",
		"lac.tempurl.host.telkomuniversity.ac.id",
		"panel-smb243.telkomuniversity.ac.id",
		"spanel.nam.business",
		"wppanel.nam.business",
		"newpanel.nam.business",
		"wheeljack.cpanel.vm-soundwave.rak4.38-39.telkomuniversity.ac.id",
	}
	res := filterValid(shouldDrop)
	if len(res) > 0 {
		t.Errorf("expected hosting-panel placeholders to be dropped, but got: %v", res)
	}

	shouldKeep := []string{
		"autodiscover.megahost.test",
		"autoconfig.megahost.test",
		"webdisk.company.co.id",
		"cpanel.tracknovate.com",
		"webmail.tracknovate.com",
		"whm.tracknovate.com",
		"cpcalendars.tracknovate.com",
		"cpcontacts.tracknovate.com",
		"cpanel.moodle.ismile.labs.telkomuniversity.ac.id",
		"webmail.telkomuniversity.ac.id",
	}
	kept := map[string]bool{}
	for _, d := range filterValid(shouldKeep) {
		kept[d] = true
	}
	for _, d := range shouldKeep {
		if !kept[d] {
			t.Errorf("real cPanel service subdomain %q was dropped", d)
		}
	}
}

func TestLegitimateServersPreserved(t *testing.T) {
	legitServers := []string{
		"api1.company.com",
		"api2.company.com",
		"db1.company.com",
		"db2.company.com",
		"web1.company.com",
		"web2.company.com",
		"cloud1.company.com",
		"portal1.company.com",
		"k8s-node1.company.com",
		"vpn1.company.com",
		"auth1.company.com",
		"mail1.company.com",
		"dev1.company.com",
		"prod01.company.com",
	}
	res := filterValid(legitServers)
	seen := map[string]bool{}
	for _, d := range res {
		seen[d] = true
	}
	for _, expected := range legitServers {
		if !seen[expected] {
			t.Errorf("legitimate server %q was unexpectedly dropped", expected)
		}
	}
}

func TestDhcpAndSpamFiltered(t *testing.T) {
	spamList := []string{
		"pool-123.isp.com",
		"dhcp-456.campus.edu",
		"dialup-789.telecom.net",
		"client-101.broadband.net",
		"1.2.3.4.in-addr.arpa",
		"3f8a91b2c4e5d6a78b9c0d1e2f.example.org",
	}
	res := filterValid(spamList)
	if len(res) > 0 {
		t.Errorf("expected all DHCP/spam domains to be filtered, but got: %v", res)
	}
}

func TestSafeOutputPathBlocksCodeFiles(t *testing.T) {
	protected := []string{
		"main.go",
		"scraper.exe",
		"go.mod",
		"go.sum",
		"torports.txt",
		"build.bat",
		"deploy.sh",
	}
	for _, p := range protected {
		_, err := safeOutputPath(p)
		if err == nil {
			t.Errorf("safeOutputPath(%q) should have failed for protected file", p)
		}
	}

	valid := "valid_results.txt"
	abs, err := safeOutputPath(valid)
	if err != nil {
		t.Errorf("safeOutputPath(%q) should succeed, got error: %v", valid, err)
	}
	if abs == "" {
		t.Errorf("expected non-empty absolute path for %q", valid)
	}
}

func TestHubAndHostingNodeJunkFiltered(t *testing.T) {
	oldKeep := keepInfra
	keepInfra = false
	defer func() { keepInfra = oldKeep }()

	junkList := []string{
		"www.hub1105.dev7.nam.business",
		"www.hub1106.dev7.nam.business",
		"hub1128.dev7.nam.business",
		"hub1140.dev7.nam.business",
		"hub2230.devnew.nam.business",
		"hub2241.devnew.nam.business",
		"lhcp1050.webapps.net",
		"lhcp1065.webapps.net",
		"mail.tbasile.lhcp3109.webapps.net",
		"bpiarulli.lhcp1124.webapps.net",
		"testdomain.lhwp3418.webapps.net",
		"authsmtp39.register.it",
		"authsmtp01.register.it",
		"hostingmysql01.register.it",
		"delete1510.nominalia.com",
		"delete1574.nominalia.com",
		"schumann02.register-europe.com",
		"vivaldi47.register.it",
		"spanel.nam.business",
		"wppanel.nam.business",
		"newpanel.nam.business",
	}

	res := filterValid(junkList)
	if len(res) > 0 {
		t.Errorf("expected all hub/lhcp/infra junk to be dropped, but survived: %v", res)
	}
}

func TestServerInstanceSpamFiltered(t *testing.T) {
	// Real leak samples (2026-09-20, out_ea045bcd.txt): hosting/VM instance
	// identifiers that use [infra-word]+name+digits rather than a bare
	// prefix+digit, so the old strict rule missed them.
	junk := []string{
		"serverdahlia2.thezenweb.com",
		"vpshostfal37.thezenweb.com",
		"vmmars3.corp.fedex.com",
		"vmanage03.transport.nsw.gov.au",
		"vmanage-931399.geod.kddi.com",
		"servermcpe95.blogkoo.com",
		"server-dedicato79863.jaiblogs.com",
		"server-dedicati-linux93759.jaiblogs.com",
		"server-support-nyc08468.jaiblogs.com",
		"shared-web-world-elb2.company.com",
		"shared-web-campus-elb1.company.com",
		"hosting1.example.com",
		"cpanel3.example.com",
		"cp5.example.com",
		"cp01int.example.com",
		"whm-qas0.example.com",
		"whm-dev0.example.com",
		"dedicato123.example.com",
	}
	res := filterValid(junk)
	if len(res) > 0 {
		t.Errorf("expected all server-instance spam to be dropped, survived: %v", res)
	}

	// Service-word + digit stays legit: these are named endpoints, not spam.
	legit := []string{
		"api1.company.com",
		"db1.company.com",
		"web1.company.com",
		"cloud1.company.com",
		"mail1.company.com",
		"vpn1.company.com",
	}
	got := filterValid(legit)
	seen := map[string]bool{}
	for _, d := range got {
		seen[d] = true
	}
	for _, d := range legit {
		if !seen[d] {
			t.Errorf("legitimate service %q was wrongly dropped", d)
		}
	}
}

func TestSpamBlogPlatformsFiltered(t *testing.T) {
	junk := []string{
		"playson-casino-games31739.mpeblog.com",
		"connertgsco.timeblog.net",
		"nordictrack-treadmills-re40368.onesmablog.com",
		"laumccabe8.shotblogs.com",
		"andreskxekq.getblogs.net",
		"lawyersxriz37.alltdesign.com",
		"haneymccormack60.blogkoo.com",
		"jasperstrqp.jaiblogs.com",
		"chetholcomb2.articlealley.com",
		"comunidaderenovacaoemcristo.flogbrasil.terra.com.br",
		"blood-avenger.letras.terra.com.br",
		"dashy.dnice.cc",
		"005q1skfw8by.stspg-customer.com",
		"air-compressor-cleaner.china-and-china.com",
		"aaronhollyxxx.camzania.com",
		"017shadow.14.forumer.com",
		"000gan.imweb.me",
	}
	res := filterValid(junk)
	if len(res) > 0 {
		t.Errorf("expected all spam-blog-platform domains dropped, survived: %v", res)
	}

	// Real SaaS/customer platforms must be preserved.
	legit := []string{
		"fbcnj-rfklz.formstack.com",
		"101vermonthyundai.com.dlr.sincrod.com",
		"api.ypx.in",
		"cms-dev.jndla.net",
		"metabase.educbank.com.br",
	}
	got := filterValid(legit)
	seen := map[string]bool{}
	for _, d := range got {
		seen[d] = true
	}
	for _, d := range legit {
		if !seen[d] {
			t.Errorf("legitimate domain %q was wrongly dropped", d)
		}
	}
}

func TestDeviceNamesFiltered(t *testing.T) {
	junk := []string{
		"android-53d0119dd87ad8c5.campus.uncg.edu",
		"laptop-du6it9pr.uncg.edu",
		"erins-iphone.uncg.edu",
		"nadias-ipad.campus.uncg.edu",
		"g-c02xw0t1jhd4.uncg.edu",
	}
	res := filterValid(junk)
	if len(res) > 0 {
		t.Errorf("expected device hostnames dropped, survived: %v", res)
	}

	legit := []string{"www.uncg.edu", "library.uncg.edu", "admin.uncg.edu"}
	got := filterValid(legit)
	if len(got) != len(legit) {
		t.Errorf("expected real subdomains preserved, got %v", got)
	}
}

func TestBigTechAndPaaSFiltered(t *testing.T) {
	bigTechList := []string{
		"pages.dev",
		"order.pages.dev",
		"landing-page.workers.dev",
		"my-project.vercel.app",
		"dashboard.vercel.com",
		"my-site.netlify.app",
		"repo.github.io",
		"app.azurewebsites.net",
		"project.firebaseapp.com",
		"shop.myshopify.com",
		"myblog.blogspot.com",
		"google.com",
		"mail.google.com",
		"maps.google.co.id",
		"google.co.uk",
		"facebook.com",
		"graph.facebook.com",
		"microsoft.com",
		"portal.azure.com",
		"apple.com",
		"amazon.com",
		"netflix.com",
		"1e100.net",
		"cdn.cloudflare.net",
	}

	res := filterValid(bigTechList)
	if len(res) > 0 {
		t.Errorf("expected all Big Tech and PaaS domains to be filtered, but survived: %v", res)
	}
}

func TestLegitSubdomainsWithBigTechNamesPreserved(t *testing.T) {
	legitList := []string{
		"google.keyroles.org",
		"facebook.mycompany.co.id",
		"apple.fruitstore.com",
		"amazon.rainforest-ngo.org",
		"pages.bookpublisher.com",
	}

	res := filterValid(legitList)
	seen := map[string]bool{}
	for _, d := range res {
		seen[d] = true
	}
	for _, expected := range legitList {
		if !seen[expected] {
			t.Errorf("legitimate company subdomain %q was unexpectedly filtered", expected)
		}
	}
}

func TestJustInstalledPanelAndEphemeralHexFiltered(t *testing.T) {
	junkList := []string{
		"lf36ac31.justinstalledpanel.com",
		"lf8948e6.justinstalledpanel.com",
		"lfc8f914.justinstalledpanel.com",
		"lfd4f4c7.justinstalledpanel.com",
		"lfda4d06.justinstalledpanel.com",
		"l02f00a2.justinstalledpanel.com",
		"l048eae4.justinstalledpanel.com",
		"l058e97c.justinstalledpanel.com",
		"l058fe1c.justinstalledpanel.com",
		"l05d5c81.justinstalledpanel.com",
		"l080caf8.justinstalledpanel.com",
		"l9078ebe.justinstalledpanel.com",
		"lefffae3.justinstalledpanel.com",
		"l02f00a2.otherhost.net",
		"lf36ac31.myserver.com",
		"server.cprapid.com",
		"host.secureserver.net",
		"rum.cdn.hstgr.net",
		"relay.directrouter.com",
		"box1.webhostbox.net",
		"ae061f.medtov.com",
		"2d6434.medtov.com",
		"laafeb.telkomuniversity.ac.id",
		"1797edfa-99ee-4751-a06d-c8cb25751a08.9761bb.com",
		"vn88.eu.cc",
		"applesky.eu.cc",
		"admin.168168.eu.cc",
		"test.edgeone.app",
		"app.edgeone.dev",
		"console.skpr.io",
		"myproject.softr.app",
	}

	res := filterValid(junkList)
	if len(res) > 0 {
		t.Errorf("expected all panel installation and ephemeral hex junk to be dropped, but survived: %v", res)
	}

	// Also verify inSkipZone rejects the apexes
	for _, apex := range []string{"justinstalledpanel.com", "cprapid.com", "secureserver.net", "hstgr.net", "directrouter.com", "webhostbox.net", "eu.cc", "edgeone.app", "edgeone.dev", "skpr.io", "softr.app", "cloudflareaccess.com", "manus.space", "djg1.co", "whoisbucket.com", "microsoftonline.com"} {
		if !inSkipZone(apex) {
			t.Errorf("expected inSkipZone(%q) to be true, got false", apex)
		}
	}
}

func TestCloudflareAccessManusAndInfraNoiseFiltered(t *testing.T) {
	junkList := []string{
		"221london.cloudflareaccess.com",
		"23andme.cloudflareaccess.com",
		"24capfund.cloudflareaccess.com",
		"1seemeinyoucreationsbyd.manus.space",
		"20d377rector.manus.space",
		"2026jb.manus.space",
		"1yr.manus.space",
		"2denergia-hruxhfyx.manus.space",
		"220-server.saxco.com.my",
		"220-cvm2.materassiedoghe.eu",
		"0140-appprod.worldsysweb.com",
		"0110api.worldsysweb.com",
		"5045aovpn.empsecure.com",
		"a0.hosting-01.hnh.digital",
		"39df27aa95f14a23b3f68b231afcda82-ro.elections.nsw.gov.au",
		"39df27aa95f14a23b3f68b231afcda82-intranet.elections.nsw.gov.au",
		"0-www-ancestrylibrary-com-au.webpac.sutherlandshire.nsw.gov.au",
		"admin.www.deuction.superset.djg1.co",
		"c5alliancecom-8.sharepoint.emea.microsoftonline.com",
		"backlinkgenerator.net.whoisbucket.com",
		"1005a.jsdcoffee.com",
	}

	res := filterValid(junkList)
	if len(res) > 0 {
		t.Errorf("expected all cloudflareaccess, manus, and server noise to be dropped, but survived: %v", res)
	}

	legitList := []string{
		"2023symposium.ibp.ucla.edu",
		"24houreconomy.enterprise.nsw.gov.au",
		"api.telkomuniversity.ac.id",
		"blog.tebs.telkomuniversity.ac.id",
		"superuser.mednet.ucla.edu",
		"network.rg.telkomuniversity.ac.id",
		"academic.telkomuniversity.ac.id",
	}

	resLegit := filterValid(legitList)
	seen := map[string]bool{}
	for _, d := range resLegit {
		seen[d] = true
	}
	for _, expected := range legitList {
		if !seen[expected] {
			t.Errorf("expected legitimate domain %q to be preserved, but was dropped", expected)
		}
	}
}

func TestAdvancedNoiseAndDGAGibberishFilter(t *testing.T) {
	// 1. More than 1 digit in subdomain
	multiDigitJunk := []string{
		"domain123.domain.com",
		"host999.example.com",
		"app2024.company.com",
		"node101.test.com",
		"srv456.mycorp.net",
	}
	res1 := filterValid(multiDigitJunk)
	if len(res1) > 0 {
		t.Errorf("expected all multi-digit subdomains to be filtered, but survived: %v", res1)
	}

	// 2. More than 1 hyphen in subdomain
	multiHyphenJunk := []string{
		"domain-1de-fcwef-frw.com",
		"a-b-c.domain.com",
		"my-cool-api.company.com",
		"us-east-1-prod.corp.net",
	}
	res2 := filterValid(multiHyphenJunk)
	if len(res2) > 0 {
		t.Errorf("expected all multi-hyphen subdomains to be filtered, but survived: %v", res2)
	}

	// 3. Gibberish / DGA / Consonant-cluster subdomains
	dgaJunk := []string{
		"ncfjdnfewi.domainkita.com",
		"kvdjsancjn.domain.com",
		"ksdjsancjn.domain.com",
		"kqdjsancjn.domain.com",
		"kadjsancjn.domain.com",
		"kpdjsancjn.domain.com",
		"xzkjsh.target.com",
		"rthbvc.target.com",
	}
	res3 := filterValid(dgaJunk)
	if len(res3) > 0 {
		t.Errorf("expected all gibberish/DGA subdomains to be filtered, but survived: %v", res3)
	}

	// 4. Legitimate single-digit, single-hyphen, and natural words preserved
	legitClean := []string{
		"api1.domain.com",
		"auth1.domain.com",
		"mail1.domain.com",
		"my-api.domain.com",
		"vpn-backup.domain.com",
		"portal.domainkita.com",
		"billing.domain.com",
		"dashboard.domain.com",
		"auth.domain.com",
	}
	res4 := filterValid(legitClean)
	seen4 := map[string]bool{}
	for _, d := range res4 {
		seen4[d] = true
	}
	for _, expected := range legitClean {
		if !seen4[expected] {
			t.Errorf("expected clean domain %q to be preserved, but was dropped", expected)
		}
	}
}

func TestUserReportedSpamDomainsFiltered(t *testing.T) {
	userReported := []string{
		"mail.arsh79.me",
		"gateway.arsh79.me",
		"beta.arsh79.me",
		"portal.arsh79.me",
		"corp.arsh79.me",
		"vpn.arsh79.me",
		"vpn.qebixax.sbs",
		"mail.qebixax.sbs",
		"m.qebixax.sbs",
		"api.qebixax.sbs",
		"corp.qebixax.sbs",
		"portal.qebixax.sbs",
		"app.qebixax.sbs",
		"admin.qebixax.sbs",
		"beta.qebixax.sbs",
		"internal.qebixax.sbs",
		"sso.qebixax.sbs",
		"staging.qebixax.sbs",
		"auth.qebixax.sbs",
		"gateway.qebixax.sbs",
		"dev.qebixax.sbs",
		"admin.7583242g4.shop",
		"m.7583242g4.shop",
		"auth.7583242g4.shop",
		"api.7583242g4.shop",
		"sso.7583242g4.shop",
		"app.7583242g4.shop",
		"portal.7583242g4.shop",
		"staging.7583242g4.shop",
		"corp.7583242g4.shop",
	}
	res := filterValid(userReported)
	if len(res) > 0 {
		t.Errorf("expected 0 domains to survive from user reported junk list, but %d survived: %v", len(res), res)
	}

	for _, d := range userReported {
		if !isGarbageDomain(d) {
			t.Errorf("isGarbageDomain(%q) = false, expected true (must be detected as garbage)", d)
		}
	}
}

func BenchmarkIsGarbageDomain(b *testing.B) {
	testDomains := []string{
		"mail.arsh79.me",
		"auth.7583242g4.shop",
		"dev.qebixax.sbs",
		"kvdjsancjn.domain.com",
		"domain-1de-fcwef-frw.com",
		"api.sub.domainkita.com",
		"portal.company.co.id",
		"app1.prod.example.com",
	}
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_ = isGarbageDomain(testDomains[i%len(testDomains)])
	}
}

func BenchmarkFilterValidBatch(b *testing.B) {
	testDomains := []string{
		"mail.arsh79.me",
		"auth.7583242g4.shop",
		"dev.qebixax.sbs",
		"kvdjsancjn.domain.com",
		"domain-1de-fcwef-frw.com",
		"api.sub.domainkita.com",
		"portal.company.co.id",
		"app1.prod.example.com",
	}
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_ = filterValidBatch(testDomains)
	}
}

func TestLargeScaleGarbageFiltering_500K(t *testing.T) {
	const countPerCategory = 100000

	// 1. Multi-digit garbage (100,000 domains)
	garbageDigits := make([]string, countPerCategory)
	for i := 0; i < countPerCategory; i++ {
		garbageDigits[i] = fmt.Sprintf("sub%d.apex%d.com", i+100, i+200)
	}

	// 2. Multi-hyphen garbage (100,000 domains)
	garbageHyphens := make([]string, countPerCategory)
	for i := 0; i < countPerCategory; i++ {
		garbageHyphens[i] = fmt.Sprintf("my-cool-server-%d.domain-service-test.com", i%100)
	}

	// 3. DGA / Gibberish (100,000 domains)
	garbageDGA := make([]string, countPerCategory)
	dgaPrefixes := []string{"kvdjsancjn", "ncfjdnfewi", "qebixax", "zxgqjkl", "kpdjsancjn", "kadjsancjn", "xzbqwtm"}
	for i := 0; i < countPerCategory; i++ {
		p := dgaPrefixes[i%len(dgaPrefixes)]
		garbageDGA[i] = fmt.Sprintf("%s%d.domainkita%d.com", p, i%10, i%10)
	}

	// 4. Valid Single-digit / single-hyphen domains (100,000 domains)
	validSingle := make([]string, countPerCategory)
	corps := []string{"alpha", "bravo", "cyber", "delta", "echo", "falcon", "galaxy", "horizon", "infinity", "jupiter", "krypton", "lunar", "matrix", "nexus", "omega", "phoenix", "quantum", "stellar", "titan", "vector"}
	services := []string{"api", "web", "app", "auth", "edge", "hub", "node", "core", "pod", "srv"}
	for i := 0; i < countPerCategory; i++ {
		corp := corps[i%len(corps)]
		svc := services[(i/len(corps))%len(services)]
		digit := (i % 9) + 1
		validSingle[i] = fmt.Sprintf("%s%d.%s-corp.com", svc, digit, corp)
	}

	// 5. Valid standard clean enterprise domains (100,000 domains)
	validEnterprise := make([]string, countPerCategory)
	subNames := []string{"mail", "portal", "dashboard", "auth", "sso", "gateway", "admin", "api", "vpn", "intranet"}
	tlds := []string{"com", "co.id", "net", "org", "io", "edu", "ac.id", "co.uk", "de", "fr"}
	for i := 0; i < countPerCategory; i++ {
		sub := subNames[i%len(subNames)]
		corp := corps[(i/len(subNames))%len(corps)]
		tld := tlds[(i/(len(subNames)*len(corps)))%len(tlds)]
		validEnterprise[i] = fmt.Sprintf("%s.%s-group.%s", sub, corp, tld)
	}

	// Execute Large Scale Filter
	allGarbage := append(garbageDigits, append(garbageHyphens, garbageDGA...)...)
	allValid := append(validSingle, validEnterprise...)

	t.Logf("Running deep scale test: %d Garbage Domains vs %d Clean Domains (Total 500,000)", len(allGarbage), len(allValid))

	// Verify Garbage is 100% dropped
	droppedGarbageCount := 0
	for _, d := range allGarbage {
		if isGarbageDomain(d) {
			droppedGarbageCount++
		}
	}
	if droppedGarbageCount != len(allGarbage) {
		t.Fatalf("Large scale test FAILED: %d out of %d garbage domains survived!", len(allGarbage)-droppedGarbageCount, len(allGarbage))
	}

	// Verify Valid domains are 100% kept
	keptValidCount := 0
	for _, d := range allValid {
		if !isGarbageDomain(d) {
			keptValidCount++
		}
	}
	if keptValidCount != len(allValid) {
		t.Fatalf("Large scale test FAILED: %d out of %d valid domains wrongly dropped!", len(allValid)-keptValidCount, len(allValid))
	}

	t.Logf("SUCCESS: 100%% of 300,000 garbage domains DROPPED, 100%% of 200,000 clean domains PRESERVED.")
}
