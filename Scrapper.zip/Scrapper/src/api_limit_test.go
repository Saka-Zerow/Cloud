package main

import (
	"net/http"
	"testing"
	"time"
)

func hdr(kv ...string) http.Header {
	h := http.Header{}
	for i := 0; i+1 < len(kv); i += 2 {
		h.Set(kv[i], kv[i+1])
	}
	return h
}

// The quota verdict is pinned against the LIVE crt.name response captured
// 2026-09-29: HTTP 429 + Retry-After: 86400 + X-Ratelimit-Remaining: 0 +
// "free tier limit reached: 100 requests per IP per day".
func TestClassifyLimitCrtNameQuotaFromHeaders(t *testing.T) {
	h := hdr("Retry-After", "86400", "X-Ratelimit-Limit", "100", "X-Ratelimit-Remaining", "0")
	body := []byte("free tier limit reached: 100 requests per IP per day. Supply an API token for unmetered access.")
	v := classifyLimit(srcCrtName, 429, h, body)
	if v.Kind != limitQuota {
		t.Fatalf("Kind = %v, want limitQuota", v.Kind)
	}
	if v.RetryAfter != 24*time.Hour {
		t.Errorf("RetryAfter = %v, want 24h (from Retry-After: 86400)", v.RetryAfter)
	}
	if !v.blocked() || !v.needsRescan() {
		t.Error("quota verdict must block and require a re-scan on another IP")
	}
}

// Body-only quota detection (200 with the quota text) — how the old code saw it.
func TestClassifyLimitCrtNameQuotaFromBodyOnly(t *testing.T) {
	v := classifyLimit(srcCrtName, 200, nil, []byte("FREE TIER LIMIT REACHED"))
	if v.Kind != limitQuota {
		t.Fatalf("Kind = %v, want limitQuota", v.Kind)
	}
	if v.RetryAfter != crtNameDailyQuota {
		t.Errorf("RetryAfter = %v, want default %v", v.RetryAfter, crtNameDailyQuota)
	}
}

// A healthy crt.name answer must NOT be flagged, and the remaining-requests
// header must survive so the exit can be rotated before the wall.
func TestClassifyLimitCrtNameHealthy(t *testing.T) {
	h := hdr("X-Ratelimit-Limit", "100", "X-Ratelimit-Remaining", "95")
	// 2+ rows: a realistic healthy apex (the "+1" suspect rule must not fire on
	// the production 200 path, exercised by TestFetchCrtViaMock below).
	v := classifyLimit(srcCrtName, 200, h, []byte(`[{"sub":"a.example.com"},{"sub":"b.example.com"}]`))
	if v.Kind != limitNone || v.blocked() {
		t.Fatalf("healthy answer flagged as %v", v.Kind)
	}
	if v.Remaining != 95 || v.Limit != 100 {
		t.Errorf("headers not parsed: remaining=%d limit=%d", v.Remaining, v.Limit)
	}
	if crtNameQuotaLow(v) {
		t.Error("remaining=95 must not trigger a proactive rotation")
	}
	low := classifyLimit(srcCrtName, 200, hdr("X-Ratelimit-Remaining", "2"), nil)
	if !crtNameQuotaLow(low) {
		t.Error("remaining=2 must trigger a proactive rotation (guard=3)")
	}
}

// rapiddns blocking appears as a Cloudflare challenge; there is no documented
// cooldown, so Retry-After is obeyed when present and the escalating base is used
// otherwise (seconds/minutes — NOT crt.name's 24h).
func TestClassifyLimitRapidChallenge(t *testing.T) {
	v := classifyLimit(srcRapidSub, 429, nil, []byte("<html>Just a moment... Enable JavaScript</html>"))
	if v.Kind != limitChallenge {
		t.Fatalf("Kind = %v, want limitChallenge", v.Kind)
	}
	if v.RetryAfter != rapidChallengeBase {
		t.Errorf("RetryAfter = %v, want %v", v.RetryAfter, rapidChallengeBase)
	}
	if v.RetryAfter >= crtNameDailyQuota {
		t.Error("rapiddns cooldown must stay in the seconds/minutes scale")
	}
	withHeader := classifyLimit(srcRapidSub, 503, hdr("Retry-After", "30"), nil)
	if withHeader.RetryAfter != 30*time.Second {
		t.Errorf("Retry-After header ignored: %v", withHeader.RetryAfter)
	}
	if ok := classifyLimit(srcRapidSub, 200, nil, []byte("<td>a.example.com</td>")); ok.Kind != limitNone {
		t.Errorf("clean 200 classified as %v", ok.Kind)
	}
}

// "+1 only" is the operator's question: a single row must be re-verified, while
// the documented rapiddns guest cap (100 rows of 3519 advertised) must NOT be
// mistaken for a limit — it is a permanent service cap, so no amount of IP
// rotation helps.
//
// NOTE on crt.name +1s: a genuinely single-host apex (e.g. a test domain with
// only one cert record) returns exactly 1 row even without any throttling. The
// re-scan is still the right call — it unions whatever another exit IP sees —
// and it is bounded by limitRescanMax so it can never loop forever. (That is why
// TestFetchCrtViaMock below uses a 6-row mock instead of a 1-row mock: 1 row is
// intentionally accepted as "suspect, will be verified again".)
func TestLimitRescanVerdictPlusOne(t *testing.T) {
	if v := limitRescanVerdict(srcCrtName, 1, 0); v.Kind != limitSuspect {
		t.Errorf("crt.name 1 row: Kind = %v, want limitSuspect", v.Kind)
	}
	if v := limitRescanVerdict(srcCrtName, 2, 0); v.needsRescan() {
		t.Error("crt.name 2 rows must be trusted")
	}
	if v := limitRescanVerdict(srcRapidSub, 1, 50); v.Kind != limitSuspect {
		t.Errorf("rapiddns 1/50: Kind = %v, want limitSuspect", v.Kind)
	}
	if v := limitRescanVerdict(srcRapidSub, rapidGuestRowCap, 3519); v.needsRescan() {
		t.Error("guest cap (100 rows) is permanent and must not be re-scanned")
	}
	suspect := limitVerdict{Kind: limitSuspect}
	if suspect.blocked() {
		t.Error("a suspect verdict must not block the request itself")
	}
	if !suspect.lowConfidence() {
		t.Error("suspect must report low confidence")
	}
}

func TestParseRetryAfterForms(t *testing.T) {
	if d := parseRetryAfter("86400"); d != 24*time.Hour {
		t.Errorf("seconds form = %v", d)
	}
	if d := parseRetryAfter(""); d != 0 {
		t.Errorf("empty = %v", d)
	}
	if d := parseRetryAfter("0"); d != 0 {
		t.Errorf("zero = %v", d)
	}
	future := time.Now().Add(90 * time.Second).UTC().Format(http.TimeFormat)
	if d := parseRetryAfter(future); d <= 0 || d > 2*time.Minute {
		t.Errorf("HTTP-date form = %v", d)
	}
}

// The gate must keep the two scales apart: crt.name's 24h quota is trusted per
// verified exit IP but clamped when the identity cannot be verified, and the
// rapiddns challenge escalates instead of blocking for a day.
func TestLimitGateCooldownScales(t *testing.T) {
	g := newLimitGate()
	key := "ip:203.0.113.9"
	d := g.note(key, limitVerdict{Kind: limitQuota, RetryAfter: crtNameDailyQuota}, true)
	if d != crtNameDailyQuota {
		t.Errorf("verified quota cooldown = %v, want 24h", d)
	}
	if blocked, left := g.blocked(key); !blocked || left <= 23*time.Hour {
		t.Errorf("gate must hold the verified IP: blocked=%v left=%v", blocked, left)
	}

	unverified := newLimitGate()
	d = unverified.note("socks:127.0.0.1:9050", limitVerdict{Kind: limitQuota, RetryAfter: crtNameDailyQuota}, false)
	if d != crtNameUnverifiedCooldown {
		t.Errorf("unverified quota cooldown = %v, want clamp %v", d, crtNameUnverifiedCooldown)
	}

	rapid := newLimitGate()
	d1 := rapid.note("ip:198.51.100.4", limitVerdict{Kind: limitChallenge}, true)
	d2 := rapid.note("ip:198.51.100.4", limitVerdict{Kind: limitChallenge}, true)
	if d1 != rapidChallengeBase {
		t.Errorf("first challenge cooldown = %v, want %v", d1, rapidChallengeBase)
	}
	if d2 <= d1 {
		t.Errorf("second challenge must escalate: %v then %v", d1, d2)
	}
	if d2 > rapidChallengeMax {
		t.Errorf("escalation exceeded the cap: %v", d2)
	}
	burned, _, cooling := rapid.stats()
	if burned == 0 || cooling != 1 {
		t.Errorf("stats = burned %d cooling %d, want burned>0 cooling=1", burned, cooling)
	}
	rapid.noteRefused()
	if _, refused, _ := rapid.stats(); refused != 1 {
		t.Errorf("refused counter = %d, want 1", refused)
	}
}

// A Free (GitHub) rapiddns account may read 100 pages; guests get exactly one.
func TestRapidPagesFor(t *testing.T) {
	if got := rapidPagesFor(0, false, rapidGuestRowCap); got != 1 {
		t.Errorf("guest pages = %d, want 1 (?page is ignored for guests)", got)
	}
	if got := rapidPagesFor(3519, true, rapidGuestRowCap); got != 36 {
		t.Errorf("free-user pages for 3519 hosts = %d, want 36 (ceil(3519/100))", got)
	}
	if got := rapidPagesFor(1_000_000, true, rapidGuestRowCap); got != rapidFreePlanPages {
		t.Errorf("free-user pages cap = %d, want %d", got, rapidFreePlanPages)
	}
}

// The limit verdict must survive the scoped-worker hand-off used by the fallback
// fan-out (the old `wScoped := *w` copy silently dropped atomic state).
func TestScopedWorkerKeepsAtomics(t *testing.T) {
	w := &worker{id: 7}
	w.useTor.Store(true)
	w.setLimitVerdict(limitVerdict{Kind: limitQuota, RetryAfter: time.Hour, Remaining: 0, Limit: 100})
	sc := w.scopedTo(nil)
	if !sc.torOn() {
		t.Error("scoped worker lost useTor")
	}
	if got := sc.limitVerdict(); got.Kind != limitQuota || got.Remaining != 0 {
		t.Errorf("scoped worker lost the limit verdict: %+v", got)
	}
	sc.setLimitVerdict(limitVerdict{Kind: limitNone})
	if w.limitVerdict().Kind != limitQuota {
		t.Error("mutating the scoped copy must not touch the original")
	}
}

// noteLimit must record a cooldown only when the exit IP can actually be
// switched (Tor on); direct mode has a single identity, so gating it would
// silently disable the provider.
func TestNoteLimitOnlyGatesWhenTorIsOn(t *testing.T) {
	off := &worker{id: 1, torAddr: "127.0.0.1:9050"}
	off.useTor.Store(false)
	if d := off.noteLimit(srcCrtName, limitVerdict{Kind: limitQuota, RetryAfter: crtNameDailyQuota}); d != 0 {
		t.Errorf("direct mode cooldown = %v, want 0", d)
	}
	if off.limitVerdict().Kind != limitQuota {
		t.Error("verdict must still be recorded for the worker loop")
	}
	if !off.ensureFreshExit(srcCrtName) {
		t.Error("ensureFreshExit must allow direct mode requests")
	}
}

func TestApiCircuitBreakerPerExitIsolation(t *testing.T) {
	cb := &apiCircuitBreaker{}

	// Exit 1 gets 429
	cb.recordExitFailure("exit-1.1.1.1", true)
	if cb.allowExit("exit-1.1.1.1") {
		t.Error("exit-1.1.1.1 must be blocked after 429")
	}

	// Exit 2 on another worker must STILL be allowed
	if !cb.allowExit("exit-2.2.2.2") {
		t.Error("exit-2.2.2.2 must be allowed when only exit-1 was rate limited")
	}

	// Global fallback must also still be allowed for non-exit requests
	if !cb.allow() {
		t.Error("global allow must remain true when only a specific exit is rate-limited")
	}

	// Recovery for Exit 1
	cb.recordExitSuccess("exit-1.1.1.1")
	if !cb.allowExit("exit-1.1.1.1") {
		t.Error("exit-1.1.1.1 must be allowed after success recovery")
	}
}

