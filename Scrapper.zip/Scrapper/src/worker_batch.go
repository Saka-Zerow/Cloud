package main

import "sync"

// --- Real batch work division + sized fallback concurrency -------------------
//
// Why this file exists ("worker-nya kayak palsu, 50 worker tetap lambat"):
//
//  1. Work was pulled from the queue ONE node at a time. With 50 workers that is
//     50 goroutines fighting over a mutex-protected channel per item, and each
//     item is a full network round trip through Tor. Batching (pull up to N,
//     then process) removes most of that contention and keeps every worker
//     busy on a contiguous slice of work: "setiap worker mengerjakan 20, habis
//     itu lanjut 20 berikutnya yang belum dikerjakan worker lain" — exactly the
//     model requested. The batch is taken from the shared queue (or the shared
//     IP queue), so no two workers ever get the same item.
//
//  2. The secondary-provider fan-out was capped by ONE GLOBAL semaphore of 8
//     (`semFallback`). With 50 workers, 42 of them hit `default:` and the old
//     code marked the apex as DONE and returned — i.e. the work was silently
//     discarded, which is the "fake worker" symptom: the workers were running,
//     but most of their work was thrown away. Now the fan-out is sized from the
//     worker count, and saturation re-queues instead of dropping.

const (
	// workerBatchMin keeps a worker from ping-ponging on tiny batches.
	workerBatchMin = 4
	// workerBatchMax is the default per-worker batch ("20 thread" model).
	workerBatchMax = 20
)

// workBatchMax is the effective per-worker batch size (flag -batch overrides the
// workerBatchMax default at runtime).
var workBatchMax = workerBatchMax

// batchSizeFor returns an adaptive batch: a fair share of the queue, bounded to
// [workerBatchMin, max]. Fair share means 50 workers on a 500-item queue take 10
// each (no starvation), while 4 workers on a 10k queue take the cap (max speed).
func batchSizeFor(queued int64, workers, max int) int {
	if max <= 0 {
		max = workerBatchMax
	}
	if workers < 1 {
		workers = 1
	}
	n := queued / int64(workers)
	if n < int64(workerBatchMin) {
		n = int64(workerBatchMin)
	}
	if n > int64(max) {
		n = int64(max)
	}
	return int(n)
}

// drainNodes pulls up to n nodes without blocking.
// FIX C-08: closed channel without ok-check produced infinite zero-value nodes.
func drainNodes(ch <-chan node, n int) []node {
	if n <= 0 {
		return nil
	}
	batch := make([]node, 0, n)
	for len(batch) < n {
		select {
		case it, ok := <-ch:
			if !ok {
				return batch
			}
			batch = append(batch, it)
		default:
			return batch
		}
	}
	return batch
}

// drainIPs pulls up to n IPs without blocking.
func drainIPs(ch <-chan string, n int) []string {
	if n <= 0 {
		return nil
	}
	batch := make([]string, 0, n)
	for len(batch) < n {
		select {
		case ip, ok := <-ch:
			if !ok {
				return batch
			}
			batch = append(batch, ip)
		default:
			return batch
		}
	}
	return batch
}

// ---------------------------------------------------------------------------
// Fallback fan-out concurrency (was a hard-coded global of 8)
// ---------------------------------------------------------------------------
// FIX C-07: previously a buffered chan was REPLACED in setFallbackConcurrency.
// The release closure captured the OLD channel, so tokens were returned to an
// abandoned channel and the NEW channel leaked slots until deadlock under 50 workers.
// Fixed with a counter-based semaphore (no channel replacement).

var fallbackPool = struct {
	mu  sync.Mutex
	cur int
	max int
}{max: 8}

// setFallbackConcurrency resizes the secondary-provider fan-out. Called once per
// run with the real worker count so 50 workers get 50 slots instead of 8.
func setFallbackConcurrency(n int) {
	if n < 8 {
		n = 8
	}
	if n > 64 {
		n = 64
	}
	fallbackPool.mu.Lock()
	fallbackPool.max = n
	// if current occupancy exceeds new max, clamp (lets running slots drain)
	if fallbackPool.cur > fallbackPool.max {
		fallbackPool.cur = fallbackPool.max
	}
	fallbackPool.mu.Unlock()
}

// acquireFallback takes one fan-out slot. ok=false means: do NOT drop the work,
// re-queue the target instead (the old code marked it done and lost it).
func acquireFallback() (release func(), ok bool) {
	fallbackPool.mu.Lock()
	if fallbackPool.cur >= fallbackPool.max {
		fallbackPool.mu.Unlock()
		return nil, false
	}
	fallbackPool.cur++
	fallbackPool.mu.Unlock()
	return func() {
		fallbackPool.mu.Lock()
		if fallbackPool.cur > 0 {
			fallbackPool.cur--
		}
		fallbackPool.mu.Unlock()
	}, true
}

// reportLimitStats is the end-of-run limit detector summary: how many distinct
// exit IPs were in use at once, how many were burned by crt.name's 24h quota and
// by rapiddns' Cloudflare challenge, and how many requests were refused because
// their exit IP was still cooling down. Printed once per run so the operator can
// see the detector working instead of guessing why a target returned +0/+1.
func reportLimitStats() {
	burnedCrt, refusedCrt, coolingCrt := crtNameGate.stats()
	burnedRapid, refusedRapid, coolingRapid := rapidGate.stats()
	if burnedCrt == 0 && burnedRapid == 0 {
		return
	}
	guiLogf("system", "", 0, "[limit] %s", describeExits())
	guiLogf("system", "", 0, "[limit] crt.name: %d exit IP dibakar, %d request ditahan (cooldown aktif %d) | rapiddns: %d exit IP dibakar, %d request ditahan (cooldown aktif %d)",
		burnedCrt, refusedCrt, coolingCrt, burnedRapid, refusedRapid, coolingRapid)
	guiLogf("system", "", 0, "[limit] catatan: crt.name kuota 100 req/IP/hari (refresh 24 jam) -> solusinya ganti IP; rapiddns challenge Cloudflare per-IP (detik-menit) -> solusinya ganti IP juga")
}

