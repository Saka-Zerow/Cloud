package main

import (
	"testing"
)

func TestScopeGuardTLDIsolation(t *testing.T) {
	seeds := []string{"kemenag.go.id", "ui.ac.id", "postel.go.id"}
	sg := NewScopeGuard(seeds, ScopeTargetTLDs)

	validCases := []string{
		"layanan.kemenag.go.id",
		"auth.ui.ac.id",
		"kominfo.go.id",
		"portal.jakarta.go.id",
		"undip.ac.id",
		"mybrand.co.id",
		"startup.id",
	}

	for _, d := range validCases {
		if !sg.IsAllowed(d) {
			t.Errorf("Expected %s to be allowed under ScopeTargetTLDs, but was rejected", d)
		}
	}

	poisonCases := []string{
		"reconcept.nl",
		"dev.reconcept.nl",
		"temptationstreats.ca",
		"notaiogentile.it",
		"hs.fi",
		"doist.com",
		"comcast.com",
		"outlook.com",
		"upmc.fr",
		"givelively.org",
	}

	for _, d := range poisonCases {
		if sg.IsAllowed(d) {
			t.Errorf("Expected %s to be REJECTED under ScopeTargetTLDs, but was allowed", d)
		}
	}
}

func TestScopeGuardSeedApexOnly(t *testing.T) {
	seeds := []string{"kemenag.go.id", "itb.ac.id"}
	sg := NewScopeGuard(seeds, ScopeSeedApexOnly)

	if !sg.IsAllowed("admin.kemenag.go.id") {
		t.Error("Expected sub of kemenag.go.id to be allowed")
	}
	if !sg.IsAllowed("auth.itb.ac.id") {
		t.Error("Expected sub of itb.ac.id to be allowed")
	}
	if sg.IsAllowed("ugm.ac.id") {
		t.Error("Expected ugm.ac.id to be rejected under ScopeSeedApexOnly")
	}
}
