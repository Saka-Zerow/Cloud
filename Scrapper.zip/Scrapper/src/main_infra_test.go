package main

import (
	"testing"
)

// Filter spam infra hosting (S1-12): label auto-generated DIBUANG default,
// kata murni tanpa digit LOLOS. Sampel dari run manual user 50k.
func TestIsInfraNoise(t *testing.T) {
	spam := []string{
		"www.vps9858.inmotionhosting.com",
		"www.vps9859.inmotionhosting.com",
		"vps16785.inmotionhosting.com",
		"www.vps16785.inmotionhosting.com",
		"vps84905.inmotionhosting.com",
		"mail.vps32691.inmotionhosting.com",
		"mail.vps71160.inmotionhosting.com",
		"vps71160.inmotionhosting.com",
		"www.vps71160.inmotionhosting.com",
		"srv12.example.net",
		"server99.provider.test",
		"ded3189.inmotionhosting.com",
		"cc252.inmotionhosting.com",
		"secure226.inmotionhosting.com",
		"ecbiz77.inmotionhosting.com",
		"biz75.inmotionhosting.com",
		"advanced54.inmotionhosting.com",
		"sudo53.inmotionhosting.com",
		"elite33.inmotionhosting.com",
		"ld27.inmotionhosting.com",
		"ecngx18.inmotionhosting.com",
		"gs14.inmotionhosting.com",
		"ngx13.inmotionhosting.com",
		"sb8.inmotionhosting.com",
		"mail.ded3189.inmotionhosting.com",
		"ftp.cc252.inmotionhosting.com",
		"www.sudo53.inmotionhosting.com",
		// DHCP kampus (run 100k user res.txt: 7196 pola netNN-userN)
		"net2-user1.be.ucla.edu",
		"net64-user254.be.ucla.edu",
		"net250-user100.be.ucla.edu",
		"user1.be.ucla.edu",
		// DHCP kampus pola lain (S2-08)
		"hauser01.res hall.edu",
		"hauser123.housing.edu",
		"husstudent01.dorm.edu",
		"resnet01.campus.edu",
		"dorm01.living.edu",
		// Hosting-panel placeholders (auto-installed / temporary), bukan service nyata
		"lac.tempurl.host.telkomuniversity.ac.id",
		"panel-smb243.telkomuniversity.ac.id",
	}
	for _, d := range spam {
		if !isInfraNoise(d) {
			t.Errorf("isInfraNoise(%q) = false, want true (infra spam)", d)
		}
	}
	legit := []string{
		"mail.example.net",
		"api.example.net",
		"blog.example.net",
		"www.example.net",
		"autodiscover.example.net",
		"autoconfig.example.net",
		"mail.megahost.test",
		"support.megahost.test",
		"secure.example.com",
		"cc.example.com",
		"ld.example.com",
		"gs.example.com",
		"sb.example.com",
		"advanced.example.com",
		"elite.example.com",
		"cloud.example.com",
		"shared.example.com",
		"ded.example.com",
		// cPanel service hostnames: subdomain nyata milik target (sama seperti yang
		// dilaporkan rapiddns). Sebelumnya salah dibuang sebagai "infra noise".
		"cpcalendars.example.com",
		"cpcontacts.example.com",
		"cpcalendars.hostingprovider.net",
		"cpcontacts.hostingprovider.net",
		"cpanel.example.net",
		"webmail.example.net",
		"whm.example.com",
		"webdisk.example.net",
		"cprwhois.example.net",
		"cpanelproxy.example.net",
		// DHCP lookalikes: superuser/netadmin/network-* HARUS lolos
		// (verified ada di res.txt run 100k user)
		"superuser.mednet.ucla.edu",
		"netadmin.epss.ucla.edu",
		"network.rg.telkomuniversity.ac.id",
		"network-login.mednet.ucla.edu",
		// hauser lookalikes: hauser.com (legit company), hauser (no digits)
		"hauser.com",
		"hauser.org",
		"www.hauser.com",
	}
	for _, d := range legit {
		if isInfraNoise(d) {
			t.Errorf("isInfraNoise(%q) = true, want false (legit target)", d)
		}
	}
}

// filterSubdomains harus buang infra default, loloskan bila keepInfra=true.
func TestFilterSubdomainsDropsInfra(t *testing.T) {
	in := []string{
		"vps9858.inmotionhosting.com",
		"mail.inmotionhosting.com",
		"inmotionhosting.com",
	}
	keepInfra = false
	got := filterSubdomains(in, "inmotionhosting.com")
	seen := map[string]bool{}
	for _, d := range got {
		seen[d] = true
	}
	if seen["vps9858.inmotionhosting.com"] {
		t.Errorf("default harus buang vps9858, got %v", got)
	}
	if !seen["mail.inmotionhosting.com"] || !seen["inmotionhosting.com"] {
		t.Errorf("legit harus lolos, got %v", got)
	}
	keepInfra = true
	defer func() { keepInfra = false }()
	got2 := filterSubdomains(in, "inmotionhosting.com")
	seen2 := map[string]bool{}
	for _, d := range got2 {
		seen2[d] = true
	}
	if !seen2["vps9858.inmotionhosting.com"] {
		t.Errorf("keepInfra=true harus loloskan vps9858, got %v", got2)
	}
}

// filterValid end-to-end: 100k res.txt junk patterns HARUS buang.
func TestFilterValidDropsDHCPAndCPpanel(t *testing.T) {
	input := []string{
		"net2-user1.be.ucla.edu",
		"net64-user254.be.ucla.edu",
		"net250-user100.be.ucla.edu",
		"user1.be.ucla.edu",
		"hauser01.res hall.edu",
		"husstudent01.dorm.edu",
		"resnet01.campus.edu",
		"dorm01.living.edu",
		"cpcalendars.ucla.edu",
		"cpcontacts.ucla.edu",
		"cpcalendars.example.com",
		"cpcontacts.example.com",
		"cpanel.hackthebox.com",
		"webmail.hackthebox.com",
		"vps9858.inmotionhosting.com",
		"ded3189.inmotionhosting.com",
		// legit must survive
		"bunchecenter.ucla.edu",
		"be.ucla.edu",
		"superuser.mednet.ucla.edu",
		"network.rg.telkomuniversity.ac.id",
		"hauser.com",
		"hauser.org",
	}
	keepInfra = false
	defer func() { keepInfra = false }()
	got := filterValid(input)
	seen := map[string]bool{}
	for _, d := range got {
		seen[d] = true
	}

	junkPatterns := []string{
		"net2-user1.be.ucla.edu",
		"net64-user254.be.ucla.edu",
		"net250-user100.be.ucla.edu",
		"user1.be.ucla.edu",
		"hauser01.res hall.edu",
		"husstudent01.dorm.edu",
		"resnet01.campus.edu",
		"dorm01.living.edu",
		"vps9858.inmotionhosting.com",
		"ded3189.inmotionhosting.com",
	}
	for _, j := range junkPatterns {
		if seen[j] {
			t.Errorf("filterValid harus buang %q, tapi lolos", j)
		}
	}

	legitPatterns := []string{
		"bunchecenter.ucla.edu",
		"be.ucla.edu",
		"superuser.mednet.ucla.edu",
		"network.rg.telkomuniversity.ac.id",
		"hauser.com",
		"hauser.org",
		// cPanel service hostnames tetap lolos (bukan infra noise)
		"cpcalendars.ucla.edu",
		"cpcontacts.ucla.edu",
		"cpanel.hackthebox.com",
		"webmail.hackthebox.com",
	}
	for _, l := range legitPatterns {
		if !seen[l] {
			t.Errorf("filterValid harus loloskan %q, tapi terbuang", l)
		}
	}
}
