package main

import (
	"context"
	"errors"
	"net"
	"testing"
	"time"

	"golang.org/x/net/proxy"
)

// fakeCtxDialer implements proxy.ContextDialer: it records the deadline the
// wrapper handed down, which is the whole point of using DialContext (x/net's
// SOCKS handshake sets that deadline on the socket AND aborts the read when the
// context is done).
type fakeCtxDialer struct {
	gotDeadline bool
	dialErr     error
}

func (f *fakeCtxDialer) Dial(network, addr string) (net.Conn, error) {
	return nil, errors.New("unused")
}

func (f *fakeCtxDialer) DialContext(ctx context.Context, network, addr string) (net.Conn, error) {
	if _, ok := ctx.Deadline(); ok {
		f.gotDeadline = true
	}
	return nil, f.dialErr
}

// blockingDialer implements only proxy.Dialer (no context support) and blocks
// forever, mimicking a SOCKS CONNECT that Tor accepts but never answers.
type blockingDialer struct {
	release chan struct{}
}

func (b *blockingDialer) Dial(network, addr string) (net.Conn, error) {
	<-b.release
	return nil, errors.New("released")
}

// A context-capable dialer must receive a deadline from the wrapper.
func TestTorDialContext_PropagatesDeadline(t *testing.T) {
	f := &fakeCtxDialer{dialErr: errors.New("boom")}
	dial := torDialContext(f)
	if _, err := dial(context.Background(), "tcp", "example.com:443"); err == nil {
		t.Fatal("expected the dial error to propagate")
	}
	if !f.gotDeadline {
		t.Fatal("DialContext was called without a deadline: a stuck SOCKS handshake could never be aborted")
	}
}

// A dialer without DialContext support must still be bounded by the caller's
// context: previously Transport.Dial ran with context.Background() and a stuck
// dial blocked its goroutine forever.
func TestTorDialContext_BoundsNonContextDialer(t *testing.T) {
	b := &blockingDialer{release: make(chan struct{})}
	defer close(b.release)
	dial := torDialContext(b)

	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Millisecond)
	defer cancel()

	start := time.Now()
	_, err := dial(ctx, "tcp", "example.com:443")
	elapsed := time.Since(start)
	if err == nil {
		t.Fatal("expected a timeout error, got nil")
	}
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("err = %v, want context.DeadlineExceeded", err)
	}
	if elapsed > 2*time.Second {
		t.Fatalf("dial took %v, want it bounded by the context deadline", elapsed)
	}
}

// A dialer whose proxy.Dial returns promptly must not be delayed by the wrapper.
func TestTorDialContext_FastDialerUnaffected(t *testing.T) {
	b := &blockingDialer{release: make(chan struct{})}
	close(b.release)
	dial := torDialContext(b)
	if _, err := dial(context.Background(), "tcp", "example.com:443"); err == nil {
		t.Fatal("expected the underlying dial error")
	}
}

// The dialer the tests exercise must itself satisfy proxy.ContextDialer, i.e.
// the wrapper's fast path is the one actually under test.
var _ proxy.ContextDialer = (*fakeCtxDialer)(nil)
