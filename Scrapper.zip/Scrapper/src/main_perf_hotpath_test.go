package main

import (
	"bufio"
	"fmt"
	"io"
	"math/rand"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
)

// ── PERF hot-path harness ─────────────────────────────────────────────────────
// These benchmarks pin down the CPU-side (non-network) cost of the pipeline.
// They exist so a regression in the filter / telemetry / write path shows up as
// ns/op, not as "the tool feels slow" during a 100k-domain run.
//
//	go test -run XXX -bench . -benchmem ./...

// randomSeedFile writes n realistic domain lines to a temp file.
func randomSeedFile(tb testing.TB, n int) string {
	tb.Helper()
	dir := tb.TempDir()
	p := filepath.Join(dir, "seeds.txt")
	var sb strings.Builder
	rnd := rand.New(rand.NewSource(7))
	labels := []string{"www", "api", "dev", "mail", "vpn", "cdn", "assets", "portal", "sso", "shop", "static", "app"}
	for i := 0; i < n; i++ {
		sb.WriteString(fmt.Sprintf("%s%d-%d.example%d.ac.id\n", labels[rnd.Intn(len(labels))], i%97, rnd.Intn(1000), i%5000))
	}
	if err := os.WriteFile(p, []byte(sb.String()), 0o644); err != nil {
		tb.Fatalf("write seed file: %v", err)
	}
	return p
}

func BenchmarkReadList100k(b *testing.B) {
	p := randomSeedFile(b, 100000)
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		out, err := readList(p)
		if err != nil {
			b.Fatalf("readList: %v", err)
		}
		if len(out) != 100000 {
			b.Fatalf("readList returned %d domains, want 100000", len(out))
		}
	}
}

func BenchmarkRecordFilterDecision(b *testing.B) {
	h := NewDebugHub(200)
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		h.RecordFilterDecision("sub.example.com", "Legitimate", "ACCEPT")
	}
}

func BenchmarkSetWorkerState(b *testing.B) {
	h := NewDebugHub(200)
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		h.SetWorkerState(i%64, "CRT_FETCH", "api.example.com")
	}
}

// BenchmarkWriteLinesParallel measures the shared-lock write funnel that every
// worker hits once per processed apex.
// BenchmarkSeedStartup100k replays runMass's input phase (read the file,
// compute registrable domains, seed dedup) so the startup cost of big seed
// lists is pinned: readList used to recompile a regex per line.
func BenchmarkSeedStartup100k(b *testing.B) {
	p := randomSeedFile(b, 100000)
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		list, err := readList(p)
		if err != nil {
			b.Fatalf("readList: %v", err)
		}
		if len(list) != 100000 {
			b.Fatalf("readList returned %d domains, want 100000", len(list))
		}
		apexes := buildSeedApexes(list)
		if len(apexes) == 0 {
			b.Fatalf("buildSeedApexes returned no apexes")
		}
		var visited sync.Map
		for _, d := range list {
			visited.Store(d, true)
		}
	}
}

func BenchmarkWriteLinesParallel(b *testing.B) {
	batch := make([]string, 40)
	for i := range batch {
		batch[i] = fmt.Sprintf("s%d.api.example.com", i)
	}
	b.ReportAllocs()
	b.ResetTimer()
	b.RunParallel(func(pb *testing.PB) {
		shared := &sharedState{
			visited:    sync.Map{},
			apexDone:   map[string]bool{},
			apexCount:  map[string]int{},
			w:          bufio.NewWriter(io.Discard),
			ipDone:     map[string]bool{},
			seedApexes: map[string]bool{},
			cancel:     func() {},
		}
		w := &worker{shared: shared}
		for pb.Next() {
			w.writeLines(batch)
		}
	})
}

// BenchmarkFilterValid measures the per-candidate filter chain, the function
// called for every host returned by every provider.
func BenchmarkFilterValid(b *testing.B) {
	in := make([]string, 0, 200)
	for i := 0; i < 200; i++ {
		in = append(in, fmt.Sprintf("host%d.api.example.com", i))
	}
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		filterValid(in)
	}
}

func BenchmarkIsValidDomain(b *testing.B) {
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		isValidDomain("api.sub.example.co.id")
	}
}

func BenchmarkETLDPlusOneCached(b *testing.B) {
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		eTLDPlusOne("api.sub.example.co.id")
	}
}

func BenchmarkInSkipZone(b *testing.B) {
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		inSkipZone("cdn.assets.example.gov.my")
	}
}

func BenchmarkIsBigTechOrPaaS(b *testing.B) {
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		isBigTechOrPaaS("cdn.assets.example.gov.my")
	}
}

func BenchmarkIsInfraNoise(b *testing.B) {
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		isInfraNoise("cdn.assets.example.gov.my")
	}
}

func BenchmarkIsProvisioningSpam(b *testing.B) {
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		isProvisioningSpam("cdn.assets.example.gov.my")
	}
}

func BenchmarkApexOf(b *testing.B) {
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		apexOf("cdn.assets.example.gov.my")
	}
}

// BenchmarkTidyOutputFile200k measures the end-of-run sort/dedup rewrite: this is
// pure wall-clock added AFTER the last domain is found and BEFORE "[ Done ]".
func BenchmarkTidyOutputFile200k(b *testing.B) {
	dir := b.TempDir()
	p := filepath.Join(dir, "out.txt")
	var sb strings.Builder
	rnd := rand.New(rand.NewSource(11))
	for i := 0; i < 200000; i++ {
		sb.WriteString(fmt.Sprintf("www%d.example%d.com\n", rnd.Intn(100000), i%2000))
	}
	content := sb.String()
	b.ReportAllocs()
	b.SetBytes(int64(len(content)))
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if err := os.WriteFile(p, []byte(content), 0o644); err != nil {
			b.Fatalf("write: %v", err)
		}
		tidyOutputFile(p)
	}
}
