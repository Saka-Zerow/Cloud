package main

import (
	"fmt"
	"net/http"
	"os"
	"testing"
	"time"

	"golang.org/x/net/proxy"
)

// ---- live test (opt-in) -----------------------------------------------------
//
// Requires a Tor with a null-auth control port, e.g.:
//
//	tor --SocksPort 9060 --ControlPort 9061 --CookieAuthentication 0 --DataDirectory <dir>
//	TOR_CTRL=127.0.0.1:9061 TOR_SOCKS=127.0.0.1:9060 go test -run TestLiveTorExitSteering -v
//
// It proves, against a real Tor, the two claims this feature rests on:
//   1. the exit relay identified via the control port is the one that carried
//      the request (its descriptor IP equals the IP-echo answer);
//   2. once that relay is excluded, Tor stops handing it to us.
//
// NOTE: it changes ExcludeExitNodes on the instance you point it at, so use a
// disposable one.

func socksClientForAddr(socks, user string) (*http.Client, error) {
	d, err := proxy.SOCKS5("tcp", socks, &proxy.Auth{User: user, Password: "x"}, proxy.Direct)
	if err != nil {
		return nil, err
	}
	return &http.Client{Transport: &http.Transport{Dial: d.Dial}, Timeout: 40 * time.Second}, nil
}

func TestLiveTorExitSteering(t *testing.T) {
	ctrlAddr, socksAddr := os.Getenv("TOR_CTRL"), os.Getenv("TOR_SOCKS")
	if ctrlAddr == "" || socksAddr == "" {
		t.Skip("set TOR_CTRL + TOR_SOCKS to a control-enabled Tor to run")
	}
	isolateBlacklist(t)

	ctl := newTorCtl(ctrlAddr)
	if ctl == nil {
		t.Skipf("control port %s tidak bisa dipakai (butuh null auth)", ctrlAddr)
	}
	defer ctl.close()
	// Register it the way startTorExitSteering() does at run start (BEFORE any
	// request), so the production attribution path sees the stream events.
	exitHealth.mu.Lock()
	exitHealth.ctls[ctrlAddr] = ctl
	delete(exitHealth.ctlFailAt, ctrlAddr)
	exitHealth.mu.Unlock()
	t.Cleanup(func() {
		exitHealth.mu.Lock()
		delete(exitHealth.ctls, ctrlAddr)
		exitHealth.mu.Unlock()
	})

	user := fmt.Sprintf("live_%d", time.Now().UnixNano()%10000000)
	client, err := socksClientForAddr(socksAddr, user)
	if err != nil {
		t.Fatal(err)
	}
	echoIP := torExitIP(client)
	if echoIP == "" {
		t.Skip("no reachable IP echo service")
	}
	fp := ctl.exitForUser(user)
	if fp == "" {
		t.Fatalf("exit relay of our own request (%s) not identified via control port", user)
	}
	descIP := ctl.relayIP(fp)
	t.Logf("request user=%s echo IP=%s -> exit relay %s (%s)", user, echoIP, shortFP(fp), descIP)
	if descIP != echoIP {
		t.Fatalf("exit attribution WRONG: control says %s, echo says %s", descIP, echoIP)
	}

	// Production policy path: three transient blocks on the same relay ban it.
	exitHealth.noteBlocked(socksAddr, user, "live 429")
	exitHealth.noteBlocked(socksAddr, user, "live 429")
	if len(exitHealth.bannedList()) != 0 {
		t.Fatal("transient block banned before the strike threshold")
	}
	exitHealth.noteBlocked(socksAddr, user, "live 429")
	banned := false
	for _, b := range exitHealth.bannedList() {
		if b == fp {
			banned = true
		}
	}
	if !banned {
		t.Fatalf("relay %s not banned after %d strikes (list=%v)", shortFP(fp), torExitStrikesToBan, exitHealth.bannedList())
	}

	// Apply the ban the same way applyLoop does, then draw 8 fresh circuits.
	if err := ctl.exclude(exitHealth.bannedList()); err != nil {
		t.Fatalf("SETCONF ExcludeExitNodes: %v", err)
	}
	reuse := 0
	for i := 0; i < 8; i++ {
		u := fmt.Sprintf("live_after%d_%d", i, time.Now().UnixNano()%100000)
		c2, err := socksClientForAddr(socksAddr, u)
		if err != nil {
			t.Fatal(err)
		}
		ip := torExitIP(c2)
		f2 := ctl.exitForUser(u)
		if f2 == fp {
			reuse++
		}
		t.Logf("  after %d: ip=%s relay=%s", i, ip, shortFP(f2))
	}
	t.Logf("excluded relay reused %d/8 times", reuse)
	if reuse > 0 {
		t.Errorf("ExcludeExitNodes tidak mencegah relay yang diblokir dipakai lagi")
	}
}
