package main

import "testing"

// Regression guard for the startup stall: KeepAliveIsolateSOCKSAuth used to be
// passed as its own top-level option ("--KeepAliveIsolateSOCKSAuth", "1"), which
// real tor rejects at config parse ("Unknown option"). Every autostarted Tor
// then exited immediately, so no SocksPort ever opened and ensureTorFleet burned
// its full 24s wait ceiling before the run silently fell back to direct IP.
func TestTorSpawnArgs_FlagRidesOnSocksPort(t *testing.T) {
	args := torSpawnArgs("9050", " KeepAliveIsolateSOCKSAuth", `C:\tmp\d`, "9051", `C:\tmp\d\control_port`)

	socks := ""
	for i, a := range args {
		if a == "--SocksPort" {
			if i+1 >= len(args) {
				t.Fatalf("--SocksPort without a value in %q", args)
			}
			socks = args[i+1]
		}
	}
	if socks != "9050 KeepAliveIsolateSOCKSAuth" {
		t.Fatalf("SocksPort value = %q, want %q", socks, "9050 KeepAliveIsolateSOCKSAuth")
	}
	for _, a := range args {
		if a == "--KeepAliveIsolateSOCKSAuth" || a == "KeepAliveIsolateSOCKSAuth" {
			t.Fatalf("flag leaked as a top-level option: %q", args)
		}
	}
}

// Older Tor builds do not know the flag: the spawn must degrade to a plain
// SocksPort (IsolateSOCKSAuth stays default-on) instead of dying at parse.
func TestTorSpawnArgs_PlainSocksPortWhenUnsupported(t *testing.T) {
	args := torSpawnArgs("9052", "", `C:\tmp\d`, "9053", `C:\tmp\d\control_port`)

	found := false
	for i, a := range args {
		if a == "--SocksPort" {
			found = true
			if args[i+1] != "9052" {
				t.Fatalf("SocksPort value = %q, want plain %q", args[i+1], "9052")
			}
		}
	}
	if !found {
		t.Fatalf("no --SocksPort in %q", args)
	}
	for _, a := range args {
		if a == "KeepAliveIsolateSOCKSAuth" {
			t.Fatalf("unsupported flag still passed: %q", args)
		}
	}
}

// Every option we pass must come with exactly one value, so a future edit cannot
// silently turn an option into a stray positional that tor reads as a config
// line (the original failure mode was an option/value pair tor did not know).
func TestTorSpawnArgs_OptionValuePairs(t *testing.T) {
	args := torSpawnArgs("9050", " KeepAliveIsolateSOCKSAuth", `C:\tmp\d`, "9051", `C:\tmp\d\cp`)
	if len(args) == 0 || len(args)%2 != 0 {
		t.Fatalf("expected option/value pairs, got %d args: %q", len(args), args)
	}
	for i := 0; i < len(args); i += 2 {
		if args[i][0] != '-' || args[i][1] != '-' {
			t.Fatalf("arg %d = %q, want a --option", i, args[i])
		}
		if args[i+1] == "" {
			t.Fatalf("option %q has an empty value", args[i])
		}
	}

	want := map[string]string{
		"--SocksPort":                "9050 KeepAliveIsolateSOCKSAuth",
		"--DataDirectory":            `C:\tmp\d`,
		"--ControlPort":              "9051",
		"--ControlPortWriteToFile":   `C:\tmp\d\cp`,
		"--CookieAuthentication":     "0",
		"--MaxCircuitDirtiness":      "3600",
		"--MaxClientCircuitsPending": "128",
	}
	for i := 0; i < len(args); i += 2 {
		w, ok := want[args[i]]
		if !ok {
			t.Fatalf("unexpected option %q", args[i])
		}
		if args[i+1] != w {
			t.Fatalf("%s = %q, want %q", args[i], args[i+1], w)
		}
		delete(want, args[i])
	}
	for k := range want {
		t.Fatalf("missing option %s", k)
	}
}

// A missing binary must never be reported as flag-capable, otherwise the fleet
// is spawned with a flag nothing validated.
func TestTorAcceptsSocksFlag_EmptyBinaryIsFalse(t *testing.T) {
	if torAcceptsSocksFlag("", " KeepAliveIsolateSOCKSAuth") {
		t.Fatal("empty tor binary reported as supporting the flag")
	}
}
