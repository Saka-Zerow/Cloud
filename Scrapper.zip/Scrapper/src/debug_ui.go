package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/pprof"
	"runtime"
	"strings"
	"time"
)

// RegisterDebugRoutes attaches all debug endpoints and HUD to the provided HTTP mux
func RegisterDebugRoutes(mux *http.ServeMux) {
	mux.HandleFunc("/debug", handleDebugHUD)
	mux.HandleFunc("/api/debug/snapshot", handleDebugSnapshot)
	mux.HandleFunc("/api/debug/events", handleDebugEvents)
	mux.HandleFunc("/api/debug/action", handleDebugAction)
}

// RegisterDebugPprof mounts the Go runtime profiler on the same loopback+token
// guard as the rest of the debug API. It is opt-in (only wired up when the debug
// server is started) and completely passive until a profile is actually
// requested, so it costs nothing on the scraping hot path.
//
//	/debug/pprof/profile?seconds=20&token=...   -> CPU profile
//	/debug/pprof/heap?token=...                 -> heap profile
//	/debug/pprof/goroutine?debug=1&token=...    -> goroutine dump
func RegisterDebugPprof(mux *http.ServeMux) {
	guard := func(h http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			if !isLoopbackHost(r) || !ValidateDebugToken(r) {
				http.Error(w, `{"error":"unauthorized: invalid or missing debug token"}`, http.StatusUnauthorized)
				return
			}
			h(w, r)
		}
	}
	// pprof.Index dispatches /debug/pprof/<name> itself (heap, goroutine,
	// allocs, block, mutex, threadcreate, cmdline, symbol, trace).
	mux.HandleFunc("/debug/pprof/", guard(pprof.Index))
	mux.HandleFunc("/debug/pprof/profile", guard(pprof.Profile))
	mux.HandleFunc("/debug/pprof/cmdline", guard(pprof.Cmdline))
	mux.HandleFunc("/debug/pprof/symbol", guard(pprof.Symbol))
	mux.HandleFunc("/debug/pprof/trace", guard(pprof.Trace))
}

// handleDebugSnapshot returns the full JSON snapshot (protected by token)
func handleDebugSnapshot(w http.ResponseWriter, r *http.Request) {
	if !isLoopbackHost(r) || !ValidateDebugToken(r) {
		http.Error(w, `{"error":"unauthorized: invalid or missing debug token"}`, http.StatusUnauthorized)
		return
	}
	snapshot := globalDebug.Snapshot()
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-cache")
	json.NewEncoder(w).Encode(snapshot)
}

// handleDebugEvents streams SSE updates every 500ms to the client
func handleDebugEvents(w http.ResponseWriter, r *http.Request) {
	if !isLoopbackHost(r) || !ValidateDebugToken(r) {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}

	flusher, ok := w.(http.Flusher)
	if !ok {
		http.Error(w, "streaming unsupported", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	w.Header().Set("Connection", "keep-alive")

	ticker := time.NewTicker(500 * time.Millisecond)
	defer ticker.Stop()

	for {
		select {
		case <-r.Context().Done():
			return
		case <-ticker.C:
			snapshot := globalDebug.Snapshot()
			data, err := json.Marshal(snapshot)
			if err != nil {
				continue
			}
			if _, err := fmt.Fprintf(w, "data: %s\n\n", data); err != nil {
				return
			}
			flusher.Flush()
		}
	}
}

// handleDebugAction executes administrative maintenance commands
func handleDebugAction(w http.ResponseWriter, r *http.Request) {
	if !isLoopbackHost(r) || !ValidateDebugToken(r) {
		http.Error(w, `{"error":"unauthorized"}`, http.StatusUnauthorized)
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, `{"error":"method not allowed"}`, http.StatusMethodNotAllowed)
		return
	}

	var req struct {
		Action string `json:"action"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, `{"error":"invalid json"}`, http.StatusBadRequest)
		return
	}

	res := map[string]interface{}{"ok": true, "action": req.Action}

	switch req.Action {
	case "switch_tor":
		ctrl := torControlAddrFor(defaultTorSocks)
		if ctrl == "" {
			ctrl = defaultTorCtrl
		}
		switched := torRotateCtrl(ctrl)
		res["switched"] = switched
		if switched {
			globalDebug.RecordTorSwitch("")
		}
	case "trigger_gc":
		before := runtime.NumGoroutine()
		runtime.GC()
		res["goroutines"] = before
		res["message"] = "Garbage Collection completed"
	case "reset_stats":
		globalDebug.Reset()
		res["message"] = "Telemetry counters reset"
	default:
		http.Error(w, `{"error":"unknown action"}`, http.StatusBadRequest)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(res)
}

// handleDebugHUD renders the Dark Cyberpunk High-Tech Debug Dashboard
func handleDebugHUD(w http.ResponseWriter, r *http.Request) {
	if !isLoopbackHost(r) || !ValidateDebugToken(r) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.WriteHeader(http.StatusUnauthorized)
		w.Write([]byte(`<!DOCTYPE html>
<html>
<head><title>401 Unauthorized — SubMass Debug HUD</title>
<style>
body { background: #080c14; color: #ff3366; font-family: monospace; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
.box { background: #0e1526; border: 1px solid #ff3366; padding: 32px; border-radius: 8px; text-align: center; max-width: 460px; box-shadow: 0 0 30px rgba(255,51,102,0.2); }
h2 { margin-top: 0; }
p { color: #8b9bb4; font-size: 14px; line-height: 1.6; }
code { background: #18223c; color: #00ffcc; padding: 2px 6px; border-radius: 4px; }
</style>
</head>
<body>
<div class="box">
  <h2>ACCESS DENIED (401)</h2>
  <p>Real-Time Debug HUD hanya dapat diakses oleh Administrator, AI Bot, dan Developer Tools berotorisasi.</p>
  <p>Sertakan token autentikasi di URL:<br><code>/debug?token=YOUR_TOKEN</code></p>
</div>
</body>
</html>`))
		return
	}

	token := r.URL.Query().Get("token")
	if token == "" {
		token = r.Header.Get("X-Debug-Token")
	}

	safeToken := strings.ReplaceAll(strings.ReplaceAll(token, "\\", "\\\\"), "\"", "\\\"")
	safeToken = strings.ReplaceAll(safeToken, "<", "&lt;")
	safeToken = strings.ReplaceAll(safeToken, ">", "&gt;")
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Write([]byte(strings.ReplaceAll(debugDashboardHTML, "__DEBUG_TOKEN__", safeToken)))
}

const debugDashboardHTML = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>SubMass — Real-Time Deep Debug HUD</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
:root {
  --bg: #070a12;
  --panel: #0d1322;
  --border: #1a233a;
  --text: #c5d1eb;
  --muted: #627293;
  --accent: #00ffcc;
  --accent2: #7928ca;
  --danger: #ff3366;
  --warning: #ffb800;
  --success: #00e676;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { background: var(--bg); color: var(--text); font-family: 'SF Mono', Consolas, 'Courier New', monospace; font-size: 13px; line-height: 1.4; padding: 16px; }
.header { display: flex; justify-content: space-between; align-items: center; padding-bottom: 16px; border-bottom: 1px solid var(--border); margin-bottom: 16px; }
.title-group { display: flex; align-items: baseline; gap: 12px; }
.title { font-size: 18px; font-weight: bold; color: var(--accent); letter-spacing: 1px; }
.badge-admin { background: rgba(0,255,204,0.15); border: 1px solid var(--accent); color: var(--accent); padding: 2px 8px; border-radius: 4px; font-size: 11px; }
.top-metrics { display: flex; gap: 20px; font-size: 12px; }
.metric-pill { background: var(--panel); border: 1px solid var(--border); padding: 4px 10px; border-radius: 6px; }
.metric-pill span { color: var(--accent); font-weight: bold; }

.grid-layout { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.full-width { grid-column: 1 / -1; }

.panel { background: var(--panel); border: 1px solid var(--border); border-radius: 8px; padding: 14px; overflow: hidden; }
.panel-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; font-size: 12px; color: var(--muted); text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 6px; }

/* Workers Grid */
.workers-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 8px; max-height: 220px; overflow-y: auto; }
.worker-card { background: #121a2f; border: 1px solid #1e2a4a; padding: 6px 8px; border-radius: 4px; font-size: 11px; }
.worker-card.idle { opacity: 0.5; }
.worker-id { font-weight: bold; color: #8ba2d0; display: flex; justify-content: space-between; }
.worker-state { display: inline-block; padding: 1px 4px; border-radius: 3px; font-size: 9px; margin-top: 2px; }
.state-IDLE { background: #263353; color: #8ba2d0; }
.state-CRT_FETCH { background: rgba(0,255,204,0.2); color: #00ffcc; }
.state-RAPID_FETCH { background: rgba(121,40,202,0.3); color: #c084fc; }
.state-REVERSE_EXPAND { background: rgba(255,184,0,0.2); color: #ffb800; }
.state-BACKOFF_429 { background: rgba(255,51,102,0.3); color: #ff3366; }
.worker-dom { font-size: 10px; color: #a4b3d6; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 4px; }

/* Filter Stream */
.filter-stream { height: 260px; overflow-y: auto; background: #060911; border: 1px solid #141c2e; border-radius: 4px; padding: 8px; font-size: 11px; }
.filter-row { display: flex; gap: 8px; padding: 3px 0; border-bottom: 1px solid rgba(255,255,255,0.03); align-items: center; }
.filter-time { color: var(--muted); font-size: 10px; }
.v-badge { padding: 1px 6px; border-radius: 3px; font-size: 9px; font-weight: bold; min-width: 85px; text-align: center; }
.v-ACCEPT { background: rgba(0,230,118,0.2); color: #00e676; border: 1px solid rgba(0,230,118,0.3); }
.v-DROP_INFRA { background: rgba(255,184,0,0.2); color: #ffb800; border: 1px solid rgba(255,184,0,0.3); }
.v-DROP_BIGTECH { background: rgba(255,51,102,0.2); color: #ff3366; border: 1px solid rgba(255,51,102,0.3); }
.v-DROP_PAAS { background: rgba(192,132,252,0.2); color: #c084fc; border: 1px solid rgba(192,132,252,0.3); }
.v-DROP_CPANEL { background: rgba(234,179,8,0.2); color: #eab308; border: 1px solid rgba(234,179,8,0.3); }
.v-DROP_DHCP { background: rgba(59,130,246,0.2); color: #60a5fa; border: 1px solid rgba(59,130,246,0.3); }
.filter-dom { flex: 1; color: #d4e0fa; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.filter-rule { color: var(--muted); font-size: 10px; }

/* Stats Row */
.stat-box { display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,0.03); }
.stat-label { color: var(--muted); }
.stat-val { font-weight: bold; color: var(--text); }

/* Action Buttons */
.btn-bar { display: flex; gap: 8px; margin-top: 12px; }
.btn { background: #162038; border: 1px solid #28375c; color: #a4badf; padding: 6px 12px; border-radius: 4px; cursor: pointer; font-family: inherit; font-size: 11px; transition: all 0.2s; }
.btn:hover { background: #202e52; color: #fff; border-color: var(--accent); }
.btn-accent { background: rgba(0,255,204,0.15); border-color: var(--accent); color: var(--accent); }
.btn-danger { background: rgba(255,51,102,0.15); border-color: var(--danger); color: var(--danger); }
</style>
</head>
<body>

<div class="header">
  <div class="title-group">
    <div class="title">SUBMASS TELEMETRY HUD</div>
    <div class="badge-admin">ADMIN / AI BOT CORE</div>
  </div>
  <div class="top-metrics">
    <div class="metric-pill">Speed: <span id="m-speed">0.0</span> /s</div>
    <div class="metric-pill">Found: <span id="m-found">0</span> / <span id="m-target">0</span></div>
    <div class="metric-pill">Queue: <span id="m-queue">0</span></div>
    <div class="metric-pill">Tor Exit: <span id="m-tor">...</span></div>
    <div class="metric-pill">Uptime: <span id="m-uptime">0s</span></div>
  </div>
</div>

<div class="grid-layout">

  <!-- Workers Matrix -->
  <div class="panel full-width">
    <div class="panel-head">
      <span>WORKER THREAD MATRIX (<span id="w-active">0</span> ACTIVE)</span>
      <span id="w-count">0 THREADS TOTAL</span>
    </div>
    <div class="workers-grid" id="workers-container">
      <div style="color:var(--muted);padding:10px;">Menunggu worker beroperasi...</div>
    </div>
  </div>

  <!-- Realtime Filter Decisions -->
  <div class="panel">
    <div class="panel-head">
      <span>LIVE FILTER INSPECTOR (AUDIT REAL-TIME)</span>
      <span>ACC: <span id="f-acc" style="color:var(--success)">0</span> | DROP: <span id="f-drop" style="color:var(--danger)">0</span></span>
    </div>
    <div class="filter-stream" id="filter-container"></div>
    <div style="margin-top:8px;font-size:10px;color:var(--muted);display:flex;gap:12px;">
      <span>Infra: <b id="d-infra">0</b></span>
      <span>BigTech: <b id="d-bigtech">0</b></span>
      <span>PaaS: <b id="d-paas">0</b></span>
      <span>cPanel: <b id="d-cpanel">0</b></span>
      <span>DHCP: <b id="d-dhcp">0</b></span>
    </div>
  </div>

  <!-- System & Network Diagnostics -->
  <div class="panel">
    <div class="panel-head">
      <span>SYSTEM & NETWORK LATENCY</span>
      <span>GO RUNTIME</span>
    </div>
    
    <div class="stat-box"><span class="stat-label">CRT Avg Latency:</span><span class="stat-val" id="n-crt-lat">0 ms (0 req, 0 err, 0 rate-429)</span></div>
    <div class="stat-box"><span class="stat-label">RapidDNS Latency:</span><span class="stat-val" id="n-rapid-lat">0 ms (0 req, 0 err)</span></div>
    <div class="stat-box"><span class="stat-label">Dual DNS Latency:</span><span class="stat-val" id="n-dns-lat">0 ms (0 req, 0 err)</span></div>
    <div class="stat-box"><span class="stat-label">Tor Circuit Switches:</span><span class="stat-val" id="n-tor-sw">0 (Last: none)</span></div>
    
    <div style="margin-top:12px;padding-top:8px;border-top:1px solid rgba(255,255,255,0.05)">
      <div class="stat-box"><span class="stat-label">Goroutines:</span><span class="stat-val" id="s-goroutines">0</span></div>
      <div class="stat-box"><span class="stat-label">Heap Memory:</span><span class="stat-val" id="s-heap">0 MB (Alloc) / 0 MB (Sys)</span></div>
      <div class="stat-box"><span class="stat-label">Garbage Collector:</span><span class="stat-val" id="s-gc">0 cycles (Pause: 0 ms)</span></div>
    </div>

    <div class="btn-bar">
      <button class="btn btn-accent" onclick="runAction('switch_tor')">Rotate Tor Circuit</button>
      <button class="btn" onclick="runAction('trigger_gc')">Free RAM (GC)</button>
      <button class="btn" onclick="downloadSnapshot()">Dump JSON State</button>
    </div>
  </div>

</div>

<script>
const TOKEN = "__DEBUG_TOKEN__";
const evtSource = new EventSource('/api/debug/events?token=' + TOKEN);

evtSource.onmessage = function(e) {
  const data = JSON.parse(e.data);
  updateHUD(data);
};

evtSource.onerror = function() {
  document.getElementById('m-tor').innerText = 'Reconnecting...';
};

function updateHUD(s) {
  document.getElementById('m-speed').innerText = s.speedPerSec.toFixed(1);
  document.getElementById('m-found').innerText = s.uniqueFound;
  document.getElementById('m-target').innerText = s.target;
  document.getElementById('m-queue').innerText = s.queueLen;
  document.getElementById('m-tor').innerText = s.network.torExitIP || 'off';
  document.getElementById('m-uptime').innerText = s.uptimeSec + 's';

  document.getElementById('w-active').innerText = s.activeWorkers;
  document.getElementById('w-count').innerText = s.workers.length + ' THREADS';

  // Workers
  const wCont = document.getElementById('workers-container');
  if (s.workers && s.workers.length > 0) {
    let html = '';
    s.workers.forEach(w => {
      const isIdle = w.state === 'IDLE' || !w.state;
      html += '<div class="worker-card ' + (isIdle ? 'idle' : '') + '">' +
        '<div class="worker-id"><span>W' + String(w.id+1).padStart(2,'0') + '</span><span>+' + w.domainsFound + '</span></div>' +
        '<span class="worker-state state-' + (w.state || 'IDLE') + '">' + (w.state || 'IDLE') + '</span>' +
        '<div class="worker-dom" title="' + (w.domain || '-') + '">' + (w.domain || '-') + '</div>' +
        '</div>';
    });
    wCont.innerHTML = html;
  }

  // Filter Stream
  document.getElementById('f-acc').innerText = s.totalAccepted;
  document.getElementById('f-drop').innerText = s.totalDropped;
  if (s.dropBreakdown) {
    document.getElementById('d-infra').innerText = s.dropBreakdown.infra || 0;
    document.getElementById('d-bigtech').innerText = s.dropBreakdown.bigtech || 0;
    document.getElementById('d-paas').innerText = s.dropBreakdown.paas || 0;
    document.getElementById('d-cpanel').innerText = s.dropBreakdown.cpanel || 0;
    document.getElementById('d-dhcp').innerText = s.dropBreakdown.dhcp || 0;
  }

  const fCont = document.getElementById('filter-container');
  if (s.recentDecisions && s.recentDecisions.length > 0) {
    let fHtml = '';
    // Show newest first
    for (let i = s.recentDecisions.length - 1; i >= 0; i--) {
      const d = s.recentDecisions[i];
      fHtml += '<div class="filter-row">' +
        '<span class="filter-time">' + d.time.split('.')[0] + '</span>' +
        '<span class="v-badge v-' + d.verdict + '">' + d.verdict + '</span>' +
        '<span class="filter-dom" title="' + d.domain + '">' + d.domain + '</span>' +
        '<span class="filter-rule">' + (d.rule || '') + '</span>' +
        '</div>';
    }
    fCont.innerHTML = fHtml;
  }

  // Network
  document.getElementById('n-crt-lat').innerText = s.network.crtLatencyMs + ' ms (' + s.network.crtRequests + ' req, ' + s.network.crtErrors + ' err, ' + s.network.crt429Count + ' 429)';
  document.getElementById('n-rapid-lat').innerText = s.network.rapidLatencyMs + ' ms (' + s.network.rapidRequests + ' req, ' + s.network.rapidErrors + ' err)';
  document.getElementById('n-dns-lat').innerText = s.network.dnsLatencyMs + ' ms (' + s.network.dnsRequests + ' req, ' + s.network.dnsErrors + ' err)';
  document.getElementById('n-tor-sw').innerText = s.network.torSwitches + ' (Last: ' + (s.network.lastTorSwitchTime || 'none') + ')';

  // System
  document.getElementById('s-goroutines').innerText = s.system.goroutines;
  document.getElementById('s-heap').innerText = s.system.heapAllocMB.toFixed(1) + ' MB / ' + s.system.heapSysMB.toFixed(1) + ' MB';
  document.getElementById('s-gc').innerText = s.system.numGC + ' cycles (Pause: ' + s.system.gcPauseMs.toFixed(1) + ' ms)';
}

function runAction(action) {
  fetch('/api/debug/action?token=' + TOKEN, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: action })
  }).then(r => r.json()).then(res => {
    alert('Action [' + action + '] completed: ' + JSON.stringify(res));
  }).catch(e => alert('Action error: ' + e));
}

function downloadSnapshot() {
  window.open('/api/debug/snapshot?token=' + TOKEN, '_blank');
}
</script>
</body>
</html>`
