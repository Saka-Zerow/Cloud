package main

import "testing"

// Regression (2026-09-27): a live rapiddns lookup for dataanalyst.id lists 8
// distinct hosts, but the tool emitted only +2 (mail, www) because the
// cPanel auto-generated filter (cpanelAutoRe) also matched the bare service
// hostnames webmail/webdisk/cpcontacts/cpcalendars/cpanel and silently dropped
// them. The output therefore looked "fake" next to the source page.
//
// This pins the full rapiddns row set through parse -> filterValid ->
// filterSubdomains with keepInfra=false (the interactive default) so the drop
// can never come back unnoticed.
func TestRapidDNSCpanelServiceHostsSurvive(t *testing.T) {
	rows := []string{
		"www.dataanalyst.id",         // CNAME
		"webmail.dataanalyst.id",     // A
		"webdisk.dataanalyst.id",     // A
		"mail.dataanalyst.id",        // CNAME
		"dataanalyst.id",             // A (apex, dropped later by the writer)
		"cpcontacts.dataanalyst.id",  // A
		"cpcalendars.dataanalyst.id", // A
		"cpanel.dataanalyst.id",      // A
	}

	body := []byte(rapiddnsTable(rows, nil))
	parsed := parseRapidHTML(body)
	if len(parsed) != len(rows) {
		t.Fatalf("parseRapidHTML extracted %d hosts, want %d: %v", len(parsed), len(rows), parsed)
	}

	oldKeep := keepInfra
	keepInfra = false
	defer func() { keepInfra = oldKeep }()

	out := filterSubdomains(filterValid(parsed), "dataanalyst.id")
	seen := make(map[string]bool, len(out))
	for _, d := range out {
		seen[d] = true
	}

	want := []string{
		"www.dataanalyst.id",
		"webmail.dataanalyst.id",
		"webdisk.dataanalyst.id",
		"mail.dataanalyst.id",
		"cpcontacts.dataanalyst.id",
		"cpcalendars.dataanalyst.id",
		"cpanel.dataanalyst.id",
	}
	for _, d := range want {
		if !seen[d] {
			t.Errorf("keepInfra=false dropped %q, got %v", d, out)
		}
	}
	if len(out) != 8 {
		t.Errorf("expected 8 hosts (7 subs + apex), got %d: %v", len(out), out)
	}

	// The service labels themselves must not be infra noise anymore.
	for _, d := range []string{
		"webmail.dataanalyst.id",
		"webdisk.dataanalyst.id",
		"cpcontacts.dataanalyst.id",
		"cpcalendars.dataanalyst.id",
		"cpanel.dataanalyst.id",
	} {
		if isInfraNoise(d) {
			t.Errorf("isInfraNoise(%q) = true, want false (real target subdomain)", d)
		}
	}

	// Auto-generated panel placeholders must still be dropped...
	for _, d := range []string{
		"lac.tempurl.host.telkomuniversity.ac.id",
		"panel-smb243.telkomuniversity.ac.id",
		"spanel.nam.business",
		"wppanel.nam.business",
		"newpanel.nam.business",
	} {
		if !isInfraNoise(d) {
			t.Errorf("isInfraNoise(%q) = false, want true (hosting placeholder)", d)
		}
	}

	// ...while real mail-autoconfig service records stay legit.
	for _, d := range []string{
		"autodiscover.dataanalyst.id",
		"autoconfig.dataanalyst.id",
	} {
		if isInfraNoise(d) {
			t.Errorf("isInfraNoise(%q) = true, want false (real service record)", d)
		}
	}
}
