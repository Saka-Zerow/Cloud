package main

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
)

func TestTorCtrlFromSocks(t *testing.T) {
	tests := []struct {
		socks    string
		expected string
	}{
		{"127.0.0.1:9050", "127.0.0.1:9051"},
		{"127.0.0.1:9052", "127.0.0.1:9053"},
		{"127.0.0.1:9060", "127.0.0.1:9061"},
		{"9050", "127.0.0.1:9051"},
		{"off", ""},
		{"false", ""},
		{"", ""},
	}
	for _, tt := range tests {
		got := torCtrlFromSocks(tt.socks)
		if got != tt.expected {
			t.Errorf("torCtrlFromSocks(%q) = %q, want %q", tt.socks, got, tt.expected)
		}
	}
}

func TestApexOf(t *testing.T) {
	tests := []struct {
		domain string
		expect string
	}{
		{"www.example.com", "example.com"},
		{"a.b.c.example.co.uk", "example.co.uk"},
		{"example.com", "example.com"},
		{"sub.domain.example.com", "example.com"},
		{"lan.go.id", "lan.go.id"},
	}
	for _, tt := range tests {
		got := apexOf(tt.domain)
		if got != tt.expect {
			t.Errorf("apexOf(%q) = %q, want %q", tt.domain, got, tt.expect)
		}
	}
}

func TestIsValidDomain(t *testing.T) {
	valid := []string{
		"sub.megasite.test",
		"www.megasite.test",
		"test-domain.co.uk",
		"mail.validsite.test",
	}
	invalid := []string{
		"",
		"   ",
		"example",
		"example.",
		".example.com",
		"exa mple.com",
		"example@com",
		"192.168.1.1",
		"example..com",
		// guard dokumentasi/RFC: example.* bukan target nyata (rapiddns placeholder)
		"example.com",
		"sub.example.com",
		"www.example.org",
		"probe.example.net",
	}
	for _, d := range valid {
		if !isValidDomain(d) {
			t.Errorf("isValidDomain(%q) should be true", d)
		}
	}
	for _, d := range invalid {
		if isValidDomain(d) {
			t.Errorf("isValidDomain(%q) should be false", d)
		}
	}
}

func TestFilterValid(t *testing.T) {
	input := []string{
		"ValidSite.TEST",
		"*.wildcard.com",
		"192.168.1.1",
		"  valid.test.com  ",
		"",
		"invalid domain",
		"valid1.test.com",
		"valid1.test.com", // duplicate
		"Example.COM",     // guard: dokumentasi/RFC placeholder, dibuang
	}
	got := filterValid(input)
	expected := map[string]bool{
		"validsite.test":  true,
		"wildcard.com":    true,
		"valid.test.com":  true,
		"valid1.test.com": true,
	}
	if len(got) != len(expected) {
		t.Errorf("filterValid returned %d items, want %d: %v", len(got), len(expected), got)
	}
	for _, d := range got {
		if !expected[d] {
			t.Errorf("filterValid returned unexpected domain: %q", d)
		}
	}
}

func TestParseRapidHTML(t *testing.T) {
	html := `<td>sub1.rapidtest.invalid</td>
<td>1.2.3.4</td>
<td>something</td>
<a href="/subdomain/sub1.rapidtest.invalid#result">link</a>
<td>sub2.rapidtest.invalid</td>
<td>_dmarc.rapidtest.invalid</td>
<td>_sip._tcp.rapidtest.invalid</td>`
	got := parseRapidHTML([]byte(html))
	found := map[string]bool{}
	for _, d := range got {
		found[d] = true
	}
	if !found["sub1.rapidtest.invalid"] {
		t.Errorf("parseRapidHTML should find sub1.rapidtest.invalid, got: %v", got)
	}
	if !found["sub2.rapidtest.invalid"] {
		t.Errorf("parseRapidHTML should find sub2.rapidtest.invalid, got: %v", got)
	}
	if !found["_dmarc.rapidtest.invalid"] {
		t.Errorf("parseRapidHTML should find _dmarc.rapidtest.invalid with underscore, got: %v", got)
	}
	if !found["_sip._tcp.rapidtest.invalid"] {
		t.Errorf("parseRapidHTML should find _sip._tcp.rapidtest.invalid with underscore, got: %v", got)
	}
}

func TestParseRapidHTMLIgnoresFooterLinks(t *testing.T) {
	// The results table uses bare <td>subdomain</td> cells; the page's footer
	// "popular domains" navigation (/subdomain/pornhub.com#result etc.) must NOT
	// be treated as results. Verified live 2026-09-20: those links are footer
	// noise, not the target's subdomains.
	html := `<td>real.footertest.invalid</td>
<a href="/subdomain/pornhub.com#result">pornhub.com</a>
<a href="/subdomain/youtube.com#result">youtube.com</a>
<td>another.footertest.invalid</td>`
	got := parseRapidHTML([]byte(html))
	found := map[string]bool{}
	for _, d := range got {
		found[d] = true
	}
	if found["pornhub.com"] {
		t.Errorf("footer link pornhub.com must not be captured, got %v", got)
	}
	if found["youtube.com"] {
		t.Errorf("footer link youtube.com must not be captured, got %v", got)
	}
	if !found["real.footertest.invalid"] || !found["another.footertest.invalid"] {
		t.Errorf("real <td> subdomains must be captured, got %v", got)
	}
}

func TestIsValidDomainRejectsExample(t *testing.T) {
	// guard akurasi: domain dokumentasi/RFC bukan target nyata.
	for _, d := range []string{"example.com", "example.org", "example.net", "a.example.com", "b.example.org", "c.example.net"} {
		if isValidDomain(d) {
			t.Errorf("isValidDomain(%q) should be false (doc placeholder)", d)
		}
	}
}

func TestDownloadPathTraversal(t *testing.T) {
	// Create a test server that acts as the GUI server
	mux := http.NewServeMux()
	mux.HandleFunc("/api/download", func(w http.ResponseWriter, r *http.Request) {
		f := r.URL.Query().Get("f")
		if f == "" {
			http.Error(w, "no file", http.StatusBadRequest)
			return
		}
		_ = f
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	})
	ts := httptest.NewServer(mux)
	defer ts.Close()

	tests := []struct {
		name   string
		path   string
		status int
	}{
		{"absolute_path", "/etc/passwd", 403},
		{"dotdot_traversal", "../../../../etc/passwd", 403},
		{"dotdot_double", "....//....//etc/passwd", 403},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			resp, err := http.Get(ts.URL + "/api/download?f=" + tt.path)
			if err != nil {
				t.Fatal(err)
			}
			defer resp.Body.Close()
			if resp.StatusCode != tt.status {
				t.Errorf("path %q: got status %d, want %d", tt.path, resp.StatusCode, tt.status)
			}
		})
	}
}

func TestAtomicGuiQueueRace(t *testing.T) {
	// Test that guiQueue atomic operations work correctly under concurrent access
	var q atomic.Int32
	done := make(chan bool)
	for i := 0; i < 100; i++ {
		go func(i int) {
			q.Store(int32(i))
			done <- true
		}(i)
	}
	for i := 0; i < 100; i++ {
		<-done
	}
	// final value should be one of 0-99 (last writer wins)
	val := q.Load()
	if val < 0 || val > 99 {
		t.Errorf("atomic.Int32 final value out of range: %d", val)
	}
}

// TestBindLoopbackReportsPortInUse: the GUI (-gui) and the debug HUD (-debug)
// both used to drop the http.ListenAndServe error, so a busy port meant a silent
// exit / a banner pointing at a dead socket. bindLoopback must fail loudly and
// with an actionable message.
func TestBindLoopbackReportsPortInUse(t *testing.T) {
	ln, err := bindLoopback("127.0.0.1:0")
	if err != nil {
		t.Fatalf("first bind failed: %v", err)
	}
	defer ln.Close()
	addr := ln.Addr().String()

	second, err := bindLoopback(addr)
	if err == nil {
		second.Close()
		t.Fatalf("bindLoopback(%s) succeeded while the port was already taken", addr)
	}
	if !strings.Contains(err.Error(), "dipakai proses lain") {
		t.Errorf("port-in-use error is not actionable: %v", err)
	}
	if !isAddrInUse(err) {
		t.Errorf("isAddrInUse missed a real address-in-use error: %v", err)
	}
	if isAddrInUse(nil) {
		t.Error("isAddrInUse(nil) = true, want false")
	}
}
