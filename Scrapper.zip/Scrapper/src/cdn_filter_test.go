package main

import (
	"testing"
)

func TestIsAnycastCDN(t *testing.T) {
	cases := []struct {
		ip   string
		want bool
	}{
		{"104.21.45.10", true},    // Cloudflare
		{"172.67.180.20", true},   // Cloudflare
		{"13.224.50.1", true},     // CloudFront
		{"151.101.65.140", true},  // Fastly
		{"23.45.67.89", true},     // Akamai
		{"103.247.12.45", false},  // Non-CDN Origin IP
		{"193.239.44.82", false},  // Non-CDN Origin IP
		{"127.0.0.1", false},      // Loopback
		{"invalid-ip", false},     // Invalid
	}

	for _, c := range cases {
		got := IsAnycastCDN(c.ip)
		if got != c.want {
			t.Errorf("IsAnycastCDN(%q) = %v; want %v", c.ip, got, c.want)
		}
	}
}

func TestGenerateSmartSubnetNeighbors(t *testing.T) {
	// CDN IP should return nil
	if n := GenerateSmartSubnetNeighbors("104.21.45.10", 6); len(n) != 0 {
		t.Errorf("expected 0 neighbors for CDN IP, got %d", len(n))
	}

	// Origin server IP
	neighbors := GenerateSmartSubnetNeighbors("103.247.12.45", 6)
	if len(neighbors) == 0 {
		t.Fatalf("expected neighbors for valid origin IP, got 0")
	}
	for _, neighbor := range neighbors {
		if neighbor == "103.247.12.45" {
			t.Errorf("neighbor list contains original IP %s", neighbor)
		}
		if IsAnycastCDN(neighbor) {
			t.Errorf("neighbor %s is a CDN IP", neighbor)
		}
	}
}

func BenchmarkIsAnycastCDN(b *testing.B) {
	ip := "104.21.45.10"
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_ = IsAnycastCDN(ip)
	}
}
