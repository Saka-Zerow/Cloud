package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// Task 002 (Session 2) — CLI / output-path validation regression tests.
// Intentionally separate from main_test.go (Session 1's TASK-001 unit tests)
// so the two sessions do not edit the same file. Function names are unique.

func TestSafeOutputPath_RejectsTraversal(t *testing.T) {
	cases := []string{"", "../evil.txt", "../../tmp/x.txt", ".."}
	for _, c := range cases {
		got, err := safeOutputPath(c)
		if err == nil {
			t.Errorf("safeOutputPath(%q) expected error, got %q", c, got)
		}
	}
}

func TestSafeOutputPath_AcceptsValidWithinWorkdir(t *testing.T) {
	rel := "s2_val_test_out.txt"
	got, err := safeOutputPath(rel)
	if err != nil {
		t.Fatalf("safeOutputPath(%q) unexpected error: %v", rel, err)
	}
	if !filepath.IsAbs(got) {
		t.Fatalf("expected absolute path, got %q", got)
	}
	wd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	rel2, err := filepath.Rel(wd, got)
	if err != nil || strings.HasPrefix(rel2, "..") {
		t.Fatalf("resolved %q escapes cwd %q (rel=%q)", got, wd, rel2)
	}
	if err := os.Remove(got); err != nil && !os.IsNotExist(err) {
		t.Fatalf("cleanup failed: %v", err)
	}
}

func TestSafeOutputPath_CreatesMissingParent(t *testing.T) {
	sub := filepath.Join("s2_val_subdir")
	rel := filepath.Join(sub, "nested.txt")
	got, err := safeOutputPath(rel)
	if err != nil {
		t.Fatalf("expected parent dir to be created, got error: %v", err)
	}
	if _, err := os.Stat(filepath.Dir(got)); err != nil {
		t.Fatalf("expected parent dir to exist at %q: %v", filepath.Dir(got), err)
	}
	_ = os.RemoveAll(sub)
}

func TestReadList_TruncatedAtMax(t *testing.T) {
	tmpDir := t.TempDir()
	path := filepath.Join(tmpDir, "big_domains.txt")
	const over = maxInputDomains + 5
	var lines []string
	for i := 0; i < over; i++ {
		lines = append(lines, "host"+itoa(i)+".example.com")
	}
	if err := os.WriteFile(path, []byte(strings.Join(lines, "\n")), 0644); err != nil {
		t.Fatalf("write failed: %v", err)
	}

	got, err := readList(path)
	if err != nil {
		t.Fatalf("readList failed: %v", err)
	}
	if len(got) != maxInputDomains {
		t.Fatalf("expected truncation to %d, got %d", maxInputDomains, len(got))
	}
}

func itoa(i int) string {
	if i == 0 {
		return "0"
	}
	var b []byte
	for i > 0 {
		b = append([]byte{byte('0' + i%10)}, b...)
		i /= 10
	}
	return string(b)
}
