package main

import (
	"context"
	"net"
	"sync/atomic"
	"testing"
)

func TestDualStageIPChannelPipeline(t *testing.T) {
	// Setup test channels
	ch := make(chan node, 100)
	ipCh := make(chan string, 100)
	var ipQLen int64
	var queueLen int64

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	shared := &sharedState{
		ctx:      ctx,
		cancel:   cancel,
		apexDone: make(map[string]bool),
		ipDone:   make(map[string]bool),
	}

	// 1. Simulate Subdomain Worker discovering subdomains and resolving their IPs
	discoveredIPs := []string{"103.247.12.45", "104.21.45.10", "193.239.44.82"}
	for _, ip := range discoveredIPs {
		if net.ParseIP(ip) == nil || IsAnycastCDN(ip) {
			continue // Should skip 104.21.45.10 (Cloudflare)
		}
		shared.mu.Lock()
		seen := shared.ipDone[ip]
		if !seen {
			shared.ipDone[ip] = true
		}
		shared.mu.Unlock()
		if !seen {
			ipCh <- ip
			atomic.AddInt64(&ipQLen, 1)
		}
	}

	// Should have queued exactly 2 non-CDN IPs
	if atomic.LoadInt64(&ipQLen) != 2 {
		t.Fatalf("expected 2 non-CDN IPs in ipCh, got %d", atomic.LoadInt64(&ipQLen))
	}

	// 2. Simulate RapidDNS Same-IP Worker consuming from ipCh and feeding new apex to ch
	consumedIP := <-ipCh
	atomic.AddInt64(&ipQLen, -1)

	if consumedIP != "103.247.12.45" {
		t.Errorf("expected first consumed IP 103.247.12.45, got %s", consumedIP)
	}

	// Simulate RapidDNS finding cross-apex domain on that IP
	sameDoms := []string{"portal.corp.co.id", "api.another-enterprise.com"}
	for _, d := range sameDoms {
		a := apexOf(d)
		if a != "" {
			if _, loaded := shared.apexSeen.LoadOrStore(a, true); !loaded {
				ch <- node{a, true, 0, "rapiddns"}
				atomic.AddInt64(&queueLen, 1)
			}
		}
	}

	if atomic.LoadInt64(&queueLen) != 2 {
		t.Fatalf("expected 2 new apexes queued into ch, got %d", atomic.LoadInt64(&queueLen))
	}

	// 3. Subdomain worker picks up from ch
	node1 := <-ch
	if node1.domain != "corp.co.id" && node1.domain != "another-enterprise.com" {
		t.Errorf("unexpected domain picked up: %s", node1.domain)
	}
}
