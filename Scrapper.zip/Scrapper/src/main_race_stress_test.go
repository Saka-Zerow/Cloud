package main

import (
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"sync"
	"testing"
)

// Concurrency stress tests. They are cheap enough for the normal suite, but
// their real value is under the race detector:
//
//	CGO_ENABLED=1 go test -race -run 'RaceStress' -v
//
// (On Windows this needs a C toolchain; on Linux/macOS it just works.)

// TestRaceStressWorkerPool drives runMass with 16 workers against a mocked
// crt.name so writeLines/shared-state/atomics are hammered concurrently.
func TestRaceStressWorkerPool(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		apex := r.URL.Query().Get("apex")
		if apex == "" {
			// DoH stub (mutation probe): NXDOMAIN.
			_, _ = w.Write([]byte(`{"Status":3,"Answer":[]}`))
			return
		}
		var b strings.Builder
		b.WriteString("[")
		for i := 0; i < 20; i++ {
			// Two-letter labels only: the project's infra filter drops names
			// like "node01"/"srv01", which would starve the pool.
			fmt.Fprintf(&b, `{"sub":"%c%c.%s"},`, 'a'+i/26, 'a'+i%26, apex)
		}
		fmt.Fprintf(&b, `{"sub":"%s"}`, apex)
		b.WriteString("]")
		_, _ = w.Write([]byte(b.String()))
	}))
	defer srv.Close()

	origAPI, origDoH, origNoReverse := crtNameAPI, dohEndpoints, noReverse
	crtNameAPI, noReverse = srv.URL, true
	dohEndpoints = []struct {
		url    string
		accept string
	}{{srv.URL, "application/dns-json"}}
	t.Cleanup(func() {
		crtNameAPI = origAPI
		dohEndpoints = origDoH
		noReverse = origNoReverse
	})

	const outName = "zz_race_stress_out.txt"
	t.Cleanup(func() { _ = os.Remove(outName) })

	// Distinct apexes: seeds sharing one apex collapse to a single fetch.
	seeds := []string{
		"a.racestress1.dev", "b.racestress2.dev", "c.racestress3.dev",
		"d.racestress4.dev", "e.racestress5.dev", "f.racestress6.dev",
		"g.racestress7.dev", "h.racestress8.dev",
	}
	n, err := runMass(seeds, 100, outName, "off", 16, false, "speed", 0)
	if err != nil {
		t.Fatalf("runMass: %v", err)
	}
	t.Logf("16-worker pool produced %d domains", n)
	if n < 40 {
		t.Errorf("only %d domains: pool looks stalled", n)
	}
}

// TestRaceStressRapidScrapers runs the rapiddns subdomain + sameip paths and the
// cap detector from many goroutines against a mocked rapiddns page.
func TestRaceStressRapidScrapers(t *testing.T) {
	rows := make([]string, 0, rapidGuestRowCap)
	for i := 0; i < rapidGuestRowCap; i++ {
		rows = append(rows, fmt.Sprintf("n%c%c.racestress.dev", 'a'+i/26%26, 'a'+i%26))
	}
	page := `<meta name="description" content="Found 3,519 subdomains for racestress.dev on RapidDNS.">` +
		rapiddnsTable(rows, []string{"203.0.113.9", "203.0.113.10"})
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(page))
	}))
	defer srv.Close()
	origBase := rapidBaseURL
	rapidBaseURL = srv.URL
	t.Cleanup(func() { rapidBaseURL = origBase })

	shared := &sharedState{}
	var wg sync.WaitGroup
	for g := 0; g < 24; g++ {
		wg.Add(1)
		go func(g int) {
			defer wg.Done()
			w := &worker{id: g, direct: srv.Client(), client: srv.Client(), shared: shared}
			for i := 0; i < 12; i++ {
				if g%2 == 0 {
					w.fetchRapidWithIPSwitch("racestress.dev")
				} else {
					w.fetchSameIP("203.0.113.9")
				}
				w.setLastAPI("rapiddns")
				_ = w.api()
			}
		}(g)
	}
	wg.Wait()

	harvested := 0
	shared.harvestedIPs.Range(func(_, _ any) bool { harvested++; return true })
	t.Logf("rapid stress: capped=%d total=%d harvested=%d",
		shared.rapidCapped, shared.rapidCappedTotal, harvested)
	if shared.rapidCapped == 0 {
		t.Error("guest-cap detector never fired under concurrency")
	}
	if harvested == 0 {
		t.Error("no IPs harvested under concurrency")
	}
}
