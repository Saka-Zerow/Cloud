package main

import "testing"

func TestBatchSizeFor(t *testing.T) {
	cases := []struct {
		queued, workers, max, want int
	}{
		{500, 50, 20, 10},  // fair share: 50 worker di queue 500 ambil 10 (tidak kelaparan)
		{10000, 4, 20, 20}, // queue besar: ambil cap
		{1, 50, 20, 4},     // queue kecil: floor batch min
		{0, 50, 20, 4},
		{400, 50, 5, 5}, // tetap hormat pada max kustom
	}
	for _, c := range cases {
		if got := batchSizeFor(int64(c.queued), c.workers, c.max); got != c.want {
			t.Errorf("batchSizeFor(%d,%d,%d) = %d, want %d", c.queued, c.workers, c.max, got, c.want)
		}
	}
}

func TestDrainChannels(t *testing.T) {
	ch := make(chan node, 10)
	for i := 0; i < 7; i++ {
		ch <- node{"d" + string(rune('a'+i)), true, 0, "t"}
	}
	got := drainNodes(ch, 20)
	if len(got) != 7 || len(ch) != 0 {
		t.Errorf("drainNodes = %d items, %d left; want 7 and 0", len(got), len(ch))
	}
	ips := make(chan string, 3)
	ips <- "1.1.1.1"
	if got := drainIPs(ips, 20); len(got) != 1 {
		t.Errorf("drainIPs = %d, want 1", len(got))
	}
}

// Slot fan-out harus mengikuti jumlah worker: model lama (global 8) membuat 50
// worker membuang pekerjaannya diam-diam saat slot penuh.
func TestAcquireFallbackSizing(t *testing.T) {
	setFallbackConcurrency(50)
	var held []func()
	for i := 0; i < 50; i++ {
		r, ok := acquireFallback()
		if !ok {
			t.Fatalf("slot %d ditolak padahal kapasitas 50", i)
		}
		held = append(held, r)
	}
	if _, ok := acquireFallback(); ok {
		t.Error("slot ke-51 diterima padahal penuh (harus re-queue, bukan eksekusi)")
	}
	for _, r := range held {
		r()
	}
	if _, ok := acquireFallback(); !ok {
		t.Error("slot kosong ditolak setelah semua dilepas")
	}
	setFallbackConcurrency(8) // kembalikan default
}

// Satu exit IP tidak boleh diklaim dua worker: yang kedua gagal, dan setelah
// dilepas klaim ulang berhasil. Inilah jaminan "jangan ada worker yang IP Tor-nya sama".
func TestExitRegistryUniqueClaim(t *testing.T) {
	exitUniq.reset()
	defer exitUniq.reset()
	if !exitUniq.claim("$FP1", "203.0.113.1", 1) {
		t.Fatal("klaim pertama gagal")
	}
	if exitUniq.claim("$FP1", "203.0.113.99", 2) {
		t.Error("worker 2 mengklaim fingerprint yang sama (tabrakan relay)")
	}
	if exitUniq.claim("$FP2", "203.0.113.1", 2) {
		t.Error("worker 2 mengklaim IP yang sama (tabrakan exit IP)")
	}
	if !exitUniq.claim("$FP3", "203.0.113.3", 2) {
		t.Error("klaim unik worker 2 gagal")
	}
	if n := exitUniq.count(); n != 2 {
		t.Errorf("unique exit count = %d, want 2", n)
	}
	exitUniq.release(1)
	if !exitUniq.claim("$FP1", "203.0.113.1", 2) {
		t.Error("klaim ulang setelah release gagal")
	}
}

// pinExit/releaseExit tidak boleh membocorkan state antar worker.
func TestPinExitRelease(t *testing.T) {
	exitUniq.reset()
	defer exitUniq.reset()
	w := &worker{id: 9}
	w.pinExit("w9_1_2", "$FP9", "198.51.100.9")
	if !w.hasPin() {
		t.Fatal("hasPin = false setelah pinExit")
	}
	if u, fp, ip := w.pinInfo(); u != "w9_1_2" || fp != "$FP9" || ip != "198.51.100.9" {
		t.Errorf("pinInfo = %s/%s/%s", u, fp, ip)
	}
	if key, verified := w.exitKeyFor(); key != "ip:198.51.100.9" || !verified {
		t.Errorf("exitKeyFor = %s verified=%v", key, verified)
	}
	w.releaseExit()
	if w.hasPin() {
		t.Error("hasPin masih true setelah releaseExit")
	}
}
