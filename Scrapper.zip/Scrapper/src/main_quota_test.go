package main

import (
	"errors"
	"testing"
)

// Kompromi quota: pesan "free tier limit reached" harus terdeteksi agar
// run exhaust terbaca sebagai quota, bukan bug loop.
func TestIsQuotaHit(t *testing.T) {
	quota := errors.New("http 200 free tier limit reached: 100 requests per IP per day. Supply an API token for unmetered access.")
	if !isQuotaHit(quota) {
		t.Fatalf("isQuotaHit(quota) = false, want true")
	}
	if isQuotaHit(errors.New("http 429 too many requests")) {
		t.Fatalf("isQuotaHit(429) = true, want false (429 != quota)")
	}
	if isQuotaHit(nil) {
		t.Fatalf("isQuotaHit(nil) = true, want false")
	}
	upper := errors.New("FREE TIER LIMIT REACHED")
	if !isQuotaHit(upper) {
		t.Fatalf("isQuotaHit upper = false, want true (case-insensitive)")
	}
}
