package main

import (
	"encoding/json"
	"io"
	"net/http"
	"os"
	"testing"
	"time"
)

// ---- live test (opt-in: TOR_LIVE=1 + local Tor on 127.0.0.1:9050) ----

// crtNameProbe fetches crt.name through the given client and reports how many
// subdomains came back.
func crtNameProbe(c *http.Client) (subs int, status int, errStr string) {
	req, err := http.NewRequest("GET", crtNameAPI+"?apex=unpad.ac.id&format=json", nil)
	if err != nil {
		return 0, 0, err.Error()
	}
	req.Header.Set("User-Agent", browserUA)
	resp, err := c.Do(req)
	if err != nil {
		return 0, 0, err.Error()
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(io.LimitReader(resp.Body, 4<<20))
	var arr []struct {
		Sub string `json:"sub"`
	}
	_ = json.Unmarshal(body, &arr)
	return len(arr), resp.StatusCode, ""
}

// TestLiveCrtNameThroughTorRotation guards the PRIMARY provider's IP story:
// crt.name must work over pinned circuits (fast path) AND survive an overloaded
// / rate-limited exit by rotating to a fresh circuit.
//
// Measured on this machine (2026-09-20, real Tor):
//   - single attempt per fresh circuit: 4/6 (one 20s timeout, one 429) — Tor's
//     exit pool is finite and some exits are burned, so one attempt is not enough
//   - production getRetry (pinned -> fresh circuit on 429 -> direct): 6/6,
//     1918 subs each, ~3 s per request
//
// The production numbers are what the scraper depends on; the single-attempt
// numbers are logged to document why the retry layer exists.
func TestLiveCrtNameThroughTorRotation(t *testing.T) {
	if os.Getenv("TOR_LIVE") != "1" {
		t.Skip("set TOR_LIVE=1 with local Tor on 127.0.0.1:9050 to run")
	}
	w := liveTorWorker(t)

	// 1. pinned circuit (crt.name's default path)
	n, code, errStr := crtNameProbe(w.client)
	t.Logf("pinned exit=%s crt.name status=%d subs=%d err=%s", torExitIP(w.client), code, n, errStr)
	if code != 200 || n == 0 {
		t.Errorf("pinned crt.name failed: status=%d subs=%d err=%s", code, n, errStr)
	}

	// 2. informational: one attempt per fresh isolated circuit
	seen := map[string]int{}
	oks := 0
	start := time.Now()
	for i := 0; i < 6; i++ {
		c := w.torPickClient()
		seen[torExitIP(c)]++
		n, code, errStr := crtNameProbe(c)
		t.Logf("  single-attempt %d: status=%d subs=%d err=%s", i, code, n, errStr)
		if code == 200 && n > 0 {
			oks++
		}
	}
	t.Logf("single-attempt rotation: %d/6 OK, %d distinct exits in %s (informational)",
		oks, len(seen), time.Since(start).Round(time.Millisecond))
	if len(seen) < 4 {
		t.Errorf("mass IP rotation too weak: only %d distinct exits out of 6", len(seen))
	}

	// 3. PRODUCTION path (what fetchCrt calls): pinned -> fresh circuit -> direct
	prodOK := 0
	prodStart := time.Now()
	for i := 0; i < 6; i++ {
		resp, err := w.getRetry(crtNameAPI + "?apex=unpad.ac.id&format=json")
		if err != nil {
			t.Logf("  production %d: err=%v", i, err)
			continue
		}
		body, _ := io.ReadAll(io.LimitReader(resp.Body, 4<<20))
		code := resp.StatusCode
		resp.Body.Close()
		var arr []struct {
			Sub string `json:"sub"`
		}
		_ = json.Unmarshal(body, &arr)
		t.Logf("  production %d: status=%d subs=%d", i, code, len(arr))
		if code == 200 && len(arr) > 0 {
			prodOK++
		}
	}
	t.Logf("crt.name via PRODUCTION getRetry: %d/6 OK in %s", prodOK, time.Since(prodStart).Round(time.Millisecond))
	if prodOK < 5 {
		t.Errorf("production crt.name path only %d/6 ok - rotation+retry should mask burned exits", prodOK)
	}
}
